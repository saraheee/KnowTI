import { useState, useRef, useCallback } from "react";

const globalStyles = `
  html, body, #root {
    margin: 0;
    padding: 0;
    min-height: 100vh;
    background: #ffffff;
  }
`;

const organisms = [
  {
    id: "human", icon: "🧑", name: "Human", type: "euk",
    tooltip: "Complex multicellular organism",
    desc: "Human cells are eukaryotic: they have a nucleus containing DNA on chromosomes, plus organelles like mitochondria that produce energy.",
    cellColor: "#B5D4F4", nucleusColor: "#378ADD",
  },
  {
    id: "plant", icon: "🌿", name: "Plant", type: "euk",
    tooltip: "Photosynthetic eukaryote",
    desc: "Plant cells are eukaryotic and also contain chloroplasts — organelles that perform photosynthesis to convert sunlight into energy.",
    cellColor: "#C0DD97", nucleusColor: "#639922",
  },
  {
    id: "fungi", icon: "🍄", name: "Fungi", type: "euk",
    tooltip: "Eukaryote: mushrooms, yeasts",
    desc: "Fungi (mushrooms, yeasts, moulds) are eukaryotes. Their cells contain a true nucleus and are neither plants nor animals.",
    cellColor: "#FAC775", nucleusColor: "#BA7517",
  },
  {
    id: "algae", icon: "🌊", name: "Algae", type: "euk",
    tooltip: "Aquatic eukaryote",
    desc: "Algae are eukaryotes. Many are single-celled but still have a cell nucleus. Some, like kelp, are large multicellular organisms.",
    cellColor: "#9FE1CB", nucleusColor: "#0F6E56",
  },
  {
    id: "bacteria", icon: "🦠", name: "Bacteria", type: "pro",
    tooltip: "Prokaryote: no nucleus",
    desc: "Bacteria are prokaryotes — their genetic material floats freely in the cytoplasm in a region called the nucleoid. There is no membrane-bound nucleus.",
    cellColor: "#F5C4B3", nucleusColor: null,
  },
  {
    id: "archaea", icon: "🧂", name: "Archaea", type: "pro",
    tooltip: "Ancient prokaryotic life",
    desc: "Archaea are prokaryotes similar to bacteria in structure but genetically distinct. They thrive in extreme environments and lack a membrane-bound nucleus.",
    cellColor: "#F4C0D1", nucleusColor: null,
  },
];

function shuffle(arr) {
  return [...arr].sort(() => Math.random() - 0.5);
}

function CellDiagram({ org }) {
  const hasNucleus = org.nucleusColor !== null;
  return (
    <svg viewBox="0 0 120 120" width={120} height={120} xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="60" cy="60" rx="50" ry="46" fill={org.cellColor} stroke="#ccc" strokeWidth="1.5" />
      <ellipse cx="60" cy="60" rx="48" ry="44" fill="none" stroke="white" strokeWidth="1" opacity="0.5" />
      {hasNucleus ? (
        <>
          <ellipse cx="60" cy="58" rx="18" ry="15" fill={org.nucleusColor} opacity="0.85" />
          <ellipse cx="60" cy="58" rx="18" ry="15" fill="none" stroke="white" strokeWidth="1" opacity="0.4" />
          <text x="60" y="62" textAnchor="middle" fontSize="8" fill="white" fontFamily="sans-serif">nucleus</text>
        </>
      ) : (
        <>
          <text x="60" y="65" textAnchor="middle" fontSize="8" fill="#993C1D" fontFamily="sans-serif">no nucleus</text>
          <line x1="44" y1="52" x2="76" y2="72" stroke="#D85A30" strokeWidth="1.5" strokeDasharray="3,2" />
        </>
      )}
      {org.id === "plant" && (
        <>
          <rect x="18" y="30" width="8" height="8" rx="1" fill="#3B6D11" opacity="0.7" />
          <rect x="22" y="72" width="8" height="8" rx="1" fill="#3B6D11" opacity="0.7" />
        </>
      )}
    </svg>
  );
}

function Modal({ org, onClose }) {
  if (!org) return null;
  return (
    <div style={{
      position: "fixed", inset: 0, display: "flex", alignItems: "center",
      justifyContent: "center", zIndex: 1000, padding: "2rem",
    }}>
      <div
        onClick={onClose}
        style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.3)" }}
      />
      <div style={{
        position: "relative", background: "#fff", border: "0.5px solid #ddd",
        borderRadius: 12, padding: "1.5rem", maxWidth: 340, width: "100%", zIndex: 1,
      }}>
        <button
          onClick={onClose}
          style={{
            position: "absolute", top: 12, right: 12, background: "none",
            border: "none", cursor: "pointer", fontSize: 20, color: "#888", lineHeight: 1,
          }}
        >✕</button>
        <div style={{ fontSize: 26, marginBottom: 4 }}>{org.icon}</div>
        <div style={{ fontSize: 16, fontWeight: 500, marginBottom: 6 }}>{org.name}</div>
        <div style={{ display: "flex", justifyContent: "center", margin: "1rem 0" }}>
          <CellDiagram org={org} />
        </div>
        <div style={{ fontSize: 13, color: "#666", lineHeight: 1.6 }}>{org.desc}</div>
      </div>
    </div>
  );
}

function OrganismCard({ org, onDragStart, onClick }) {
  const [shake, setShake] = useState(false);
  const [tooltip, setTooltip] = useState(false);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

  return (
    <div
      draggable
      onDragStart={() => onDragStart(org.id)}
      onClick={() => onClick(org)}
      onMouseEnter={(e) => { setTooltip(true); setTooltipPos({ x: e.clientX, y: e.clientY }); }}
      onMouseMove={(e) => setTooltipPos({ x: e.clientX, y: e.clientY })}
      onMouseLeave={() => setTooltip(false)}
      style={{
        border: "0.5px solid #ddd", borderRadius: 8, padding: "10px 14px",
        cursor: "grab", background: "#fff", userSelect: "none",
        display: "flex", flexDirection: "column", alignItems: "center",
        gap: 6, width: 90, fontSize: 13, animation: shake ? "shake 0.35s" : "none",
        transition: "transform 0.15s",
      }}
    >
      <span style={{ fontSize: 28, lineHeight: 1 }}>{org.icon}</span>
      <span style={{ fontWeight: 500, textAlign: "center", fontSize: 12 }}>{org.name}</span>
      {tooltip && (
        <div style={{
          position: "fixed", left: tooltipPos.x + 14, top: tooltipPos.y - 10,
          background: "#fff", border: "0.5px solid #ddd", borderRadius: 8,
          padding: "10px 14px", fontSize: 12, maxWidth: 200,
          pointerEvents: "none", zIndex: 999, boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
        }}>
          <div style={{ fontWeight: 500, marginBottom: 4, fontSize: 13 }}>{org.name}</div>
          <div style={{ color: "#666", lineHeight: 1.5 }}>{org.tooltip}</div>
        </div>
      )}
    </div>
  );
}

function PlacedCard({ org }) {
  return (
    <div style={{
      border: `0.5px solid ${org.type === "euk" ? "#1D9E75" : "#D85A30"}`,
      borderRadius: 8, padding: "8px 12px",
      background: org.type === "euk" ? "#E1F5EE" : "#FAECE7",
      display: "flex", flexDirection: "column", alignItems: "center",
      gap: 4, width: 80, fontSize: 12,
    }}>
      <span style={{ fontSize: 24 }}>{org.icon}</span>
      <span style={{ fontWeight: 500, textAlign: "center" }}>{org.name}</span>
    </div>
  );
}

export default function NucleusSorter() {
  const [tray, setTray] = useState(() => shuffle(organisms));
  const [placed, setPlaced] = useState({ euk: [], pro: [] });
  const [dragOver, setDragOver] = useState(null);
  const [draggingId, setDraggingId] = useState(null);
  const [wrongFlash, setWrongFlash] = useState(null);
  const [modal, setModal] = useState(null);
  const [score, setScore] = useState(0);
  const total = organisms.length;

  const handleDragStart = (id) => setDraggingId(id);

  const handleDrop = (zone) => {
    setDragOver(null);
    if (!draggingId) return;
    const org = organisms.find((o) => o.id === draggingId);
    if (!org) return;
    const alreadyPlaced = placed.euk.find((o) => o.id === org.id) || placed.pro.find((o) => o.id === org.id);
    if (alreadyPlaced) return;

    if (org.type === zone) {
      setPlaced((prev) => ({ ...prev, [zone]: [...prev[zone], org] }));
      setTray((prev) => prev.filter((o) => o.id !== org.id));
      setScore((s) => s + 1);
    } else {
      setWrongFlash(org.id);
      setTimeout(() => setWrongFlash(null), 400);
    }
    setDraggingId(null);
  };

  const reset = () => {
    setTray(shuffle(organisms));
    setPlaced({ euk: [], pro: [] });
    setScore(0);
    setWrongFlash(null);
  };

  return (
    <>
      <style>{globalStyles}</style>
    <div style={{
      minHeight: "100vh",
      background: "#ffffff",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "2rem",
    }}>
    <div style={{ padding: "1rem 0", fontFamily: "system-ui, sans-serif", maxWidth: 680, width: "100%" }}>
      <style>{`
        @keyframes shake { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-6px)} 40%{transform:translateX(6px)} 60%{transform:translateX(-4px)} 80%{transform:translateX(4px)} }
        @keyframes pop { 0%{transform:scale(1)} 50%{transform:scale(1.1)} 100%{transform:scale(1)} }
      `}</style>

      {/* Score + Reset */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "1rem" }}>
        <div>
          <div style={{ fontSize: 11, color: "#999", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 2 }}>Sorted correctly</div>
          <span style={{ fontSize: 18, fontWeight: 500 }}>{score} / {total}</span>
        </div>
        <button
          onClick={reset}
          style={{
            fontSize: 13, padding: "6px 14px", border: "0.5px solid #ddd",
            borderRadius: 8, background: "transparent", color: "#666", cursor: "pointer",
          }}
        >↺ Reset</button>
      </div>

      {/* Tray */}
      <div style={{
        display: "flex", flexWrap: "wrap", gap: 10, justifyContent: "center",
        padding: "1rem", border: "0.5px solid #eee", borderRadius: 12,
        background: "#fafafa", marginBottom: "1.5rem", minHeight: 90,
      }}>
        {tray.length === 0 && score < total && (
          <span style={{ fontSize: 13, color: "#999", alignSelf: "center" }}>All cards placed!</span>
        )}
        {tray.map((org) => (
          <div
            key={org.id}
            style={{ animation: wrongFlash === org.id ? "shake 0.35s" : "none" }}
          >
            <OrganismCard org={org} onDragStart={handleDragStart} onClick={setModal} />
          </div>
        ))}
      </div>

      {/* Drop zones */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: "1.5rem" }}>
        {[
          { zone: "euk", label: "Eukaryotes", sub: "Has a cell nucleus", dotColor: "#1D9E75", borderColor: "#5DCAA5", badgeBg: "#E1F5EE", badgeText: "#0F6E56" },
          { zone: "pro", label: "Prokaryotes", sub: "No cell nucleus", dotColor: "#D85A30", borderColor: "#F0997B", badgeBg: "#FAECE7", badgeText: "#993C1D" },
        ].map(({ zone, label, sub, dotColor, borderColor, badgeBg, badgeText }) => (
          <div
            key={zone}
            onDragOver={(e) => { e.preventDefault(); setDragOver(zone); }}
            onDragLeave={() => setDragOver(null)}
            onDrop={() => handleDrop(zone)}
            style={{
              border: `2px dashed ${borderColor}`,
              borderRadius: 12, padding: "1rem", minHeight: 200,
              background: dragOver === zone ? "#f5f5f5" : "transparent",
              transition: "background 0.2s",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <span style={{ width: 10, height: 10, borderRadius: "50%", background: dotColor, display: "inline-block" }} />
              <span style={{ fontSize: 14, fontWeight: 500 }}>{label}</span>
            </div>
            <div style={{
              display: "inline-flex", alignItems: "center", gap: 4, fontSize: 11,
              borderRadius: 20, padding: "2px 8px", fontWeight: 500,
              background: badgeBg, color: badgeText, marginBottom: 12,
            }}>{sub}</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, minHeight: 80 }}>
              {placed[zone].map((org) => <PlacedCard key={org.id} org={org} />)}
            </div>
          </div>
        ))}
      </div>

      {/* Success banner */}
      {score === total && (
        <div style={{
          textAlign: "center", padding: "1rem", background: "#E1F5EE",
          borderRadius: 8, fontSize: 14, color: "#0F6E56", fontWeight: 500,
        }}>
          All organisms correctly sorted! You understand the key difference between eukaryotes and prokaryotes.
        </div>
      )}

      {/* Modal */}
      <Modal org={modal} onClose={() => setModal(null)} />
    </div>
    </div>
    </>
  );
}