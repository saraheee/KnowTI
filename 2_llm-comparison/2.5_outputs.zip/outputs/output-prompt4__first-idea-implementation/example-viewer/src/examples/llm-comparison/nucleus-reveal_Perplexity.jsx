import React, { useMemo, useState } from "react";

const examples = [
  { name: "Humans", type: "Eukaryote" },
  { name: "Animals", type: "Eukaryote" },
  { name: "Plants", type: "Eukaryote" },
  { name: "Fungi", type: "Eukaryote" },
  { name: "Algae", type: "Eukaryote" },
  { name: "Bacteria", type: "Not eukaryote" },
  { name: "Archaea", type: "Not eukaryote" },
];

function Tag({ label, selected, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        border: "1px solid " + (selected ? "#2563eb" : "#dbe3ef"),
        background: selected ? "#eff6ff" : "#fff",
        color: "#0f172a",
        borderRadius: 999,
        padding: "10px 14px",
        fontSize: 14,
        cursor: "pointer",
        boxShadow: selected ? "0 4px 12px rgba(37,99,235,0.12)" : "none",
      }}
    >
      {label}
    </button>
  );
}

function Cell({ eukaryote, active, setActive }) {
  const nucleusColor = eukaryote ? "#7c3aed" : "#e5e7eb";
  const bodyColor = eukaryote ? "#dbeafe" : "#f3f4f6";
  const borderColor = eukaryote ? "#2563eb" : "#9ca3af";
  const ribosomes = useMemo(
    () => Array.from({ length: eukaryote ? 12 : 5 }, (_, i) => i),
    [eukaryote]
  );

  return (
    <div
      onClick={() => setActive((prev) => (prev === eukaryote ? null : eukaryote))}
      title={eukaryote ? "Cell with nucleus" : "Cell without nucleus"}
      style={{
        position: "relative",
        width: 330,
        height: 330,
        borderRadius: "50%",
        border: `4px solid ${borderColor}`,
        background: `radial-gradient(circle at 50% 45%, ${bodyColor} 0%, #ffffff 65%)`,
        boxShadow:
          active === eukaryote
            ? "0 0 0 8px rgba(37,99,235,0.12)"
            : "0 14px 30px rgba(15,23,42,0.08)",
        cursor: "pointer",
        transition: "all 250ms ease",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 18,
          borderRadius: "50%",
          border: "1px solid rgba(148,163,184,0.35)",
        }}
      />

      {ribosomes.map((i) => {
        const angle = (Math.PI * 2 * i) / ribosomes.length;
        const r = eukaryote ? 108 : 112;
        const x = 165 + Math.cos(angle) * r;
        const y = 165 + Math.sin(angle) * r;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x,
              top: y,
              width: 8,
              height: 8,
              borderRadius: "50%",
              background: eukaryote ? "#60a5fa" : "#d1d5db",
              transform: "translate(-50%,-50%)",
            }}
          />
        );
      })}

      {eukaryote && (
        <div
          style={{
            position: "absolute",
            left: "50%",
            top: "50%",
            width: 128,
            height: 128,
            transform: "translate(-50%,-50%)",
            borderRadius: "50%",
            background: "radial-gradient(circle at 40% 35%, #c4b5fd 0%, #7c3aed 70%)",
            boxShadow: "inset 0 0 0 4px rgba(255,255,255,0.55), 0 0 24px rgba(124,58,237,0.22)",
            transition: "transform 250ms ease",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 28,
              borderRadius: "50%",
              background: "rgba(255,255,255,0.16)",
            }}
          />
          <div
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              width: 18,
              height: 18,
              borderRadius: "50%",
              transform: "translate(-50%,-50%)",
              background: "#fff7ed",
            }}
          />
        </div>
      )}

      {!eukaryote && (
        <div
          style={{
            position: "absolute",
            left: "50%",
            top: "50%",
            transform: "translate(-50%,-50%)",
            color: "#6b7280",
            fontSize: 15,
            fontWeight: 600,
          }}
        >
          No nucleus
        </div>
      )}

      <div
        style={{
          position: "absolute",
          bottom: 18,
          left: "50%",
          transform: "translateX(-50%)",
          fontSize: 14,
          fontWeight: 700,
          color: borderColor,
          letterSpacing: 0.2,
        }}
      >
        {eukaryote ? "With nucleus" : "Without nucleus"}
      </div>
    </div>
  );
}

export default function EukaryoteReveal() {
  const [selected, setSelected] = useState(null);
  const [active, setActive] = useState(true);

  const current = selected ?? active;
  const filtered = examples.filter((e) =>
    current ? e.type === "Eukaryote" : e.type !== "Eukaryote"
  );

  return (
    <div
      style={{
        fontFamily: "Inter, system-ui, sans-serif",
        background: "#fff",
        minHeight: "100vh",
        color: "#0f172a",
      }}
    >
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "28px 24px 36px" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 16,
            marginBottom: 18,
            flexWrap: "wrap",
          }}
        >
          <div>
            <div style={{ fontSize: 28, fontWeight: 800, letterSpacing: -0.4 }}>
              Eukaryotes
            </div>
            <div style={{ fontSize: 14, color: "#64748b", marginTop: 4 }}>
              A cell with a nucleus
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <div
              style={{
                padding: "8px 12px",
                borderRadius: 999,
                background: current ? "#ecfdf5" : "#f8fafc",
                border: "1px solid #dbe3ef",
                fontSize: 13,
                fontWeight: 700,
              }}
            >
              {current ? "State: With nucleus" : "State: Without nucleus"}
            </div>
            <Tag
              label="With nucleus"
              selected={current}
              onClick={() => setSelected(true)}
            />
            <Tag
              label="Without nucleus"
              selected={current === false}
              onClick={() => setSelected(false)}
            />
            <button
              onClick={() => {
                setSelected(null);
                setActive(true);
              }}
              style={{
                border: "none",
                background: "#2563eb",
                color: "#fff",
                borderRadius: 999,
                padding: "10px 14px",
                fontSize: 14,
                cursor: "pointer",
              }}
            >
              Reset
            </button>
          </div>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1.1fr 0.9fr",
            gap: 24,
            alignItems: "center",
          }}
        >
          <div style={{ display: "flex", justifyContent: "center", gap: 24, flexWrap: "wrap" }}>
            <div>
              <Cell eukaryote={false} active={current === false} setActive={setSelected} />
              <div style={{ textAlign: "center", marginTop: 10, fontSize: 13, color: "#64748b" }}>
                Without nucleus
              </div>
            </div>

            <div>
              <Cell eukaryote={true} active={current === true} setActive={setSelected} />
              <div style={{ textAlign: "center", marginTop: 10, fontSize: 13, color: "#64748b" }}>
                With nucleus
              </div>
            </div>
          </div>

          <div
            style={{
              border: "1px solid #e5e7eb",
              borderRadius: 24,
              padding: 20,
              background: "#fafafa",
              minHeight: 360,
            }}
          >
            <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 10 }}>Examples</div>

            <div style={{ display: "flex", flexWrap: "wrap", gap: 10, marginBottom: 16 }}>
              {[true, false].map((v) => (
                <button
                  key={String(v)}
                  onClick={() => setSelected(v)}
                  style={{
                    border: "1px solid " + (current === v ? "#2563eb" : "#dbe3ef"),
                    background: current === v ? "#eff6ff" : "#fff",
                    borderRadius: 999,
                    padding: "8px 12px",
                    cursor: "pointer",
                  }}
                >
                  {v ? "Eukaryotes" : "Not eukaryotes"}
                </button>
              ))}
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(2, minmax(0,1fr))",
                gap: 12,
              }}
            >
              {filtered.map((item) => (
                <div
                  key={item.name}
                  style={{
                    padding: 14,
                    borderRadius: 18,
                    background: "#fff",
                    border: "1px solid #e5e7eb",
                    boxShadow: "0 4px 10px rgba(15,23,42,0.04)",
                  }}
                >
                  <div style={{ fontWeight: 700 }}>{item.name}</div>
                  <div style={{ fontSize: 13, color: "#64748b", marginTop: 3 }}>
                    {item.type}
                  </div>
                </div>
              ))}
            </div>

            <div style={{ marginTop: 16, fontSize: 13, color: "#64748b", lineHeight: 1.5 }}>
              Click a cell to focus on it and filter the examples. The purple nucleus marks the feature that defines eukaryotes.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}