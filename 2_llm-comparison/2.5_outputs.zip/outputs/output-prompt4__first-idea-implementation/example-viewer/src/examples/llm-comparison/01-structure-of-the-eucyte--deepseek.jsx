import React, { useState, useRef, useEffect } from 'react';
import './EukaryoticCell--deepseek.css';

const EukaryoticCellVisualization = () => {
  const [isAnimating, setIsAnimating] = useState(true);
  const [showEukaryotic, setShowEukaryotic] = useState(true);
  const [hoverInfo, setHoverInfo] = useState(null);
  const animationRef = useRef(null);

  const cellStructures = {
    eukaryotic: [
      { id: 'nucleus', name: 'Nucleus', color: '#ff6b6b', x: 50, y: 50, size: 25, description: 'Control center containing DNA' },
      { id: 'mitochondria', name: 'Mitochondria', color: '#4ecdc4', x: 25, y: 30, size: 8, description: 'Powerhouse of the cell' },
      { id: 'er', name: 'Endoplasmic Reticulum', color: '#45b7d1', x: 70, y: 30, size: 12, description: 'Protein synthesis and transport' },
      { id: 'golgi', name: 'Golgi Apparatus', color: '#96ceb4', x: 30, y: 70, size: 10, description: 'Protein modification and packaging' },
      { id: 'lysosomes', name: 'Lysosomes', color: '#feca57', x: 75, y: 75, size: 6, description: 'Cellular digestion' },
      { id: 'ribosomes', name: 'Ribosomes', color: '#ff9ff3', x: 40, y: 60, size: 3, description: 'Protein synthesis' }
    ],
    prokaryotic: [
      { id: 'nucleoid', name: 'Nucleoid', color: '#ff6b6b', x: 50, y: 50, size: 20, description: 'Free-floating DNA region' },
      { id: 'ribosomes', name: 'Ribosomes', color: '#ff9ff3', x: 60, y: 40, size: 3, description: 'Protein synthesis' },
      { id: 'cellWall', name: 'Cell Wall', color: '#54a0ff', x: 50, y: 50, size: 45, description: 'Protective outer layer' }
    ]
  };

  const animateParticles = () => {
    if (!isAnimating || !animationRef.current) return;

    const canvas = animationRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw cell membrane
    ctx.strokeStyle = '#2c3e50';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height / 2, 180, 0, 2 * Math.PI);
    ctx.stroke();

    const structures = showEukaryotic ? cellStructures.eukaryotic : cellStructures.prokaryotic;
    
    // Draw organelles
    structures.forEach(organelle => {
      ctx.fillStyle = organelle.color;
      ctx.beginPath();
      ctx.arc(
        organelle.x * canvas.width / 100,
        organelle.y * canvas.height / 100,
        organelle.size,
        0,
        2 * Math.PI
      );
      ctx.fill();
      
      // Add organelle membrane for nucleus in eukaryotic
      if (showEukaryotic && organelle.id === 'nucleus') {
        ctx.strokeStyle = '#2c3e50';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
    });

    // Animate particles
    const time = Date.now() * 0.001;
    const particleCount = showEukaryotic ? 50 : 30;

    for (let i = 0; i < particleCount; i++) {
      const angle = (i / particleCount) * Math.PI * 2 + time * 0.5;
      const radius = showEukaryotic ? 60 + Math.sin(time + i) * 20 : 80 + Math.sin(time + i) * 40;
      
      const x = canvas.width / 2 + Math.cos(angle) * radius;
      const y = canvas.height / 2 + Math.sin(angle) * radius;

      ctx.fillStyle = showEukaryotic ? '#3498db' : '#e74c3c';
      ctx.beginPath();
      ctx.arc(x, y, 2, 0, 2 * Math.PI);
      ctx.fill();
    }

    requestAnimationFrame(animateParticles);
  };

  useEffect(() => {
    animateParticles();
  }, [isAnimating, showEukaryotic]);

  const handleCanvasClick = (event) => {
    const canvas = animationRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / canvas.width) * 100;
    const y = ((event.clientY - rect.top) / canvas.height) * 100;

    const structures = showEukaryotic ? cellStructures.eukaryotic : cellStructures.prokaryotic;
    
    const clickedOrganelle = structures.find(organelle => {
      const distance = Math.sqrt(
        Math.pow(x - organelle.x, 2) + Math.pow(y - organelle.y, 2)
      );
      return distance < organelle.size;
    });

    setHoverInfo(clickedOrganelle || null);
  };

  const resetSimulation = () => {
    setIsAnimating(true);
    setShowEukaryotic(true);
    setHoverInfo(null);
  };

  return (
    <div className="cell-visualization">
      <div className="controls">
        <button 
          className={`control-btn ${isAnimating ? 'active' : ''}`}
          onClick={() => setIsAnimating(!isAnimating)}
        >
          {isAnimating ? '⏸️ Pause' : '▶️ Play'}
        </button>
        
        <button 
          className={`control-btn toggle ${showEukaryotic ? 'eukaryotic' : 'prokaryotic'}`}
          onClick={() => setShowEukaryotic(!showEukaryotic)}
        >
          {showEukaryotic ? '🦠 Prokaryotic' : '🧬 Eukaryotic'}
        </button>
        
        <button 
          className="control-btn reset"
          onClick={resetSimulation}
        >
          🔄 Reset
        </button>
      </div>

      <div className="visualization-area">
        <canvas
          ref={animationRef}
          width={600}
          height={400}
          onClick={handleCanvasClick}
          className="cell-canvas"
        />
        
        <div className="status-indicator">
          <div className={`status ${showEukaryotic ? 'eukaryotic' : 'prokaryotic'}`}>
            {showEukaryotic ? '🧬 Eukaryotic Cell' : '🦠 Prokaryotic Cell'}
          </div>
          <div className="description">
            {showEukaryotic 
              ? 'Organized structure with membrane-bound nucleus and organelles'
              : 'Simple structure without membrane-bound nucleus'}
          </div>
        </div>

        {hoverInfo && (
          <div 
            className="info-panel"
            style={{
              left: `${hoverInfo.x}%`,
              top: `${hoverInfo.y}%`
            }}
          >
            <h4>{hoverInfo.name}</h4>
            <p>{hoverInfo.description}</p>
          </div>
        )}
      </div>

      <div className="key-features">
        <div className="feature">
          <div className="color-dot eukaryotic"></div>
          <span>Membrane-bound nucleus</span>
        </div>
        <div className="feature">
          <div className="color-dot organelle"></div>
          <span>Specialized organelles</span>
        </div>
        <div className="feature">
          <div className="color-dot particle"></div>
          <span>Cellular processes</span>
        </div>
      </div>
    </div>
  );
};

export default EukaryoticCellVisualization;