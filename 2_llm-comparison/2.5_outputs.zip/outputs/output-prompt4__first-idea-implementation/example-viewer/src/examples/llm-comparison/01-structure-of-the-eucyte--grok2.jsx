import React, { useState, useEffect, useRef } from 'react';

const CellVisualizer = () => {
  const [isEukaryotic, setIsEukaryotic] = useState(true); // true: eukaryotic, false: prokaryotic
  const [isPlaying, setIsPlaying] = useState(false);
  const [animationFrame, setAnimationFrame] = useState(0);
  const animationRef = useRef(null);

  const particleCount = 20;
  const organelleColors = {
    nucleus: '#4CAF50',
    mitochondria: '#2196F3',
    er: '#FFC107',
    ribosomes: '#F44336',
    dna: '#9C27B0',
  };

  useEffect(() => {
    if (isPlaying) {
      const animate = () => {
        setAnimationFrame((prev) => (prev + 1) % 360);
        animationRef.current = requestAnimationFrame(animate);
      };
      animationRef.current = requestAnimationFrame(animate);
    }
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying]);

  const resetSimulation = () => {
    setIsPlaying(false);
    setAnimationFrame(0);
    setIsEukaryotic(true);
  };

  const toggleState = () => {
    setIsEukaryotic(!isEukaryotic);
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const renderParticles = () => {
    return Array.from({ length: particleCount }).map((_, i) => {
      const angle = (animationFrame + i * (360 / particleCount)) % 360;
      const rad = angle * (Math.PI / 180);
      if (isEukaryotic) {
        // Orderly movement within compartments
        const compartment = i % 3; // 0: nucleus, 1: mitochondria, 2: cytoplasm
        let cx, cy, r;
        if (compartment === 0) {
          cx = 250; cy = 250; r = 50;
        } else if (compartment === 1) {
          cx = 350; cy = 300; r = 30;
        } else {
          cx = 200; cy = 350; r = 40;
        }
        const x = cx + Math.cos(rad) * r;
        const y = cy + Math.sin(rad) * r;
        return <circle key={i} cx={x} cy={y} r="3" fill="#FF5722" />;
      } else {
        // Chaotic movement everywhere
        const x = 250 + Math.cos(rad) * 150 + Math.sin(rad * 2) * 50;
        const y = 250 + Math.sin(rad) * 150 + Math.cos(rad * 2) * 50;
        return <circle key={i} cx={x} cy={y} r="3" fill="#795548" />;
      }
    });
  };

  return (
    <div style={{ backgroundColor: 'white', padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2 style={{ textAlign: 'center', color: '#333' }}>Structure of the Eukaryotic Cell</h2>
      <p style={{ textAlign: 'center', color: '#666', fontSize: '14px' }}>
        Interact to see the distinction from prokaryotes and the role of the nucleus.
      </p>
      <svg width="500" height="500" viewBox="0 0 500 500" style={{ display: 'block', margin: '0 auto', border: '1px solid #ddd' }}>
        {/* Cell Membrane */}
        <circle cx="250" cy="250" r="200" fill="none" stroke="#2196F3" strokeWidth="4" />
        
        {isEukaryotic ? (
          <>
            {/* Nucleus */}
            <circle cx="250" cy="250" r="80" fill={organelleColors.nucleus} fillOpacity="0.3" stroke={organelleColors.nucleus} strokeWidth="2">
              <title>The nucleus houses DNA and controls cell activities.</title>
            </circle>
            {/* DNA in nucleus */}
            <path d="M220 220 Q250 250 280 280" stroke={organelleColors.dna} strokeWidth="3" fill="none" />
            <title>DNA organized in the nucleus.</title>
            
            {/* Mitochondria */}
            <ellipse cx="350" cy="300" rx="40" ry="20" fill={organelleColors.mitochondria} fillOpacity="0.3" stroke={organelleColors.mitochondria} strokeWidth="2">
              <title>Mitochondria: Powerhouse of the cell.</title>
            </ellipse>
            
            {/* Endoplasmic Reticulum */}
            <path d="M100 200 Q150 250 100 300 Q150 350 100 400" stroke={organelleColors.er} strokeWidth="5" fill="none" strokeDasharray="5,5">
              <title>Endoplasmic Reticulum: Protein and lipid synthesis.</title>
            </path>
            
            {/* Ribosomes */}
            <circle cx="150" cy="150" r="5" fill={organelleColors.ribosomes} />
            <circle cx="300" cy="200" r="5" fill={organelleColors.ribosomes} />
            <circle cx="200" cy="350" r="5" fill={organelleColors.ribosomes} />
            <title>Ribosomes: Protein synthesis sites.</title>
            
            {/* Clear separation */}
            <rect x="0" y="0" width="500" height="500" fill="none" />
          </>
        ) : (
          <>
            {/* No nucleus, DNA floating */}
            <path d="M100 100 Q200 200 300 100 Q400 200 300 300" stroke={organelleColors.dna} strokeWidth="3" fill="none" strokeDasharray="10,10">
              <title>DNA dispersed in the cytoplasm (nucleoid region).</title>
            </path>
            
            {/* Scattered ribosomes */}
            <circle cx="120" cy="180" r="5" fill={organelleColors.ribosomes} />
            <circle cx="280" cy="220" r="5" fill={organelleColors.ribosomes} />
            <circle cx="350" cy="300" r="5" fill={organelleColors.ribosomes} />
            <circle cx="180" cy="350" r="5" fill={organelleColors.ribosomes} />
            <title>Ribosomes scattered throughout.</title>
            
            {/* No compartments, chaotic */}
            <rect x="0" y="0" width="500" height="500" fill="#FFEBEE" fillOpacity="0.1" />
          </>
        )}
        
        {renderParticles()}
      </svg>
      
      <div style={{ textAlign: 'center', marginTop: '20px' }}>
        <button onClick={togglePlayPause} style={{ margin: '0 10px', padding: '10px 20px', background: isPlaying ? '#F44336' : '#4CAF50', color: 'white', border: 'none', cursor: 'pointer' }}>
          {isPlaying ? 'Pause' : 'Play'}
        </button>
        <button onClick={toggleState} style={{ margin: '0 10px', padding: '10px 20px', background: '#2196F3', color: 'white', border: 'none', cursor: 'pointer' }}>
          Toggle to {isEukaryotic ? 'Prokaryotic' : 'Eukaryotic'}
        </button>
        <button onClick={resetSimulation} style={{ margin: '0 10px', padding: '10px 20px', background: '#FFC107', color: 'white', border: 'none', cursor: 'pointer' }}>
          Reset
        </button>
      </div>
      
      <p style={{ textAlign: 'center', marginTop: '10px', color: '#333' }}>
        Current State: {isEukaryotic ? 'Eukaryotic Cell (Organized with Nucleus)' : 'Prokaryotic Cell (No Nucleus, Chaotic)'}
      </p>
    </div>
  );
};

export default CellVisualizer;