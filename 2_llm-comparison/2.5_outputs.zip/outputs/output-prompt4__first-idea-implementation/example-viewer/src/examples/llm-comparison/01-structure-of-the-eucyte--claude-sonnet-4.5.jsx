import React, { useState, useEffect } from 'react';
import { Zap, Box, Droplet, Package, Activity } from 'lucide-react';

const organelles = [
  {
    id: 'mitochondria',
    name: 'Mitochondria',
    icon: Zap,
    color: '#EF4444',
    position: { x: 70, y: 65 },
    process: 'Energy Production',
    description: 'Converts nutrients into ATP (cellular energy)',
    particleColor: '#FCA5A5'
  },
  {
    id: 'ribosome',
    name: 'Ribosome',
    icon: Box,
    color: '#3B82F6',
    position: { x: 25, y: 40 },
    process: 'Protein Synthesis',
    description: 'Assembles amino acids into proteins',
    particleColor: '#93C5FD'
  },
  {
    id: 'lysosome',
    name: 'Lysosome',
    icon: Droplet,
    color: '#8B5CF6',
    position: { x: 60, y: 25 },
    process: 'Waste Breakdown',
    description: 'Digests and recycles cellular waste',
    particleColor: '#C4B5FD'
  },
  {
    id: 'golgi',
    name: 'Golgi Apparatus',
    icon: Package,
    color: '#10B981',
    position: { x: 30, y: 70 },
    process: 'Packaging & Sorting',
    description: 'Modifies and packages proteins for transport',
    particleColor: '#6EE7B7'
  },
  {
    id: 'nucleus',
    name: 'Nucleus',
    icon: Activity,
    color: '#F59E0B',
    position: { x: 50, y: 50 },
    process: 'Genetic Control',
    description: 'Stores DNA and controls cellular activities by regulating gene expression',
    particleColor: '#FCD34D'
  }
];

const Particle = ({ x, y, color, delay }) => {
  return (
    <div
      className="absolute w-2 h-2 rounded-full animate-pulse"
      style={{
        left: `${x}%`,
        top: `${y}%`,
        backgroundColor: color,
        animationDelay: `${delay}s`,
        boxShadow: `0 0 10px ${color}`
      }}
    />
  );
};

const Organelle = ({ organelle, isActive, onClick, isHovered }) => {
  const Icon = organelle.icon;
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    if (isActive) {
      const newParticles = Array.from({ length: 5 }, (_, i) => ({
        id: `${organelle.id}-${i}-${Date.now()}`,
        x: organelle.position.x + (Math.random() - 0.5) * 15,
        y: organelle.position.y + (Math.random() - 0.5) * 15,
        delay: i * 0.3
      }));
      setParticles(newParticles);
    } else {
      setParticles([]);
    }
  }, [isActive, organelle]);

  return (
    <>
      <div
        className="absolute cursor-pointer transition-all duration-300 group"
        style={{
          left: `${organelle.position.x}%`,
          top: `${organelle.position.y}%`,
          transform: 'translate(-50%, -50%)'
        }}
        onClick={onClick}
      >
        <div
          className={`relative flex items-center justify-center w-16 h-16 rounded-full transition-all duration-300 ${
            isActive ? 'scale-125' : 'scale-100 hover:scale-110'
          }`}
          style={{
            backgroundColor: isActive ? organelle.color : '#F3F4F6',
            border: `3px solid ${organelle.color}`,
            boxShadow: isActive ? `0 0 30px ${organelle.color}` : 'none'
          }}
        >
          <Icon
            size={28}
            strokeWidth={2.5}
            color={isActive ? 'white' : organelle.color}
          />
        </div>

        {isHovered && !isActive && organelle.id !== 'nucleus' && (
          <div
            className="absolute left-1/2 -translate-x-1/2 mt-2 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap z-10"
            style={{
              backgroundColor: organelle.color,
              color: 'white',
              top: '100%',
              boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
            }}
          >
            {organelle.name}
          </div>
        )}
      </div>

      {particles.map((particle) => (
        <Particle
          key={particle.id}
          x={particle.x}
          y={particle.y}
          color={organelle.particleColor}
          delay={particle.delay}
        />
      ))}
    </>
  );
};

export default function CellFactory() {
  const [activeOrganelle, setActiveOrganelle] = useState(null);
  const [hoveredOrganelle, setHoveredOrganelle] = useState(null);
  const [showAll, setShowAll] = useState(false);

  const active = showAll ? organelles[0] : activeOrganelle;

  return (
    <div className="w-full h-screen bg-white flex items-center justify-center p-8">
      <div className="max-w-6xl w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            Cell Compartmentalization
          </h1>
          <p className="text-gray-600 text-lg">
            Click organelles to see specialized processes
          </p>
        </div>

        {/* Main visualization */}
        <div className="flex gap-8 items-center">
          {/* Cell visualization */}
          <div className="flex-1 relative">
            <div
              className="relative mx-auto rounded-full border-4 border-gray-300 overflow-hidden"
              style={{
                width: '500px',
                height: '500px',
                background: showAll
                  ? 'linear-gradient(135deg, #FEE2E2 0%, #DBEAFE 33%, #EDE9FE 66%, #D1FAE5 100%)'
                  : '#FAFAFA'
              }}
            >
              {/* Nucleus */}
              <div
                className="absolute cursor-pointer transition-all duration-300 group"
                style={{
                  width: '120px',
                  height: '120px',
                  left: '50%',
                  top: '50%',
                  transform: 'translate(-50%, -50%)'
                }}
                onClick={() => {
                  setShowAll(false);
                  const nucleus = organelles.find(o => o.id === 'nucleus');
                  setActiveOrganelle(
                    activeOrganelle?.id === 'nucleus' ? null : nucleus
                  );
                }}
                onMouseEnter={() => setHoveredOrganelle('nucleus')}
                onMouseLeave={() => setHoveredOrganelle(null)}
              >
                <div
                  className={`w-full h-full rounded-full border-2 flex items-center justify-center transition-all duration-300 ${
                    activeOrganelle?.id === 'nucleus' ? 'scale-110' : 'hover:scale-105'
                  }`}
                  style={{
                    borderColor: activeOrganelle?.id === 'nucleus' ? '#F59E0B' : '#9CA3AF',
                    backgroundColor: activeOrganelle?.id === 'nucleus' ? '#F59E0B' : '#F3F4F6',
                    boxShadow: activeOrganelle?.id === 'nucleus' ? '0 0 30px #F59E0B' : 'none'
                  }}
                >
                  <Activity
                    size={32}
                    strokeWidth={2.5}
                    color={activeOrganelle?.id === 'nucleus' ? 'white' : '#6B7280'}
                  />
                </div>

                {hoveredOrganelle === 'nucleus' && activeOrganelle?.id !== 'nucleus' && (
                  <div
                    className="absolute left-1/2 -translate-x-1/2 mt-2 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap z-10"
                    style={{
                      backgroundColor: '#F59E0B',
                      color: 'white',
                      top: '100%',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
                    }}
                  >
                    Nucleus
                  </div>
                )}
              </div>

              {/* Nucleus particles when active */}
              {activeOrganelle?.id === 'nucleus' && (
                <>
                  {Array.from({ length: 8 }, (_, i) => (
                    <Particle
                      key={`nucleus-particle-${i}`}
                      x={50 + (Math.random() - 0.5) * 12}
                      y={50 + (Math.random() - 0.5) * 12}
                      color="#FCD34D"
                      delay={i * 0.2}
                    />
                  ))}
                </>
              )}

              {/* Organelles */}
              {organelles.map((organelle) => (
                <div
                  key={organelle.id}
                  onMouseEnter={() => setHoveredOrganelle(organelle.id)}
                  onMouseLeave={() => setHoveredOrganelle(null)}
                >
                  <Organelle
                    organelle={organelle}
                    isActive={showAll || activeOrganelle?.id === organelle.id}
                    onClick={() => {
                      setShowAll(false);
                      setActiveOrganelle(
                        activeOrganelle?.id === organelle.id ? null : organelle
                      );
                    }}
                    isHovered={hoveredOrganelle === organelle.id}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Info panel */}
          <div className="w-80">
            {activeOrganelle && !showAll ? (
              <div
                className="p-6 rounded-2xl transition-all duration-300"
                style={{
                  backgroundColor: `${activeOrganelle.color}15`,
                  border: `2px solid ${activeOrganelle.color}`
                }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: activeOrganelle.color }}
                  >
                    {React.createElement(activeOrganelle.icon, {
                      size: 24,
                      color: 'white',
                      strokeWidth: 2.5
                    })}
                  </div>
                  <h2 className="text-2xl font-bold text-gray-800">
                    {activeOrganelle.name}
                  </h2>
                </div>
                <div className="mb-3">
                  <div
                    className="inline-block px-3 py-1 rounded-full text-sm font-semibold text-white mb-3"
                    style={{ backgroundColor: activeOrganelle.color }}
                  >
                    {activeOrganelle.process}
                  </div>
                </div>
                <p className="text-gray-700 text-base leading-relaxed">
                  {activeOrganelle.description}
                </p>
              </div>
            ) : showAll ? (
              <div className="p-6 rounded-2xl bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-purple-300">
                <div className="flex items-center gap-3 mb-4">
                  <Activity size={32} className="text-purple-600" strokeWidth={2.5} />
                  <h2 className="text-2xl font-bold text-gray-800">
                    All Active
                  </h2>
                </div>
                <p className="text-gray-700 text-base leading-relaxed mb-4">
                  Multiple specialized processes running simultaneously in separate compartments.
                </p>
                <p className="text-gray-700 text-base leading-relaxed font-semibold">
                  This is cellular efficiency! 🚀
                </p>
              </div>
            ) : (
              <div className="p-6 rounded-2xl bg-gray-50 border-2 border-gray-300">
                <h2 className="text-2xl font-bold text-gray-800 mb-3">
                  Explore the Cell
                </h2>
                <p className="text-gray-600 text-base leading-relaxed mb-4">
                  Click on any organelle to see its specialized function and how compartmentalization enables it.
                </p>
                <div className="text-sm text-gray-500 space-y-1">
                  {organelles.map((org) => (
                    <div key={org.id} className="flex items-center gap-2">
                      <div
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: org.color }}
                      />
                      <span>{org.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Toggle button */}
            <button
              onClick={() => {
                setShowAll(!showAll);
                if (!showAll) setActiveOrganelle(null);
              }}
              className="mt-4 w-full py-3 px-6 rounded-xl font-semibold text-white transition-all duration-300 hover:scale-105"
              style={{
                backgroundColor: showAll ? '#6366F1' : '#10B981',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
              }}
            >
              {showAll ? 'Focus on One' : 'Show All Processes'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}