import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

const CellCompartmentalization = () => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isCompartmentalized, setIsCompartmentalized] = useState(true);
  const canvasRef = useRef(null);
  const animationRef = useRef(null);
  const particlesRef = useRef([]);

  // Particle class
  class Particle {
    constructor(type, compartmentalized) {
      this.type = type; // 'A', 'B', 'C'
      this.reset(compartmentalized);
    }

    reset(compartmentalized) {
      if (compartmentalized) {
        // Assign to specific compartment
        if (this.type === 'A') {
          this.x = Math.random() * 180 + 30;
          this.y = Math.random() * 180 + 30;
          this.zone = 'mitochondria';
        } else if (this.type === 'B') {
          this.x = Math.random() * 180 + 250;
          this.y = Math.random() * 180 + 30;
          this.zone = 'er';
        } else {
          this.x = Math.random() * 180 + 470;
          this.y = Math.random() * 180 + 30;
          this.zone = 'golgi';
        }
      } else {
        // Random position anywhere
        this.x = Math.random() * 620 + 30;
        this.y = Math.random() * 380 + 30;
        this.zone = 'cytoplasm';
      }
      
      this.vx = (Math.random() - 0.5) * 2;
      this.vy = (Math.random() - 0.5) * 2;
      this.radius = 6;
      this.reactionProgress = 0;
      this.reacting = false;
    }

    update(compartmentalized, width, height) {
      this.x += this.vx;
      this.y += this.vy;

      if (compartmentalized) {
        // Keep particles in their zones
        let bounds;
        if (this.zone === 'mitochondria') {
          bounds = { minX: 30, maxX: 210, minY: 30, maxY: 210 };
        } else if (this.zone === 'er') {
          bounds = { minX: 250, maxX: 430, minY: 30, maxY: 210 };
        } else {
          bounds = { minX: 470, maxX: 650, minY: 30, maxY: 210 };
        }

        if (this.x < bounds.minX || this.x > bounds.maxX) this.vx *= -1;
        if (this.y < bounds.minY || this.y > bounds.maxY) this.vy *= -1;
        this.x = Math.max(bounds.minX, Math.min(bounds.maxX, this.x));
        this.y = Math.max(bounds.minY, Math.min(bounds.maxY, this.y));
      } else {
        // Bounce off canvas edges
        if (this.x < 30 || this.x > width - 30) this.vx *= -1;
        if (this.y < 30 || this.y > height - 30) this.vy *= -1;
        this.x = Math.max(30, Math.min(width - 30, this.x));
        this.y = Math.max(30, Math.min(height - 30, this.y));
      }

      // Update reaction progress
      if (this.reacting) {
        this.reactionProgress += 0.05;
        if (this.reactionProgress >= 1) {
          this.reacting = false;
          this.reactionProgress = 0;
        }
      }
    }

    draw(ctx) {
      const colors = {
        A: '#ef4444',
        B: '#3b82f6',
        C: '#10b981'
      };

      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fillStyle = colors[this.type];
      
      if (this.reacting) {
        ctx.globalAlpha = 0.3 + 0.7 * (1 - this.reactionProgress);
      }
      
      ctx.fill();
      ctx.globalAlpha = 1;

      // Reaction glow
      if (this.reacting) {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius + 8 * this.reactionProgress, 0, Math.PI * 2);
        ctx.strokeStyle = colors[this.type];
        ctx.lineWidth = 2;
        ctx.globalAlpha = 1 - this.reactionProgress;
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
  }

  // Initialize particles
  useEffect(() => {
    const particles = [];
    const typeCounts = { A: 15, B: 15, C: 15 };
    
    Object.entries(typeCounts).forEach(([type, count]) => {
      for (let i = 0; i < count; i++) {
        particles.push(new Particle(type, isCompartmentalized));
      }
    });
    
    particlesRef.current = particles;
  }, []);

  // Reset particles when toggling compartmentalization
  useEffect(() => {
    particlesRef.current.forEach(p => p.reset(isCompartmentalized));
  }, [isCompartmentalized]);

  // Animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    let reactionTimer = 0;

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);

      if (isCompartmentalized) {
        // Draw compartments
        const compartments = [
          { x: 30, y: 30, w: 180, h: 180, color: '#fee2e2', label: 'Mitochondria', reaction: 'Energy Production' },
          { x: 250, y: 30, w: 180, h: 180, color: '#dbeafe', label: 'Endoplasmic Reticulum', reaction: 'Protein Synthesis' },
          { x: 470, y: 30, w: 180, h: 180, color: '#d1fae5', label: 'Golgi Apparatus', reaction: 'Protein Processing' }
        ];

        compartments.forEach(comp => {
          ctx.fillStyle = comp.color;
          ctx.fillRect(comp.x, comp.y, comp.w, comp.h);
          
          ctx.strokeStyle = comp.color === '#fee2e2' ? '#ef4444' : 
                           comp.color === '#dbeafe' ? '#3b82f6' : '#10b981';
          ctx.lineWidth = 2;
          ctx.strokeRect(comp.x, comp.y, comp.w, comp.h);

          // Label
          ctx.fillStyle = '#1f2937';
          ctx.font = 'bold 14px sans-serif';
          ctx.fillText(comp.label, comp.x + 10, comp.y + 20);
          
          ctx.font = '11px sans-serif';
          ctx.fillStyle = '#6b7280';
          ctx.fillText(comp.reaction, comp.x + 10, comp.y + 38);
        });
      } else {
        // Draw cytoplasm background
        ctx.fillStyle = '#f9fafb';
        ctx.fillRect(30, 30, 620, 380);
        ctx.strokeStyle = '#d1d5db';
        ctx.lineWidth = 2;
        ctx.strokeRect(30, 30, 620, 380);

        // Chaos indicator
        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText('Mixed Reactions - Interference', 40, 60);
      }

      // Trigger reactions periodically
      if (isPlaying) {
        reactionTimer++;
        if (reactionTimer > 60) {
          const sameZone = particlesRef.current.filter(p => {
            if (isCompartmentalized) {
              return p.zone === 'mitochondria';
            }
            return true;
          });
          
          if (sameZone.length >= 2) {
            const p1 = sameZone[Math.floor(Math.random() * sameZone.length)];
            const p2 = sameZone[Math.floor(Math.random() * sameZone.length)];
            
            if (p1 !== p2 && !p1.reacting && !p2.reacting) {
              const dist = Math.hypot(p1.x - p2.x, p1.y - p2.y);
              if (dist < 50) {
                p1.reacting = true;
                p2.reacting = true;
              }
            }
          }
          
          reactionTimer = 0;
        }
      }

      // Update and draw particles
      particlesRef.current.forEach(particle => {
        if (isPlaying) {
          particle.update(isCompartmentalized, width, height);
        }
        particle.draw(ctx);
      });

      // Draw reaction counter
      const reacting = particlesRef.current.filter(p => p.reacting).length;
      ctx.fillStyle = '#1f2937';
      ctx.font = 'bold 14px sans-serif';
      ctx.fillText(`Active Reactions: ${reacting}`, 30, height - 20);

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, isCompartmentalized]);

  const handleReset = () => {
    particlesRef.current.forEach(p => p.reset(isCompartmentalized));
  };

  return (
    <div className="w-full h-screen flex flex-col items-center justify-center bg-white p-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 text-center">
          Cell Compartmentalization
        </h1>
        <p className="text-gray-600 text-center">
          {isCompartmentalized 
            ? 'Organized compartments enable simultaneous specialized reactions'
            : 'Without compartments, reactions interfere with each other'}
        </p>
      </div>

      <canvas
        ref={canvasRef}
        width={680}
        height={440}
        className="border-2 border-gray-300 rounded-lg shadow-lg mb-6"
      />

      <div className="flex gap-4 items-center">
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          {isPlaying ? <Pause size={20} /> : <Play size={20} />}
          {isPlaying ? 'Pause' : 'Play'}
        </button>

        <button
          onClick={() => setIsCompartmentalized(!isCompartmentalized)}
          className={`px-6 py-3 rounded-lg font-medium transition-colors ${
            isCompartmentalized
              ? 'bg-green-600 text-white hover:bg-green-700'
              : 'bg-red-600 text-white hover:bg-red-700'
          }`}
        >
          {isCompartmentalized ? 'With Compartments' : 'Without Compartments'}
        </button>

        <button
          onClick={handleReset}
          className="flex items-center gap-2 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-medium"
        >
          <RotateCcw size={20} />
          Reset
        </button>
      </div>

      <div className="mt-6 flex gap-8 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-red-500"></div>
          <span className="text-gray-700">Type A Molecules</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-blue-500"></div>
          <span className="text-gray-700">Type B Molecules</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-green-500"></div>
          <span className="text-gray-700">Type C Molecules</span>
        </div>
      </div>
    </div>
  );
};

export default CellCompartmentalization;