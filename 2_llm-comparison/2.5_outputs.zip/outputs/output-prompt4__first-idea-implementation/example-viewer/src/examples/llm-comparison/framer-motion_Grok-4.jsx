'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function EukaryotesDefinitionVisualizer() {
  const [showEukaryote, setShowEukaryote] = useState(true);
  const [isAnimating, setIsAnimating] = useState(false);
  const [selectedExample, setSelectedExample] = useState(null);

  const examples = [
    { name: "Human", icon: "🧍‍♂️", type: "eukaryote" },
    { name: "Plant", icon: "🌿", type: "eukaryote" },
    { name: "Fungi", icon: "🍄", type: "eukaryote" },
    { name: "Algae", icon: "🌱", type: "eukaryote" },
    { name: "Bacteria", icon: "🦠", type: "prokaryote" },
  ];

  return (
    <div className="min-h-screen bg-white py-12 px-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-3">
            What are Eukaryotes?
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Organisms that possess a cell nucleus
          </p>
        </div>

        {/* Controls */}
        <div className="flex justify-center gap-4 mb-10">
          <button
            onClick={() => setShowEukaryote(!showEukaryote)}
            className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-semibold flex items-center gap-3 transition"
          >
            {showEukaryote ? "Show Prokaryote" : "Show Eukaryote"}
          </button>

          <button
            onClick={() => setIsAnimating(!isAnimating)}
            className="px-8 py-4 bg-gray-900 hover:bg-black text-white rounded-2xl font-semibold flex items-center gap-3 transition"
          >
            {isAnimating ? "⏸ Pause" : "▶ Play Animation"}
          </button>

          <button
            onClick={() => { 
              setShowEukaryote(true); 
              setIsAnimating(false); 
            }}
            className="px-8 py-4 border-2 border-gray-300 hover:bg-gray-100 rounded-2xl font-semibold transition"
          >
            Reset
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Prokaryote Side */}
          <motion.div
            className={`rounded-3xl p-10 border-4 transition-all duration-700 ${
              showEukaryote 
                ? 'border-gray-200 bg-gray-50' 
                : 'border-red-400 bg-red-50 shadow-xl'
            }`}
          >
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-red-700">Prokaryote</h2>
              <p className="text-red-600 mt-1">No Cell Nucleus</p>
            </div>

            <div className="relative h-96 flex items-center justify-center">
              <motion.div
                className="w-72 h-72 rounded-full border-8 border-red-400 relative"
                animate={{ backgroundColor: showEukaryote ? '#f3f4f6' : '#fee2e2' }}
              >
                <AnimatePresence>
                  {Array.from({ length: 14 }).map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-4 h-4 bg-red-500 rounded-full"
                      initial={{ x: 0, y: 0 }}
                      animate={{
                        x: isAnimating && !showEukaryote ? Math.random() * 180 - 90 : 0,
                        y: isAnimating && !showEukaryote ? Math.random() * 180 - 90 : 0,
                      }}
                      transition={{ duration: 1.8, repeat: Infinity }}
                    />
                  ))}
                </AnimatePresence>
                <div className="absolute inset-0 flex items-center justify-center text-8xl opacity-40">
                  🦠
                </div>
              </motion.div>
            </div>

            <p className="text-center text-gray-600 mt-8 text-sm">
              Simple cell • DNA floats freely in cytoplasm
            </p>
          </motion.div>

          {/* Eukaryote Side */}
          <motion.div
            className={`rounded-3xl p-10 border-4 transition-all duration-700 ${
              showEukaryote 
                ? 'border-blue-500 bg-blue-50 shadow-xl' 
                : 'border-gray-200 bg-gray-50'
            }`}
          >
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-blue-700">Eukaryote (Eukaryont)</h2>
              <p className="text-blue-600 mt-1">Has a Cell Nucleus</p>
            </div>

            <div className="relative h-96 flex items-center justify-center">
              <motion.div
                className="w-80 h-80 rounded-full border-8 border-blue-600 relative bg-blue-50"
                animate={{ backgroundColor: showEukaryote ? '#dbeafe' : '#f3f4f6' }}
              >
                {/* Nucleus */}
                <motion.div
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-44 h-44 rounded-full bg-white border-8 border-blue-700 flex items-center justify-center shadow-2xl"
                  animate={{
                    scale: showEukaryote ? [1, 1.08, 1] : 0.75,
                  }}
                  transition={{ duration: 4, repeat: Infinity }}
                >
                  <span className="text-6xl">🧬</span>
                  {showEukaryote && (
                    <motion.div
                      className="absolute inset-2 border-2 border-blue-400 rounded-full"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                    />
                  )}
                </motion.div>
              </motion.div>
            </div>

            <p className="text-center text-gray-600 mt-8 text-sm">
              Complex cell • DNA protected inside nucleus
            </p>
          </motion.div>
        </div>

        {/* Examples Section */}
        <div className="mt-16">
          <h3 className="text-center text-2xl font-semibold text-gray-800 mb-8">
            Examples of Eukaryotes
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6">
            {examples.map((item) => (
              <motion.div
                key={item.name}
                whileHover={{ scale: 1.08 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedExample(item.name)}
                className={`cursor-pointer rounded-2xl p-6 text-center border-2 transition-all ${
                  item.type === 'eukaryote'
                    ? 'border-blue-500 hover:bg-blue-50'
                    : 'border-red-400 hover:bg-red-50'
                }`}
              >
                <div className="text-6xl mb-4">{item.icon}</div>
                <p className="font-semibold">{item.name}</p>
                <p className={`text-xs mt-1 ${item.type === 'eukaryote' ? 'text-blue-600' : 'text-red-600'}`}>
                  {item.type === 'eukaryote' ? 'Eukaryote' : 'Prokaryote'}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedExample && (
          <div 
            className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4" 
            onClick={() => setSelectedExample(null)}
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="bg-white rounded-3xl max-w-lg w-full p-10 text-center"
              onClick={e => e.stopPropagation()}
            >
              <div className="text-8xl mb-6">
                {examples.find(e => e.name === selectedExample)?.icon}
              </div>
              <h3 className="text-4xl font-bold mb-4">{selectedExample}</h3>
              <p className="text-gray-600 text-lg leading-relaxed">
                {selectedExample === "Bacteria"
                  ? "Prokaryote: Does not have a cell nucleus. Its genetic material floats freely in the cell."
                  : "Eukaryote (also called Eukaryont): Possesses a true cell nucleus that contains its genetic material."}
              </p>
              <button
                onClick={() => setSelectedExample(null)}
                className="mt-10 px-10 py-3.5 bg-gray-900 text-white rounded-2xl hover:bg-black transition"
              >
                Close
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}