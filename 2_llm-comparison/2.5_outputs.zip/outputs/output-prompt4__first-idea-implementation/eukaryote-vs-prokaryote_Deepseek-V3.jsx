import React, { useState, useEffect, useRef, useCallback } from 'react';

const EukaryoteVsProkaryote = () => {
  // State management
  const [animationActive, setAnimationActive] = useState(true);
  const [highlightNucleus, setHighlightNucleus] = useState(false);
  const [showEukInfo, setShowEukInfo] = useState(false);
  const [showProInfo, setShowProInfo] = useState(false);
  const [resetKey, setResetKey] = useState(0);
  
  // Refs for particle containers
  const eukParticlesRef = useRef(null);
  const proParticlesRef = useRef(null);
  const animationFrameRef = useRef(null);
  const particlesRef = useRef({ euk: [], pro: [] });

  // Helper: create particles dynamically inside a container
  const createParticles = useCallback((container, count, isEukaryote) => {
    if (!container) return [];
    const existing = container.querySelectorAll('.particle');
    existing.forEach(p => p.remove());
    const particles = [];
    for (let i = 0; i < count; i++) {
      const div = document.createElement('div');
      div.className = `particle ${!isEukaryote ? 'pro-particle' : ''}`;
      const top = 20 + Math.random() * 60;
      const left = 20 + Math.random() * 60;
      div.style.top = `${top}%`;
      div.style.left = `${left}%`;
      div.style.position = 'absolute';
      div.style.width = '8px';
      div.style.height = '8px';
      div.style.borderRadius = '50%';
      div.style.pointerEvents = 'none';
      div.style.background = isEukaryote ? '#3b82f6' : '#94a3b8';
      div.style.opacity = '0.8';
      if (animationActive) {
        div.style.animation = isEukaryote 
          ? 'floatMove 2s infinite alternate ease-in-out'
          : 'chaoticMove 1.6s infinite alternate ease';
      } else {
        div.style.animation = 'none';
      }
      container.appendChild(div);
      particles.push(div);
    }
    return particles;
  }, [animationActive]);

  // Refresh particles on animation toggle or reset
  const refreshParticles = useCallback(() => {
    if (eukParticlesRef.current) {
      particlesRef.current.euk = createParticles(eukParticlesRef.current, 14, true);
    }
    if (proParticlesRef.current) {
      particlesRef.current.pro = createParticles(proParticlesRef.current, 12, false);
    }
  }, [createParticles]);

  // Update particle animations when animationActive changes
  useEffect(() => {
    const updateParticleAnimations = () => {
      const eukParts = eukParticlesRef.current?.querySelectorAll('.particle') || [];
      const proParts = proParticlesRef.current?.querySelectorAll('.particle') || [];
      eukParts.forEach(p => {
        if (animationActive) p.style.animation = 'floatMove 2s infinite alternate ease-in-out';
        else p.style.animation = 'none';
      });
      proParts.forEach(p => {
        if (animationActive) p.style.animation = 'chaoticMove 1.6s infinite alternate ease';
        else p.style.animation = 'none';
      });
    };
    updateParticleAnimations();
  }, [animationActive]);

  // Initialize particles on mount and after reset
  useEffect(() => {
    refreshParticles();
  }, [refreshParticles, resetKey]);

  const handleReset = () => {
    setAnimationActive(true);
    setHighlightNucleus(false);
    setShowEukInfo(false);
    setShowProInfo(false);
    setResetKey(prev => prev + 1);
  };

  // Drag and drop logic
  const handleDragStart = (e) => {
    e.dataTransfer.setData('text/plain', 'nucleus');
    e.dataTransfer.effectAllowed = 'copy';
  };

  const handleDragOver = (e) => e.preventDefault();

  const handleDropOnPro = (e) => {
    e.preventDefault();
    const data = e.dataTransfer.getData('text/plain');
    if (data === 'nucleus') {
      alert('❌ Prokaryotes do NOT have a nucleus! DNA remains in nucleoid region. This shows why compartmentalization is unique to eukaryotes.');
    }
  };

  const handleDropOnEuk = (e) => {
    e.preventDefault();
    const data = e.dataTransfer.getData('text/plain');
    if (data === 'nucleus') {
      setHighlightNucleus(true);
      alert('✓ Nucleus already present! Highlighting it for you.');
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto p-6 bg-white rounded-2xl shadow-lg font-sans" key={resetKey}>
      <h2 className="text-2xl font-bold text-center text-gray-800 mb-2">Eukaryote vs Prokaryote</h2>
      <p className="text-center text-gray-500 mb-6">Do they have a nucleus? → Compartmentalization matters</p>

      {/* Controls */}
      <div className="flex flex-wrap justify-center gap-4 mb-8">
        <button
          onClick={() => setAnimationActive(!animationActive)}
          className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition flex items-center gap-2"
        >
          {animationActive ? '⏸️ Pause Animation' : '▶️ Play Animation'}
        </button>
        <button
          onClick={() => setHighlightNucleus(!highlightNucleus)}
          className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition"
        >
          🔆 Toggle Highlight (Nucleus)
        </button>
        <button
          onClick={handleReset}
          className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition"
        >
          🔄 Reset
        </button>
      </div>

      {/* Status Indicator */}
      <div className="flex justify-center mb-6">
        <div className="inline-flex items-center gap-2 px-4 py-1 bg-gray-100 rounded-full">
          <span className={`w-3 h-3 rounded-full ${animationActive ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></span>
          <span className="text-sm text-gray-600">{animationActive ? 'Animation active' : 'Animation paused'}</span>
        </div>
      </div>

      {/* Two Columns */}
      <div className="grid md:grid-cols-2 gap-8">
        {/* Eukaryote Column */}
        <div
          className="relative bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-4 shadow-md border-2 border-blue-200 transition-all hover:shadow-xl cursor-pointer"
          onClick={() => setShowEukInfo(!showEukInfo)}
          onDragOver={handleDragOver}
          onDrop={handleDropOnEuk}
        >
          <div className="text-center mb-2">
            <h3 className="text-xl font-semibold text-blue-800">Eukaryote (Eukaryont)</h3>
            <span className="inline-block text-xs bg-blue-100 px-2 py-1 rounded-full mt-1">✅ Contains nucleus</span>
          </div>
          <div className="relative w-64 h-64 mx-auto bg-blue-100 rounded-full border-4 border-blue-300">
            <div className="absolute inset-0 rounded-full bg-blue-50 opacity-30"></div>
            {/* Nucleus */}
            <div
              className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full bg-purple-500 flex items-center justify-center transition-all duration-500 shadow-lg ${
                highlightNucleus ? 'ring-4 ring-yellow-400 scale-110' : ''
              }`}
              title="Contains DNA (chromosomes) | Command center of eukaryotic cell"
            >
              <span className="text-white text-xs font-bold">NUCLEUS</span>
            </div>
            {/* Particle container */}
            <div ref={eukParticlesRef} className="absolute inset-0 overflow-hidden rounded-full"></div>
          </div>
          {showEukInfo && (
            <div className="mt-3 p-2 bg-white rounded-lg shadow-inner text-sm text-gray-700">
              ✅ Possess a cell nucleus<br />
              ✅ Called eukaryonts<br />
              ✅ DNA enclosed within nuclear membrane<br />
              ✅ Complex organelles via compartmentalization
            </div>
          )}
          <p className="text-center text-xs text-gray-500 mt-2">Click for details | Hover nucleus for tooltip</p>
        </div>

        {/* Prokaryote Column */}
        <div
          className="relative bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-4 shadow-md border-2 border-gray-300 transition-all hover:shadow-xl cursor-pointer"
          onClick={() => setShowProInfo(!showProInfo)}
          onDragOver={handleDragOver}
          onDrop={handleDropOnPro}
        >
          <div className="text-center mb-2">
            <h3 className="text-xl font-semibold text-gray-700">Prokaryote</h3>
            <span className="inline-block text-xs bg-gray-300 px-2 py-1 rounded-full mt-1">❌ No nucleus</span>
          </div>
          <div className="relative w-64 h-64 mx-auto bg-gray-200 rounded-full border-4 border-gray-400">
            {/* Nucleoid region */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full bg-gray-300 opacity-60"></div>
            <div className="absolute top-1/3 left-1/3 w-12 h-1 bg-green-700 rounded rotate-12"></div>
            <div className="absolute bottom-1/3 right-1/4 w-10 h-1 bg-green-700 rounded -rotate-45"></div>
            <div className="absolute top-2/3 left-2/4 w-14 h-1 bg-green-700 rounded rotate-75"></div>
            <span className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-[10px] bg-gray-500 text-white px-1 rounded">DNA (nucleoid)</span>
            {/* Particle container */}
            <div ref={proParticlesRef} className="absolute inset-0 overflow-hidden rounded-full"></div>
          </div>
          {showProInfo && (
            <div className="mt-3 p-2 bg-white rounded-lg shadow-inner text-sm text-gray-700">
              ❌ No true nucleus<br />
              ❌ DNA in nucleoid region (free floating)<br />
              ❌ Lacks membrane-bound organelles<br />
              ❌ Bacteria & Archaea
            </div>
          )}
          <p className="text-center text-xs text-gray-500 mt-2">Click for details | Hover DNA for tooltip</p>
        </div>
      </div>

      {/* Draggable Nucleus Badge */}
      <div
        draggable
        onDragStart={handleDragStart}
        className="fixed bottom-5 right-5 bg-white border border-gray-300 rounded-full px-3 py-2 shadow-md text-sm cursor-grab flex items-center gap-2 z-10 hover:bg-gray-50"
      >
        🧫 Drag "Nucleus"
      </div>

      {/* Key takeaway */}
      <div className="mt-8 p-4 bg-indigo-50 rounded-xl text-center">
        <p className="text-gray-800">
          <strong>✔ Eukaryotes</strong> have a <strong>membrane-bound nucleus</strong> → organized DNA → complex gene regulation.
        </p>
        <p className="text-gray-600 text-sm mt-1">Toggle <strong>Highlight</strong> to see nucleus clearly. Animated particles represent molecular activity.</p>
      </div>

      {/* CSS Animations */}
      <style jsx>{`
        @keyframes floatMove {
          0% { transform: translate(0, 0); opacity: 0.4; }
          100% { transform: translate(15px, -15px); opacity: 1; }
        }
        @keyframes chaoticMove {
          0% { transform: translate(0, 0) rotate(0deg); opacity: 0.3; }
          100% { transform: translate(20px, 10px) rotate(90deg); opacity: 0.9; }
        }
      `}</style>
    </div>
  );
};

export default EukaryoteVsProkaryote;