import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RefreshCw, Layers, ShieldAlert, CheckCircle, Info, HelpCircle } from 'lucide-react';

export default function EukaryoteBlueprint() {
  const [isEukaryote, setIsEukaryote] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [hoveredElement, setHoveredElement] = useState(null);
  const [clickDetails, setClickDetails] = useState(null);
  const canvasRef = useRef(null);

  // Biological Information Data Map
  const elementInfo = {
    nucleus: {
      title: "True Cell Nucleus",
      desc: "The absolute defining taxonomic criteria of a Eukaryote. A membrane-bound vault that completely isolates genomic DNA from the rest of the cytoplasm.",
      significance: "Protects transcription and allows complex gene regulation, paving the way for multicellular life."
    },
    dna: {
      title: "Genetic Material (DNA)",
      desc: "In Eukaryotes, DNA is highly organized into linear chromosomes protected inside a nucleus. In Prokaryotes, it floats completely free as a chaotic, naked nucleoid string.",
      significance: "Organized chromosomes prevent replication errors in large, complex genomes."
    },
    organelles: {
      title: "Compartmentalized Organelles",
      desc: "Internal reaction spaces (Mitochondria, Rough ER) bound by membranes. They operate like dedicated rooms in a factory.",
      significance: "Allows incompatible chemical processes to occur simultaneously without interfering with each other."
    },
    cytoplasm: {
      title: "Cytoplasm / Metabolic Space",
      desc: "The fluid filling the cell. In prokaryotes, all transcription, translation, and metabolic reactions blend together here natively.",
      significance: "Without boundaries, metabolic efficiency drops as cellular scale increases."
    }
  };

  // Particle Simulation Engine
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animationFrameId;

    // Adjust for crisp retina rendering
    const dpr = window.devicePixelRatio || 1;
    canvas.width = 540 * dpr;
    canvas.height = 400 * dpr;
    ctx.scale(dpr, dpr);

    const width = 540;
    const height = 400;
    const centerX = width / 2;
    const centerY = height / 2;
    const nucleusRadius = 75;

    // Generate random DNA-like and Metabolic background particles
    const particleCount = 45;
    const particles = [];
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 1.5,
        vy: (Math.random() - 0.5) * 1.5,
        radius: Math.random() * 3 + 2,
        type: i % 3 === 0 ? 'dna' : i % 3 === 1 ? 'enzyme' : 'atp',
        angle: Math.random() * Math.PI * 2,
        speed: Math.random() * 0.02 + 0.01
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // 1. Draw Outer Cell Plasma Membrane Boundary
      ctx.beginPath();
      ctx.arc(centerX, centerY, 175, 0, Math.PI * 2);
      ctx.fillStyle = isEukaryote ? '#F8FAFC' : '#FFFDF5';
      ctx.fill();
      ctx.strokeStyle = isEukaryote ? '#CBD5E1' : '#F59E0B';
      ctx.lineWidth = 3;
      ctx.stroke();

      // 2. Draw Nuclear Membrane Envelope (Only in Eukaryote State)
      if (isEukaryote) {
        ctx.save();
        // Outer glowing boundary ring
        ctx.shadowColor = '#3B82F6';
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.arc(centerX, centerY, nucleusRadius, 0, Math.PI * 2);
        ctx.fillStyle = '#EFF6FF';
        ctx.fill();
        ctx.strokeStyle = '#3B82F6';
        ctx.lineWidth = 4;
        ctx.setLineDash([8, 4]); // Stylized nuclear pores
        ctx.stroke();
        ctx.restore();

        // Label Area for Interaction Tracking
        ctx.fillStyle = '#2563EB';
        ctx.font = 'bold 10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText("NUCLEUS", centerX, centerY - nucleusRadius - 8);
      }

      // 3. Process and Draw Moving Particles
      particles.forEach(p => {
        if (isPlaying) {
          if (isEukaryote) {
            if (p.type === 'dna') {
              // EUKARYOTE: Force all DNA particles to gather safely inside the central nucleus
              const dx = centerX - p.x;
              const dy = centerY - p.y;
              const dist = Math.sqrt(dx * dx + dy * dy);
              const maxRange = nucleusRadius - 12;

              if (dist > maxRange) {
                p.x += dx * 0.05;
                p.y += dy * 0.05;
              } else {
                // Gentle orbital motion inside the nuclear membrane
                p.angle += p.speed;
                p.x = centerX + Math.cos(p.angle) * (maxRange * (0.3 + (p.radius / 6)));
                p.y = centerY + Math.sin(p.angle) * (maxRange * (0.3 + (p.radius / 6)));
              }
            } else {
              // EUKARYOTE: Keep enzymes and metabolic particles outside in the cytoplasm
              p.x += p.vx;
              p.y += p.vy;

              const dx = centerX - p.x;
              const dy = centerY - p.y;
              const dist = Math.sqrt(dx * dx + dy * dy);

              // Bounce off the outer membrane
              if (dist > 165) {
                p.vx *= -1;
                p.vy *= -1;
                p.x += p.vx * 2;
                p.y += p.vy * 2;
              }
              // Bounce away from the inner nuclear envelope
              if (dist < nucleusRadius + 6) {
                const angle = Math.atan2(dy, dx);
                p.vx = -Math.cos(angle) * 1.2;
                p.vy = -Math.sin(angle) * 1.2;
                p.x += p.vx * 2;
                p.y += p.vy * 2;
              }
            }
          } else {
            // PROKARYOTE: Everything wanders around chaotically throughout the whole cell space
            p.x += p.vx;
            p.y += p.vy;

            const dx = centerX - p.x;
            const dy = centerY - p.y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist > 165) {
              p.vx *= -1;
              p.vy *= -1;
              p.x += p.vx * 2;
              p.y += p.vy * 2;
            }
          }
        }

        // Color coding scheme depending on molecular type
        if (p.type === 'dna') {
          ctx.fillStyle = isEukaryote ? '#2563EB' : '#DC2626'; // Blue vs Red chaotic strands
          // Draw chromosome X shapes for Eukaryote, squiggly loops for prokaryote
          if (isEukaryote) {
            ctx.font = '12px sans-serif';
            ctx.fillText('🧬', p.x - 6, p.y + 4);
          } else {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fill();
          }
        } else if (p.type === 'enzyme') {
          ctx.fillStyle = '#10B981'; // Green enzymes
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle = '#F59E0B'; // Amber energy/structural particles
          ctx.fillRect(p.x - p.radius, p.y - p.radius, p.radius * 2, p.radius * 2);
        }
      });

      // 4. Structural hints for organelles in Eukaryotes
      if (isEukaryote) {
        ctx.strokeStyle = 'rgba(16, 185, 129, 0.4)';
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(centerX + 110, centerY - 60, 25, Math.PI * 1.2, Math.PI * 0.2);
        ctx.stroke();
        ctx.fillStyle = '#10B981';
        ctx.font = '9px sans-serif';
        ctx.fillText("ORGANELLE", centerX + 110, centerY - 92);
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationFrameId);
  }, [isEukaryote, isPlaying]);

  const handleReset = () => {
    setIsEukaryote(true);
    setIsPlaying(true);
    setClickDetails(null);
  };

  return (
    <div className="flex flex-col lg:flex-row w-full max-w-6xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100 font-sans antialiased text-slate-800 my-4">
      
      {/* Narrative Control Panel Sidebar */}
      <div className="w-full lg:w-5/12 p-6 lg:p-8 bg-slate-50 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-slate-100">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-1 text-xs font-bold uppercase tracking-wider bg-blue-100 text-blue-800 rounded-full">
              Taxonomy Sandbox
            </span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 leading-tight tracking-tight mb-2">
            Taxonomic Classification of Eukaryotes
          </h2>
          <p className="text-sm text-slate-500 mb-6">
            The presence of a structured cellular nucleus is the universal dividing line between Eukaryotes and Prokaryotes.
          </p>

          {/* Interactive State Toggle Buttons */}
          <div className="bg-white p-2 rounded-xl shadow-sm border border-slate-200/80 flex gap-2 mb-6">
            <button
              onClick={() => { setIsEukaryote(true); setClickDetails(null); }}
              className={`flex-1 py-3 px-4 rounded-lg font-bold text-xs tracking-wide uppercase transition-all flex items-center justify-center gap-2 ${
                isEukaryote 
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20' 
                  : 'bg-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              <CheckCircle className="w-4 h-4" /> Eukaryote State
            </button>
            <button
              onClick={() => { setIsEukaryote(false); setClickDetails(null); }}
              className={`flex-1 py-3 px-4 rounded-lg font-bold text-xs tracking-wide uppercase transition-all flex items-center justify-center gap-2 ${
                !isEukaryote 
                  ? 'bg-amber-500 text-white shadow-md shadow-amber-500/20' 
                  : 'bg-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              <ShieldAlert className="w-4 h-4" /> Prokaryote State
            </button>
          </div>

          {/* Real-time Status Indicators */}
          <div className="space-y-3 mb-6">
            <div className="flex items-start gap-3 bg-white p-3.5 rounded-xl border border-slate-200/60">
              <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${isEukaryote ? 'bg-blue-500' : 'bg-amber-500'}`} />
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Structural State</h4>
                <p className="text-sm font-semibold text-slate-800">
                  {isEukaryote ? 'Organized / Compartmentalized Space' : 'Chaotic / Single Reaction Space'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 bg-white p-3.5 rounded-xl border border-slate-200/60">
              <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${isEukaryote ? 'bg-emerald-500' : 'bg-rose-500'}`} />
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">Taxonomic Groups Included</h4>
                <p className="text-sm font-medium text-slate-600 leading-relaxed">
                  {isEukaryote 
                    ? 'Humans, Animals, Plants, Fungi, Algae.' 
                    : 'Bacteria and Archaea only (No nuclear membrane present).'}
                </p>
              </div>
            </div>
          </div>

          {/* Educational Inspector Block (Triggered via click or hover) */}
          <div className="min-h-[140px] bg-slate-900 text-slate-100 rounded-xl p-4 shadow-inner relative overflow-hidden transition-all duration-300">
            {clickDetails || hoveredElement ? (
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <Info className="w-4 h-4 text-blue-400" />
                  <h3 className="font-bold text-sm text-white">
                    {elementInfo[clickDetails || hoveredElement].title}
                  </h3>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed mb-2">
                  {elementInfo[clickDetails || hoveredElement].desc}
                </p>
                <div className="border-t border-slate-800 pt-2 mt-2">
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block mb-0.5">Evolutionary Edge:</span>
                  <p className="text-xs italic text-slate-400">
                    {elementInfo[clickDetails || hoveredElement].significance}
                  </p>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center py-6 text-slate-500">
                <HelpCircle className="w-8 h-8 mb-2 stroke-[1.5] text-slate-600 animate-pulse" />
                <p className="text-xs font-medium max-w-[240px]">
                  Hover over or click interactive elements to see how structure determines taxonomy.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Global Blueprint Controls */}
        <div className="flex items-center justify-between gap-4 pt-6 border-t border-slate-200 mt-6 lg:mt-0">
          <div className="flex gap-2">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-2.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-slate-800 hover:bg-slate-100 transition-colors shadow-sm"
              title={isPlaying ? 'Pause Simulation' : 'Play Simulation'}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
            <button
              onClick={handleReset}
              className="p-2.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-slate-800 hover:bg-slate-100 transition-colors shadow-sm"
              title="Reset Sandbox"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5" /> Interactive Lab Map
          </span>
        </div>
      </div>

      {/* Visual Canvas Microscopic Interface Container */}
      <div className="flex-1 p-4 lg:p-6 flex flex-col items-center justify-center relative bg-slate-50/50">
        
        {/* Hotspot Target Triggers Overlay */}
        <div className="absolute top-8 left-8 right-8 bottom-8 pointer-events-none z-10 font-mono text-[10px] uppercase font-bold tracking-wider text-slate-400/80">
          <div className="absolute top-0 left-0 border-l-2 border-t-2 border-slate-300 w-4 h-4" />
          <div className="absolute top-0 right-0 border-r-2 border-t-2 border-slate-300 w-4 h-4" />
          <div className="absolute bottom-0 left-0 border-l-2 border-b-2 border-slate-300 w-4 h-4" />
          <div className="absolute bottom-0 right-0 border-r-2 border-b-2 border-slate-300 w-4 h-4" />
        </div>

        {/* Interactive Click Zones mapped cleanly over the Canvas */}
        <div className="relative w-full max-w-[540px] aspect-[54/40] bg-white rounded-xl shadow-inner overflow-hidden border border-slate-200">
          <canvas ref={canvasRef} className="w-full h-full block" />

          {/* Absolute Invisible Interactive Buttons for Tooltips */}
          {isEukaryote && (
            <button
              onMouseEnter={() => setHoveredElement('nucleus')}
              onMouseLeave={() => setHoveredElement(null)}
              onClick={() => setClickDetails(clickDetails === 'nucleus' ? null : 'nucleus')}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[140px] h-[140px] rounded-full cursor-pointer pointer-events-auto bg-transparent border-2 border-dashed border-transparent hover:border-blue-400/40 transition-colors focus:outline-none"
              title="Click to lock Nucleus Inspector info"
            />
          )}

          <button
            onMouseEnter={() => setHoveredElement('dna')}
            onMouseLeave={() => setHoveredElement(null)}
            onClick={() => setClickDetails(clickDetails === 'dna' ? null : 'dna')}
            className={`absolute w-12 h-12 cursor-pointer rounded-full bg-transparent border border-dashed border-transparent hover:border-red-400/40 focus:outline-none ${
              isEukaryote ? 'top-[48%] left-[46%]' : 'top-[35%] left-[25%]'
            }`}
          />

          {isEukaryote && (
            <button
              onMouseEnter={() => setHoveredElement('organelles')}
              onMouseLeave={() => setHoveredElement(null)}
              onClick={() => setClickDetails(clickDetails === 'organelles' ? null : 'organelles')}
              className="absolute top-[28%] right-[22%] w-16 h-12 cursor-pointer bg-transparent border border-dashed border-transparent hover:border-emerald-400/40 focus:outline-none"
            />
          )}

          <button
            onMouseEnter={() => setHoveredElement('cytoplasm')}
            onMouseLeave={() => setHoveredElement(null)}
            onClick={() => setClickDetails(clickDetails === 'cytoplasm' ? null : 'cytoplasm')}
            className="absolute bottom-[15%] left-[15%] w-20 h-12 cursor-pointer bg-transparent border border-dashed border-transparent hover:border-slate-400/40 focus:outline-none"
          />
        </div>

        {/* Micro-Legend Footnote */}
        <div className="w-full max-w-[540px] mt-3 flex justify-between px-1 text-[11px] text-slate-400 font-medium">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-blue-600 rounded-sm inline-block" /> 🧬 Chromosomal DNA</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-emerald-500 rounded-full inline-block" /> Enzymes / Proteins</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-amber-500 inline-block" /> ATP Energy Molecules</span>
          </div>
          <span className="italic">Click map objects to lock data panel</span>
        </div>
      </div>

    </div>
  );
}