import { useEffect, useMemo, useState } from "react";
import { Play, Pause, RotateCcw, Shuffle } from "lucide-react";
import { motion } from "framer-motion";

export default function CellCityComparisonSimulator() {
  const [playing, setPlaying] = useState(true);
  const [organized, setOrganized] = useState(true);
  const [selected, setSelected] = useState(null);
  const [dnaPosition, setDnaPosition] = useState({ x: 180, y: 180 });
  const [dragging, setDragging] = useState(false);

  const particles = useMemo(
    () =>
      Array.from({ length: 18 }, (_, i) => ({
        id: i,
        left: Math.random() * 85,
        top: Math.random() * 85,
        delay: Math.random() * 3,
      })),
    []
  );

  useEffect(() => {
    if (organized) {
      setDnaPosition({ x: 180, y: 180 });
    }
  }, [organized]);

  const insideNucleus =
    dnaPosition.x > 135 &&
    dnaPosition.x < 305 &&
    dnaPosition.y > 135 &&
    dnaPosition.y < 305;

  return (
    <div className="min-h-screen bg-white text-gray-900 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold mb-3">
            Eukaryotic Cell Simulator
          </h1>
          <p className="text-gray-600 text-lg max-w-3xl mx-auto">
            Explore how the nucleus organizes and protects genetic material in
            eukaryotic cells.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-4 mb-8">
          <button
            onClick={() => setPlaying(!playing)}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-black text-white shadow-lg hover:scale-105 transition-transform"
          >
            {playing ? <Pause size={18} /> : <Play size={18} />}
            {playing ? "Pause" : "Play"}
          </button>

          <button
            onClick={() => setOrganized(!organized)}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-blue-600 text-white shadow-lg hover:scale-105 transition-transform"
          >
            <Shuffle size={18} />
            Toggle State
          </button>

          <button
            onClick={() => {
              setOrganized(true);
              setPlaying(true);
              setSelected(null);
              setDnaPosition({ x: 180, y: 180 });
            }}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gray-100 border border-gray-300 shadow-lg hover:scale-105 transition-transform"
          >
            <RotateCcw size={18} />
            Reset
          </button>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="rounded-3xl border border-blue-200 bg-blue-50 p-6 shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-3xl font-bold">With Nucleus</h2>
                <p className="text-gray-600 mt-1">
                  Organized and protected cellular activity
                </p>
              </div>

              <div className="px-4 py-2 rounded-full bg-green-500 text-white font-semibold shadow-md">
                Organized
              </div>
            </div>

            <div className="relative h-[560px] rounded-full border-[6px] border-blue-300 bg-white overflow-hidden">
              {particles.map((p) => (
                <motion.div
                  key={p.id}
                  animate={
                    playing
                      ? {
                          y: [0, -15, 0],
                          opacity: [0.4, 1, 0.4],
                        }
                      : {}
                  }
                  transition={{
                    repeat: Infinity,
                    duration: 2 + p.delay,
                  }}
                  className="absolute w-4 h-4 rounded-full bg-blue-400"
                  style={{ left: `${p.left}%`, top: `${p.top}%` }}
                />
              ))}

              <motion.div
                animate={playing ? { scale: [1, 1.05, 1] } : {}}
                transition={{ repeat: Infinity, duration: 3 }}
                className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
              >
                <div
                  onClick={() =>
                    setSelected({
                      title: "Nucleus",
                      text: "The nucleus stores and protects DNA while coordinating cellular activity.",
                    })
                  }
                  className="w-48 h-48 rounded-full bg-purple-500 border-[10px] border-purple-300 shadow-2xl flex items-center justify-center cursor-pointer hover:scale-105 transition-transform"
                >
                  <div className="text-center text-white">
                    <div className="text-6xl mb-2">🧬</div>
                    <div className="font-bold text-xl">Nucleus</div>
                  </div>
                </div>
              </motion.div>

              <div
                draggable
                onDragStart={() => setDragging(true)}
                onDragEnd={(e) => {
                  setDragging(false);
                  const rect = e.currentTarget.parentElement.getBoundingClientRect();
                  setDnaPosition({
                    x: e.clientX - rect.left,
                    y: e.clientY - rect.top,
                  });
                }}
                style={{ left: dnaPosition.x, top: dnaPosition.y }}
                className="absolute cursor-grab active:cursor-grabbing z-20"
              >
                <motion.div
                  animate={
                    playing
                      ? {
                          rotate: [0, 8, -8, 0],
                        }
                      : {}
                  }
                  transition={{ repeat: Infinity, duration: 4 }}
                  className="text-5xl"
                >
                  🧬
                </motion.div>
              </div>

              <InfoCard
                icon="🧑"
                title="Human Cell"
                text="Human cells are eukaryotic and contain a nucleus."
                position="top-10 left-10"
                setSelected={setSelected}
              />

              <InfoCard
                icon="🌿"
                title="Plant Cell"
                text="Plant cells are eukaryotic and contain a nucleus."
                position="bottom-10 right-10"
                setSelected={setSelected}
              />

              <InfoCard
                icon="⚡"
                title="Mitochondria"
                text="Mitochondria generate ATP energy for the cell."
                position="top-24 right-20"
                setSelected={setSelected}
                small
              />

              <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
                <div
                  className={`px-5 py-3 rounded-2xl shadow-lg font-medium transition-all ${
                    insideNucleus
                      ? "bg-green-100 border border-green-300 text-green-700"
                      : "bg-red-100 border border-red-300 text-red-700"
                  }`}
                >
                  {insideNucleus
                    ? "DNA Protected Inside Nucleus"
                    : "Drag DNA Into the Nucleus"}
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-3xl border border-gray-300 bg-gray-100 p-6 shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-3xl font-bold">Without Nucleus</h2>
                <p className="text-gray-600 mt-1">
                  No central organization or protection
                </p>
              </div>

              <div className="px-4 py-2 rounded-full bg-red-500 text-white font-semibold shadow-md">
                Chaotic
              </div>
            </div>

            <div className="relative h-[560px] rounded-full border-[6px] border-gray-400 bg-white overflow-hidden">
              {particles.map((p) => (
                <motion.div
                  key={`chaos-${p.id}`}
                  animate={
                    playing
                      ? {
                          x: [0, 40, -30, 0],
                          y: [0, -40, 20, 0],
                        }
                      : {}
                  }
                  transition={{
                    repeat: Infinity,
                    duration: 3 + p.delay,
                  }}
                  className="absolute w-5 h-5 rounded-full bg-red-400 opacity-80"
                  style={{ left: `${p.left}%`, top: `${p.top}%` }}
                />
              ))}

              <motion.div
                animate={
                  playing
                    ? {
                        rotate: [0, 12, -12, 0],
                        scale: [1, 1.1, 1],
                      }
                    : {}
                }
                transition={{ repeat: Infinity, duration: 2 }}
                className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center"
              >
                <div className="text-8xl">🧬</div>
                <div className="font-bold text-red-600 mt-2 text-xl">
                  Exposed DNA
                </div>
              </motion.div>

              <div className="absolute inset-0 bg-gradient-to-br from-transparent via-red-100/30 to-transparent pointer-events-none" />

              <div className="absolute bottom-8 left-1/2 -translate-x-1/2 bg-red-100 border border-red-300 rounded-2xl px-5 py-4 shadow-xl text-center max-w-xs">
                <div className="font-bold text-red-700 text-lg">
                  No Central Control
                </div>
                <div className="text-sm text-gray-700 mt-1">
                  DNA is vulnerable and cellular activity becomes disorganized.
                </div>
              </div>
            </div>
          </div>
        </div>

        {selected && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="fixed bottom-6 right-6 w-80 bg-white border border-gray-200 rounded-3xl shadow-2xl p-6 z-50"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="text-2xl font-bold mb-2">{selected.title}</h3>
                <p className="text-gray-600 leading-relaxed">
                  {selected.text}
                </p>
              </div>

              <button
                onClick={() => setSelected(null)}
                className="text-gray-400 hover:text-black text-xl"
              >
                ×
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

function InfoCard({ icon, title, text, position, setSelected, small }) {
  return (
    <motion.div
      whileHover={{ scale: 1.08 }}
      className={`absolute ${position} cursor-pointer`}
      onClick={() => setSelected({ title, text })}
    >
      <div
        className={`${
          small ? "w-20 h-20 text-sm" : "w-32 h-32"
        } rounded-3xl bg-white border border-blue-200 shadow-xl flex flex-col items-center justify-center text-center p-2`}
      >
        <div className={`${small ? "text-3xl" : "text-5xl"}`}>{icon}</div>
        <div className="font-semibold mt-1">{title}</div>
      </div>
    </motion.div>
  );
}
