import React, { useState } from 'react';
import { BookOpen, AlertCircle, Users, Eye, Info, X, ChevronRight, CheckCircle, XCircle, HelpCircle, Skull, Award, Scale } from 'lucide-react';

const HistoricalTimeline = () => {
  const [selectedPublication, setSelectedPublication] = useState(null);
  const [showContext, setShowContext] = useState(true);
  const [hoveredItem, setHoveredItem] = useState(null);
  const [hoveredMetric, setHoveredMetric] = useState(null);
  const [activeLayer, setActiveLayer] = useState('all');

  const publications = [
    {
      id: 1,
      year: 1933,
      title: "Sobotta Atlas",
      author: "J. Sobotta",
      ethicalStatus: "ethical",
      quality: 80,
      specimens: { status: "ethical", icon: CheckCircle, text: "Medical school donations" },
      artist: { status: "clean", icon: CheckCircle, text: "No Nazi ties" },
      symbols: { status: "none", icon: CheckCircle, text: "No symbols" },
      usage: { status: "active", icon: Award, text: "Still in use worldwide" },
      tooltip: "Pre-Nazi standard reference"
    },
    {
      id: 2,
      year: 1937,
      title: "Pernkopf Vol. 1",
      author: "E. Pernkopf",
      ethicalStatus: "problematic",
      quality: 98,
      specimens: { status: "questionable", icon: HelpCircle, text: "Sources unclear after 1938" },
      artist: { status: "nazi", icon: AlertCircle, text: "Nazi party member (1933)" },
      symbols: { status: "some", icon: AlertCircle, text: "SS signatures appear" },
      usage: { status: "controversial", icon: AlertCircle, text: "Exceptional but tainted" },
      tooltip: "Transition period - quality rises, ethics decline"
    },
    {
      id: 3,
      year: 1941,
      title: "Pernkopf Vol. 2",
      author: "E. Pernkopf",
      ethicalStatus: "unethical",
      quality: 99,
      specimens: { status: "victims", icon: Skull, text: "1,377 executed victims confirmed" },
      artist: { status: "ss", icon: XCircle, text: "SS members Endtresser, Batke" },
      symbols: { status: "swastikas", icon: XCircle, text: "Swastikas, SS runes" },
      usage: { status: "referenced", icon: AlertCircle, text: "Still used in neurosurgery" },
      tooltip: "Peak anatomical detail, peak ethical violation"
    },
    {
      id: 4,
      year: 1943,
      title: "Wehrmacht Atlas",
      author: "Military Physicians",
      ethicalStatus: "unethical",
      quality: 75,
      specimens: { status: "war", icon: Skull, text: "Military + civilian victims" },
      artist: { status: "military", icon: XCircle, text: "Wehrmacht/SS medical corps" },
      symbols: { status: "reich", icon: XCircle, text: "Reich eagle, swastikas" },
      usage: { status: "archived", icon: Eye, text: "Historical collections only" },
      tooltip: "Military documentation of war crimes"
    },
    {
      id: 5,
      year: 1952,
      title: "Pernkopf Vol. 3-4",
      author: "E. Pernkopf",
      ethicalStatus: "unethical",
      quality: 98,
      specimens: { status: "old", icon: Skull, text: "1938-45 specimens reused" },
      artist: { status: "hidden", icon: AlertCircle, text: "Nazi symbols erased" },
      symbols: { status: "removed", icon: HelpCircle, text: "Symbols deleted, origins hidden" },
      usage: { status: "published", icon: XCircle, text: "Major publishers ignored ethics" },
      tooltip: "Cover-up: symbols removed, crimes hidden"
    },
    {
      id: 6,
      year: 1960,
      title: "Grant's Atlas",
      author: "J.C.B. Grant",
      ethicalStatus: "ethical",
      quality: 85,
      specimens: { status: "donated", icon: CheckCircle, text: "Willed body programs" },
      artist: { status: "clean", icon: CheckCircle, text: "Modern ethical standards" },
      symbols: { status: "none", icon: CheckCircle, text: "No ideological content" },
      usage: { status: "standard", icon: Award, text: "Medical school standard" },
      tooltip: "Modern ethical alternative emerges"
    },
    {
      id: 7,
      year: 1998,
      title: "Vienna Investigation",
      author: "University Commission",
      ethicalStatus: "investigation",
      quality: 0,
      specimens: { status: "documented", icon: Info, text: "All 1,377 victims identified" },
      artist: { status: "exposed", icon: Info, text: "Nazi ties fully documented" },
      symbols: { status: "revealed", icon: Info, text: "Original symbols recovered" },
      usage: { status: "policy", icon: Scale, text: "New institutional policies" },
      tooltip: "Historical reckoning and accountability"
    }
  ];

  const getStatusColor = (status) => {
    const colors = {
      ethical: { bg: 'bg-green-100', border: 'border-green-500', text: 'text-green-700', dot: 'bg-green-500', glow: 'shadow-green-200' },
      problematic: { bg: 'bg-yellow-100', border: 'border-yellow-500', text: 'text-yellow-700', dot: 'bg-yellow-500', glow: 'shadow-yellow-200' },
      unethical: { bg: 'bg-red-100', border: 'border-red-500', text: 'text-red-700', dot: 'bg-red-500', glow: 'shadow-red-200' },
      investigation: { bg: 'bg-blue-100', border: 'border-blue-500', text: 'text-blue-700', dot: 'bg-blue-500', glow: 'shadow-blue-200' }
    };
    return colors[status] || colors.ethical;
  };

  const MetricCircle = ({ pub, metric, hoveredMetric, onHover }) => {
    const data = pub[metric];
    const isHovered = hoveredMetric === `${pub.id}-${metric}`;
    
    const statusColors = {
      ethical: '#10b981', clean: '#10b981', none: '#10b981', active: '#10b981', donated: '#10b981', standard: '#10b981',
      questionable: '#f59e0b', nazi: '#f59e0b', some: '#f59e0b', controversial: '#f59e0b', hidden: '#f59e0b', removed: '#f59e0b',
      victims: '#ef4444', ss: '#ef4444', swastikas: '#ef4444', war: '#ef4444', old: '#ef4444', reich: '#ef4444',
      documented: '#3b82f6', exposed: '#3b82f6', revealed: '#3b82f6', policy: '#3b82f6'
    };
    
    const color = statusColors[data.status] || '#6b7280';
    const Icon = data.icon;
    
    return (
      <div 
        className="relative group cursor-pointer"
        onMouseEnter={() => onHover(`${pub.id}-${metric}`)}
        onMouseLeave={() => onHover(null)}
      >
        <div className={`w-16 h-16 rounded-full border-4 flex items-center justify-center transition-all ${
          isHovered ? 'scale-125 shadow-2xl' : 'scale-100'
        }`} style={{ 
          borderColor: color,
          backgroundColor: `${color}20`
        }}>
          <Icon size={24} style={{ color }} />
        </div>
        
        {isHovered && (
          <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-48 bg-gray-900 text-white text-xs rounded-lg px-3 py-2 z-50">
            <div className="font-bold mb-1">{metric.toUpperCase()}</div>
            {data.text}
            <div className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-1">
              <div className="border-4 border-transparent border-t-gray-900"></div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const QualityMeter = ({ value, ethicalStatus }) => {
    const getColor = () => {
      if (ethicalStatus === 'ethical') return '#10b981';
      if (ethicalStatus === 'unethical') return '#ef4444';
      return '#f59e0b';
    };
    
    return (
      <div className="relative w-full h-3 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className="h-full transition-all duration-1000 rounded-full"
          style={{ 
            width: `${value}%`,
            backgroundColor: getColor()
          }}
        />
        <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-gray-700">
          {value}% Quality
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Compact Header */}
        <div className="text-center mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-2">
            Anatomical Atlases 1933-1998
          </h1>
          <p className="text-sm text-gray-600">Click and hover to reveal ethical history</p>
        </div>

        {/* Interactive Legend */}
        <div className="bg-white rounded-xl p-4 mb-6 shadow-lg">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { status: 'ethical', icon: CheckCircle, label: 'Ethical' },
              { status: 'problematic', icon: HelpCircle, label: 'Questionable' },
              { status: 'unethical', icon: XCircle, label: 'Unethical' },
              { status: 'investigation', icon: Info, label: 'Investigation' }
            ].map(item => {
              const colors = getStatusColor(item.status);
              const Icon = item.icon;
              return (
                <button
                  key={item.status}
                  onClick={() => setActiveLayer(activeLayer === item.status ? 'all' : item.status)}
                  className={`flex items-center gap-2 p-2 rounded-lg transition-all ${
                    activeLayer === item.status || activeLayer === 'all'
                      ? `${colors.bg} ${colors.border} border-2`
                      : 'bg-gray-100 border-2 border-transparent opacity-50'
                  }`}
                >
                  <Icon size={16} className={colors.text} />
                  <span className={`text-xs font-medium ${colors.text}`}>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Context Toggle */}
        <div className="flex justify-center mb-6">
          <button
            onClick={() => setShowContext(!showContext)}
            className={`px-6 py-2 rounded-full font-medium transition-all text-sm ${
              showContext 
                ? 'bg-blue-600 text-white shadow-lg' 
                : 'bg-white text-gray-700 border-2 border-gray-300'
            }`}
          >
            {showContext ? '👁️ Context ON' : '👁️ Context OFF'}
          </button>
        </div>

        {/* Visual Timeline */}
        <div className="relative">
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-green-500 via-red-500 to-blue-500 transform md:-translate-x-1/2" />

          <div className="space-y-6">
            {publications.map((pub, index) => {
              if (activeLayer !== 'all' && activeLayer !== pub.ethicalStatus) return null;
              
              const colors = getStatusColor(pub.ethicalStatus);
              const isLeft = index % 2 === 0;
              const isHovered = hoveredItem === pub.id;
              const isSelected = selectedPublication?.id === pub.id;

              return (
                <div
                  key={pub.id}
                  className={`relative flex items-center ${isLeft ? 'md:flex-row' : 'md:flex-row-reverse'}`}
                >
                  {/* Year Badge */}
                  <div className="absolute left-8 md:left-1/2 transform md:-translate-x-1/2 flex flex-col items-center z-20">
                    <div className={`w-12 h-12 rounded-full ${colors.dot} border-4 border-white shadow-xl flex items-center justify-center z-10 transition-transform ${
                      isHovered ? 'scale-125' : ''
                    }`}>
                      <span className="text-white font-bold text-sm">{pub.year.toString().slice(-2)}</span>
                    </div>
                  </div>

                  {/* Card */}
                  <div className={`w-full md:w-5/12 ml-20 md:ml-0 ${isLeft ? 'md:mr-auto md:pr-8' : 'md:ml-auto md:pl-8'}`}>
                    <div
                      onClick={() => setSelectedPublication(isSelected ? null : pub)}
                      onMouseEnter={() => setHoveredItem(pub.id)}
                      onMouseLeave={() => setHoveredItem(null)}
                      className={`bg-white rounded-2xl p-4 border-3 cursor-pointer transition-all ${colors.border} ${
                        isHovered || isSelected ? `shadow-2xl ${colors.glow} scale-105` : 'shadow-lg'
                      }`}
                    >
                      {/* Header */}
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h3 className="font-bold text-gray-800 text-lg">{pub.title}</h3>
                          <p className="text-xs text-gray-500">{pub.author}</p>
                        </div>
                        <div className={`text-2xl ${isSelected ? 'rotate-90' : ''} transition-transform`}>
                          {isSelected ? '▼' : '▶'}
                        </div>
                      </div>

                      {/* Quality Bar */}
                      {pub.quality > 0 && (
                        <div className="mb-3">
                          <QualityMeter value={pub.quality} ethicalStatus={pub.ethicalStatus} />
                        </div>
                      )}

                      {/* Metric Circles */}
                      <div className="grid grid-cols-4 gap-2 mb-3">
                        <div className="text-center">
                          <MetricCircle 
                            pub={pub} 
                            metric="specimens" 
                            hoveredMetric={hoveredMetric}
                            onHover={setHoveredMetric}
                          />
                          <div className="text-xs text-gray-500 mt-1">Source</div>
                        </div>
                        <div className="text-center">
                          <MetricCircle 
                            pub={pub} 
                            metric="artist" 
                            hoveredMetric={hoveredMetric}
                            onHover={setHoveredMetric}
                          />
                          <div className="text-xs text-gray-500 mt-1">Artist</div>
                        </div>
                        <div className="text-center">
                          <MetricCircle 
                            pub={pub} 
                            metric="symbols" 
                            hoveredMetric={hoveredMetric}
                            onHover={setHoveredMetric}
                          />
                          <div className="text-xs text-gray-500 mt-1">Symbols</div>
                        </div>
                        <div className="text-center">
                          <MetricCircle 
                            pub={pub} 
                            metric="usage" 
                            hoveredMetric={hoveredMetric}
                            onHover={setHoveredMetric}
                          />
                          <div className="text-xs text-gray-500 mt-1">Today</div>
                        </div>
                      </div>

                      {/* Tooltip on hover */}
                      {isHovered && showContext && (
                        <div className={`text-xs ${colors.text} ${colors.bg} rounded-lg p-2 font-medium`}>
                          💡 {pub.tooltip}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Expanded Detail Modal */}
        {selectedPublication && (
          <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
            <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[85vh] overflow-y-auto shadow-2xl">
              {/* Header */}
              <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-t-3xl">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-2xl font-bold mb-1">{selectedPublication.title}</h2>
                    <p className="text-blue-100">{selectedPublication.year} • {selectedPublication.author}</p>
                  </div>
                  <button
                    onClick={() => setSelectedPublication(null)}
                    className="bg-white bg-opacity-20 hover:bg-opacity-30 rounded-full p-2 transition-all"
                  >
                    <X size={24} />
                  </button>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 space-y-4">
                {/* Visual Metrics Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {['specimens', 'artist', 'symbols', 'usage'].map(metric => {
                    const data = selectedPublication[metric];
                    const Icon = data.icon;
                    const statusColors = {
                      ethical: 'bg-green-100 border-green-500 text-green-700',
                      clean: 'bg-green-100 border-green-500 text-green-700',
                      none: 'bg-green-100 border-green-500 text-green-700',
                      donated: 'bg-green-100 border-green-500 text-green-700',
                      standard: 'bg-green-100 border-green-500 text-green-700',
                      active: 'bg-green-100 border-green-500 text-green-700',
                      questionable: 'bg-yellow-100 border-yellow-500 text-yellow-700',
                      nazi: 'bg-yellow-100 border-yellow-500 text-yellow-700',
                      some: 'bg-yellow-100 border-yellow-500 text-yellow-700',
                      controversial: 'bg-yellow-100 border-yellow-500 text-yellow-700',
                      hidden: 'bg-yellow-100 border-yellow-500 text-yellow-700',
                      removed: 'bg-yellow-100 border-yellow-500 text-yellow-700',
                      victims: 'bg-red-100 border-red-500 text-red-700',
                      ss: 'bg-red-100 border-red-500 text-red-700',
                      swastikas: 'bg-red-100 border-red-500 text-red-700',
                      war: 'bg-red-100 border-red-500 text-red-700',
                      old: 'bg-red-100 border-red-500 text-red-700',
                      reich: 'bg-red-100 border-red-500 text-red-700',
                      documented: 'bg-blue-100 border-blue-500 text-blue-700',
                      exposed: 'bg-blue-100 border-blue-500 text-blue-700',
                      revealed: 'bg-blue-100 border-blue-500 text-blue-700',
                      policy: 'bg-blue-100 border-blue-500 text-blue-700'
                    };
                    const colorClass = statusColors[data.status] || 'bg-gray-100 border-gray-500 text-gray-700';
                    
                    return (
                      <div key={metric} className={`rounded-xl p-4 border-2 ${colorClass} text-center`}>
                        <Icon size={32} className="mx-auto mb-2" />
                        <div className="font-bold text-xs uppercase mb-1">{metric}</div>
                        <div className="text-xs">{data.text}</div>
                      </div>
                    );
                  })}
                </div>

                {/* Quality Visualization */}
                {selectedPublication.quality > 0 && (
                  <div className="bg-gray-50 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-semibold text-gray-700">Anatomical Quality</span>
                      <span className="text-3xl font-bold text-gray-800">{selectedPublication.quality}%</span>
                    </div>
                    <QualityMeter value={selectedPublication.quality} ethicalStatus={selectedPublication.ethicalStatus} />
                  </div>
                )}

                {/* Context Message */}
                {showContext && (
                  <div className={`rounded-xl p-6 border-2 ${getStatusColor(selectedPublication.ethicalStatus).border} ${getStatusColor(selectedPublication.ethicalStatus).bg}`}>
                    <div className="flex items-start gap-3">
                      <Info size={24} className={getStatusColor(selectedPublication.ethicalStatus).text} />
                      <div className={getStatusColor(selectedPublication.ethicalStatus).text}>
                        <div className="font-bold mb-2">Key Message:</div>
                        <div className="text-sm">{selectedPublication.tooltip}</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Compact Footer */}
        <div className="mt-12 bg-white rounded-2xl p-6 shadow-lg">
          <div className="grid md:grid-cols-3 gap-6 text-sm">
            <div className="text-center">
              <div className="text-3xl mb-2">📈</div>
              <div className="font-bold text-gray-800">Quality ≠ Ethics</div>
              <div className="text-gray-600">Highest detail from worst crimes</div>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-2">⚖️</div>
              <div className="font-bold text-gray-800">The Dilemma</div>
              <div className="text-gray-600">Use knowledge from atrocity?</div>
            </div>
            <div className="text-center">
              <div className="text-3xl mb-2">🔍</div>
              <div className="font-bold text-gray-800">1998 Reckoning</div>
              <div className="text-gray-600">Truth revealed, policies changed</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HistoricalTimeline;