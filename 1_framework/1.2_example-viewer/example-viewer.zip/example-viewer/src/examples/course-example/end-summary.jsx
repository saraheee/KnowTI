import { useState } from "react";
import { 
  Eye, 
  Brain, 
  FileText, 
  Activity, 
  Camera, 
  Filter, 
  Layers, 
  Box, 
  Users, 
  Microscope,
  Heart,
  AlertCircle,
  TrendingUp,
  Stethoscope,
  Baby,
  Zap,
  BookOpen,
  Map,
  BarChart3,
  Target,
  Sparkles
} from "lucide-react";

export default function MedicalVisualizationInteractive() {
  const [activeCategory, setActiveCategory] = useState(1);
  const [hoveredKeyword, setHoveredKeyword] = useState(null);
  const [highlightedKeyword, setHighlightedKeyword] = useState(null);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });
  
  const getKeywordIcon = (keywordName) => {
    const iconMap = {
      "Course Topics": <BookOpen size={16} />,
      "Image Acquisition": <Camera size={16} />,
      "Filtering & Preprocessing": <Filter size={16} />,
      "Segmentation": <Layers size={16} />,
      "Volume Rendering": <Box size={16} />,
      "Definition": <Eye size={16} />,
      "Making Data Visible": <Sparkles size={16} />,
      "Visual Analytics": <BarChart3 size={16} />,
      "Cognition & Insights": <Brain size={16} />,
      "Historical Maps": <Map size={16} />,
      "Napoleon's March": <TrendingUp size={16} />,
      "Medical Illustrations": <FileText size={16} />,
      "Brain Anatomy": <Brain size={16} />,
      "Flow Visualization": <Activity size={16} />,
      "Medical Data Application": <Stethoscope size={16} />,
      "Anatomy Studies": <Users size={16} />,
      "Body Worlds": <Users size={16} />,
      "X-rays": <Camera size={16} />,
      "CT Scans": <Layers size={16} />,
      "MRI": <Microscope size={16} />,
      "Ultrasound": <Baby size={16} />,
      "Radiologists": <Stethoscope size={16} />,
      "Surgeons": <Activity size={16} />,
      "Medical Students": <BookOpen size={16} />,
      "Patients": <Heart size={16} />,
      "Structure Recognition": <Eye size={16} />,
      "Illness Identification": <AlertCircle size={16} />,
      "Disease Progression": <TrendingUp size={16} />,
      "Qualitative & Quantitative": <BarChart3 size={16} />,
      "Slice Views": <Layers size={16} />,
      "Cinematic Rendering": <Box size={16} />,
      "Computer Graphics": <Box size={16} />,
      "Image Analysis": <Filter size={16} />,
      "Blood Flow": <Activity size={16} />,
      "Feature Extraction": <Target size={16} />,
      "Information Density": <BarChart3 size={16} />,
      "Gestalt Effect": <Eye size={16} />,
      "Accessibility": <Users size={16} />,
      "Misleading Visualizations": <AlertCircle size={16} />,
      "Vis-lies": <AlertCircle size={16} />
    };
    return iconMap[keywordName] || <Eye size={16} />;
  };
  
  const categories = [
    {
      id: 1,
      title: "Course Overview",
      description: "Introduction to Medical Visualization topics and goals",
      color: "#3b82f6",
      keywords: [
        { name: "Course Topics", description: "Basic theoretical and algorithmic knowledge on image acquisition, filtering, segmentation, and volume rendering", timecode: "00:02:10-00:02:19" },
        { name: "Image Acquisition", description: "How we acquire images that clinical experts use in diagnostics and therapy", timecode: "00:02:19-00:02:24" },
        { name: "Filtering & Preprocessing", description: "How to filter and pre-process images to extract meaningful structures", timecode: "00:02:41-00:02:48" },
        { name: "Segmentation", description: "Algorithms to identify and separate structures in medical images", timecode: "00:02:48-00:02:54" },
        { name: "Volume Rendering", description: "The very basic volume rendering pipeline for 3D medical data", timecode: "00:02:54-00:03:03" }
      ]
    },
    {
      id: 2,
      title: "Visualization Fundamentals",
      description: "What is visualization and why do we use it?",
      color: "#10b981",
      keywords: [
        { name: "Definition", description: "The act of forming a picture of somebody or something in your mind", timecode: "00:26:15-00:26:31" },
        { name: "Making Data Visible", description: "Making something able to be seen by the eye", timecode: "00:26:59-00:27:08" },
        { name: "Visual Analytics", description: "Field with wonderful resources from experts like Tamara Munzner, one of the gurus of visualization", timecode: "00:27:22-00:27:30" },
        { name: "Cognition & Insights", description: "The scientific field that takes advantage of our vision and perception to increase our cognition and help us get insights into complex data", timecode: "00:31:02-00:31:17" }
      ]
    },
    {
      id: 3,
      title: "Historical Context",
      description: "Visualization throughout history",
      color: "#8b4513",
      keywords: [
        { name: "Historical Maps", description: "The oldest known world map from Babylon, dating back to the sixth century before Christ", timecode: "00:31:42-00:32:01" },
        { name: "Napoleon's March", description: "The most well-known visualization of all times by Charminard, showing Napoleon's march to Moscow with army size and temperature data", timecode: "00:33:32-00:33:40" },
        { name: "Medical Illustrations", description: "Historical medical visualizations like Gray's Anatomy and Leonardo da Vinci's anatomical studies", timecode: "00:35:36-00:35:49" },
        { name: "Brain Anatomy", description: "Very old representation of the brain done by Gray in one of the oldest anatomy books", timecode: "00:35:36-00:35:43" },
        { name: "Flow Visualization", description: "Leonardo da Vinci observing flow in rivers by putting obstacles and seeing how vortices formed", timecode: "00:35:58-00:36:03" }
      ]
    },
    {
      id: 4,
      title: "Medical Data",
      description: "What makes medical visualization unique?",
      color: "#ec4899",
      keywords: [
        { name: "Medical Data Application", description: "Visualization applied to medical data - the same terminology applies, what changes is the field of application", timecode: "00:37:16-00:37:23" },
        { name: "Anatomy Studies", description: "People looking into the body in very invasive ways, as depicted in Rembrandt's 'Anatomy Lecture of Dr. Nicolaes Tulp' from the 1600s", timecode: "00:37:48-00:38:03" },
        { name: "Body Worlds", description: "Gunther von Hagen's controversial exhibition where bodies were preserved and displayed, claimed to be from donors", timecode: "00:42:42-00:42:49" },
        { name: "X-rays", description: "Non-invasive imaging - we've almost probably all gotten X-rays when breaking something", timecode: "00:42:33-00:42:39" },
        { name: "CT Scans", description: "3D representations of our body - a 3D version of X-rays", timecode: "00:42:46-00:42:52" },
        { name: "MRI", description: "Very detailed acquisitions of all our soft tissues and functions", timecode: "00:42:52-00:43:03" },
        { name: "Ultrasound", description: "We can see our babies even before they are born", timecode: "00:42:52-00:42:56" }
      ]
    },
    {
      id: 5,
      title: "Users & Applications",
      description: "Who uses medical visualizations and why?",
      color: "#ef4444",
      keywords: [
        { name: "Radiologists", description: "Doctors who specialize in looking at medical images for diagnosis", timecode: "00:43:25-00:43:32" },
        { name: "Surgeons", description: "Different kinds of specialists who use medical images for planning procedures", timecode: "00:43:36-00:43:41" },
        { name: "Medical Students", description: "Learning from data acquired from patients with specific pathologies or learning how anatomical structures are depicted on such images", timecode: "00:43:50-00:43:55" },
        { name: "Patients", description: "Patient participation - a trend in medicine where patients have a say in their treatment and can help decide what's best for them", timecode: "00:44:04-00:44:16" },
        { name: "Structure Recognition", description: "Doctors want to be able to recognize structures and organs - what is normal versus abnormal", timecode: "00:44:51-00:44:57" },
        { name: "Illness Identification", description: "Finding abnormal areas, identifying illnesses and the context of an illness", timecode: "00:45:03-00:45:10" },
        { name: "Disease Progression", description: "Seeing how an illness is progressing through time - in cancer, several acquisitions are done before, during, and after treatment", timecode: "00:45:23-00:45:30" },
        { name: "Qualitative & Quantitative", description: "Doctors evaluate qualitatively by being trained to look at images, or quantitatively by making measurements directly on such images", timecode: "00:45:45-00:45:55" }
      ]
    },
    {
      id: 6,
      title: "Visualization Techniques",
      description: "Methods for displaying medical data",
      color: "#7c3aed",
      keywords: [
        { name: "Slice Views", description: "Very typical way doctors are trained to look at data - scrolling through images of the body from head to toes", timecode: "00:46:12-00:46:33" },
        { name: "Cinematic Rendering", description: "Siemens Healthcare renderer with deep learning support able to render in very high detail with realistic shading", timecode: "00:46:44-00:47:01" },
        { name: "Computer Graphics", description: "All the aesthetically pleasing or simulation of how different materials are interacting with the environment", timecode: "00:48:10-00:48:19" },
        { name: "Image Analysis", description: "Responsible for starting from images and deriving specific features of interest, like highlighting different organs with colors", timecode: "00:48:52-00:48:59" },
        { name: "Blood Flow", description: "Beautiful and insightful renderings showing how blood flows through the aorta with velocity indicated by colors", timecode: "00:49:32-00:49:47" },
        { name: "Feature Extraction", description: "Taking images from a patient and deriving features that describe blood flow to create visualizations", timecode: "00:49:57-00:50:03" }
      ]
    },
    {
      id: 7,
      title: "Value & Challenges",
      description: "Why visualizations matter and potential pitfalls",
      color: "#0891b2",
      keywords: [
        { name: "Information Density", description: "One picture is a thousand words - they provide a lot of information with very few clutter in very small space", timecode: "00:54:06-00:54:13" },
        { name: "Gestalt Effect", description: "They can give you a very good overview - you're able to see structure that in a table you would not be able to see", timecode: "00:54:21-00:54:26" },
        { name: "Accessibility", description: "Figures can make information much more accessible and easier to understand for less expert populations", timecode: "00:54:44-00:54:52" },
        { name: "Misleading Visualizations", description: "Figures can sometimes lie - the COVID pandemic infographic used perspective making Spanish flu look larger than bubonic plague despite fewer deaths", timecode: "00:55:14-00:55:20" },
        { name: "Vis-lies", description: "A whole field within visualization specifically dedicated to misleading visualizations", timecode: "00:55:14-00:55:20" }
      ]
    }
  ];

  const category = categories.find(c => c.id === activeCategory);

  const handleMouseEnter = (keyword, event) => {
    const rect = event.target.getBoundingClientRect();
    setTooltipPosition({
      x: rect.left + rect.width / 2,
      y: rect.top - 10
    });
    setHoveredKeyword(keyword);
    setHighlightedKeyword(keyword.name);
  };

  const handleMouseLeave = () => {
    setHoveredKeyword(null);
    setHighlightedKeyword(null);
  };

  return (
    <div className="w-full min-h-screen p-3 sm:p-6 bg-gradient-to-br from-slate-100 to-slate-200">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-800 mb-2">Medical Visualization - Interactive Summary</h1>
          <p className="text-sm sm:text-base text-gray-600">Hover over keywords for detailed explanations</p>
        </div>

        <div className="flex justify-center mb-4 sm:mb-6">
          <div className="flex flex-wrap gap-2 justify-center p-3 sm:p-4 bg-white rounded-lg shadow-md max-w-5xl">
            {categories.map(cat => (
              <button
                key={cat.id}
                className="px-3 sm:px-4 py-1.5 sm:py-2 rounded-full font-medium transition-all duration-200 text-xs sm:text-sm whitespace-nowrap hover:scale-105"
                style={{ 
                  backgroundColor: activeCategory === cat.id ? cat.color : "white",
                  color: activeCategory === cat.id ? "white" : cat.color,
                  borderWidth: 2,
                  borderColor: cat.color,
                  boxShadow: activeCategory === cat.id ? "0 4px 6px rgba(0, 0, 0, 0.1)" : "none"
                }}
                onClick={() => setActiveCategory(cat.id)}
              >
                {cat.title}
              </button>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6 flex flex-col">
            <div className="mb-4 sm:mb-6 flex-shrink-0">
              <h2 className="text-xl sm:text-2xl font-bold mb-2" style={{ color: category.color }}>{category.title}</h2>
              <p className="text-sm sm:text-base text-gray-700">{category.description}</p>
            </div>
            <div className="flex-1 overflow-y-auto space-y-2 sm:space-y-3" style={{ minHeight: "500px", maxHeight: "650px" }}>
              {category.keywords.map((keyword, index) => (
                <div 
                  key={index}
                  className="p-3 sm:p-4 rounded-lg cursor-pointer transition-all duration-200 border-2 hover:scale-102"
                  style={{ 
                    borderColor: category.color, 
                    backgroundColor: highlightedKeyword === keyword.name ? `${category.color}30` : `${category.color}10`,
                    transform: highlightedKeyword === keyword.name ? "scale(1.02)" : "scale(1)"
                  }}
                  onMouseEnter={(e) => handleMouseEnter(keyword, e)}
                  onMouseLeave={handleMouseLeave}
                >
                  <div className="flex items-center gap-2 sm:gap-3 mb-1 sm:mb-2">
                    <div style={{ color: category.color }} className="flex-shrink-0">
                      {getKeywordIcon(keyword.name)}
                    </div>
                    <span className="font-semibold text-sm sm:text-base text-gray-800">{keyword.name}</span>
                  </div>
                  <div className="text-xs text-gray-600 ml-6 sm:ml-7">{keyword.timecode}</div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-4 sm:p-6 flex flex-col">
            <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-gray-800 flex-shrink-0">Medical Visualization Pipeline</h2>
            <div className="flex-1 flex justify-center items-center" style={{ minHeight: "500px", maxHeight: "650px" }}>
              <svg width="100%" height="100%" viewBox="0 0 550 650" className="max-w-full" preserveAspectRatio="xMidYMid meet">
                {/* Large surrounding box: "Visualization: Making the unseen visible" */}
                <rect x="40" y="20" width="470" height="600" rx="15" fill="none" stroke="#6366f1" strokeWidth="4" strokeDasharray="10,5" opacity="0.6" />
                
                {/* Eye icons in corners */}
                <g transform="translate(50, 30)">
                  <circle cx="0" cy="0" r="15" fill="#6366f1" opacity="0.2" />
                  <path d="M-8,-3 Q0,-8 8,-3 Q0,2 -8,-3" fill="#6366f1" />
                  <circle cx="0" cy="-3" r="3" fill="#6366f1" />
                </g>
                <g transform="translate(500, 30)">
                  <circle cx="0" cy="0" r="15" fill="#6366f1" opacity="0.2" />
                  <path d="M-8,-3 Q0,-8 8,-3 Q0,2 -8,-3" fill="#6366f1" />
                  <circle cx="0" cy="-3" r="3" fill="#6366f1" />
                </g>
                <g transform="translate(50, 610)">
                  <circle cx="0" cy="0" r="15" fill="#6366f1" opacity="0.2" />
                  <path d="M-8,-3 Q0,-8 8,-3 Q0,2 -8,-3" fill="#6366f1" />
                  <circle cx="0" cy="-3" r="3" fill="#6366f1" />
                </g>
                <g transform="translate(500, 610)">
                  <circle cx="0" cy="0" r="15" fill="#6366f1" opacity="0.2" />
                  <path d="M-8,-3 Q0,-8 8,-3 Q0,2 -8,-3" fill="#6366f1" />
                  <circle cx="0" cy="-3" r="3" fill="#6366f1" />
                </g>
                
                {/* Title text for the box */}
                <text x="275" y="50" textAnchor="middle" fontSize="16" fontWeight="bold" fill="#6366f1">
                  Visualization: Making the Unseen Visible
                </text>
                
                {/* Data Source - ICON SMALLER AND MOVED BOTTOM LEFT */}
                <rect x="200" y="80" width="150" height="60" rx="8" fill="white" stroke={activeCategory === 1 || activeCategory === 4 ? "#3b82f6" : "#94a3b8"} strokeWidth="3" />
                <g transform="translate(213, 105)">
                  <circle cx="0" cy="0" r="6" fill="none" stroke="#3b82f6" strokeWidth="1.5" />
                  <rect x="-4" y="-4" width="8" height="8" fill="#3b82f6" />
                </g>
                <text x="275" y="115" textAnchor="middle" fontSize="16" fontWeight="bold" fill="#2d3748">Medical Data</text>
                
                {/* Arrow down */}
                <path d="M275 140 L275 165" stroke="#2d3748" strokeWidth="3" markerEnd="url(#arrowhead)" />
                
                {/* Image Acquisition - ICON MOVED LEFT */}
                <rect x="175" y="165" width="200" height="75" rx="8" fill="white" stroke={activeCategory === 1 || activeCategory === 4 ? "#10b981" : "#94a3b8"} strokeWidth="3" />
                <g transform="translate(190, 187)">
                  <rect x="-6" y="-6" width="12" height="12" rx="2" fill="none" stroke="#10b981" strokeWidth="2" />
                  <circle cx="0" cy="0" r="3" fill="#10b981" />
                </g>
                <text x="275" y="193" textAnchor="middle" fontSize="16" fontWeight="bold" fill="#2d3748">Image Acquisition</text>
                <text x="275" y="210" textAnchor="middle" fontSize="13" fill="#4a5568">X-ray • CT • MRI</text>
                <text x="275" y="227" textAnchor="middle" fontSize="13" fill="#4a5568">Ultrasound</text>
                
                {/* Arrow down */}
                <path d="M275 240 L275 270" stroke="#2d3748" strokeWidth="3" markerEnd="url(#arrowhead)" />
                
                {/* Image Analysis */}
                <rect x="155" y="270" width="240" height="85" rx="8" fill="white" stroke={activeCategory === 1 || activeCategory === 6 ? "#8b4513" : "#94a3b8"} strokeWidth="3" />
                <g transform="translate(180, 295)">
                  <path d="M0,0 L8,0 L8,8 L0,8 Z M3,3 L5,3 L5,5 L3,5 Z" fill="#8b4513" />
                </g>
                <text x="275" y="298" textAnchor="middle" fontSize="16" fontWeight="bold" fill="#2d3748">Image Analysis</text>
                <text x="275" y="316" textAnchor="middle" fontSize="13" fill="#4a5568">Filtering & Preprocessing</text>
                <text x="275" y="332" textAnchor="middle" fontSize="13" fill="#4a5568">Segmentation</text>
                <text x="275" y="348" textAnchor="middle" fontSize="13" fill="#4a5568">Feature Extraction</text>
                
                {/* Arrow down */}
                <path d="M275 355 L275 385" stroke="#2d3748" strokeWidth="3" markerEnd="url(#arrowhead)" />
                
                {/* Visualization */}
                <rect x="125" y="385" width="300" height="105" rx="8" fill="white" stroke={activeCategory === 1 || activeCategory === 6 ? "#7c3aed" : "#94a3b8"} strokeWidth="3" />
                <g transform="translate(150, 410)">
                  <rect x="-5" y="-5" width="10" height="10" fill="#7c3aed" />
                  <rect x="-3" y="-3" width="6" height="6" fill="white" />
                </g>
                <text x="275" y="413" textAnchor="middle" fontSize="16" fontWeight="bold" fill="#2d3748">Visualization Techniques</text>
                <text x="275" y="432" textAnchor="middle" fontSize="13" fill="#4a5568">Volume Rendering</text>
                <text x="275" y="448" textAnchor="middle" fontSize="13" fill="#4a5568">Slice Views</text>
                <text x="275" y="464" textAnchor="middle" fontSize="13" fill="#4a5568">Cinematic Rendering</text>
                <text x="275" y="480" textAnchor="middle" fontSize="13" fill="#4a5568">Blood Flow Visualization</text>
                
                {/* Arrow down */}
                <path d="M275 490 L275 520" stroke="#2d3748" strokeWidth="3" markerEnd="url(#arrowhead)" />
                
                {/* Users */}
                <rect x="100" y="520" width="350" height="85" rx="8" fill="white" stroke={activeCategory === 5 ? "#ef4444" : "#94a3b8"} strokeWidth="3" />
                <g transform="translate(125, 545)">
                  <circle cx="0" cy="-3" r="5" fill="#ef4444" />
                  <path d="M-7,5 Q-7,0 0,0 Q7,0 7,5 L7,8 L-7,8 Z" fill="#ef4444" />
                </g>
                <text x="275" y="548" textAnchor="middle" fontSize="16" fontWeight="bold" fill="#2d3748">End Users</text>
                <text x="275" y="567" textAnchor="middle" fontSize="13" fill="#4a5568">Radiologists • Surgeons</text>
                <text x="275" y="583" textAnchor="middle" fontSize="13" fill="#4a5568">Medical Students • Patients</text>
                <text x="275" y="599" textAnchor="middle" fontSize="13" fill="#4a5568">Clinical Experts</text>
                
                {/* Side annotations with icons */}
                {activeCategory === 2 && (
                  <>
                    <rect x="70" y="220" width="70" height="80" rx="5" fill="white" stroke="#10b981" strokeWidth="2" />
                    <g transform="translate(105, 245)">
                      <circle cx="0" cy="0" r="12" fill="#10b98120" />
                      <path d="M-6,-3 Q0,-8 6,-3 Q0,2 -6,-3" fill="#10b981" />
                      <circle cx="0" cy="-3" r="2.5" fill="#10b981" />
                    </g>
                    <text x="105" y="270" textAnchor="middle" fontSize="11" fill="#2d3748" fontWeight="bold">Making</text>
                    <text x="105" y="283" textAnchor="middle" fontSize="11" fill="#2d3748" fontWeight="bold">the unseen</text>
                    <text x="105" y="296" textAnchor="middle" fontSize="11" fill="#2d3748" fontWeight="bold">visible</text>
                  </>
                )}
                
                {activeCategory === 3 && (
                  <>
                    <rect x="430" y="160" width="90" height="90" rx="5" fill="white" stroke="#8b4513" strokeWidth="2" />
                    <g transform="translate(475, 185)">
                      <circle cx="0" cy="0" r="12" fill="#8b451320" />
                      <path d="M-8,0 L-3,-8 L3,-8 L8,0 L3,8 L-3,8 Z" fill="none" stroke="#8b4513" strokeWidth="1.5" />
                      <circle cx="0" cy="0" r="3" fill="#8b4513" />
                    </g>
                    <text x="475" y="210" textAnchor="middle" fontSize="11" fill="#2d3748" fontWeight="bold">Historical</text>
                    <text x="475" y="223" textAnchor="middle" fontSize="10" fill="#4a5568">6th century BC</text>
                    <text x="475" y="236" textAnchor="middle" fontSize="10" fill="#4a5568">Da Vinci, Gray</text>
                    <text x="475" y="249" textAnchor="middle" fontSize="10" fill="#4a5568">Napoleon</text>
                  </>
                )}
                
                {activeCategory === 7 && (
                  <>
                    <rect x="440" y="410" width="85" height="75" rx="8" fill="white" stroke="#0891b2" strokeWidth="2" />
                    <g transform="translate(482, 432)">
                      <path d="M0,-8 L-7,8 L7,8 Z" fill="#0891b2" opacity="0.3" />
                      <path d="M-4,0 L0,-4 L4,0 M-4,4 L0,0 L4,4" stroke="#0891b2" strokeWidth="1.5" fill="none" />
                    </g>
                    <text x="482" y="455" textAnchor="middle" fontSize="11" fill="#2d3748" fontWeight="bold">Benefits</text>
                    <text x="482" y="468" textAnchor="middle" fontSize="9" fill="#4a5568">Rich info</text>
                    <text x="482" y="479" textAnchor="middle" fontSize="9" fill="#4a5568">Accessible</text>
                    
                    <rect x="25" y="410" width="85" height="75" rx="8" fill="white" stroke="#0891b2" strokeWidth="2" />
                    <g transform="translate(67, 432)">
                      <circle cx="0" cy="0" r="10" fill="none" stroke="#0891b2" strokeWidth="1.5" />
                      <path d="M-3,-3 L3,3 M3,-3 L-3,3" stroke="#0891b2" strokeWidth="2" />
                    </g>
                    <text x="67" y="455" textAnchor="middle" fontSize="11" fill="#2d3748" fontWeight="bold">Caution</text>
                    <text x="67" y="468" textAnchor="middle" fontSize="9" fill="#4a5568">Can mislead</text>
                    <text x="67" y="479" textAnchor="middle" fontSize="9" fill="#4a5568">Vis-lies</text>
                  </>
                )}
                
                {/* Arrow marker definition */}
                <defs>
                  <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                    <polygon points="0 0, 10 3, 0 6" fill="#2d3748" />
                  </marker>
                </defs>
                
                {/* Computer Graphics box - FIXED: Now separate box on the right side with INCREASED HEIGHT */}
                {activeCategory === 6 && (
                  <>
                    <rect x="430" y="270" width="95" height="95" rx="8" fill="white" stroke="#7c3aed" strokeWidth="2" strokeDasharray="5,5" />
                    <g transform="translate(477, 298)">
                      <circle cx="0" cy="0" r="12" fill="#7c3aed20" />
                      <rect x="-6" y="-6" width="12" height="12" fill="#7c3aed" opacity="0.3" />
                      <path d="M-4,-4 L4,-4 L4,4 L-4,4 Z" fill="none" stroke="#7c3aed" strokeWidth="1.5" />
                    </g>
                    <text x="477" y="323" textAnchor="middle" fontSize="11" fill="#7c3aed" fontWeight="bold">Computer</text>
                    <text x="477" y="336" textAnchor="middle" fontSize="11" fill="#7c3aed" fontWeight="bold">Graphics</text>
                    <text x="477" y="351" textAnchor="middle" fontSize="9" fill="#6b21a8">Aesthetics &</text>
                    <text x="477" y="362" textAnchor="middle" fontSize="9" fill="#6b21a8">Simulation</text>
                  </>
                )}
              </svg>
            </div>
          </div>
        </div>
      </div>
      
      {/* Modern Tooltip - RESPONSIVE */}
      {hoveredKeyword && (
        <div 
          className="fixed z-50 bg-white rounded-xl shadow-2xl border-2 p-3 sm:p-5 max-w-[90vw] sm:max-w-md pointer-events-none transform -translate-x-1/2 -translate-y-full transition-all duration-200 ease-out"
          style={{ 
            left: tooltipPosition.x,
            top: tooltipPosition.y - 15,
            borderColor: category.color,
            boxShadow: `0 20px 40px -10px ${category.color}40`
          }}
        >
          <div 
            className="absolute left-1/2 transform -translate-x-1/2 top-full"
            style={{
              width: 0,
              height: 0,
              borderLeft: '10px solid transparent',
              borderRight: '10px solid transparent',
              borderTop: `10px solid ${category.color}`
            }}
          />
          
          <div className="flex items-center gap-2 mb-2 sm:mb-3">
            <div style={{ color: category.color }} className="flex-shrink-0">
              {getKeywordIcon(hoveredKeyword.name)}
            </div>
            <div className="font-semibold text-gray-800 text-sm sm:text-base" style={{ color: category.color }}>
              {hoveredKeyword.name}
            </div>
          </div>
          <div className="text-xs sm:text-sm text-gray-700 leading-relaxed mb-2 sm:mb-3">
            {hoveredKeyword.description}
          </div>
          <div className="text-xs text-gray-500 font-mono border-t pt-2">
            ⏱ {hoveredKeyword.timecode}
          </div>
        </div>
      )}
    </div>
  );
}