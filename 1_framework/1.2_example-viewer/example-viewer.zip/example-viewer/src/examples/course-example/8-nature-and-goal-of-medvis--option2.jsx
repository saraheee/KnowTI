import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Info, ChevronRight } from 'lucide-react';

const MedicalVisualizationPipeline = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStage, setCurrentStage] = useState(0);
  const [progress, setProgress] = useState(0);
  const [animationSpeed, setAnimationSpeed] = useState(1);
  const [hoveredElement, setHoveredElement] = useState(null);

  // Pipeline stages
  const stages = [
    {
      id: 'acquisition',
      name: 'Data Acquisition',
      description: 'Raw medical imaging data captured from scanning devices',
      icon: '🔬',
      color: '#64748b',
      details: [
        'CT/MRI scanner captures volumetric data',
        'Resolution: 512×512×300 voxels typical',
        'Raw DICOM format with metadata'
      ]
    },
    {
      id: 'processing',
      name: 'Data Processing',
      description: 'Noise reduction, normalization, and enhancement of raw data',
      icon: '⚙️',
      color: '#3b82f6',
      details: [
        'Noise filtering and artifact removal',
        'Intensity normalization across slices',
        'Contrast enhancement for features'
      ]
    },
    {
      id: 'segmentation',
      name: 'Segmentation',
      description: 'Identification and labeling of anatomical structures',
      icon: '🎯',
      color: '#8b5cf6',
      details: [
        'Automated/semi-automated region detection',
        'Boundary delineation of organs',
        'Classification of tissue types'
      ]
    },
    {
      id: 'rendering',
      name: '3D Rendering',
      description: 'Creation of visual representation for medical interpretation',
      icon: '🎨',
      color: '#10b981',
      details: [
        'Volume rendering or surface extraction',
        'Lighting and shading for depth perception',
        'Interactive 3D visualization'
      ]
    }
  ];

  // SIMPLIFIED Animation loop - PROPERLY FIXED
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setProgress(prevProgress => {
        if (prevProgress >= 100) {
          // Don't increment if we're already at 100
          return prevProgress;
        }
        
        const newProgress = prevProgress + (2 * animationSpeed);
        return Math.min(newProgress, 100);
      });
    }, 50);

    return () => clearInterval(interval);
  }, [isPlaying, animationSpeed]);

  // Separate effect to handle stage transitions
  useEffect(() => {
    if (progress >= 100 && isPlaying) {
      if (currentStage < stages.length - 1) {
        // Move to next stage after a brief delay
        const timeout = setTimeout(() => {
          setCurrentStage(prev => prev + 1);
          setProgress(0);
        }, 500);
        
        return () => clearTimeout(timeout);
      } else {
        // Animation complete
        setIsPlaying(false);
      }
    }
  }, [progress, isPlaying, currentStage, stages.length]);

  const handleReset = () => {
    setIsPlaying(false);
    setCurrentStage(0);
    setProgress(0);
  };

  const handleStageClick = (index) => {
    setCurrentStage(index);
    setProgress(0);
    setIsPlaying(false);
  };

  // Visualization of data at each stage
  const DataVisualization = ({ stage, progress }) => {
    console.log('Rendering stage:', stage, 'with progress:', progress);
    
    return (
      <svg width="700" height="400" className="bg-gray-900 rounded-lg">
        {/* Stage 0: Raw Acquisition */}
        {stage === 0 && (
          <g>
            {/* Noisy grayscale data */}
            {Array.from({ length: 80 }, (_, i) => {
              const x = 50 + (i % 20) * 30;
              const y = 50 + Math.floor(i / 20) * 30;
              const noise = Math.random() * 0.5;
              const intensity = 0.3 + noise;
              return (
                <rect
                  key={i}
                  x={x}
                  y={y}
                  width="25"
                  height="25"
                  fill={`rgba(255,255,255,${intensity})`}
                  opacity={Math.min(progress / 100, 1)}
                >
                  <animate
                    attributeName="opacity"
                    values={`${intensity};${intensity + 0.1};${intensity}`}
                    dur="2s"
                    repeatCount="indefinite"
                  />
                </rect>
              );
            })}
            {/* Scanner grid overlay */}
            <g opacity="0.3">
              {Array.from({ length: 20 }, (_, i) => (
                <line
                  key={`v-${i}`}
                  x1={50 + i * 30}
                  y1="50"
                  x2={50 + i * 30}
                  y2="350"
                  stroke="#60a5fa"
                  strokeWidth="0.5"
                />
              ))}
              {Array.from({ length: 12 }, (_, i) => (
                <line
                  key={`h-${i}`}
                  x1="50"
                  y1={50 + i * 30}
                  x2="650"
                  y2={50 + i * 30}
                  stroke="#60a5fa"
                  strokeWidth="0.5"
                />
              ))}
            </g>
            <text x="350" y="380" fill="#94a3b8" fontSize="14" textAnchor="middle">
              Raw Voxel Data - Unprocessed
            </text>
          </g>
        )}

        {/* Stage 1: Processing */}
        {stage === 1 && (
          <g>
            {/* Cleaner, normalized data */}
            {Array.from({ length: 80 }, (_, i) => {
              const x = 50 + (i % 20) * 30;
              const y = 50 + Math.floor(i / 20) * 30;
              const isAnatomyRegion = (i % 20 > 6 && i % 20 < 14) && (Math.floor(i / 20) > 1 && Math.floor(i / 20) < 6);
              const intensity = isAnatomyRegion ? 0.7 : 0.2;
              const processedIntensity = intensity * (progress / 100);
              return (
                <rect
                  key={i}
                  x={x}
                  y={y}
                  width="25"
                  height="25"
                  fill={`rgba(100,181,246,${processedIntensity})`}
                  opacity={Math.min(progress / 100, 1)}
                />
              );
            })}
            {/* Processing wave effect */}
            <line
              x1="50"
              y1={50 + (progress / 100) * 300}
              x2="650"
              y2={50 + (progress / 100) * 300}
              stroke="#3b82f6"
              strokeWidth="3"
              opacity="0.6"
            />
            <text x="350" y="380" fill="#94a3b8" fontSize="14" textAnchor="middle">
              Enhanced & Normalized Data
            </text>
          </g>
        )}

        {/* Stage 2: Segmentation */}
        {stage === 2 && (
          <g>
            {/* Heart - anatomical shape */}
            <path
              d="M 350 260 
                 C 350 260, 320 240, 310 210
                 C 300 180, 310 160, 330 160
                 C 345 160, 350 170, 350 170
                 C 350 170, 355 160, 370 160
                 C 390 160, 400 180, 390 210
                 C 380 240, 350 260, 350 260 Z"
              fill="#dc2626"
              opacity={Math.min((progress / 100) * 0.3, 0.3)}
            />
            <path
              d="M 350 260 
                 C 350 260, 320 240, 310 210
                 C 300 180, 310 160, 330 160
                 C 345 160, 350 170, 350 170
                 C 350 170, 355 160, 370 160
                 C 390 160, 400 180, 390 210
                 C 380 240, 350 260, 350 260 Z"
              fill="none"
              stroke="#ef4444"
              strokeWidth="3"
              opacity={Math.min(progress / 100, 1)}
              strokeDasharray={`${(progress / 100) * 500}, 500`}
            />
            
            {/* Left Lung - anatomical shape */}
            {progress > 30 && (
              <>
                <path
                  d="M 230 150
                     C 210 150, 200 160, 200 180
                     C 200 200, 200 240, 210 260
                     C 220 280, 240 290, 260 285
                     C 270 282, 275 275, 275 260
                     C 275 240, 270 200, 265 180
                     C 260 160, 250 150, 230 150 Z"
                  fill="#3b82f6"
                  opacity={Math.min((progress - 30) / 70 * 0.3, 0.3)}
                />
                <path
                  d="M 230 150
                     C 210 150, 200 160, 200 180
                     C 200 200, 200 240, 210 260
                     C 220 280, 240 290, 260 285
                     C 270 282, 275 275, 275 260
                     C 275 240, 270 200, 265 180
                     C 260 160, 250 150, 230 150 Z"
                  fill="none"
                  stroke="#3b82f6"
                  strokeWidth="2.5"
                  opacity={Math.min((progress - 30) / 70, 1)}
                  strokeDasharray={`${((progress - 30) / 70) * 400}, 400`}
                />
              </>
            )}
            
            {/* Right Lung - anatomical shape */}
            {progress > 60 && (
              <>
                <path
                  d="M 470 150
                     C 490 150, 500 160, 500 180
                     C 500 200, 500 240, 490 260
                     C 480 280, 460 290, 440 285
                     C 430 282, 425 275, 425 260
                     C 425 240, 430 200, 435 180
                     C 440 160, 450 150, 470 150 Z"
                  fill="#10b981"
                  opacity={Math.min((progress - 60) / 40 * 0.3, 0.3)}
                />
                <path
                  d="M 470 150
                     C 490 150, 500 160, 500 180
                     C 500 200, 500 240, 490 260
                     C 480 280, 460 290, 440 285
                     C 430 282, 425 275, 425 260
                     C 425 240, 430 200, 435 180
                     C 440 160, 450 150, 470 150 Z"
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="2.5"
                  opacity={Math.min((progress - 60) / 40, 1)}
                  strokeDasharray={`${((progress - 60) / 40) * 400}, 400`}
                />
              </>
            )}

            {/* Labels */}
            {progress > 80 && (
              <g opacity={Math.min((progress - 80) / 20, 1)}>
                <text x="350" y="215" fill="#fca5a5" fontSize="13" textAnchor="middle" fontWeight="700">Heart</text>
                <text x="237" y="220" fill="#93c5fd" fontSize="12" textAnchor="middle" fontWeight="700">Left Lung</text>
                <text x="463" y="220" fill="#6ee7b7" fontSize="12" textAnchor="middle" fontWeight="700">Right Lung</text>
              </g>
            )}
            
            <text x="350" y="380" fill="#94a3b8" fontSize="14" textAnchor="middle">
              Segmented Anatomical Structures
            </text>
          </g>
        )}

        {/* Stage 3: Rendering */}
        {stage === 3 && (
          <g>
            {/* Heart - realistic 3D rendering */}
            <g opacity={Math.min(progress / 100, 1)}>
              {/* Heart base shadow */}
              <ellipse
                cx="350"
                cy="270"
                rx="65"
                ry="15"
                fill="#000"
                opacity="0.2"
              />
              
              {/* Heart main body */}
              <path
                d="M 350 270
                   C 350 270, 315 245, 305 210
                   C 295 175, 305 150, 330 150
                   C 345 150, 350 162, 350 162
                   C 350 162, 355 150, 370 150
                   C 395 150, 405 175, 395 210
                   C 385 245, 350 270, 350 270 Z"
                fill="url(#heartGradient3D)"
              />
              
              {/* Heart highlight for 3D effect */}
              <ellipse
                cx="340"
                cy="180"
                rx="35"
                ry="30"
                fill="url(#heartHighlight3D)"
                opacity="0.4"
              />
              
              {/* Cardiac chambers detail */}
              <path
                d="M 335 200 Q 350 210, 365 200"
                stroke="#7f1d1d"
                strokeWidth="1.5"
                fill="none"
                opacity="0.6"
              />
              
              {/* Left ventricle detail */}
              <ellipse
                cx="340"
                cy="220"
                rx="18"
                ry="22"
                fill="none"
                stroke="#991b1b"
                strokeWidth="1"
                opacity="0.5"
              />
              
              {/* Right ventricle detail */}
              <ellipse
                cx="360"
                cy="220"
                rx="15"
                ry="20"
                fill="none"
                stroke="#991b1b"
                strokeWidth="1"
                opacity="0.5"
              />
            </g>
            
            {/* Left Lung - realistic 3D rendering */}
            {progress > 25 && (
              <g opacity={Math.min((progress - 25) / 75, 1)}>
                {/* Lung shadow */}
                <ellipse
                  cx="245"
                  cy="285"
                  rx="40"
                  ry="12"
                  fill="#000"
                  opacity="0.15"
                />
                
                {/* Lung main body */}
                <path
                  d="M 235 160
                     C 210 160, 195 175, 195 200
                     C 195 220, 195 250, 205 270
                     C 215 290, 235 300, 260 295
                     C 275 292, 282 283, 282 265
                     C 282 245, 277 210, 272 185
                     C 267 165, 255 160, 235 160 Z"
                  fill="url(#lungGradient3D)"
                />
                
                {/* Lung highlight */}
                <ellipse
                  cx="225"
                  cy="200"
                  rx="30"
                  ry="35"
                  fill="url(#lungHighlight3D)"
                  opacity="0.35"
                />
                
                {/* Lung lobes detail */}
                <path
                  d="M 210 190 Q 240 200, 265 210"
                  stroke="#1e40af"
                  strokeWidth="1.5"
                  fill="none"
                  opacity="0.4"
                />
                <path
                  d="M 210 230 Q 235 235, 260 240"
                  stroke="#1e40af"
                  strokeWidth="1.5"
                  fill="none"
                  opacity="0.4"
                />
              </g>
            )}
            
            {/* Right Lung - realistic 3D rendering */}
            {progress > 25 && (
              <g opacity={Math.min((progress - 25) / 75, 1)}>
                {/* Lung shadow */}
                <ellipse
                  cx="455"
                  cy="285"
                  rx="40"
                  ry="12"
                  fill="#000"
                  opacity="0.15"
                />
                
                {/* Lung main body */}
                <path
                  d="M 465 160
                     C 490 160, 505 175, 505 200
                     C 505 220, 505 250, 495 270
                     C 485 290, 465 300, 440 295
                     C 425 292, 418 283, 418 265
                     C 418 245, 423 210, 428 185
                     C 433 165, 445 160, 465 160 Z"
                  fill="url(#lungGradient3D)"
                />
                
                {/* Lung highlight */}
                <ellipse
                  cx="475"
                  cy="200"
                  rx="30"
                  ry="35"
                  fill="url(#lungHighlight3D)"
                  opacity="0.35"
                />
                
                {/* Lung lobes detail */}
                <path
                  d="M 490 190 Q 460 200, 435 210"
                  stroke="#1e40af"
                  strokeWidth="1.5"
                  fill="none"
                  opacity="0.4"
                />
                <path
                  d="M 490 230 Q 465 235, 440 240"
                  stroke="#1e40af"
                  strokeWidth="1.5"
                  fill="none"
                  opacity="0.4"
                />
                <path
                  d="M 485 255 Q 465 258, 445 260"
                  stroke="#1e40af"
                  strokeWidth="1.5"
                  fill="none"
                  opacity="0.4"
                />
              </g>
            )}

            {/* Vascular structure - enhanced */}
            {progress > 50 && (
              <g opacity={Math.min((progress - 50) / 50, 1)}>
                {/* Aorta */}
                <path
                  d="M 350 155 Q 342 135, 328 120"
                  stroke="url(#aortaGradient)"
                  strokeWidth="8"
                  fill="none"
                  strokeLinecap="round"
                />
                {/* Aorta highlight */}
                <path
                  d="M 348 155 Q 340 137, 328 122"
                  stroke="#fca5a5"
                  strokeWidth="3"
                  fill="none"
                  strokeLinecap="round"
                  opacity="0.6"
                />
                
                {/* Pulmonary artery */}
                <path
                  d="M 350 155 Q 358 135, 372 120"
                  stroke="url(#pulmonaryGradient)"
                  strokeWidth="7"
                  fill="none"
                  strokeLinecap="round"
                />
                {/* Pulmonary highlight */}
                <path
                  d="M 352 155 Q 360 137, 372 122"
                  stroke="#93c5fd"
                  strokeWidth="2.5"
                  fill="none"
                  strokeLinecap="round"
                  opacity="0.6"
                />
                
                {/* Superior vena cava */}
                <path
                  d="M 365 155 L 375 130"
                  stroke="#60a5fa"
                  strokeWidth="5"
                  fill="none"
                  strokeLinecap="round"
                  opacity="0.8"
                />
              </g>
            )}

            {/* Labels with better positioning */}
            {progress > 70 && (
              <g opacity={Math.min((progress - 70) / 30, 1)}>
                <text x="350" y="245" fill="#fff" fontSize="14" textAnchor="middle" fontWeight="700" 
                      stroke="#7f1d1d" strokeWidth="0.5">Heart</text>
                <text x="240" y="230" fill="#fff" fontSize="13" textAnchor="middle" fontWeight="700"
                      stroke="#1e40af" strokeWidth="0.5">Left Lung</text>
                <text x="460" y="230" fill="#fff" fontSize="13" textAnchor="middle" fontWeight="700"
                      stroke="#1e40af" strokeWidth="0.5">Right Lung</text>
              </g>
            )}

            <text x="350" y="380" fill="#94a3b8" fontSize="14" textAnchor="middle">
              Clinically Interpretable 3D Model
            </text>

            {/* Enhanced Gradients */}
            <defs>
              <radialGradient id="heartGradient3D">
                <stop offset="0%" stopColor="#ef4444" />
                <stop offset="50%" stopColor="#dc2626" />
                <stop offset="100%" stopColor="#991b1d" />
              </radialGradient>
              <radialGradient id="heartHighlight3D">
                <stop offset="0%" stopColor="#fca5a5" />
                <stop offset="100%" stopColor="#ef4444" opacity="0" />
              </radialGradient>
              <radialGradient id="lungGradient3D">
                <stop offset="0%" stopColor="#60a5fa" />
                <stop offset="50%" stopColor="#3b82f6" />
                <stop offset="100%" stopColor="#1e40af" />
              </radialGradient>
              <radialGradient id="lungHighlight3D">
                <stop offset="0%" stopColor="#bfdbfe" />
                <stop offset="100%" stopColor="#60a5fa" opacity="0" />
              </radialGradient>
              <linearGradient id="aortaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#dc2626" />
                <stop offset="100%" stopColor="#7f1d1d" />
              </linearGradient>
              <linearGradient id="pulmonaryGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" />
                <stop offset="100%" stopColor="#1e40af" />
              </linearGradient>
            </defs>
          </g>
        )}
      </svg>
    );
  };

  const InfoTooltip = ({ element }) => {
    if (!element) return null;
    const info = stages.find(s => s.id === element);
    if (!info) return null;

    return (
      <div 
        className="absolute top-4 right-4 bg-white border-2 border-blue-500 rounded-xl p-4 shadow-2xl z-20 animate-in fade-in duration-200"
        style={{ width: '320px' }}
      >
        <div className="flex items-start gap-3 mb-3">
          <div className="text-3xl">{info.icon}</div>
          <div className="flex-1">
            <h3 className="font-bold text-gray-800 text-base mb-1">{info.name}</h3>
            <p className="text-xs text-gray-600 leading-relaxed">{info.description}</p>
          </div>
        </div>
        
        {/* Visual representation */}
        <div className="mb-3 p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
          <svg width="280" height="60">
            {element === 'acquisition' && (
              <g>
                <rect x="10" y="10" width="260" height="40" fill="#64748b" opacity="0.3" rx="5" />
                {Array.from({ length: 12 }, (_, i) => (
                  <circle
                    key={i}
                    cx={30 + i * 22}
                    cy={30}
                    r="3"
                    fill="#94a3b8"
                    opacity={0.3 + Math.random() * 0.4}
                  >
                    <animate
                      attributeName="opacity"
                      values="0.3;0.8;0.3"
                      dur={`${1 + Math.random()}s`}
                      repeatCount="indefinite"
                    />
                  </circle>
                ))}
                <text x="140" y="65" fontSize="10" fill="#64748b" textAnchor="middle">Raw Scanner Data</text>
              </g>
            )}

            {element === 'processing' && (
              <g>
                <rect x="10" y="20" width="120" height="25" fill="#64748b" opacity="0.3" rx="3" />
                <path d="M 135 32 L 160 32" stroke="#3b82f6" strokeWidth="2" markerEnd="url(#arrowProc)" />
                <rect x="165" y="20" width="120" height="25" fill="#3b82f6" opacity="0.4" rx="3" />
                <defs>
                  <marker id="arrowProc" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                    <polygon points="0 0, 10 3, 0 6" fill="#3b82f6" />
                  </marker>
                </defs>
                <text x="70" y="37" fontSize="9" fill="#64748b" textAnchor="middle">Noisy</text>
                <text x="225" y="37" fontSize="9" fill="#1e40af" textAnchor="middle" fontWeight="600">Enhanced</text>
              </g>
            )}

            {element === 'segmentation' && (
              <g>
                <circle cx="70" cy="30" r="20" fill="#ef4444" opacity="0.3" />
                <circle cx="140" cy="30" r="15" fill="#3b82f6" opacity="0.3" />
                <circle cx="210" cy="30" r="15" fill="#10b981" opacity="0.3" />
                <text x="70" y="33" fontSize="9" fill="#dc2626" textAnchor="middle" fontWeight="600">1</text>
                <text x="140" y="33" fontSize="9" fill="#1e40af" textAnchor="middle" fontWeight="600">2</text>
                <text x="210" y="33" fontSize="9" fill="#059669" textAnchor="middle" fontWeight="600">3</text>
                <text x="140" y="55" fontSize="9" fill="#64748b" textAnchor="middle">Labeled Regions</text>
              </g>
            )}

            {element === 'rendering' && (
              <g>
                <ellipse cx="70" cy="30" rx="25" ry="20" fill="url(#renderHeart)" />
                <ellipse cx="140" cy="30" rx="20" ry="18" fill="url(#renderLung1)" />
                <ellipse cx="210" cy="30" rx="20" ry="18" fill="url(#renderLung2)" />
                <circle cx="60" cy="22" r="8" fill="#fca5a5" opacity="0.6" />
                <defs>
                  <radialGradient id="renderHeart">
                    <stop offset="0%" stopColor="#ef4444" />
                    <stop offset="100%" stopColor="#991b1b" />
                  </radialGradient>
                  <radialGradient id="renderLung1">
                    <stop offset="0%" stopColor="#60a5fa" />
                    <stop offset="100%" stopColor="#1e40af" />
                  </radialGradient>
                  <radialGradient id="renderLung2">
                    <stop offset="0%" stopColor="#34d399" />
                    <stop offset="100%" stopColor="#059669" />
                  </radialGradient>
                </defs>
                <text x="140" y="55" fontSize="9" fill="#64748b" textAnchor="middle">3D Visualization</text>
              </g>
            )}
          </svg>
        </div>

        <div className="space-y-1.5">
          {info.details.map((detail, i) => (
            <div key={i} className="flex items-start gap-2 text-xs text-gray-700 bg-gray-50 p-2 rounded">
              <span className="text-blue-500 mt-0.5 font-bold">•</span>
              <span className="flex-1">{detail}</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full h-screen bg-white flex flex-col items-center justify-center p-6">
      {/* Header */}
      <div className="mb-4 text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Medical Data Visualization Pipeline
        </h1>
        <p className="text-gray-600 mb-1">
          From Raw Scanner Data to Clinical Interpretation
        </p>
        <p className="text-sm text-blue-600 flex items-center justify-center gap-2">
          <Info size={16} />
          Hover over pipeline stages for detailed information
        </p>
      </div>

      {/* Pipeline Stages */}
      <div className="flex items-center justify-center gap-3 mb-6">
        {stages.map((stage, index) => (
          <React.Fragment key={stage.id}>
            <div
              className={`relative flex flex-col items-center cursor-pointer transition-all duration-300 ${
                currentStage === index ? 'scale-110' : 'scale-100 opacity-70 hover:opacity-100'
              }`}
              onClick={() => handleStageClick(index)}
              onMouseEnter={() => setHoveredElement(stage.id)}
              onMouseLeave={() => setHoveredElement(null)}
            >
              <div
                className={`w-20 h-20 rounded-full flex items-center justify-center text-3xl transition-all duration-300 ${
                  currentStage >= index ? 'shadow-lg' : 'shadow'
                }`}
                style={{
                  backgroundColor: currentStage >= index ? stage.color : '#e5e7eb',
                  border: currentStage === index ? `4px solid ${stage.color}` : '4px solid transparent'
                }}
              >
                {stage.icon}
              </div>
              <div className="mt-2 text-center">
                <div className={`text-sm font-semibold ${currentStage >= index ? 'text-gray-800' : 'text-gray-400'}`}>
                  {stage.name}
                </div>
                {currentStage === index && (
                  <div className="text-xs text-blue-600 font-medium mt-1">
                    {Math.round(progress)}%
                  </div>
                )}
              </div>
            </div>
            {index < stages.length - 1 && (
              <ChevronRight
                size={24}
                className={`${currentStage > index ? 'text-gray-800' : 'text-gray-300'} transition-colors`}
              />
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Main Visualization Area */}
      <div className="relative mb-4">
        <DataVisualization stage={currentStage} progress={progress} />
        <InfoTooltip element={hoveredElement} />
      </div>

      {/* Progress Bar */}
      <div className="bg-white rounded-xl shadow-lg p-4 mb-4" style={{ width: '700px' }}>
        <div className="flex items-center gap-3 mb-2">
          <span className="text-sm font-semibold text-gray-700 min-w-32">
            Stage Progress:
          </span>
          <div className="flex-1 bg-gray-200 rounded-full h-3 overflow-hidden">
            <div
              className="h-full transition-all duration-300 rounded-full"
              style={{
                width: `${progress}%`,
                backgroundColor: stages[currentStage]?.color || '#3b82f6'
              }}
            />
          </div>
          <span className="text-sm font-bold text-gray-800 min-w-12">
            {Math.round(progress)}%
          </span>
        </div>
      </div>

      {/* Speed Control */}
      <div className="bg-white rounded-xl shadow-lg p-4 mb-4 flex items-center gap-4" style={{ width: '700px' }}>
        <div className="flex items-center gap-2 min-w-32">
          <span className="text-sm font-semibold text-gray-700">Animation Speed:</span>
          <span className="text-sm font-bold text-blue-600">{animationSpeed.toFixed(1)}x</span>
        </div>
        <input
          type="range"
          min="0.2"
          max="3"
          step="0.1"
          value={animationSpeed}
          onChange={(e) => setAnimationSpeed(parseFloat(e.target.value))}
          className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          style={{
            background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${((animationSpeed - 0.2) / 2.8) * 100}%, #e5e7eb ${((animationSpeed - 0.2) / 2.8) * 100}%, #e5e7eb 100%)`
          }}
        />
        <div className="flex gap-2 text-xs text-gray-500">
          <span>0.2x</span>
          <span>→</span>
          <span>3.0x</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex gap-4 mb-4">
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-lg"
          disabled={currentStage === stages.length - 1 && progress === 100}
        >
          {isPlaying ? <Pause size={20} /> : <Play size={20} />}
          {isPlaying ? 'Pause' : 'Play'}
        </button>

        <button
          onClick={handleReset}
          className="flex items-center gap-2 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors shadow-lg"
        >
          <RotateCcw size={20} />
          Reset
        </button>
      </div>

      {/* Debug Info */}
      <div className="text-xs text-gray-400 mb-2">
        Current Stage: {currentStage} ({stages[currentStage]?.name}) | Progress: {Math.round(progress)}%
      </div>

      {/* Legend */}
      <div className="text-center text-sm text-gray-600 max-w-3xl">
        <p className="font-semibold mb-2">Medical Visualization Pipeline Process:</p>
        <p>
          Watch how raw medical imaging data transforms through processing stages into clinically interpretable 
          3D visualizations. Each stage applies specific visualization principles to make anatomical structures 
          visible and understandable for medical diagnosis.
        </p>
      </div>
    </div>
  );
};

export default MedicalVisualizationPipeline;