import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, AlertTriangle, Info } from 'lucide-react';

const AorticRegurgitationDetector = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isRegurgitant, setIsRegurgitant] = useState(false);
  const [cyclePhase, setCyclePhase] = useState(0);
  const [animationSpeed, setAnimationSpeed] = useState(1);
  const [particles, setParticles] = useState([]);
  const [backflowCount, setBackflowCount] = useState(0);
  const [hoveredElement, setHoveredElement] = useState(null);
  const animationRef = useRef(null);

  // Initialize particles
  useEffect(() => {
    const initialParticles = Array.from({ length: 80 }, (_, i) => ({
      id: i,
      x: 150,
      y: 250 + (i % 20) * 8,
      vx: 0,
      vy: 0,
      isBackflow: false,
      trail: []
    }));
    setParticles(initialParticles);
  }, []);

  // Get current phase info
  const getPhaseInfo = () => {
    if (cyclePhase < 0.4) {
      return { name: 'Systole', isOpen: true, color: '#ef4444' };
    } else {
      return { name: 'Diastole', isOpen: false, color: '#3b82f6' };
    }
  };

  // Animation loop
  useEffect(() => {
    if (!isPlaying) return;

    const animate = () => {
      setCyclePhase(prev => (prev + 0.01 * animationSpeed) % 1);
      
      setParticles(prevParticles => {
        let backflowCounter = 0;

        const updated = prevParticles.map(p => {
          let newX = p.x;
          let newY = p.y;
          let newVx = p.vx;
          let newVy = p.vy;
          let isBackflow = false;

          const phase = getPhaseInfo();
          
          // In left ventricle (source)
          if (newX < 250) {
            if (phase.isOpen) {
              // Systole - push forward
              newVx = (3 + Math.sin(cyclePhase * Math.PI * 5) * 0.5) * animationSpeed;
            } else {
              // Diastole - no forward flow
              newVx *= 0.9;
            }
          }

          // At valve region
          if (newX >= 250 && newX < 280) {
            if (phase.isOpen) {
              // Valve open - allow through
              newVx = 3.5 * animationSpeed;
            } else {
              // Valve closed
              if (isRegurgitant) {
                // Regurgitation - flow backwards
                newVx = -2.5 * animationSpeed;
                isBackflow = true;
                backflowCounter++;
              } else {
                // Normal - stop flow
                newVx = 0;
                newX = 250;
              }
            }
          }

          // In aorta (right side)
          if (newX >= 280 && newX < 650) {
            if (!phase.isOpen && isRegurgitant) {
              // Continue backflow in aorta during diastole
              newVx = -2 * animationSpeed;
              isBackflow = true;
            } else if (phase.isOpen) {
              // Normal forward flow during systole
              newVx = 2.5 * animationSpeed;
            } else {
              // Normal diastole - minimal forward drift
              newVx = 0.5 * animationSpeed;
            }
          }

          // Apply velocity
          newX += newVx;
          newY += (Math.sin(newX * 0.05 + p.id) * 0.3);

          // Friction
          newVx *= 0.98;

          // Update trail
          let newTrail = [...p.trail, { x: newX, y: newY }];
          if (newTrail.length > 15) newTrail.shift();

          // Reset particles that exit boundaries
          if (newX > 650 || (newX < 140 && isBackflow)) {
            newX = 150;
            newY = 250 + (p.id % 20) * 8;
            newVx = 0;
            newVy = 0;
            isBackflow = false;
            newTrail = [];
          }

          return {
            ...p,
            x: newX,
            y: newY,
            vx: newVx,
            vy: newVy,
            isBackflow,
            trail: newTrail
          };
        });

        setBackflowCount(backflowCounter);
        return updated;
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationRef.current);
  }, [isPlaying, cyclePhase, isRegurgitant, animationSpeed]);

  const handleReset = () => {
    setIsPlaying(false);
    setCyclePhase(0);
    setBackflowCount(0);
    const resetParticles = Array.from({ length: 80 }, (_, i) => ({
      id: i,
      x: 150,
      y: 250 + (i % 20) * 8,
      vx: 0,
      vy: 0,
      isBackflow: false,
      trail: []
    }));
    setParticles(resetParticles);
  };

  const phaseInfo = getPhaseInfo();

  // Information content for each element
  const infoContent = {
    ventricle: {
      title: "Left Ventricle",
      description: "The heart's main pumping chamber that contracts during systole to eject blood through the aortic valve.",
      details: [
        "Normal ejection fraction: 55-70%",
        "Contracts ~70 times per minute at rest",
        "Generates pressure up to 120 mmHg"
      ],
      icon: "❤️"
    },
    valve: {
      title: "Aortic Valve",
      description: isRegurgitant 
        ? "Currently showing REGURGITATION: incomplete closure allows backward flow during diastole."
        : "Normal competent valve: opens during systole, closes completely during diastole to prevent backflow.",
      details: isRegurgitant 
        ? [
            "⚠️ Incomplete leaflet coaptation",
            "Causes: calcification, endocarditis, dilation",
            "Results in volume overload of left ventricle"
          ]
        : [
            "Three cusps (leaflets) ensure complete closure",
            "Opens at ~80 mmHg pressure",
            "Closes in <50 milliseconds"
          ],
      icon: isRegurgitant ? "🔴" : "🟢"
    },
    aorta: {
      title: "Aorta",
      description: "The body's largest artery carrying oxygenated blood from the heart to systemic circulation.",
      details: [
        "Diameter: ~3 cm in ascending portion",
        "Blood velocity: 1-1.5 m/s during systole",
        "Elastic walls accommodate pressure changes"
      ],
      icon: "🫀"
    },
    normalFlow: {
      title: "Normal Forward Flow",
      description: "Healthy unidirectional blood flow from ventricle through valve into aorta.",
      details: [
        "Laminar flow pattern",
        "Velocity: ~1.0 m/s average",
        "No turbulence or reversal"
      ],
      icon: "🔵"
    },
    backflow: {
      title: "Abnormal Backflow",
      description: "Pathological retrograde flow indicating aortic regurgitation.",
      details: [
        "⚠️ Occurs only during diastole",
        "Severity measured by regurgitant fraction",
        "Causes left ventricular dilation over time"
      ],
      icon: "🔴"
    },
    systole: {
      title: "Systole Phase",
      description: "Ventricular contraction phase when blood is actively ejected into the aorta.",
      details: [
        "Duration: ~300ms (40% of cardiac cycle)",
        "Valve opens to allow forward flow",
        "Peak pressure: 120 mmHg"
      ],
      icon: "💪"
    },
    diastole: {
      title: "Diastole Phase",
      description: "Ventricular relaxation phase when the chamber refills with blood.",
      details: [
        "Duration: ~500ms (60% of cardiac cycle)",
        "Valve should close completely",
        "Pressure drops to ~80 mmHg"
      ],
      icon: "💙"
    }
  };

  const InfoTooltip = ({ element }) => {
    if (!element) return null;
    const info = infoContent[element];
    if (!info) return null;

    return (
      <div 
        className="absolute top-4 right-4 bg-white border-2 border-blue-500 rounded-xl p-4 shadow-2xl z-20 animate-in fade-in duration-200"
        style={{ width: '320px' }}
      >
        <div className="flex items-start gap-3 mb-3">
          <div className="text-3xl">{info.icon}</div>
          <div className="flex-1">
            <h3 className="font-bold text-gray-800 text-base mb-1">{info.title}</h3>
            <p className="text-xs text-gray-600 leading-relaxed">{info.description}</p>
          </div>
        </div>
        
        {/* Visual representation */}
        <div className="mb-3 p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
          <svg width="280" height="50" className="mx-auto">
            {element === 'ventricle' && (
              <>
                <ellipse cx="40" cy="25" rx="30" ry="20" fill="#ef4444" opacity="0.3" />
                <text x="40" y="30" fontSize="12" fill="#991b1b" textAnchor="middle" fontWeight="600">LV</text>
                <path d="M 75 25 L 110 25" stroke="#3b82f6" strokeWidth="2" markerEnd="url(#arrowblue)" />
                <defs>
                  <marker id="arrowblue" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                    <polygon points="0 0, 10 3, 0 6" fill="#3b82f6" />
                  </marker>
                </defs>
                <text x="145" y="30" fontSize="10" fill="#64748b">Ejection</text>
              </>
            )}
            
            {element === 'valve' && (
              <>
                <rect x="20" y="10" width="8" height="30" fill={phaseInfo.isOpen ? "#64748b" : "#1e293b"} rx="2" />
                <text x="50" y="28" fontSize="11" fill="#475569" fontWeight="600">
                  {phaseInfo.isOpen ? "OPEN" : "CLOSED"}
                </text>
                {isRegurgitant && !phaseInfo.isOpen && (
                  <>
                    <path d="M 85 25 L 115 25" stroke="#ef4444" strokeWidth="2" strokeDasharray="3,3" markerEnd="url(#arrowred)" />
                    <defs>
                      <marker id="arrowred" markerWidth="10" markerHeight="10" refX="0" refY="3" orient="auto">
                        <polygon points="10 0, 0 3, 10 6" fill="#ef4444" />
                      </marker>
                    </defs>
                    <text x="145" y="28" fontSize="10" fill="#dc2626">Leak</text>
                  </>
                )}
              </>
            )}
            
            {element === 'aorta' && (
              <>
                <rect x="20" y="15" width="100" height="20" fill="#bfdbfe" opacity="0.5" rx="5" />
                <path d="M 30 25 L 110 25" stroke="#3b82f6" strokeWidth="3" markerEnd="url(#arrowblue2)" />
                <defs>
                  <marker id="arrowblue2" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                    <polygon points="0 0, 10 3, 0 6" fill="#3b82f6" />
                  </marker>
                </defs>
                <text x="145" y="28" fontSize="10" fill="#1e40af">→ Body</text>
              </>
            )}
            
            {element === 'normalFlow' && (
              <>
                {[0, 1, 2, 3, 4].map(i => (
                  <circle key={i} cx={40 + i * 25} cy="25" r="6" fill="#3b82f6" opacity="0.7">
                    <animate attributeName="cx" from={40 + i * 25} to={40 + i * 25 + 150} dur="2s" repeatCount="indefinite" />
                  </circle>
                ))}
                <path d="M 200 25 L 240 25" stroke="#3b82f6" strokeWidth="2" markerEnd="url(#arrowblue3)" />
                <defs>
                  <marker id="arrowblue3" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                    <polygon points="0 0, 10 3, 0 6" fill="#3b82f6" />
                  </marker>
                </defs>
              </>
            )}
            
            {element === 'backflow' && (
              <>
                {[0, 1, 2, 3].map(i => (
                  <circle key={i} cx={200 - i * 30} cy="25" r="6" fill="#ef4444" opacity="0.7">
                    <animate attributeName="cx" from={200 - i * 30} to={200 - i * 30 - 150} dur="2s" repeatCount="indefinite" />
                  </circle>
                ))}
                <path d="M 240 25 L 200 25" stroke="#ef4444" strokeWidth="2" markerEnd="url(#arrowred2)" />
                <defs>
                  <marker id="arrowred2" markerWidth="10" markerHeight="10" refX="0" refY="3" orient="auto">
                    <polygon points="10 0, 0 3, 10 6" fill="#ef4444" />
                  </marker>
                </defs>
              </>
            )}
            
            {(element === 'systole' || element === 'diastole') && (
              <>
                <circle cx="50" cy="25" r="20" fill="none" stroke={phaseInfo.color} strokeWidth="3" />
                <path 
                  d={element === 'systole' 
                    ? "M 50 25 L 50 10 L 65 25" 
                    : "M 50 25 L 50 40 L 65 25"
                  }
                  stroke={phaseInfo.color} 
                  strokeWidth="3" 
                  fill="none"
                />
                <text x="100" y="30" fontSize="11" fill={phaseInfo.color} fontWeight="600">
                  {element === 'systole' ? 'Contract' : 'Relax'}
                </text>
              </>
            )}
          </svg>
        </div>

        <div className="space-y-1.5">
          {info.details.map((detail, i) => (
            <div key={i} className="flex items-start gap-2 text-xs text-gray-700 bg-gray-50 p-2 rounded">
              <span className="text-blue-500 mt-0.5 font-bold">•</span>
              <span className="flex-1">{detail}</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full h-screen bg-white flex flex-col items-center justify-center p-6">
      {/* Header */}
      <div className="mb-4 text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Aortic Regurgitation Detector
        </h1>
        <p className="text-gray-600 mb-1">
          Real-time Detection of Abnormal Backflow Patterns
        </p>
        <p className="text-sm text-blue-600 flex items-center justify-center gap-2">
          <Info size={16} />
          Hover over elements for detailed information
        </p>
      </div>

      {/* Main Visualization */}
      <div className="relative bg-gradient-to-r from-red-50 via-white to-blue-50 rounded-2xl shadow-2xl mb-4" style={{ width: '800px', height: '500px' }}>
        <svg width="800" height="500" className="absolute top-0 left-0">
          {/* Left Ventricle - Interactive */}
          <rect 
            x="50" y="200" width="180" height="200" 
            fill="#fecaca" 
            opacity={hoveredElement === 'ventricle' ? 0.5 : 0.3}
            rx="10"
            style={{ cursor: 'pointer', transition: 'opacity 0.2s' }}
            onMouseEnter={() => setHoveredElement('ventricle')}
            onMouseLeave={() => setHoveredElement(null)}
          />
          <text x="140" y="310" fontSize="16" fill="#991b1b" textAnchor="middle" fontWeight="600" style={{ pointerEvents: 'none' }}>
            Left Ventricle
          </text>

          {/* Aortic Valve - Interactive */}
          <g transform={`translate(250, 300)`}>
            <rect 
              x="-15" y="-60" width="30" height="120" 
              fill="#64748b" 
              opacity={hoveredElement === 'valve' ? 0.4 : 0.2}
              rx="5"
              style={{ cursor: 'pointer', transition: 'opacity 0.2s' }}
              onMouseEnter={() => setHoveredElement('valve')}
              onMouseLeave={() => setHoveredElement(null)}
            />
            
            <g style={{ pointerEvents: 'none' }}>
              {phaseInfo.isOpen ? (
                <>
                  <line x1="0" y1="-40" x2="-12" y2="-50" stroke="#475569" strokeWidth="6" strokeLinecap="round" />
                  <line x1="0" y1="40" x2="-12" y2="50" stroke="#475569" strokeWidth="6" strokeLinecap="round" />
                </>
              ) : (
                <>
                  <line x1="0" y1="-40" x2="0" y2="-10" stroke="#1e293b" strokeWidth="8" strokeLinecap="round" />
                  <line x1="0" y1="10" x2="0" y2="40" stroke="#1e293b" strokeWidth="8" strokeLinecap="round" />
                  {isRegurgitant && (
                    <>
                      <line x1="0" y1="-10" x2="0" y2="10" stroke="#ef4444" strokeWidth="4" strokeLinecap="round" opacity="0.8" />
                      <circle cx="0" cy="0" r="8" fill="#ef4444" opacity="0.3" />
                    </>
                  )}
                </>
              )}
            </g>
            <text x="0" y="80" fontSize="14" fill="#475569" textAnchor="middle" fontWeight="600" style={{ pointerEvents: 'none' }}>
              Aortic Valve
            </text>
          </g>

          {/* Aorta - Interactive */}
          <rect 
            x="280" y="200" width="400" height="200" 
            fill="#bfdbfe" 
            opacity={hoveredElement === 'aorta' ? 0.5 : 0.3}
            rx="10"
            style={{ cursor: 'pointer', transition: 'opacity 0.2s' }}
            onMouseEnter={() => setHoveredElement('aorta')}
            onMouseLeave={() => setHoveredElement(null)}
          />
          <text x="480" y="310" fontSize="16" fill="#1e40af" textAnchor="middle" fontWeight="600" style={{ pointerEvents: 'none' }}>
            Aorta
          </text>

          {!isRegurgitant && (
            <>
              <path d="M 680 290 L 700 300 L 680 310 Z" fill="#3b82f6" opacity="0.5" />
              <text x="720" y="305" fontSize="14" fill="#3b82f6">Normal Flow</text>
            </>
          )}

          {/* Flow particles with trails */}
          {particles.map(p => {
            const color = p.isBackflow ? '#ef4444' : '#3b82f6';
            const isHovered = hoveredElement === (p.isBackflow ? 'backflow' : 'normalFlow');
            
            return (
              <g key={p.id}>
                {p.trail.length > 1 && (
                  <path
                    d={`M ${p.trail.map((t, i) => `${t.x},${t.y}`).join(' L ')}`}
                    stroke={color}
                    strokeWidth={isHovered ? "2" : "1.5"}
                    fill="none"
                    opacity={isHovered ? 0.4 : 0.2}
                  />
                )}
                <circle
                  cx={p.x}
                  cy={p.y}
                  r={isHovered ? (p.isBackflow ? 6 : 5) : (p.isBackflow ? 5 : 4)}
                  fill={color}
                  opacity={isHovered ? 1 : 0.8}
                  style={{ cursor: 'pointer', transition: 'all 0.2s' }}
                  onMouseEnter={() => setHoveredElement(p.isBackflow ? 'backflow' : 'normalFlow')}
                  onMouseLeave={() => setHoveredElement(null)}
                />
              </g>
            );
          })}

          {isRegurgitant && backflowCount > 0 && (
            <>
              <g opacity="0.6">
                <path d="M 600 280 L 580 290 L 600 300 Z" fill="#ef4444">
                  <animate attributeName="opacity" values="0.3;0.8;0.3" dur="1s" repeatCount="indefinite" />
                </path>
                <path d="M 560 280 L 540 290 L 560 300 Z" fill="#ef4444">
                  <animate attributeName="opacity" values="0.3;0.8;0.3" dur="1s" begin="0.2s" repeatCount="indefinite" />
                </path>
                <path d="M 520 280 L 500 290 L 520 300 Z" fill="#ef4444">
                  <animate attributeName="opacity" values="0.3;0.8;0.3" dur="1s" begin="0.4s" repeatCount="indefinite" />
                </path>
              </g>
              <text x="620" y="260" fontSize="14" fill="#dc2626" fontWeight="600">
                ⚠ Backflow Detected
              </text>
            </>
          )}

          {/* Phase indicator - Interactive */}
          <rect 
            x="350" y="20" width="100" height="60" 
            fill={phaseInfo.color} 
            opacity={hoveredElement === (phaseInfo.isOpen ? 'systole' : 'diastole') ? 0.4 : 0.2}
            rx="8"
            style={{ cursor: 'pointer', transition: 'opacity 0.2s' }}
            onMouseEnter={() => setHoveredElement(phaseInfo.isOpen ? 'systole' : 'diastole')}
            onMouseLeave={() => setHoveredElement(null)}
          />
          <text x="400" y="45" fontSize="14" fill={phaseInfo.color} textAnchor="middle" fontWeight="600" style={{ pointerEvents: 'none' }}>
            {phaseInfo.name}
          </text>
          <text x="400" y="65" fontSize="12" fill="#64748b" textAnchor="middle" style={{ pointerEvents: 'none' }}>
            {phaseInfo.isOpen ? 'Valve Open' : 'Valve Closed'}
          </text>
        </svg>

        {/* Info Tooltip */}
        <InfoTooltip element={hoveredElement} />

        {/* Alert Panel - Only shows when no tooltip */}
        {isRegurgitant && !phaseInfo.isOpen && !hoveredElement && (
          <div className="absolute bottom-4 right-4 bg-red-50 border-2 border-red-400 rounded-lg p-3 max-w-xs">
            <div className="flex items-start gap-2">
              <AlertTriangle className="text-red-600 flex-shrink-0 mt-0.5" size={18} />
              <div>
                <div className="font-bold text-red-800 text-sm mb-1">
                  Aortic Regurgitation
                </div>
                <div className="text-xs text-red-700">
                  • {backflowCount} particles flowing backward<br/>
                  • Incomplete valve closure<br/>
                  • Volume overload risk
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Status Panel */}
      <div className="bg-white rounded-xl shadow-lg p-3 mb-4 flex items-center gap-6" style={{ width: '800px' }}>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: phaseInfo.color }} />
          <div>
            <div className="text-xs text-gray-500">Phase</div>
            <div className="font-semibold text-gray-800 text-sm">{phaseInfo.name}</div>
          </div>
        </div>

        <div 
          className="flex items-center gap-2 cursor-pointer hover:bg-blue-50 p-2 rounded transition-colors"
          onMouseEnter={() => setHoveredElement('normalFlow')}
          onMouseLeave={() => setHoveredElement(null)}
        >
          <div className="w-3 h-3 rounded-full bg-blue-500" />
          <div>
            <div className="text-xs text-gray-500">Forward</div>
            <div className="font-semibold text-gray-800 text-sm">
              {particles.filter(p => !p.isBackflow && p.vx > 0).length}
            </div>
          </div>
        </div>

        {isRegurgitant && (
          <div 
            className="flex items-center gap-2 cursor-pointer hover:bg-red-50 p-2 rounded transition-colors"
            onMouseEnter={() => setHoveredElement('backflow')}
            onMouseLeave={() => setHoveredElement(null)}
          >
            <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
            <div>
              <div className="text-xs text-gray-500">Backflow</div>
              <div className="font-semibold text-red-600 text-sm">{backflowCount}</div>
            </div>
          </div>
        )}

        <div className="flex items-center gap-2">
          <div className="text-xl">{isRegurgitant ? '❌' : '✅'}</div>
          <div>
            <div className="text-xs text-gray-500">Valve</div>
            <div className="font-semibold text-gray-800 text-sm">
              {isRegurgitant ? 'Regurgitant' : 'Competent'}
            </div>
          </div>
        </div>
      </div>

      {/* Speed Control */}
      <div className="bg-white rounded-xl shadow-lg p-4 mb-4 flex items-center gap-4" style={{ width: '800px' }}>
        <div className="flex items-center gap-2 min-w-32">
          <span className="text-sm font-semibold text-gray-700">Animation Speed:</span>
          <span className="text-sm font-bold text-blue-600">{animationSpeed.toFixed(1)}x</span>
        </div>
        <input
          type="range"
          min="0.2"
          max="3"
          step="0.1"
          value={animationSpeed}
          onChange={(e) => setAnimationSpeed(parseFloat(e.target.value))}
          className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
          style={{
            background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${((animationSpeed - 0.2) / 2.8) * 100}%, #e5e7eb ${((animationSpeed - 0.2) / 2.8) * 100}%, #e5e7eb 100%)`
          }}
        />
        <div className="flex gap-2 text-xs text-gray-500">
          <span>0.2x</span>
          <span>→</span>
          <span>3.0x</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex gap-4 mb-4">
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-lg"
        >
          {isPlaying ? <Pause size={20} /> : <Play size={20} />}
          {isPlaying ? 'Pause' : 'Play'}
        </button>

        <button
          onClick={() => setIsRegurgitant(!isRegurgitant)}
          className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-colors shadow-lg ${
            isRegurgitant 
              ? 'bg-red-600 text-white hover:bg-red-700' 
              : 'bg-green-600 text-white hover:bg-green-700'
          }`}
        >
          {isRegurgitant ? 'Regurgitant Valve' : 'Normal Valve'}
        </button>

        <button
          onClick={handleReset}
          className="flex items-center gap-2 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors shadow-lg"
        >
          <RotateCcw size={20} />
          Reset
        </button>
      </div>

      {/* Legend */}
      <div className="text-center text-sm text-gray-600 max-w-3xl">
        <p className="font-semibold mb-2">Compare valve performance across cardiac phases:</p>
        <p className="mb-1">
          <span className="font-medium text-green-600">Normal Valve:</span> Complete closure during diastole prevents backflow. 
          All particles flow forward into systemic circulation.
        </p>
        <p>
          <span className="font-medium text-red-600">Regurgitant Valve:</span> Incomplete closure allows blood to leak backward during diastole. 
          Red particles indicate abnormal retrograde flow causing volume overload.
        </p>
      </div>
    </div>
  );
};

export default AorticRegurgitationDetector;