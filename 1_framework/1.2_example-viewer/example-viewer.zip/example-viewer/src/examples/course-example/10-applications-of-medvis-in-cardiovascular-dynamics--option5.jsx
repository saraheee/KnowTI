import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Heart, AlertTriangle } from 'lucide-react';

const CardiacFlowVisualization = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPathological, setIsPathological] = useState(false);
  const [cyclePhase, setCyclePhase] = useState(0);
  const [particles, setParticles] = useState([]);
  const animationRef = useRef(null);
  const canvasRef = useRef(null);

  // Cardiac cycle phases
  const getPhaseInfo = () => {
    if (cyclePhase < 0.3) return { name: 'Early Systole', color: '#ef4444' };
    if (cyclePhase < 0.5) return { name: 'Peak Systole', color: '#dc2626' };
    if (cyclePhase < 0.7) return { name: 'Late Systole', color: '#f97316' };
    if (cyclePhase < 0.85) return { name: 'Early Diastole', color: '#3b82f6' };
    return { name: 'Late Diastole', color: '#60a5fa' };
  };

  // Initialize particles
  useEffect(() => {
    const initialParticles = Array.from({ length: 60 }, (_, i) => ({
      id: i,
      x: 180 + Math.random() * 40,
      y: 300 + Math.random() * 60,
      vx: 0,
      vy: 0,
      life: Math.random(),
      isBackflow: false,
      inVortex: false
    }));
    setParticles(initialParticles);
  }, []);

  // Animation loop
  useEffect(() => {
    if (!isPlaying) return;

    const animate = () => {
      setCyclePhase(prev => (prev + 0.008) % 1);
      
      setParticles(prevParticles => {
        return prevParticles.map(p => {
          let newX = p.x;
          let newY = p.y;
          let newVx = p.vx;
          let newVy = p.vy;
          let isBackflow = false;
          let inVortex = false;

          // Heart contraction creates flow
          const systoleStrength = cyclePhase < 0.5 ? Math.sin(cyclePhase * Math.PI * 2) : 0;
          const diastolePhase = cyclePhase > 0.5;

          // Flow through aortic valve
          if (newX < 250 && newY > 280 && newY < 380) {
            if (systoleStrength > 0.3) {
              // Forward flow during systole
              newVx = 2 + systoleStrength * 2;
              newVy = (300 - newY) * 0.05;
            } else if (diastolePhase && isPathological) {
              // Backflow during diastole (regurgitation)
              newVx = -1.5;
              isBackflow = true;
            }
          }

          // Flow in ascending aorta
          if (newX > 250 && newX < 400 && newY > 240 && newY < 320) {
            newVx += (280 - newY) * 0.02;
            
            // Vortex formation in pathological state
            if (isPathological && newX > 280 && newX < 350) {
              const dx = newX - 320;
              const dy = newY - 280;
              const dist = Math.sqrt(dx * dx + dy * dy);
              if (dist < 40) {
                newVx += -dy * 0.05;
                newVy += dx * 0.05;
                inVortex = true;
              }
            }
          }

          // Flow in aortic arch
          if (newX > 380 && newY > 180 && newY < 280) {
            newVy = -1.5 + (newX - 380) * 0.01;
            newVx = 1.2;
          }

          // Flow in descending aorta
          if (newX > 420 && newY < 200) {
            newVy = -2;
            newVx *= 0.95;
          }

          // Apply velocity
          newX += newVx;
          newY += newVy;

          // Friction
          newVx *= 0.98;
          newVy *= 0.98;

          // Reset particles that exit
          if (newX > 500 || newY < 100 || newX < 150) {
            newX = 180 + Math.random() * 40;
            newY = 300 + Math.random() * 60;
            newVx = 0;
            newVy = 0;
          }

          return {
            ...p,
            x: newX,
            y: newY,
            vx: newVx,
            vy: newVy,
            isBackflow,
            inVortex,
            life: (p.life + 0.01) % 1
          };
        });
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationRef.current);
  }, [isPlaying, cyclePhase, isPathological]);

  const handleReset = () => {
    setIsPlaying(false);
    setCyclePhase(0);
    const resetParticles = Array.from({ length: 60 }, (_, i) => ({
      id: i,
      x: 180 + Math.random() * 40,
      y: 300 + Math.random() * 60,
      vx: 0,
      vy: 0,
      life: Math.random(),
      isBackflow: false,
      inVortex: false
    }));
    setParticles(resetParticles);
  };

  const phaseInfo = getPhaseInfo();
  const heartScale = 1 + (cyclePhase < 0.5 ? Math.sin(cyclePhase * Math.PI * 2) * 0.15 : 0);

  // Calculate wall stress
  const getStressLevel = (x, y) => {
    if (isPathological) {
      // High stress in vortex region
      if (x > 280 && x < 350 && y > 240 && y < 320) return 'high';
      // Moderate stress at valve
      if (x > 230 && x < 270 && y > 280 && y < 320) return 'medium';
    }
    return 'normal';
  };

  return (
    <div className="w-full h-screen bg-white flex flex-col items-center justify-center p-8">
      {/* Header */}
      <div className="mb-6 text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Cardiovascular Flow Dynamics
        </h1>
        <p className="text-gray-600">
          Cardiac Cycle Analysis: Flow Patterns, Backflow Detection & Rupture Risk
        </p>
      </div>

      {/* Main Visualization */}
      <div className="relative bg-gradient-to-b from-gray-50 to-gray-100 rounded-2xl shadow-2xl p-8 mb-6" style={{ width: '700px', height: '550px' }}>
        <svg width="700" height="550" className="absolute top-0 left-0">
          {/* Aortic wall stress indicators */}
          {isPathological && (
            <>
              {/* High stress zone */}
              <ellipse cx="320" cy="280" rx="50" ry="45" fill="#fee2e2" opacity="0.6" />
              <ellipse cx="320" cy="280" rx="45" ry="40" fill="#fecaca" opacity="0.4" />
              
              {/* Valve stress */}
              <rect x="230" y="290" width="40" height="30" fill="#fed7aa" opacity="0.5" rx="5" />
            </>
          )}

          {/* Heart chamber */}
          <ellipse 
            cx="200" 
            cy="340" 
            rx={60 * heartScale} 
            ry={70 * heartScale} 
            fill={phaseInfo.color}
            opacity="0.3"
            stroke={phaseInfo.color}
            strokeWidth="3"
          />
          <ellipse 
            cx="200" 
            cy="340" 
            rx={50 * heartScale} 
            ry={60 * heartScale} 
            fill={phaseInfo.color}
            opacity="0.2"
          />

          {/* Aortic valve */}
          <g>
            {cyclePhase < 0.5 ? (
              // Open valve
              <>
                <path d="M 240 310 L 250 290 L 260 310" fill="#64748b" opacity="0.7" />
                <path d="M 240 320 L 250 340 L 260 320" fill="#64748b" opacity="0.7" />
              </>
            ) : (
              // Closed valve (with leak if pathological)
              <>
                <rect x="240" y="305" width="20" height="20" fill="#475569" opacity="0.8" rx="2" />
                {isPathological && (
                  <line x1="245" y1="315" x2="255" y2="315" stroke="#ef4444" strokeWidth="2" opacity="0.6" />
                )}
              </>
            )}
          </g>

          {/* Ascending aorta */}
          <path
            d="M 260 280 Q 280 260, 320 260 L 400 260 Q 440 260, 460 240"
            fill="none"
            stroke="#94a3b8"
            strokeWidth="60"
            opacity="0.3"
          />

          {/* Aortic arch */}
          <path
            d="M 460 240 Q 480 200, 480 160"
            fill="none"
            stroke="#94a3b8"
            strokeWidth="55"
            opacity="0.3"
          />

          {/* Descending aorta */}
          <rect x="455" y="100" width="50" height="60" fill="#94a3b8" opacity="0.3" rx="5" />

          {/* Vortex indicator */}
          {isPathological && (
            <g opacity="0.4">
              <circle cx="320" cy="280" r="35" fill="none" stroke="#a855f7" strokeWidth="2" strokeDasharray="5,5">
                <animateTransform
                  attributeName="transform"
                  type="rotate"
                  from="0 320 280"
                  to="360 320 280"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
              <circle cx="320" cy="280" r="25" fill="none" stroke="#c084fc" strokeWidth="2" strokeDasharray="3,3">
                <animateTransform
                  attributeName="transform"
                  type="rotate"
                  from="0 320 280"
                  to="-360 320 280"
                  dur="1.5s"
                  repeatCount="indefinite"
                />
              </circle>
            </g>
          )}

          {/* Flow particles */}
          {particles.map(p => {
            let color = '#3b82f6';
            let size = 4;
            
            if (p.isBackflow) {
              color = '#ef4444';
              size = 5;
            } else if (p.inVortex) {
              color = '#a855f7';
              size = 4.5;
            }

            return (
              <circle
                key={p.id}
                cx={p.x}
                cy={p.y}
                r={size}
                fill={color}
                opacity={0.7 + Math.sin(p.life * Math.PI * 2) * 0.3}
              />
            );
          })}

          {/* Annotations */}
          <text x="180" y="450" fontSize="14" fill="#64748b" textAnchor="middle">Left Ventricle</text>
          <text x="350" y="350" fontSize="14" fill="#64748b" textAnchor="middle">Ascending Aorta</text>
          <text x="520" y="200" fontSize="14" fill="#64748b" textAnchor="middle">Descending</text>
          <text x="520" y="220" fontSize="14" fill="#64748b" textAnchor="middle">Aorta</text>
        </svg>

        {/* Risk indicators */}
        {isPathological && (
          <div className="absolute top-4 right-4 bg-red-50 border-2 border-red-300 rounded-lg p-3 flex items-start gap-2 max-w-xs">
            <AlertTriangle className="text-red-600 flex-shrink-0" size={20} />
            <div>
              <div className="font-semibold text-red-800 text-sm">High Risk Zones Detected</div>
              <div className="text-xs text-red-700 mt-1">
                • Abnormal backflow present<br/>
                • Vortex formation detected<br/>
                • Elevated wall stress
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Status Panel */}
      <div className="bg-white rounded-xl shadow-lg p-4 mb-6 flex items-center gap-8" style={{ width: '700px' }}>
        <div className="flex items-center gap-3">
          <div 
            className="w-4 h-4 rounded-full animate-pulse"
            style={{ backgroundColor: phaseInfo.color }}
          />
          <div>
            <div className="text-xs text-gray-500">Cardiac Phase</div>
            <div className="font-semibold text-gray-800">{phaseInfo.name}</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Heart className="text-pink-500" size={20} />
          <div>
            <div className="text-xs text-gray-500">Heart Rate</div>
            <div className="font-semibold text-gray-800">75 BPM</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="w-4 h-4 rounded-full bg-blue-500" />
          <div>
            <div className="text-xs text-gray-500">Forward Flow</div>
          </div>
        </div>

        {isPathological && (
          <>
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded-full bg-red-500" />
              <div>
                <div className="text-xs text-gray-500">Backflow</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded-full bg-purple-500" />
              <div>
                <div className="text-xs text-gray-500">Vortex</div>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Controls */}
      <div className="flex gap-4">
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-lg"
        >
          {isPlaying ? <Pause size={20} /> : <Play size={20} />}
          {isPlaying ? 'Pause' : 'Play'}
        </button>

        <button
          onClick={() => setIsPathological(!isPathological)}
          className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-colors shadow-lg ${
            isPathological 
              ? 'bg-red-600 text-white hover:bg-red-700' 
              : 'bg-green-600 text-white hover:bg-green-700'
          }`}
        >
          {isPathological ? 'Pathological State' : 'Healthy State'}
        </button>

        <button
          onClick={handleReset}
          className="flex items-center gap-2 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors shadow-lg"
        >
          <RotateCcw size={20} />
          Reset
        </button>
      </div>

      {/* Legend */}
      <div className="mt-6 text-center text-sm text-gray-600 max-w-2xl">
        <p className="font-semibold mb-2">Toggle between states to observe:</p>
        <p>
          <span className="font-medium">Healthy:</span> Normal forward flow during systole, complete valve closure during diastole
        </p>
        <p>
          <span className="font-medium">Pathological:</span> Aortic regurgitation with backflow, turbulent vortex formation, and elevated wall stress indicating rupture risk
        </p>
      </div>
    </div>
  );
};

export default CardiacFlowVisualization;