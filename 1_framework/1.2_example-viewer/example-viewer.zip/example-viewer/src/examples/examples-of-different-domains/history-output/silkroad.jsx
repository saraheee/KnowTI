import { useState, useEffect, useRef, useCallback } from "react";

const CITIES = [
  { id:"rome",   name:"Rome",           x:80,  y:118, goods:["Glass","Wool","Wine"],    info:"Western terminus. Insatiable demand for luxury silks drove the entire trade network." },
  { id:"const",  name:"Constantinople", x:170, y:100, goods:["Glass","Gold","Coins"],   info:"Gateway between East and West. Emperor Justinian smuggled silkworm eggs here in 552 CE." },
  { id:"alex",   name:"Alexandria",     x:182, y:168, goods:["Papyrus","Ivory","Gold"], info:"Great Mediterranean port. Egyptian goods joined the network here." },
  { id:"anti",   name:"Antioch",        x:218, y:128, goods:["Glass","Purple dye"],     info:"Major entrepôt where Parthian and Roman merchants exchanged goods." },
  { id:"ctesi",  name:"Ctesiphon",      x:278, y:155, goods:["Spices","Pearls"],        info:"Parthian/Sasanian capital. Controlled the middle of the overland route for centuries." },
  { id:"merv",   name:"Merv",           x:372, y:138, goods:["Cotton","Lapis lazuli"],  info:"Oasis city. Crossroads of three branches of the Silk Road." },
  { id:"samar",  name:"Samarkand",      x:418, y:114, goods:["Paper","Horses"],         info:"Sogdian merchants here were the greatest long-distance traders of the ancient world." },
  { id:"kash",   name:"Kashgar",        x:502, y:115, goods:["Jade","Horses"],          info:"Where northern and southern routes around the Taklamakan Desert rejoined." },
  { id:"dun",    name:"Dunhuang",       x:584, y:112, goods:["Silk","Tea","Lacquer"],   info:"Last Chinese outpost. Merchants rested here before crossing the Taklamakan Desert." },
  { id:"chang",  name:"Chang'an",       x:660, y:142, goods:["Silk","Porcelain","Tea"], info:"Eastern terminus. Tang Dynasty capital of 1 million people — the world's largest city." },
];

const ROUTE = CITIES.map(c=>[c.x, c.y]);

const GOODS = [
  { label:"Silk",      color:"#dc2626", dir:1,  icon:"🟥" },
  { label:"Porcelain", color:"#2563eb", dir:1,  icon:"🔵" },
  { label:"Spices",    color:"#d97706", dir:1,  icon:"🟡" },
  { label:"Glass",     color:"#0891b2", dir:-1, icon:"💠" },
  { label:"Gold",      color:"#ca8a04", dir:-1, icon:"🟨" },
];

function lerp(a,b,t){return a+(b-a)*t;}

function routePoint(t) {
  const pts = ROUTE;
  const n   = pts.length - 1;
  const seg = Math.min(Math.floor(t*n), n-1);
  const lt  = t*n - seg;
  return { x: lerp(pts[seg][0],pts[seg+1][0],lt), y: lerp(pts[seg][1],pts[seg+1][1],lt) };
}

function routeLen() {
  let d=0;
  for(let i=1;i<ROUTE.length;i++){
    const dx=ROUTE[i][0]-ROUTE[i-1][0], dy=ROUTE[i][1]-ROUTE[i-1][1];
    d+=Math.sqrt(dx*dx+dy*dy);
  }
  return d;
}
const TOTAL_LEN = routeLen();

function buildPathD() {
  return ROUTE.map((p,i)=>(i===0?`M${p[0]},${p[1]}`:`L${p[0]},${p[1]}`)).join(" ");
}
const PATH_D = buildPathD();

export default function App() {
  const [playing,   setPlaying]   = useState(true);
  const [speed,     setSpeed]     = useState(1);
  const [time,      setTime]      = useState(0);
  const [hovCity,   setHovCity]   = useState(null);
  const [activeGood,setActiveGood]= useState(null);

  const speedRef=useRef(1), animRef=useRef(null), prevTsRef=useRef(null);
  useEffect(()=>{speedRef.current=speed;},[speed]);

  const animate=useCallback((ts)=>{
    if(prevTsRef.current!==null){
      const dt=ts-prevTsRef.current;
      setTime(t=>(t+dt*speedRef.current*0.00012)%1);
    }
    prevTsRef.current=ts;
    animRef.current=requestAnimationFrame(animate);
  },[]);

  useEffect(()=>{
    if(playing){prevTsRef.current=null;animRef.current=requestAnimationFrame(animate);}
    else cancelAnimationFrame(animRef.current);
    return()=>cancelAnimationFrame(animRef.current);
  },[playing,animate]);

  const shownGoods = activeGood ? GOODS.filter(g=>g.label===activeGood) : GOODS;

  const hov = CITIES.find(c=>c.id===hovCity);

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"18px 28px 12px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:820,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:10}}>
          <div>
            <h1 style={{fontSize:20,fontWeight:800,color:"#0f172a",margin:"0 0 2px",letterSpacing:"-0.02em"}}>The Silk Road</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>130 BCE – 1453 CE · 7,000 km of trade routes</p>
          </div>
          {/* Good filters */}
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            <button onClick={()=>setActiveGood(null)}
              style={{padding:"4px 11px",borderRadius:20,border:"1.5px solid #e2e8f0",
                background:!activeGood?"#0f172a":"#fff",color:!activeGood?"#fff":"#64748b",
                fontSize:11,fontWeight:700,cursor:"pointer"}}>All goods</button>
            {GOODS.map(g=>(
              <button key={g.label} onClick={()=>setActiveGood(activeGood===g.label?null:g.label)}
                style={{padding:"4px 11px",borderRadius:20,
                  border:`1.5px solid ${activeGood===g.label?g.color:"#e2e8f0"}`,
                  background:activeGood===g.label?g.color+"18":"#fff",
                  color:activeGood===g.label?g.color:"#64748b",
                  fontSize:11,fontWeight:700,cursor:"pointer",transition:"all 0.15s"}}>
                {g.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Map */}
      <div style={{flex:1,position:"relative",padding:"0 16px",display:"flex",flexDirection:"column"}}>
        <svg viewBox="0 0 780 280" width="100%" style={{flex:1,maxHeight:230,display:"block"}}>
          <defs>
            <radialGradient id="seaGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#e0f2fe"/>
              <stop offset="100%" stopColor="#bae6fd"/>
            </radialGradient>
          </defs>

          {/* Background: sea */}
          <rect x={0} y={0} width={780} height={280} fill="url(#seaGrad)" rx={8}/>

          {/* Simplified Eurasian landmass */}
          <path d="M30,60 Q60,30 150,40 Q220,28 300,35 Q380,28 460,32 Q540,28 620,38 Q680,38 730,55 Q755,75 750,130 Q745,175 710,210 Q670,240 610,248 Q540,255 470,248 Q390,252 320,245 Q250,248 200,235 Q155,228 125,210 Q90,195 65,170 Q35,148 28,120 Z"
            fill="#fef3c7" stroke="#e5e7eb" strokeWidth={1}/>

          {/* Mediterranean sea cutout */}
          <ellipse cx={145} cy={155} rx={70} ry={35} fill="url(#seaGrad)" opacity={0.7}/>

          {/* Caspian Sea */}
          <ellipse cx={330} cy={120} rx={18} ry={30} fill="#bae6fd" opacity={0.6}/>

          {/* Route path */}
          <path d={PATH_D} fill="none" stroke="#d4a843" strokeWidth={2.5}
            strokeDasharray="6,4" opacity={0.6}/>

          {/* Animated goods particles */}
          {shownGoods.map((g,gi)=>
            [0, 0.22, 0.44, 0.66].map((offset,pi)=>{
              const rawT = (time + offset + gi*0.055) % 1;
              const t    = g.dir === 1 ? rawT : 1 - rawT;
              const pt   = routePoint(t);
              return (
                <circle key={`${gi}-${pi}`}
                  cx={pt.x} cy={pt.y} r={4.5}
                  fill={g.color}
                  opacity={0.85}
                  style={{filter:"drop-shadow(0 1px 3px rgba(0,0,0,0.25))"}}
                />
              );
            })
          )}

          {/* City dots */}
          {CITIES.map(c=>{
            const isHov=hovCity===c.id;
            return (
              <g key={c.id} style={{cursor:"pointer"}}
                onMouseEnter={()=>setHovCity(c.id)}
                onMouseLeave={()=>setHovCity(null)}>
                <circle cx={c.x} cy={c.y} r={isHov?11:7}
                  fill={isHov?"#0f172a":"#fff"}
                  stroke="#0f172a" strokeWidth={2}
                  style={{transition:"all 0.2s"}}/>
                {/* City name */}
                <text x={c.x} y={c.y-(isHov?16:12)} textAnchor="middle" fontSize={isHov?11:9}
                  fontWeight={isHov?700:500} fill="#0f172a" fontFamily="system-ui,sans-serif"
                  style={{transition:"all 0.2s",pointerEvents:"none"}}>
                  {c.name}
                </text>
              </g>
            );
          })}

          {/* Directions */}
          <text x={380} y={270} textAnchor="middle" fontSize={9} fill="#94a3b8" fontFamily="system-ui,sans-serif" letterSpacing="0.05em">
            ← Westbound (glass, gold) · Eastbound (silk, porcelain, spices) →
          </text>
        </svg>

        {/* City info tooltip */}
        {hov&&(
          <div style={{
            position:"absolute",top:12,left:28,
            background:"#fff",border:"1px solid #e2e8f0",
            borderRadius:12,padding:"14px 16px",maxWidth:240,
            boxShadow:"0 8px 32px rgba(0,0,0,0.1)",zIndex:10,
          }}>
            <div style={{fontSize:13,fontWeight:800,color:"#0f172a",marginBottom:4}}>{hov.name}</div>
            <p style={{fontSize:12,lineHeight:1.65,color:"#475569",margin:"0 0 8px"}}>{hov.info}</p>
            <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
              {hov.goods.map(g=>(
                <span key={g} style={{fontSize:10,background:"#f8fafc",border:"1px solid #e2e8f0",
                  borderRadius:10,padding:"2px 8px",color:"#64748b",fontWeight:600}}>{g}</span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div style={{padding:"8px 28px 16px",maxWidth:820,margin:"0 auto",width:"100%",boxSizing:"border-box"}}>
        <div style={{display:"flex",alignItems:"center",gap:12,
          background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,padding:"9px 16px"}}>
          <button onClick={()=>setPlaying(p=>!p)} style={{
            width:34,height:34,borderRadius:8,border:"none",
            background:playing?"#64748b":"#0f172a",color:"#fff",fontSize:14,
            cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            {playing?"⏸":"▶"}
          </button>
          <button onClick={()=>{setTime(0);setPlaying(true);}} style={{
            width:30,height:30,borderRadius:7,border:"1px solid #e2e8f0",
            background:"#fff",color:"#94a3b8",fontSize:12,cursor:"pointer",flexShrink:0}}>↺</button>
          <div style={{flex:1,display:"flex",alignItems:"center",gap:8}}>
            <span style={{fontSize:10,color:"#94a3b8",fontWeight:700,letterSpacing:"0.08em"}}>SPEED</span>
            <input type="range" min={0.25} max={4} step={0.25} value={speed}
              onChange={e=>setSpeed(+e.target.value)}
              style={{flex:1,accentColor:"#d4a843",cursor:"pointer"}}/>
            <span style={{fontSize:12,fontWeight:800,color:"#d4a843",minWidth:24}}>{speed}×</span>
          </div>
          <span style={{fontSize:11,color:"#94a3b8",flexShrink:0}}>Hover cities · filter goods above</span>
        </div>
      </div>
    </div>
  );
}
