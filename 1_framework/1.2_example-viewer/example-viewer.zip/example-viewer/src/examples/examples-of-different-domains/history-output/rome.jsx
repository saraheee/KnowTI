import { useState } from "react";

const FACTORS = [
  {
    key:"military",
    label:"Military Overstretch",
    color:"#dc2626",
    light:"#fef2f2",
    border:"#fecaca",
    icon:"⚔",
    summary:"The empire's borders — 5,000 km long — required an army too large to fund.",
    detail:"By the 4th century the army had grown from 300,000 to over 600,000 men, mostly paid mercenaries and Germanic foederati whose loyalty was to their commander, not Rome. Defending every frontier simultaneously became impossible.",
  },
  {
    key:"economic",
    label:"Economic Collapse",
    color:"#d97706",
    light:"#fffbeb",
    border:"#fde68a",
    icon:"⚖",
    summary:"Currency debasement, taxation, and trade disruption destroyed Rome's financial base.",
    detail:"Emperors debased the silver denarius from 85% silver (Nero) to 5% (260s). Hyperinflation followed. Heavy taxes crushed the peasantry; trade routes were disrupted by constant warfare. The western economy fragmented into local subsistence.",
  },
  {
    key:"political",
    label:"Political Instability",
    color:"#7c3aed",
    light:"#f5f3ff",
    border:"#ddd6fe",
    icon:"👑",
    summary:"Between 235–284 CE, 26 emperors ruled — nearly all assassinated.",
    detail:"The 'Crisis of the Third Century' saw Rome nearly fragment. With no clear succession mechanism, any general with loyal troops could claim the throne. Civil wars became more frequent than barbarian invasions, exhausting the empire from within.",
  },
  {
    key:"invasions",
    label:"Barbarian Invasions",
    color:"#2563eb",
    light:"#eff6ff",
    border:"#bfdbfe",
    icon:"🗡",
    summary:"Germanic tribes — Visigoths, Vandals, Huns — systematically dismantled the western provinces.",
    detail:"The Huns drove the Visigoths into Roman territory (376 CE); they sacked Rome in 410. The Vandals took North Africa (429–439) and its grain supply. By 476, Odoacer deposed the last western emperor — not a dramatic fall, but a slow handover of power to Germanic kings.",
  },
  {
    key:"religion",
    label:"Rise of Christianity",
    color:"#059669",
    light:"#ecfdf5",
    border:"#a7f3d0",
    icon:"✝",
    summary:"Edward Gibbon's controversial thesis: Christianity redirected elite energy and resources from civic life.",
    detail:"From Constantine (312 CE), enormous wealth flowed to the church. Gibbon argued pacifism and monasticism weakened the martial spirit. More broadly, the unity provided by Roman religion was replaced by often bitter theological disputes that divided the empire.",
  },
];

const REGIONS = [
  { id:"italia",  label:"Italia",          x:185, y:140, w:55, h:70,   peak:"#fbbf24", fall:"#94a3b8", owner:"Odoacer (Germanic, 476 CE)" },
  { id:"gaul",    label:"Gaul",            x:90,  y:85,  w:90, h:80,   peak:"#fbbf24", fall:"#94a3b8", owner:"Frankish Kingdom (Clovis, 486 CE)" },
  { id:"hispania",label:"Hispania",        x:50,  y:140, w:85, h:70,   peak:"#fbbf24", fall:"#94a3b8", owner:"Visigothic Kingdom (415 CE)" },
  { id:"brit",    label:"Britannia",       x:80,  y:38,  w:60, h:48,   peak:"#fbbf24", fall:"#94a3b8", owner:"Abandoned by Rome (410 CE)" },
  { id:"nafrica", label:"N. Africa",       x:100, y:230, w:130, h:45,  peak:"#fbbf24", fall:"#94a3b8", owner:"Vandal Kingdom (429 CE)" },
  { id:"egypt",   label:"Egypt",           x:278, y:228, w:55, h:48,   peak:"#fbbf24", fall:"#4ade80", owner:"Eastern Empire (Byzantine)" },
  { id:"balkans", label:"Balkans",         x:235, y:108, w:80, h:75,   peak:"#fbbf24", fall:"#4ade80", owner:"Eastern Empire (Byzantine)" },
  { id:"anatolia",label:"Anatolia",        x:310, y:130, w:95, h:65,   peak:"#fbbf24", fall:"#4ade80", owner:"Eastern Empire (Byzantine)" },
  { id:"levant",  label:"Levant/Syria",    x:320, y:195, w:55, h:55,   peak:"#fbbf24", fall:"#4ade80", owner:"Eastern Empire (Byzantine)" },
];

export default function App() {
  const [activeFactor, setActiveFactor] = useState(null);
  const [era, setEra] = useState("peak");  // "peak" | "fall"
  const [hovRegion, setHovRegion] = useState(null);

  const af = FACTORS.find(f=>f.key===activeFactor);
  const hov = REGIONS.find(r=>r.id===hovRegion);

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"16px 28px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:860,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",gap:10,flexWrap:"wrap"}}>
          <div>
            <h1 style={{fontSize:20,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>
              The Fall of the Western Roman Empire
            </h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>
              284 CE — 476 CE · A civilisation in slow collapse
            </p>
          </div>
          {/* Era toggle */}
          <div style={{display:"flex",background:"#f1f5f9",borderRadius:10,padding:3,gap:2}}>
            {[["peak","Peak Empire · 284 CE"],["fall","Fall · 476 CE"]].map(([v,label])=>(
              <button key={v} onClick={()=>setEra(v)} style={{
                padding:"6px 14px",borderRadius:8,border:"none",fontSize:12,fontWeight:700,
                background:era===v?"#fff":"transparent",
                color:era===v?"#0f172a":"#64748b",
                boxShadow:era===v?"0 1px 4px rgba(0,0,0,0.1)":"none",
                cursor:"pointer",transition:"all 0.2s",whiteSpace:"nowrap",
              }}>{label}</button>
            ))}
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",overflow:"hidden",maxWidth:860,margin:"0 auto",width:"100%",
        padding:"12px 28px 14px",boxSizing:"border-box",gap:16}}>

        {/* Map panel */}
        <div style={{flex:1,position:"relative"}}>
          <svg viewBox="0 0 440 290" width="100%" style={{display:"block",maxHeight:250}}>

            {/* Sea */}
            <rect x={0} y={0} width={440} height={290} fill="#bae6fd" rx={8} opacity={0.5}/>

            {/* Regions */}
            {REGIONS.map(r=>{
              const isHov = hovRegion===r.id;
              const fill  = era==="peak" ? "#fbbf24" : r.fall;
              return (
                <g key={r.id} style={{cursor:"pointer"}}
                  onMouseEnter={()=>setHovRegion(r.id)}
                  onMouseLeave={()=>setHovRegion(null)}>
                  <rect x={r.x} y={r.y} width={r.w} height={r.h} rx={4}
                    fill={fill}
                    stroke={isHov?"#0f172a":"#fff"}
                    strokeWidth={isHov?2:1}
                    opacity={isHov?1:0.85}
                    style={{transition:"all 0.4s"}}/>
                  <text x={r.x+r.w/2} y={r.y+r.h/2+4} textAnchor="middle"
                    fontSize={9} fontWeight={600} fill={era==="fall"&&r.fall==="#4ade80"?"#065f46":"#78350f"}
                    fontFamily="system-ui,sans-serif" style={{pointerEvents:"none"}}>
                    {r.label}
                  </text>
                </g>
              );
            })}

            {/* Rome city marker */}
            <circle cx={210} cy={162} r={5} fill="#dc2626"/>
            <text x={210} y={175} textAnchor="middle" fontSize={8} fontWeight={700} fill="#dc2626" fontFamily="system-ui,sans-serif">ROME</text>

            {/* Constantinople */}
            <circle cx={285} cy={118} r={4} fill="#2563eb"/>
            <text x={285} y={112} textAnchor="middle" fontSize={7} fontWeight={700} fill="#2563eb" fontFamily="system-ui,sans-serif">C'PLE</text>

            {/* Legend */}
            <rect x={5} y={255} width={10} height={10} fill="#fbbf24" rx={2}/>
            <text x={18} y={264} fontSize={8} fill="#64748b" fontFamily="system-ui,sans-serif">Roman Empire</text>
            <rect x={90} y={255} width={10} height={10} fill="#94a3b8" rx={2}/>
            <text x={103} y={264} fontSize={8} fill="#64748b" fontFamily="system-ui,sans-serif">Lost (West)</text>
            <rect x={155} y={255} width={10} height={10} fill="#4ade80" rx={2}/>
            <text x={168} y={264} fontSize={8} fill="#64748b" fontFamily="system-ui,sans-serif">Survived (East)</text>
          </svg>

          {/* Region hover tooltip */}
          {hov&&(
            <div style={{position:"absolute",top:8,left:0,
              background:"#fff",border:"1px solid #e2e8f0",borderRadius:10,padding:"10px 14px",maxWidth:180,
              boxShadow:"0 6px 24px rgba(0,0,0,0.1)",zIndex:10,pointerEvents:"none"}}>
              <div style={{fontSize:12,fontWeight:700,color:"#0f172a",marginBottom:3}}>{hov.label}</div>
              <div style={{fontSize:11,color:era==="fall"?"#dc2626":"#16a34a",fontWeight:600,marginBottom:3}}>
                {era==="fall" ? "476 CE: "+hov.owner : "Under Roman control"}
              </div>
            </div>
          )}
        </div>

        {/* Factors panel */}
        <div style={{width:260,display:"flex",flexDirection:"column",gap:7,overflow:"auto"}}>
          <p style={{fontSize:11,color:"#94a3b8",margin:"0 0 4px",letterSpacing:"0.05em",fontWeight:600,textTransform:"uppercase"}}>
            Click a factor to explore:
          </p>
          {FACTORS.map(f=>{
            const isActive=activeFactor===f.key;
            return (
              <div key={f.key} onClick={()=>setActiveFactor(isActive?null:f.key)}
                style={{background:isActive?f.light:"#f8fafc",border:`1.5px solid ${isActive?f.color:f.border}`,
                  borderRadius:10,padding:"11px 13px",cursor:"pointer",transition:"all 0.2s",
                  boxShadow:isActive?"0 4px 16px rgba(0,0,0,0.07)":"none"}}>
                <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:isActive?5:0}}>
                  <span style={{fontSize:15}}>{f.icon}</span>
                  <span style={{fontSize:12,fontWeight:700,color:isActive?f.color:"#334155"}}>{f.label}</span>
                </div>
                {isActive?(
                  <p style={{fontSize:12,lineHeight:1.65,color:"#1e293b",margin:0,fontStyle:"italic"}}>{f.detail}</p>
                ):(
                  <p style={{fontSize:11,color:"#94a3b8",margin:"4px 0 0",lineHeight:1.5}}>{f.summary}</p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
