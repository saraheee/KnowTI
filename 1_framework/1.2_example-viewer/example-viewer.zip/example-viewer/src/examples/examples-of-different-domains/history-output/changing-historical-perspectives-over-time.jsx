import { useState, useCallback } from 'react';

export default function App() {
  const [selectedPerspective, setSelectedPerspective] = useState('western');
  const [hoveredEvent, setHoveredEvent] = useState(null);

  const perspectives = {
    western: {
      title: "2024 Western Narrative",
      color: "#3B82F6",
      description: "Current dominant historical perspective"
    },
    asian: {
      title: "2099 Asian-Centric View",
      color: "#EF4444",
      description: "Future perspective with Asian global dominance"
    },
    muslim: {
      title: "2099 Islamic World View",
      color: "#10B981",
      description: "Future perspective with Islamic civilization prominence"
    },
    american: {
      title: "2099 Americas-Focused View",
      color: "#8B5CF6",
      description: "Future perspective with Americas regional dominance"
    }
  };

  const historicalEvents = [
    {
      id: 'wwi',
      title: "World War I",
      year: 1918,
      position: { top: '20%', left: '15%' },
      current: "The Great War that reshaped Europe and ended empires",
      interpretations: {
        asian: "A European civil war that accelerated Asia's economic rise while the West destroyed itself",
        muslim: "The collapse of the Ottoman Empire, leading to a century-long Islamic renaissance",
        american: "The moment the Americas began their inevitable rise to global leadership"
      }
    },
    {
      id: 'wwii',
      title: "World War II",
      year: 1945,
      position: { top: '35%', left: '25%' },
      current: "The defining conflict of the century, victory of democracy over fascism",
      interpretations: {
        asian: "The war that ended Western colonial dominance and began the Asian Century",
        muslim: "A Christian-secular conflict that opened space for Islamic civilization's return",
        american: "The first truly hemispheric war, proving the Americas' strategic unity"
      }
    },
    {
      id: 'coldwar',
      title: "Cold War",
      year: 1991,
      position: { top: '50%', left: '35%' },
      current: "Ideological struggle between capitalism and communism, won by the free world",
      interpretations: {
        asian: "A distraction that allowed Asia to develop while superpowers competed",
        muslim: "The decline of both Western ideologies, clearing path for Islamic governance models",
        american: "The period when the Americas learned to act as a unified geopolitical bloc"
      }
    },
    {
      id: 'decolonization',
      title: "Decolonization",
      year: 1975,
      position: { top: '30%', left: '55%' },
      current: "The liberation of colonies and emergence of new nations",
      interpretations: {
        asian: "The restoration of Asia's natural position as the world's economic center",
        muslim: "The beginning of the Islamic world's reunification after colonial fragmentation",
        american: "The Americas' successful export of independence movements worldwide"
      }
    },
    {
      id: 'technology',
      title: "Technological Revolution",
      year: 1995,
      position: { top: '65%', left: '45%' },
      current: "Digital revolution transforming human communication and commerce",
      interpretations: {
        asian: "Asia's mastery of technology that enabled the Great Convergence of 2040-2070",
        muslim: "Technology that enabled the Islamic Golden Age 2.0 through connected ummah",
        american: "The foundation of the Americas' knowledge-based economic integration"
      }
    },
    {
      id: 'globalization',
      title: "Globalization",
      year: 2000,
      position: { top: '80%', left: '25%' },
      current: "Economic integration creating a connected world economy",
      interpretations: {
        asian: "The restoration of Asia's historical role as the world's marketplace",
        muslim: "The network that enabled Islamic finance to become the global standard",
        american: "The system that proved the Americas' model of regional cooperation"
      }
    }
  ];

  const handlePerspectiveChange = useCallback((perspective) => {
    setSelectedPerspective(perspective);
    setHoveredEvent(null);
  }, []);

  const handleEventHover = useCallback((eventId) => {
    setHoveredEvent(eventId);
  }, []);

  const handleEventLeave = useCallback(() => {
    setHoveredEvent(null);
  }, []);

  const sortedEvents = [...historicalEvents].sort((a, b) => a.year - b.year);

  return (
    <div style={{
      width: '100%',
      height: '100vh',
      backgroundColor: '#ffffff',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    }}>
      {/* Header */}
      <div style={{
        padding: '2rem',
        borderBottom: '1px solid #E5E7EB',
        textAlign: 'center'
      }}>
        <h1 style={{
          fontSize: '2rem',
          fontWeight: 'bold',
          margin: '0 0 0.5rem 0',
          color: '#111827'
        }}>
          2099 Historical Retrospective Generator
        </h1>
        <p style={{
          color: '#6B7280',
          margin: 0,
          fontSize: '1.1rem'
        }}>
          How might future historians reinterpret our 20th century?
        </p>
      </div>

      {/* Perspective Selector */}
      <div style={{
        padding: '1.5rem 2rem',
        borderBottom: '1px solid #E5E7EB',
        display: 'flex',
        gap: '1rem',
        justifyContent: 'center',
        flexWrap: 'wrap'
      }}>
        {Object.entries(perspectives).map(([key, perspective]) => (
          <button
            key={key}
            onClick={() => handlePerspectiveChange(key)}
            style={{
              padding: '0.75rem 1.5rem',
              border: selectedPerspective === key ? `2px solid ${perspective.color}` : '2px solid #E5E7EB',
              backgroundColor: selectedPerspective === key ? `${perspective.color}10` : '#ffffff',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '0.9rem',
              fontWeight: selectedPerspective === key ? 'bold' : 'normal',
              color: selectedPerspective === key ? perspective.color : '#374151',
              transition: 'all 0.2s ease'
            }}
          >
            {perspective.title}
          </button>
        ))}
      </div>

      {/* Timeline */}
      <div style={{
        padding: '1rem 2rem',
        borderBottom: '1px solid #E5E7EB',
        backgroundColor: '#F9FAFB'
      }}>
        <div style={{
          position: 'relative',
          height: '80px',
          display: 'flex',
          alignItems: 'center'
        }}>
          {/* Timeline line */}
          <div style={{
            position: 'absolute',
            top: '50%',
            left: '5%',
            right: '5%',
            height: '2px',
            backgroundColor: perspectives[selectedPerspective].color,
            opacity: 0.3
          }} />
          
          {/* Timeline events */}
          {sortedEvents.map((event, index) => {
            const leftPosition = 5 + (index * 15);
            return (
              <div
                key={event.id}
                onMouseEnter={() => handleEventHover(event.id)}
                onMouseLeave={handleEventLeave}
                style={{
                  position: 'absolute',
                  left: `${leftPosition}%`,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  cursor: 'pointer'
                }}
              >
                <div style={{
                  width: hoveredEvent === event.id ? '14px' : '10px',
                  height: hoveredEvent === event.id ? '14px' : '10px',
                  borderRadius: '50%',
                  backgroundColor: perspectives[selectedPerspective].color,
                  border: '2px solid #ffffff',
                  marginBottom: '0.5rem',
                  transition: 'all 0.2s ease',
                  zIndex: 2
                }} />
                <div style={{
                  fontSize: '0.7rem',
                  fontWeight: 'bold',
                  color: perspectives[selectedPerspective].color,
                  textAlign: 'center',
                  whiteSpace: 'nowrap'
                }}>
                  {event.year}
                </div>
                <div style={{
                  fontSize: '0.6rem',
                  color: '#6B7280',
                  textAlign: 'center',
                  maxWidth: '80px',
                  lineHeight: '1.2'
                }}>
                  {event.title}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <div style={{
        flex: 1,
        display: 'flex',
        position: 'relative'
      }}>
        {/* Timeline Visualization */}
        <div style={{
          flex: 1,
          position: 'relative',
          padding: '2rem',
          background: 'linear-gradient(135deg, #F9FAFB 0%, #F3F4F6 100%)'
        }}>
          {/* Timeline Line */}
          <div style={{
            position: 'absolute',
            left: '10%',
            top: '10%',
            bottom: '10%',
            width: '2px',
            backgroundColor: perspectives[selectedPerspective].color,
            opacity: 0.3
          }} />

          {/* Century Label */}
          <div style={{
            position: 'absolute',
            top: '5%',
            left: '5%',
            fontSize: '1.2rem',
            fontWeight: 'bold',
            color: perspectives[selectedPerspective].color
          }}>
            20th Century
          </div>

          {/* Historical Events */}
          {historicalEvents.map((event) => (
            <div
              key={event.id}
              onMouseEnter={() => handleEventHover(event.id)}
              onMouseLeave={handleEventLeave}
              style={{
                position: 'absolute',
                ...event.position,
                width: '200px',
                cursor: 'pointer'
              }}
            >
              {/* Event Marker */}
              <div style={{
                width: '12px',
                height: '12px',
                borderRadius: '50%',
                backgroundColor: perspectives[selectedPerspective].color,
                marginBottom: '0.5rem',
                transform: hoveredEvent === event.id ? 'scale(1.3)' : 'scale(1)',
                transition: 'transform 0.2s ease'
              }} />

              {/* Event Title */}
              <div style={{
                fontSize: '0.9rem',
                fontWeight: 'bold',
                color: '#111827',
                marginBottom: '0.5rem',
                padding: '0.5rem',
                backgroundColor: hoveredEvent === event.id ? '#ffffff' : 'transparent',
                borderRadius: '4px',
                boxShadow: hoveredEvent === event.id ? '0 4px 6px -1px rgba(0, 0, 0, 0.1)' : 'none',
                transition: 'all 0.2s ease'
              }}>
                {event.title}
              </div>

              {/* Current Interpretation */}
              {hoveredEvent === event.id && selectedPerspective === 'western' && (
                <div style={{
                  position: 'absolute',
                  top: '100%',
                  left: 0,
                  width: '300px',
                  padding: '1rem',
                  backgroundColor: '#ffffff',
                  border: `2px solid ${perspectives.western.color}`,
                  borderRadius: '8px',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                  zIndex: 10,
                  fontSize: '0.9rem',
                  color: '#374151'
                }}>
                  <div style={{
                    fontWeight: 'bold',
                    color: perspectives.western.color,
                    marginBottom: '0.5rem'
                  }}>
                    Current View (2024):
                  </div>
                  {event.current}
                </div>
              )}

              {/* Future Interpretation */}
              {hoveredEvent === event.id && selectedPerspective !== 'western' && (
                <div style={{
                  position: 'absolute',
                  top: '100%',
                  left: 0,
                  width: '300px',
                  padding: '1rem',
                  backgroundColor: '#ffffff',
                  border: `2px solid ${perspectives[selectedPerspective].color}`,
                  borderRadius: '8px',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                  zIndex: 10,
                  fontSize: '0.9rem'
                }}>
                  <div style={{
                    fontWeight: 'bold',
                    color: perspectives[selectedPerspective].color,
                    marginBottom: '0.5rem'
                  }}>
                    2099 Reinterpretation:
                  </div>
                  <div style={{ color: '#374151', marginBottom: '1rem' }}>
                    {event.interpretations[selectedPerspective]}
                  </div>
                  <div style={{
                    fontSize: '0.8rem',
                    color: '#6B7280',
                    borderTop: '1px solid #E5E7EB',
                    paddingTop: '0.5rem'
                  }}>
                    <strong>Previously thought:</strong> {event.current}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Information Panel */}
        <div style={{
          width: '350px',
          backgroundColor: '#ffffff',
          borderLeft: '1px solid #E5E7EB',
          padding: '2rem',
          display: 'flex',
          flexDirection: 'column'
        }}>
          <h3 style={{
            fontSize: '1.3rem',
            fontWeight: 'bold',
            color: perspectives[selectedPerspective].color,
            marginBottom: '1rem'
          }}>
            {perspectives[selectedPerspective].title}
          </h3>

          <p style={{
            color: '#6B7280',
            marginBottom: '2rem',
            fontSize: '0.95rem',
            lineHeight: '1.5'
          }}>
            {perspectives[selectedPerspective].description}
          </p>

          <div style={{
            padding: '1.5rem',
            backgroundColor: `${perspectives[selectedPerspective].color}08`,
            borderLeft: `4px solid ${perspectives[selectedPerspective].color}`,
            borderRadius: '4px',
            marginBottom: '2rem'
          }}>
            <h4 style={{
              fontSize: '1rem',
              fontWeight: 'bold',
              color: '#111827',
              marginBottom: '0.5rem'
            }}>
              Key Insight
            </h4>
            <p style={{
              fontSize: '0.9rem',
              color: '#374151',
              margin: 0,
              lineHeight: '1.4'
            }}>
              {selectedPerspective === 'western' && "Our current historical narrative reflects mid-20th century Western dominance. Future shifts in global power will inevitably reshape these stories."}
              {selectedPerspective === 'asian' && "By 2099, Asia's economic dominance may reframe the 20th century as the period when the West briefly interrupted Asia's natural centrality."}
              {selectedPerspective === 'muslim' && "A resurgent Islamic civilization might view the 20th century as the end of Western secular dominance and the beginning of religious renewal."}
              {selectedPerspective === 'american' && "If the Americas unite economically, they might reinterpret the 20th century as the foundation of hemispheric cooperation."}
            </p>
          </div>

          <div style={{
            fontSize: '0.85rem',
            color: '#9CA3AF',
            textAlign: 'center',
            borderTop: '1px solid #E5E7EB',
            paddingTop: '1rem'
          }}>
            Hover over events to see reinterpretations
          </div>
        </div>
      </div>
    </div>
  );
}