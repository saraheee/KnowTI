import { useState, useRef } from "react";

const PHASES = [
  { id:"ancien",  label:"Ancien Régime",          dates:"Before 1789",  color:"#7c3aed", light:"#f5f3ff", border:"#ddd6fe" },
  { id:"reform",  label:"Constitutional Monarchy", dates:"1789–1792",   color:"#2563eb", light:"#eff6ff", border:"#bfdbfe" },
  { id:"terror",  label:"The Terror",              dates:"1793–1794",   color:"#dc2626", light:"#fef2f2", border:"#fecaca" },
  { id:"direct",  label:"Directory & Napoleon",    dates:"1795–1804",   color:"#059669", light:"#ecfdf5", border:"#a7f3d0" },
];

const EVENTS = [
  { id:"e1",  label:"Estate-General convened",    phase:"reform", year:"May 1789",    hint:"Louis XVI called this assembly for first time in 175 years — to solve the debt crisis.",  why:"The Estates-General met in 1789 when Louis XVI needed to raise taxes. It triggered the revolution." },
  { id:"e2",  label:"Storming of the Bastille",   phase:"reform", year:"Jul 1789",    hint:"Medieval fortress as royal tyranny. Its fall was symbolic, not strategic.",              why:"The Bastille fell on 14 July 1789 — now France's national day — marking the people's power." },
  { id:"e3",  label:"Declaration of the Rights of Man", phase:"reform", year:"Aug 1789", hint:"Drafted partly by Lafayette with Jefferson's advice.",                               why:"August 1789, early in the constitutional phase. Enshrined liberty and equality." },
  { id:"e4",  label:"King Louis XVI executed",    phase:"terror", year:"Jan 1793",    hint:"He tried to flee France (1791). His execution shocked monarchies across Europe.",       why:"21 January 1793 — the Terror's signature act. Monarchy abolished." },
  { id:"e5",  label:"Robespierre's Great Terror", phase:"terror", year:"1793–94",     hint:"The Committee of Public Safety sent 17,000 to the guillotine in 14 months.",           why:"Robespierre's rule of fear defined 1793–94 before he himself was executed (Thermidor)." },
  { id:"e6",  label:"Robespierre guillotined",    phase:"terror", year:"Jul 1794",    hint:"The revolution devoured its own — Thermidorian Reaction ended the Terror.",            why:"9 Thermidor (27 July 1794) ended the Terror — Robespierre fell to the machine he built." },
  { id:"e7",  label:"The Directory established",  phase:"direct", year:"Nov 1795",    hint:"Five-man executive. Corrupt and ineffective, but ended the Terror's excesses.",        why:"The Directory replaced the Convention in 1795, bridging Terror and Napoleon." },
  { id:"e8",  label:"Napoleon's coup (18 Brumaire)",phase:"direct",year:"Nov 1799",   hint:"Napoleon dissolved the Directory in a coup and declared himself First Consul.",       why:"18 Brumaire 1799 ended the Revolution. Napoleon became First Consul, then Emperor." },
  { id:"e9",  label:"The Three Estates",          phase:"ancien", year:"Pre-1789",    hint:"First (clergy) and Second (nobility) estates paid almost no taxes. The Third paid all.", why:"The Ancien Régime's three estates — clergy, nobles, commoners — existed before the Revolution." },
  { id:"e10", label:"Tax farming & debt crisis",  phase:"ancien", year:"1786–89",     hint:"France was bankrupt after the American Revolution and Louis XIV's wars.",              why:"France's debt was 1.5× its annual revenue by 1789 — the economic trigger of revolution." },
];

function shuffle(arr) {
  const a=[...arr];
  for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
  return a;
}

export default function App() {
  const [pool,      setPool]      = useState(()=>shuffle(EVENTS));
  const [placed,    setPlaced]    = useState({});   // {phaseId: [eventId...]}
  const [feedback,  setFeedback]  = useState({});   // {eventId: "correct"|"wrong"}
  const [tooltip,   setTooltip]   = useState(null); // eventId
  const dragging = useRef(null);

  const score = Object.values(feedback).filter(v=>v==="correct").length;

  const onDragStart=(id)=>{ dragging.current=id; };

  const onDrop=(phaseId)=>{
    const id=dragging.current; if(!id) return;
    dragging.current=null;
    const ev=EVENTS.find(e=>e.id===id); if(!ev) return;
    const correct=ev.phase===phaseId;
    setFeedback(f=>({...f,[id]:correct?"correct":"wrong"}));
    if(correct){
      setPool(p=>p.filter(e=>e.id!==id));
      setPlaced(p=>({...p,[phaseId]:[...(p[phaseId]||[]),id]}));
      // clear wrong feedback for other slots
    } else {
      setTimeout(()=>setFeedback(f=>{const n={...f};delete n[id];return n;}),1200);
    }
  };

  const reset=()=>{setPool(shuffle(EVENTS));setPlaced({});setFeedback({});setTooltip(null);};

  const tooltipEv = EVENTS.find(e=>e.id===tooltip);

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"15px 24px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:960,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <h1 style={{fontSize:20,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>The French Revolution</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>1789–1799 · Drag each event to its correct phase</p>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{fontSize:13,fontWeight:700,color:"#0f172a"}}>
              {score} / {EVENTS.length} <span style={{fontWeight:400,color:"#94a3b8"}}>placed</span>
            </div>
            <button onClick={reset} style={{padding:"6px 14px",border:"1px solid #e2e8f0",borderRadius:8,
              background:"#fff",color:"#64748b",fontSize:11,fontWeight:600,cursor:"pointer"}}>↺ Reset</button>
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",
        padding:"10px 20px 12px",maxWidth:960,margin:"0 auto",width:"100%",boxSizing:"border-box",gap:10}}>

        {/* Phase columns */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,flex:1,overflow:"hidden"}}>
          {PHASES.map(ph=>{
            const placedIds=placed[ph.id]||[];
            return (
              <div key={ph.id}
                onDragOver={e=>e.preventDefault()}
                onDrop={()=>onDrop(ph.id)}
                style={{display:"flex",flexDirection:"column",gap:6,overflow:"hidden"}}>
                {/* Phase header */}
                <div style={{background:ph.light,border:`2px solid ${ph.border}`,borderRadius:10,
                  padding:"9px 12px",textAlign:"center",flexShrink:0}}>
                  <div style={{fontSize:12,fontWeight:800,color:ph.color,letterSpacing:"0.04em"}}>{ph.label}</div>
                  <div style={{fontSize:10,color:ph.color,opacity:0.7,marginTop:1}}>{ph.dates}</div>
                </div>
                {/* Drop zone */}
                <div style={{flex:1,background:"#fafafa",border:`2px dashed ${ph.border}`,borderRadius:10,
                  padding:8,display:"flex",flexDirection:"column",gap:6,overflow:"auto",minHeight:80}}>
                  {placedIds.map(id=>{
                    const ev=EVENTS.find(e=>e.id===id);
                    return (
                      <div key={id}
                        onMouseEnter={()=>setTooltip(id)} onMouseLeave={()=>setTooltip(null)}
                        style={{background:ph.light,border:`1.5px solid ${ph.border}`,borderRadius:8,
                          padding:"8px 10px",cursor:"default",position:"relative"}}>
                        <div style={{fontSize:11,fontWeight:700,color:ph.color,lineHeight:1.3}}>✓ {ev.label}</div>
                        <div style={{fontSize:10,color:ph.color,opacity:0.7,marginTop:1}}>{ev.year}</div>
                        {tooltip===id&&tooltipEv&&(
                          <div style={{position:"absolute",left:"calc(100% + 6px)",top:0,
                            background:"#0f172a",color:"#fff",borderRadius:8,padding:"10px 12px",
                            width:200,fontSize:11,lineHeight:1.6,zIndex:50,pointerEvents:"none",
                            boxShadow:"0 8px 24px rgba(0,0,0,0.2)"}}>
                            {tooltipEv.why}
                          </div>
                        )}
                      </div>
                    );
                  })}
                  {placedIds.length===0&&(
                    <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",
                      fontSize:10,color:"#cbd5e1",fontStyle:"italic"}}>Drop events here</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Event pool */}
        <div style={{flexShrink:0}}>
          <div style={{fontSize:10,color:"#94a3b8",fontWeight:700,letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:7}}>
            Events to place — drag each to the correct phase:
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:7}}>
            {pool.map(ev=>{
              const iswrong=feedback[ev.id]==="wrong";
              return (
                <div key={ev.id}
                  draggable
                  onDragStart={()=>onDragStart(ev.id)}
                  onMouseEnter={()=>setTooltip(ev.id)}
                  onMouseLeave={()=>setTooltip(null)}
                  style={{
                    background:iswrong?"#fef2f2":"#f8fafc",
                    border:`1.5px solid ${iswrong?"#fecaca":"#e2e8f0"}`,
                    borderRadius:8,padding:"7px 12px",cursor:"grab",
                    transition:"all 0.15s",userSelect:"none",position:"relative",
                    boxShadow:iswrong?"0 0 0 2px #fca5a5":"none",
                  }}>
                  <div style={{fontSize:11,fontWeight:600,color:iswrong?"#dc2626":"#334155",lineHeight:1.3}}>
                    {iswrong?"✗ Try another phase":""}  {ev.label}
                  </div>
                  <div style={{fontSize:10,color:"#94a3b8",marginTop:1}}>{ev.year}</div>
                  {tooltip===ev.id&&(
                    <div style={{position:"absolute",bottom:"calc(100% + 6px)",left:0,
                      background:"#0f172a",color:"#fff",borderRadius:8,padding:"10px 12px",
                      width:220,fontSize:11,lineHeight:1.6,zIndex:50,pointerEvents:"none",
                      boxShadow:"0 8px 24px rgba(0,0,0,0.2)"}}>
                      💡 {ev.hint}
                    </div>
                  )}
                </div>
              );
            })}
            {pool.length===0&&(
              <div style={{fontSize:13,fontWeight:700,color:"#059669",padding:"8px 0"}}>
                🎉 All {EVENTS.length} events placed correctly!
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
