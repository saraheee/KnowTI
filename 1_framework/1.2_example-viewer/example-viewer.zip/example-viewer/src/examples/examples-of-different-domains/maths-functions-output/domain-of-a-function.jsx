import { useState, useCallback } from "react";

const ITEMS = [
  { id: "x1", value: "-2", type: "domain" },
  { id: "x2", value: "0", type: "domain" },
  { id: "x3", value: "3", type: "domain" },
  { id: "x4", value: "5", type: "domain" },
  { id: "fx1", value: "4", type: "range" },
  { id: "fx2", value: "0", type: "range" },
  { id: "fx3", value: "9", type: "range" },
  { id: "fx4", value: "25", type: "range" },
];

const TABLE_DATA = [
  { x: "-2", fx: "4" },
  { x: "0", fx: "0" },
  { x: "3", fx: "9" },
  { x: "5", fx: "25" },
];

const COLORS = {
  domain: {
    bg: "#e0f2fe",
    border: "#0284c7",
    text: "#0369a1",
    chip: "#0ea5e9",
    hover: "#bae6fd",
    correct: "#0284c7",
    label: "Domain",
  },
  range: {
    bg: "#fdf4ff",
    border: "#a855f7",
    text: "#7e22ce",
    chip: "#a855f7",
    hover: "#f3e8ff",
    correct: "#a855f7",
    label: "Range",
  },
  wrong: {
    bg: "#fee2e2",
    border: "#ef4444",
    text: "#b91c1c",
  },
};

function Chip({ item, onDragStart, placed, correct, hovered, onMouseEnter, onMouseLeave }) {
  const isDomain = item.type === "domain";
  const color = isDomain ? COLORS.domain : COLORS.range;

  let bg = "#f1f5f9";
  let border = "#cbd5e1";
  let textColor = "#334155";

  if (placed && correct === true) {
    bg = color.bg;
    border = color.border;
    textColor = color.text;
  } else if (placed && correct === false) {
    bg = COLORS.wrong.bg;
    border = COLORS.wrong.border;
    textColor = COLORS.wrong.text;
  } else if (hovered) {
    bg = "#e2e8f0";
  }

  return (
    <div
      draggable
      onDragStart={() => onDragStart(item.id)}
      onMouseEnter={() => onMouseEnter(item.id)}
      onMouseLeave={onMouseLeave}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "8px 20px",
        borderRadius: "999px",
        border: `2px solid ${border}`,
        background: bg,
        color: textColor,
        fontWeight: "700",
        fontSize: "18px",
        cursor: "grab",
        userSelect: "none",
        transition: "background 0.15s, border-color 0.15s, transform 0.1s",
        transform: hovered && !placed ? "scale(1.08)" : "scale(1)",
        boxShadow: hovered ? "0 4px 16px rgba(0,0,0,0.10)" : "0 1px 4px rgba(0,0,0,0.06)",
        minWidth: "64px",
      }}
    >
      {item.value}
    </div>
  );
}

function Bucket({ bucketType, items, onDrop, onDragOver, onDragLeave, isOver, placements, showHint }) {
  const color = COLORS[bucketType];
  const def = bucketType === "domain"
    ? "All valid input values (x)"
    : "All possible output values f(x)";
  const symbol = bucketType === "domain" ? "x" : "f(x)";

  return (
    <div
      onDrop={() => onDrop(bucketType)}
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      style={{
        flex: 1,
        minHeight: "220px",
        borderRadius: "20px",
        border: `3px dashed ${isOver ? color.border : "#cbd5e1"}`,
        background: isOver ? color.hover : color.bg,
        padding: "24px 20px 20px",
        transition: "background 0.18s, border-color 0.18s",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "12px",
      }}
    >
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "2px", marginBottom: "6px" }}>
        <div style={{
          fontSize: "20px",
          fontWeight: "800",
          color: color.text,
          letterSpacing: "-0.5px",
        }}>
          {color.label}
        </div>
        <div style={{
          fontSize: "13px",
          color: color.text,
          opacity: 0.7,
          fontStyle: "italic",
        }}>
          {symbol} values
        </div>
        {showHint && (
          <div style={{
            fontSize: "12px",
            color: color.text,
            background: color.bg,
            border: `1px solid ${color.border}`,
            borderRadius: "8px",
            padding: "4px 10px",
            marginTop: "4px",
            opacity: 0.9,
          }}>
            {def}
          </div>
        )}
      </div>
      <div style={{
        display: "flex",
        flexWrap: "wrap",
        gap: "10px",
        justifyContent: "center",
        minHeight: "56px",
        alignItems: "center",
        width: "100%",
      }}>
        {items.length === 0 && (
          <div style={{ color: "#94a3b8", fontSize: "14px", fontStyle: "italic" }}>
            Drop values here
          </div>
        )}
        {items.map((item) => {
          const placement = placements[item.id];
          const correct = placement ? placement.correct : null;
          const color2 = item.type === "domain" ? COLORS.domain : COLORS.range;
          let bg = "#fff";
          let border = "#e2e8f0";
          let textColor2 = "#334155";
          if (correct === true) {
            bg = color2.bg;
            border = color2.border;
            textColor2 = color2.text;
          } else if (correct === false) {
            bg = COLORS.wrong.bg;
            border = COLORS.wrong.border;
            textColor2 = COLORS.wrong.text;
          }
          return (
            <div
              key={item.id}
              style={{
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "8px 20px",
                borderRadius: "999px",
                border: `2px solid ${border}`,
                background: bg,
                color: textColor2,
                fontWeight: "700",
                fontSize: "18px",
                boxShadow: "0 1px 4px rgba(0,0,0,0.07)",
                position: "relative",
              }}
            >
              {item.value}
              {correct === true && (
                <span style={{ marginLeft: "6px", fontSize: "14px" }}>✓</span>
              )}
              {correct === false && (
                <span style={{ marginLeft: "6px", fontSize: "14px" }}>✗</span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function App() {
  const [placements, setPlacements] = useState({});
  const [dragId, setDragId] = useState(null);
  const [overBucket, setOverBucket] = useState(null);
  const [hoveredChip, setHoveredChip] = useState(null);
  const [showHint, setShowHint] = useState(false);
  const [hoveredRow, setHoveredRow] = useState(null);
  const [showExplain, setShowExplain] = useState(false);

  const unplaced = ITEMS.filter((item) => !placements[item.id]);
  const domainItems = ITEMS.filter(
    (item) => placements[item.id]?.bucket === "domain"
  );
  const rangeItems = ITEMS.filter(
    (item) => placements[item.id]?.bucket === "range"
  );

  const allPlaced = unplaced.length === 0;
  const score = Object.values(placements).filter((p) => p.correct).length;

  const handleDragStart = useCallback((id) => {
    setDragId(id);
  }, []);

  const handleDrop = useCallback(
    (bucket) => {
      if (!dragId) return;
      const item = ITEMS.find((i) => i.id === dragId);
      const correct = item.type === bucket;
      setPlacements((prev) => ({
        ...prev,
        [dragId]: { bucket, correct },
      }));
      setDragId(null);
      setOverBucket(null);
    },
    [dragId]
  );

  const handleDragOver = useCallback(
    (e, bucket) => {
      e.preventDefault();
      setOverBucket(bucket);
    },
    []
  );

  const handleDragLeave = useCallback(() => {
    setOverBucket(null);
  }, []);

  const handleReset = () => {
    setPlacements({});
    setShowExplain(false);
  };

  return (
    <div
      style={{
        background: "#ffffff",
        width: "100%",
        minHeight: "100vh",
        fontFamily: "'Segoe UI', system-ui, sans-serif",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "40px 16px 60px",
        boxSizing: "border-box",
      }}
    >
      {/* Header */}
      <div style={{ textAlign: "center", marginBottom: "32px", maxWidth: "640px" }}>
        <div style={{
          fontSize: "13px",
          fontWeight: "600",
          color: "#64748b",
          letterSpacing: "2px",
          textTransform: "uppercase",
          marginBottom: "8px",
        }}>
          Functions
        </div>
        <h1 style={{
          fontSize: "clamp(24px, 4vw, 36px)",
          fontWeight: "900",
          color: "#0f172a",
          margin: "0 0 10px",
          letterSpacing: "-1px",
        }}>
          Domain vs. Range Sorter
        </h1>
        <p style={{ color: "#64748b", fontSize: "16px", margin: 0, lineHeight: 1.6 }}>
          Drag each value from the table into the correct bucket.{" "}
          <button
            onClick={() => setShowHint((h) => !h)}
            style={{
              background: "none",
              border: "none",
              color: "#0284c7",
              cursor: "pointer",
              fontWeight: "600",
              fontSize: "15px",
              textDecoration: "underline",
              padding: 0,
            }}
          >
            {showHint ? "Hide hints" : "Need a hint?"}
          </button>
        </p>
      </div>

      {/* Table */}
      <div style={{ marginBottom: "36px", overflowX: "auto", width: "100%", maxWidth: "500px" }}>
        <table style={{
          width: "100%",
          borderCollapse: "separate",
          borderSpacing: "0",
          borderRadius: "16px",
          overflow: "hidden",
          boxShadow: "0 2px 16px rgba(0,0,0,0.07)",
        }}>
          <thead>
            <tr>
              <th style={{
                background: COLORS.domain.bg,
                color: COLORS.domain.text,
                padding: "14px 24px",
                fontSize: "15px",
                fontWeight: "800",
                textAlign: "center",
                borderBottom: `2px solid ${COLORS.domain.border}`,
              }}>
                x
                {showHint && (
                  <div style={{ fontSize: "11px", fontWeight: "500", opacity: 0.8, marginTop: "2px" }}>
                    input (Domain)
                  </div>
                )}
              </th>
              <th style={{
                background: COLORS.range.bg,
                color: COLORS.range.text,
                padding: "14px 24px",
                fontSize: "15px",
                fontWeight: "800",
                textAlign: "center",
                borderBottom: `2px solid ${COLORS.range.border}`,
              }}>
                f(x)
                {showHint && (
                  <div style={{ fontSize: "11px", fontWeight: "500", opacity: 0.8, marginTop: "2px" }}>
                    output (Range)
                  </div>
                )}
              </th>
            </tr>
          </thead>
          <tbody>
            {TABLE_DATA.map((row, i) => (
              <tr
                key={i}
                onMouseEnter={() => setHoveredRow(i)}
                onMouseLeave={() => setHoveredRow(null)}
                style={{
                  background: hoveredRow === i ? "#f8fafc" : "#fff",
                  transition: "background 0.12s",
                }}
              >
                <td style={{
                  padding: "14px 24px",
                  textAlign: "center",
                  fontSize: "18px",
                  fontWeight: "700",
                  color: hoveredRow === i ? COLORS.domain.text : "#1e293b",
                  borderBottom: i < TABLE_DATA.length - 1 ? "1px solid #f1f5f9" : "none",
                  transition: "color 0.12s",
                }}>
                  {row.x}
                  {hoveredRow === i && (
                    <span style={{ fontSize: "11px", color: COLORS.domain.text, marginLeft: "6px", fontWeight: "500" }}>
                      input
                    </span>
                  )}
                </td>
                <td style={{
                  padding: "14px 24px",
                  textAlign: "center",
                  fontSize: "18px",
                  fontWeight: "700",
                  color: hoveredRow === i ? COLORS.range.text : "#1e293b",
                  borderBottom: i < TABLE_DATA.length - 1 ? "1px solid #f1f5f9" : "none",
                  transition: "color 0.12s",
                }}>
                  {row.fx}
                  {hoveredRow === i && (
                    <span style={{ fontSize: "11px", color: COLORS.range.text, marginLeft: "6px", fontWeight: "500" }}>
                      output
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Unplaced chips */}
      {unplaced.length > 0 && (
        <div style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "12px",
          justifyContent: "center",
          marginBottom: "32px",
          minHeight: "60px",
          alignItems: "center",
          maxWidth: "560px",
          width: "100%",
          padding: "16px",
          borderRadius: "16px",
          background: "#f8fafc",
          border: "2px dashed #e2e8f0",
        }}>
          <div style={{
            width: "100%",
            textAlign: "center",
            fontSize: "12px",
            color: "#94a3b8",
            marginBottom: "4px",
            fontWeight: "600",
            letterSpacing: "1px",
            textTransform: "uppercase",
          }}>
            Values to sort
          </div>
          {unplaced.map((item) => (
            <Chip
              key={item.id}
              item={item}
              onDragStart={handleDragStart}
              placed={false}
              correct={null}
              hovered={hoveredChip === item.id}
              onMouseEnter={setHoveredChip}
              onMouseLeave={() => setHoveredChip(null)}
            />
          ))}
        </div>
      )}

      {/* Buckets */}
      <div style={{
        display: "flex",
        gap: "20px",
        width: "100%",
        maxWidth: "640px",
        marginBottom: "28px",
        flexWrap: "wrap",
      }}>
        <Bucket
          bucketType="domain"
          items={domainItems}
          onDrop={handleDrop}
          onDragOver={(e) => handleDragOver(e, "domain")}
          onDragLeave={handleDragLeave}
          isOver={overBucket === "domain"}
          placements={placements}
          showHint={showHint}
        />
        <Bucket
          bucketType="range"
          items={rangeItems}
          onDrop={handleDrop}
          onDragOver={(e) => handleDragOver(e, "range")}
          onDragLeave={handleDragLeave}
          isOver={overBucket === "range"}
          placements={placements}
          showHint={showHint}
        />
      </div>

      {/* Score / feedback */}
      {allPlaced && (
        <div style={{
          maxWidth: "500px",
          width: "100%",
          borderRadius: "16px",
          background: score === 8 ? "#f0fdf4" : "#fff7ed",
          border: `2px solid ${score === 8 ? "#22c55e" : "#f59e0b"}`,
          padding: "24px",
          textAlign: "center",
          marginBottom: "20px",
        }}>
          <div style={{
            fontSize: "28px",
            fontWeight: "900",
            color: score === 8 ? "#15803d" : "#b45309",
            marginBottom: "6px",
          }}>
            {score === 8 ? "🎉 Perfect!" : `${score} / 8 correct`}
          </div>
          <div style={{ color: "#64748b", fontSize: "15px", marginBottom: "16px" }}>
            {score === 8
              ? "You correctly identified all domain and range values."
              : "Some values are in the wrong bucket. Try again!"}
          </div>
          <div style={{ display: "flex", gap: "12px", justifyContent: "center", flexWrap: "wrap" }}>
            <button
              onClick={handleReset}
              style={{
                padding: "10px 24px",
                borderRadius: "999px",
                border: "2px solid #e2e8f0",
                background: "#fff",
                color: "#334155",
                fontWeight: "700",
                fontSize: "14px",
                cursor: "pointer",
              }}
            >
              Reset
            </button>
            {score === 8 && (
              <button
                onClick={() => setShowExplain((s) => !s)}
                style={{
                  padding: "10px 24px",
                  borderRadius: "999px",
                  border: "2px solid #0284c7",
                  background: "#0284c7",
                  color: "#fff",
                  fontWeight: "700",
                  fontSize: "14px",
                  cursor: "pointer",
                }}
              >
                {showExplain ? "Hide explanation" : "Explain the concepts"}
              </button>
            )}
          </div>
        </div>
      )}

      {/* Explanation panel */}
      {showExplain && (
        <div style={{
          maxWidth: "500px",
          width: "100%",
          borderRadius: "16px",
          background: "#f8fafc",
          border: "1px solid #e2e8f0",
          padding: "24px",
          display: "flex",
          flexDirection: "column",
          gap: "16px",
        }}>
          <div>
            <div style={{
              display: "inline-block",
              background: COLORS.domain.bg,
              color: COLORS.domain.text,
              borderRadius: "8px",
              padding: "3px 12px",
              fontWeight: "800",
              fontSize: "14px",
              marginBottom: "6px",
            }}>
              Domain
            </div>
            <p style={{ margin: 0, color: "#334155", fontSize: "15px", lineHeight: 1.6 }}>
              The <strong>domain</strong> is the set of all valid <em>input</em> values — the x‑values you plug into the function. Here: <strong>{"{"}-2, 0, 3, 5{"}"}</strong>.
            </p>
          </div>
          <div>
            <div style={{
              display: "inline-block",
              background: COLORS.range.bg,
              color: COLORS.range.text,
              borderRadius: "8px",
              padding: "3px 12px",
              fontWeight: "800",
              fontSize: "14px",
              marginBottom: "6px",
            }}>
              Range
            </div>
            <p style={{ margin: 0, color: "#334155", fontSize: "15px", lineHeight: 1.6 }}>
              The <strong>range</strong> is the set of all possible <em>output</em> values — the f(x) values the function produces. Here: <strong>{"{"} 0, 4, 9, 25{"}"}</strong>.
            </p>
          </div>
          <div style={{
            background: "#fff",
            border: "1px solid #e2e8f0",
            borderRadius: "10px",
            padding: "14px 16px",
            color: "#64748b",
            fontSize: "14px",
            lineHeight: 1.6,
          }}>
            <strong style={{ color: "#334155" }}>Key distinction:</strong> Domain → what goes <em>in</em>. Range → what comes <em>out</em>. A value can only be in the range if the function actually produces it.
          </div>
        </div>
      )}
    </div>
  );
}