import { useState, useCallback } from "react";

const PIECES = [
  {
    id: "notation",
    label: "Notation",
    color: "#6366f1",
    lightColor: "#e0e7ff",
    x: 60,
    y: 80,
    detail: "f(x), g(t), h(n)… the symbolic language of functions is dense and unfamiliar, making even simple expressions feel foreign at first.",
    challenge: "Students often confuse f(x) as multiplication rather than 'f evaluated at x'.",
  },
  {
    id: "domain",
    label: "Domain",
    color: "#0ea5e9",
    lightColor: "#e0f2fe",
    x: 75,
    y: 55,
    detail: "The set of all valid inputs. Knowing which values are allowed — and why — requires understanding restrictions like division by zero or square roots of negatives.",
    challenge: "Finding domain from graphs vs. equations requires different reasoning skills.",
  },
  {
    id: "range",
    label: "Range",
    color: "#10b981",
    lightColor: "#d1fae5",
    x: 15,
    y: 55,
    detail: "All possible output values. The range depends on both the rule and the domain, making it harder to determine than the domain.",
    challenge: "Students struggle to distinguish domain (inputs) from range (outputs) intuitively.",
  },
  {
    id: "evaluation",
    label: "Evaluation",
    color: "#f59e0b",
    lightColor: "#fef3c7",
    x: 15,
    y: 80,
    detail: "Substituting a value into a function to find the output. This requires careful algebraic manipulation and order of operations.",
    challenge: "Evaluating f(x+h) or f(2x) trips up students who aren't yet fluent with substitution.",
  },
  {
    id: "composition",
    label: "Composition",
    color: "#ec4899",
    lightColor: "#fce7f3",
    x: 72,
    y: 20,
    detail: "Applying one function to the output of another: f(g(x)). Order matters — f(g(x)) ≠ g(f(x)) in general.",
    challenge: "The layered substitution and reversed reading direction (inside-out) confuse many learners.",
  },
  {
    id: "inverse",
    label: "Inverse",
    color: "#8b5cf6",
    lightColor: "#ede9fe",
    x: 18,
    y: 20,
    detail: "The function that 'undoes' another. f⁻¹(f(x)) = x. Only one-to-one functions have inverses.",
    challenge: "f⁻¹(x) looks like a negative exponent but means something completely different.",
  },
  {
    id: "graphs",
    label: "Graphs",
    color: "#ef4444",
    lightColor: "#fee2e2",
    x: 45,
    y: 12,
    detail: "Visual representations connecting inputs to outputs. The vertical line test determines if a graph is a function.",
    challenge: "Translating between algebraic and graphical representations requires strong spatial reasoning.",
  },
  {
    id: "types",
    label: "Types",
    color: "#14b8a6",
    lightColor: "#ccfbf1",
    x: 45,
    y: 82,
    detail: "Linear, quadratic, exponential, logarithmic, trigonometric… each family has its own patterns, rules, and behaviors.",
    challenge: "Each function type feels like a new subject; connecting them into a unified concept is difficult.",
  },
];

const FRAME_SLOTS = PIECES.map((p, i) => ({
  id: p.id,
  angle: (i / PIECES.length) * 360,
}));

function PuzzlePiece({ piece, isPlaced, isHovered, isDragging, onMouseEnter, onMouseLeave, onClick, style }) {
  const baseSize = 90;
  return (
    <div
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      onClick={onClick}
      style={{
        position: "absolute",
        width: baseSize,
        height: baseSize,
        borderRadius: isPlaced ? "12px" : "16px 4px 16px 4px",
        background: isHovered || isDragging ? piece.color : piece.lightColor,
        border: `2.5px solid ${piece.color}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        transform: isHovered ? "scale(1.08)" : isDragging ? "scale(1.04) rotate(2deg)" : "scale(1)",
        transition: "transform 0.2s ease, background 0.2s ease, box-shadow 0.2s ease",
        boxShadow: isHovered
          ? `0 8px 24px ${piece.color}55`
          : `0 2px 8px ${piece.color}33`,
        zIndex: isHovered || isDragging ? 10 : 2,
        userSelect: "none",
        ...style,
      }}
    >
      <span
        style={{
          fontSize: 13,
          fontWeight: 700,
          color: isHovered || isDragging ? "#fff" : piece.color,
          letterSpacing: 0.3,
          textAlign: "center",
          padding: "0 8px",
          transition: "color 0.2s ease",
        }}
      >
        {piece.label}
      </span>
    </div>
  );
}

function InfoPanel({ piece, onClose }) {
  if (!piece) return null;
  return (
    <div
      style={{
        position: "fixed",
        bottom: 24,
        left: "50%",
        transform: "translateX(-50%)",
        background: "#ffffff",
        border: `2px solid ${piece.color}`,
        borderRadius: 16,
        padding: "20px 28px",
        maxWidth: 480,
        width: "calc(100% - 48px)",
        boxShadow: `0 8px 32px ${piece.color}44`,
        zIndex: 100,
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
        <span
          style={{
            fontSize: 16,
            fontWeight: 800,
            color: piece.color,
            letterSpacing: 0.3,
          }}
        >
          {piece.label}
        </span>
        <button
          onClick={onClose}
          style={{
            background: "none",
            border: "none",
            cursor: "pointer",
            color: "#94a3b8",
            fontSize: 18,
            lineHeight: 1,
            padding: "0 2px",
          }}
        >
          ×
        </button>
      </div>
      <p style={{ fontSize: 14, color: "#334155", lineHeight: 1.6, margin: "0 0 10px 0" }}>
        {piece.detail}
      </p>
      <div
        style={{
          background: piece.lightColor,
          borderRadius: 8,
          padding: "10px 14px",
          borderLeft: `3px solid ${piece.color}`,
        }}
      >
        <span style={{ fontSize: 12, fontWeight: 700, color: piece.color, textTransform: "uppercase", letterSpacing: 0.5 }}>
          Common Difficulty
        </span>
        <p style={{ fontSize: 13, color: "#475569", margin: "4px 0 0 0", lineHeight: 1.55 }}>
          {piece.challenge}
        </p>
      </div>
    </div>
  );
}

export default function App() {
  const [placedIds, setPlacedIds] = useState([]);
  const [hoveredId, setHoveredId] = useState(null);
  const [selectedPiece, setSelectedPiece] = useState(null);
  const [viewMode, setViewMode] = useState("scattered"); // "scattered" | "assembled"
  const [framePieceHover, setFramePieceHover] = useState(null);

  const allPlaced = placedIds.length === PIECES.length;

  const handlePieceClick = useCallback((piece) => {
    if (viewMode === "scattered") {
      setPlacedIds((prev) =>
        prev.includes(piece.id) ? prev : [...prev, piece.id]
      );
      setSelectedPiece(piece);
    } else {
      setSelectedPiece(piece);
    }
  }, [viewMode]);

  const handleAssemble = useCallback(() => {
    setViewMode("assembled");
    setPlacedIds(PIECES.map((p) => p.id));
    setSelectedPiece(null);
  }, []);

  const handleScatter = useCallback(() => {
    setViewMode("scattered");
    setPlacedIds([]);
    setSelectedPiece(null);
    setFramePieceHover(null);
  }, []);

  // Positions in assembled ring
  const getFramePos = useCallback((index, total, cx, cy, radius) => {
    const angle = ((index / total) * 2 * Math.PI) - Math.PI / 2;
    return {
      x: cx + radius * Math.cos(angle),
      y: cy + radius * Math.sin(angle),
    };
  }, []);

  return (
    <div
      style={{
        width: "100%",
        height: "100vh",
        background: "#ffffff",
        position: "relative",
        overflow: "hidden",
        fontFamily: "'Inter', 'Segoe UI', sans-serif",
      }}
    >
      {/* Header */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "18px 32px",
          borderBottom: "1px solid #f1f5f9",
          zIndex: 20,
          background: "#ffffff",
        }}
      >
        <div>
          <div style={{ fontSize: 18, fontWeight: 800, color: "#1e293b", letterSpacing: -0.3 }}>
            Functions Puzzle
          </div>
          <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 2 }}>
            {viewMode === "scattered"
              ? "Click a piece to place it · hover to preview"
              : "All subtopics assembled — click any to explore"}
          </div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button
            onClick={handleScatter}
            style={{
              padding: "8px 18px",
              borderRadius: 8,
              border: `1.5px solid ${viewMode === "scattered" ? "#6366f1" : "#e2e8f0"}`,
              background: viewMode === "scattered" ? "#6366f1" : "#ffffff",
              color: viewMode === "scattered" ? "#ffffff" : "#64748b",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s ease",
            }}
          >
            Scattered
          </button>
          <button
            onClick={handleAssemble}
            style={{
              padding: "8px 18px",
              borderRadius: 8,
              border: `1.5px solid ${viewMode === "assembled" ? "#6366f1" : "#e2e8f0"}`,
              background: viewMode === "assembled" ? "#6366f1" : "#ffffff",
              color: viewMode === "assembled" ? "#ffffff" : "#64748b",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.2s ease",
            }}
          >
            Assembled
          </button>
        </div>
      </div>

      {/* Main canvas */}
      <div
        style={{
          position: "absolute",
          top: 73,
          left: 0,
          right: 0,
          bottom: selectedPiece ? 140 : 0,
          transition: "bottom 0.3s ease",
        }}
      >
        {/* Central frame */}
        <div
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: viewMode === "assembled" ? 340 : 200,
            height: viewMode === "assembled" ? 340 : 200,
            borderRadius: "50%",
            border: `2.5px dashed ${allPlaced ? "#6366f1" : "#cbd5e1"}`,
            background: allPlaced ? "#f5f3ff" : "#f8fafc",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            transition: "all 0.4s ease",
            zIndex: 1,
          }}
        >
          <div style={{ textAlign: "center", padding: 20 }}>
            {viewMode === "scattered" && placedIds.length === 0 && (
              <>
                <div style={{ fontSize: 28, marginBottom: 6 }}>🧩</div>
                <div style={{ fontSize: 13, color: "#94a3b8", fontWeight: 500 }}>
                  Click pieces<br />to connect
                </div>
              </>
            )}
            {viewMode === "scattered" && placedIds.length > 0 && !allPlaced && (
              <>
                <div style={{ fontSize: 24, fontWeight: 800, color: "#6366f1" }}>
                  {placedIds.length}/{PIECES.length}
                </div>
                <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 4 }}>
                  subtopics<br />connected
                </div>
              </>
            )}
            {allPlaced && (
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: "#6366f1", marginBottom: 4 }}>
                  Functions
                </div>
                <div style={{ fontSize: 11, color: "#8b5cf6", fontWeight: 500, letterSpacing: 0.5 }}>
                  ONE COMPLEX TOPIC
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Progress dots in scattered mode */}
        {viewMode === "scattered" && (
          <div
            style={{
              position: "absolute",
              bottom: 16,
              left: "50%",
              transform: "translateX(-50%)",
              display: "flex",
              gap: 6,
            }}
          >
            {PIECES.map((p) => (
              <div
                key={p.id}
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: "50%",
                  background: placedIds.includes(p.id) ? p.color : "#e2e8f0",
                  transition: "background 0.3s ease",
                }}
              />
            ))}
          </div>
        )}

        {/* Scattered mode: pieces at fixed positions */}
        {viewMode === "scattered" &&
          PIECES.map((piece) => {
            const isPlaced = placedIds.includes(piece.id);
            if (isPlaced) return null;
            return (
              <PuzzlePiece
                key={piece.id}
                piece={piece}
                isPlaced={false}
                isHovered={hoveredId === piece.id}
                isDragging={false}
                onMouseEnter={() => setHoveredId(piece.id)}
                onMouseLeave={() => setHoveredId(null)}
                onClick={() => handlePieceClick(piece)}
                style={{
                  left: `calc(${piece.x}% - 45px)`,
                  top: `calc(${piece.y}% - 45px)`,
                }}
              />
            );
          })}

        {/* Assembled mode: pieces in a ring */}
        {viewMode === "assembled" &&
          PIECES.map((piece, i) => {
            const canvasW = window.innerWidth;
            const canvasH = window.innerHeight - 73;
            const cx = canvasW / 2;
            const cy = canvasH / 2;
            const radius = Math.min(canvasW, canvasH) * 0.32;
            const pos = getFramePos(i, PIECES.length, cx, cy, radius);
            const isHov = framePieceHover === piece.id;
            return (
              <div
                key={piece.id}
                onMouseEnter={() => setFramePieceHover(piece.id)}
                onMouseLeave={() => setFramePieceHover(null)}
                onClick={() => handlePieceClick(piece)}
                style={{
                  position: "absolute",
                  left: pos.x - 45,
                  top: pos.y - 45,
                  width: 90,
                  height: 90,
                  borderRadius: 12,
                  background: isHov ? piece.color : piece.lightColor,
                  border: `2.5px solid ${piece.color}`,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  transform: isHov ? "scale(1.1)" : "scale(1)",
                  transition: "transform 0.2s ease, background 0.2s ease, box-shadow 0.2s ease",
                  boxShadow: isHov ? `0 8px 24px ${piece.color}55` : `0 2px 8px ${piece.color}33`,
                  zIndex: isHov ? 10 : 2,
                  userSelect: "none",
                }}
              >
                <span
                  style={{
                    fontSize: 13,
                    fontWeight: 700,
                    color: isHov ? "#fff" : piece.color,
                    textAlign: "center",
                    padding: "0 6px",
                    transition: "color 0.2s ease",
                  }}
                >
                  {piece.label}
                </span>
                {isHov && (
                  <span
                    style={{
                      fontSize: 10,
                      color: "rgba(255,255,255,0.85)",
                      marginTop: 4,
                      textAlign: "center",
                      padding: "0 6px",
                    }}
                  >
                    click for details
                  </span>
                )}
              </div>
            );
          })}

        {/* Connector lines in assembled mode */}
        {viewMode === "assembled" && (
          <svg
            style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 0 }}
          >
            {PIECES.map((piece, i) => {
              const canvasW = window.innerWidth;
              const canvasH = window.innerHeight - 73;
              const cx = canvasW / 2;
              const cy = canvasH / 2;
              const radius = Math.min(canvasW, canvasH) * 0.32;
              const pos = getFramePos(i, PIECES.length, cx, cy, radius);
              return (
                <line
                  key={piece.id}
                  x1={cx}
                  y1={cy}
                  x2={pos.x}
                  y2={pos.y}
                  stroke={piece.color}
                  strokeWidth={framePieceHover === piece.id ? 2 : 1}
                  strokeOpacity={framePieceHover === piece.id ? 0.5 : 0.18}
                  strokeDasharray={framePieceHover === piece.id ? "none" : "4 4"}
                />
              );
            })}
          </svg>
        )}

        {/* Placed pieces in scattered mode (float toward center) */}
        {viewMode === "scattered" &&
          PIECES.filter((p) => placedIds.includes(p.id)).map((piece, i) => {
            const placed = placedIds.filter((id) => id !== piece.id).length;
            const angle = (i / PIECES.length) * 2 * Math.PI - Math.PI / 2;
            const r = 75;
            const cx = 50;
            const cy = 50;
            const px = cx + (r * Math.cos(angle)) / (window.innerWidth / 100);
            const py = cy + (r * Math.sin(angle)) / ((window.innerHeight - 73) / 100);
            return (
              <PuzzlePiece
                key={piece.id}
                piece={piece}
                isPlaced
                isHovered={hoveredId === piece.id}
                isDragging={false}
                onMouseEnter={() => setHoveredId(piece.id)}
                onMouseLeave={() => setHoveredId(null)}
                onClick={() => handlePieceClick(piece)}
                style={{
                  left: `calc(${px}% - 45px)`,
                  top: `calc(${py}% - 45px)`,
                  opacity: 0.92,
                }}
              />
            );
          })}
      </div>

      {/* Info panel */}
      <InfoPanel
        piece={selectedPiece}
        onClose={() => setSelectedPiece(null)}
      />

      {/* Hint when all placed in scatter mode */}
      {viewMode === "scattered" && allPlaced && !selectedPiece && (
        <div
          style={{
            position: "absolute",
            top: 90,
            left: "50%",
            transform: "translateX(-50%)",
            background: "#f5f3ff",
            border: "1.5px solid #6366f1",
            borderRadius: 10,
            padding: "10px 20px",
            fontSize: 13,
            color: "#6366f1",
            fontWeight: 600,
            zIndex: 20,
            whiteSpace: "nowrap",
          }}
        >
          All pieces placed! Switch to Assembled view →
        </div>
      )}

      {/* Legend hint */}
      {viewMode === "scattered" && placedIds.length === 0 && (
        <div
          style={{
            position: "absolute",
            top: 90,
            right: 32,
            fontSize: 12,
            color: "#94a3b8",
            background: "#f8fafc",
            borderRadius: 8,
            padding: "8px 14px",
            border: "1px solid #e2e8f0",
          }}
        >
          8 subtopics make up Functions
        </div>
      )}
    </div>
  );
}