import { useState, useRef, useCallback, useMemo } from "react";

export default function App() {
  const [inputValue, setInputValue] = useState("");
  const [selectedFunction, setSelectedFunction] = useState("linear");
  const [hoveredPoint, setHoveredPoint] = useState(false);
  const [hoveredFx, setHoveredFx] = useState(false);
  const [showYNotation, setShowYNotation] = useState(false);
  const [inputFocused, setInputFocused] = useState(false);
  const inputRef = useRef(null);

  const functions = {
    linear: { label: "f(x) = 2x + 1", fn: (x) => 2 * x + 1, color: "#6366f1" },
    quadratic: { label: "f(x) = x²", fn: (x) => x * x, color: "#ec4899" },
    absolute: { label: "f(x) = |x - 2|", fn: (x) => Math.abs(x - 2), color: "#10b981" },
  };

  const currentFn = functions[selectedFunction];

  const x = parseFloat(inputValue);
  const isValid = inputValue !== "" && !isNaN(x) && isFinite(x);
  const result = isValid ? currentFn.fn(x) : null;

  const gridRange = 6;
  const gridSize = 260;
  const center = gridSize / 2;
  const scale = gridSize / (gridRange * 2);

  const toCanvas = useCallback(
    (cx, cy) => ({
      px: center + cx * scale,
      py: center - cy * scale,
    }),
    [center, scale]
  );

  const curvePath = useMemo(() => {
    const pts = [];
    for (let xi = -gridRange; xi <= gridRange; xi += 0.15) {
      const yi = currentFn.fn(xi);
      if (Math.abs(yi) <= gridRange + 1) {
        const p = toCanvas(xi, yi);
        pts.push(`${pts.length === 0 ? "M" : "L"}${p.px},${p.py}`);
      }
    }
    return pts.join(" ");
  }, [selectedFunction, toCanvas, gridRange, currentFn]);

  const pointCanvas = isValid ? toCanvas(x, result) : null;
  const pointInView =
    pointCanvas &&
    pointCanvas.px >= 0 &&
    pointCanvas.px <= gridSize &&
    pointCanvas.py >= 0 &&
    pointCanvas.py <= gridSize;

  const gridLines = [];
  for (let i = -gridRange; i <= gridRange; i++) {
    const pos = center + i * scale;
    gridLines.push(
      <line
        key={`v${i}`}
        x1={pos}
        y1={0}
        x2={pos}
        y2={gridSize}
        stroke={i === 0 ? "#334155" : "#e2e8f0"}
        strokeWidth={i === 0 ? 1.5 : 0.5}
      />
    );
    gridLines.push(
      <line
        key={`h${i}`}
        x1={0}
        y1={pos}
        x2={gridSize}
        y2={pos}
        stroke={i === 0 ? "#334155" : "#e2e8f0"}
        strokeWidth={i === 0 ? 1.5 : 0.5}
      />
    );
  }

  const tickLabels = [];
  for (let i = -gridRange; i <= gridRange; i++) {
    if (i === 0) continue;
    if (Math.abs(i) % 2 === 0) {
      const xPos = center + i * scale;
      const yPos = center - i * scale;
      tickLabels.push(
        <text key={`xt${i}`} x={xPos} y={center + 12} textAnchor="middle" fontSize="9" fill="#94a3b8">
          {i}
        </text>
      );
      tickLabels.push(
        <text key={`yt${i}`} x={center - 14} y={yPos + 3} textAnchor="middle" fontSize="9" fill="#94a3b8">
          {i}
        </text>
      );
    }
  }

  return (
    <div
      style={{
        background: "#ffffff",
        width: "100%",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "'Inter', 'Segoe UI', sans-serif",
        padding: "32px 16px",
        boxSizing: "border-box",
      }}
    >
      {/* Header */}
      <div style={{ textAlign: "center", marginBottom: "40px", maxWidth: "480px" }}>
        <h1
          style={{
            fontSize: "22px",
            fontWeight: "700",
            color: "#0f172a",
            margin: "0 0 8px 0",
            letterSpacing: "-0.3px",
          }}
        >
          Point Builder
        </h1>
        <p style={{ fontSize: "14px", color: "#64748b", margin: 0, lineHeight: 1.5 }}>
          Enter an x value to see how{" "}
          <span style={{ color: currentFn.color, fontWeight: "600" }}>f(x)</span> and{" "}
          <span
            style={{
              color: showYNotation ? "#f59e0b" : "#94a3b8",
              fontWeight: "600",
              cursor: "pointer",
              textDecoration: "underline",
              textDecorationStyle: "dashed",
            }}
            onClick={() => setShowYNotation((v) => !v)}
            title="Toggle y notation"
          >
            y
          </span>{" "}
          are the same output
        </p>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "row",
          gap: "48px",
          alignItems: "flex-start",
          flexWrap: "wrap",
          justifyContent: "center",
          width: "100%",
          maxWidth: "720px",
        }}
      >
        {/* Left Panel */}
        <div style={{ display: "flex", flexDirection: "column", gap: "24px", minWidth: "260px" }}>
          {/* Function Selector */}
          <div>
            <p
              style={{
                fontSize: "11px",
                fontWeight: "600",
                color: "#94a3b8",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                margin: "0 0 10px 0",
              }}
            >
              Choose a function
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              {Object.entries(functions).map(([key, fn]) => (
                <button
                  key={key}
                  onClick={() => setSelectedFunction(key)}
                  style={{
                    padding: "10px 16px",
                    borderRadius: "10px",
                    border: selectedFunction === key ? `2px solid ${fn.color}` : "2px solid #f1f5f9",
                    background: selectedFunction === key ? `${fn.color}10` : "#fafafa",
                    color: selectedFunction === key ? fn.color : "#64748b",
                    fontWeight: selectedFunction === key ? "700" : "500",
                    fontSize: "14px",
                    cursor: "pointer",
                    textAlign: "left",
                    transition: "all 0.15s ease",
                    fontFamily: "inherit",
                  }}
                >
                  {fn.label}
                </button>
              ))}
            </div>
          </div>

          {/* Input */}
          <div>
            <p
              style={{
                fontSize: "11px",
                fontWeight: "600",
                color: "#94a3b8",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                margin: "0 0 10px 0",
              }}
            >
              Input value
            </p>
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <span style={{ fontSize: "16px", fontWeight: "700", color: "#334155" }}>x =</span>
              <input
                ref={inputRef}
                type="number"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onFocus={() => setInputFocused(true)}
                onBlur={() => setInputFocused(false)}
                placeholder="e.g. 3"
                style={{
                  width: "100px",
                  padding: "10px 14px",
                  borderRadius: "10px",
                  border: inputFocused
                    ? `2px solid ${currentFn.color}`
                    : isValid
                    ? `2px solid ${currentFn.color}60`
                    : "2px solid #e2e8f0",
                  fontSize: "18px",
                  fontWeight: "700",
                  color: "#0f172a",
                  outline: "none",
                  background: "#ffffff",
                  fontFamily: "inherit",
                  transition: "border-color 0.15s ease",
                }}
              />
            </div>
          </div>

          {/* Output Cards */}
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            {/* f(x) card */}
            <div
              onMouseEnter={() => setHoveredFx(true)}
              onMouseLeave={() => setHoveredFx(false)}
              style={{
                borderRadius: "14px",
                padding: "16px 18px",
                background: isValid ? `${currentFn.color}08` : "#f8fafc",
                border: hoveredFx && isValid ? `2px solid ${currentFn.color}` : `2px solid ${isValid ? currentFn.color + "30" : "#f1f5f9"}`,
                cursor: "default",
                transition: "all 0.15s ease",
                minHeight: "60px",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span
                  style={{
                    fontSize: "15px",
                    fontWeight: "700",
                    color: isValid ? currentFn.color : "#cbd5e1",
                    fontFamily: "monospace",
                  }}
                >
                  f({isValid ? x : "x"}) =
                </span>
                <span
                  style={{
                    fontSize: "22px",
                    fontWeight: "800",
                    color: isValid ? currentFn.color : "#e2e8f0",
                    fontFamily: "monospace",
                  }}
                >
                  {isValid ? (Number.isInteger(result) ? result : result.toFixed(2)) : "?"}
                </span>
              </div>
              {hoveredFx && isValid && (
                <p style={{ margin: "8px 0 0 0", fontSize: "12px", color: "#64748b", lineHeight: 1.4 }}>
                  "f of x" — the output when x = {x} is plugged in
                </p>
              )}
            </div>

            {/* Toggle notation */}
            <div
              onClick={() => setShowYNotation((v) => !v)}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: "8px",
                padding: "6px 0",
                cursor: "pointer",
              }}
            >
              <div
                style={{
                  width: "36px",
                  height: "20px",
                  borderRadius: "10px",
                  background: showYNotation ? "#f59e0b" : "#e2e8f0",
                  position: "relative",
                  transition: "background 0.2s ease",
                  flexShrink: 0,
                }}
              >
                <div
                  style={{
                    position: "absolute",
                    top: "2px",
                    left: showYNotation ? "18px" : "2px",
                    width: "16px",
                    height: "16px",
                    borderRadius: "50%",
                    background: "#ffffff",
                    transition: "left 0.2s ease",
                    boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                  }}
                />
              </div>
              <span style={{ fontSize: "12px", color: "#64748b", userSelect: "none" }}>
                Show <strong>y =</strong> notation
              </span>
            </div>

            {/* y card */}
            {showYNotation && (
              <div
                style={{
                  borderRadius: "14px",
                  padding: "16px 18px",
                  background: isValid ? "#fef3c720" : "#fffbeb",
                  border: `2px solid ${isValid ? "#f59e0b80" : "#fde68a"}`,
                  transition: "all 0.15s ease",
                  minHeight: "60px",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <span
                    style={{
                      fontSize: "15px",
                      fontWeight: "700",
                      color: isValid ? "#d97706" : "#fbbf24",
                      fontFamily: "monospace",
                    }}
                  >
                    y =
                  </span>
                  <span
                    style={{
                      fontSize: "22px",
                      fontWeight: "800",
                      color: isValid ? "#d97706" : "#fde68a",
                      fontFamily: "monospace",
                    }}
                  >
                    {isValid ? (Number.isInteger(result) ? result : result.toFixed(2)) : "?"}
                  </span>
                </div>
                {isValid && (
                  <p style={{ margin: "8px 0 0 0", fontSize: "12px", color: "#92400e", lineHeight: 1.4 }}>
                    Same value — y is just another name for f(x)
                  </p>
                )}
              </div>
            )}

            {/* Coordinate point */}
            {isValid && (
              <div
                onMouseEnter={() => setHoveredPoint(true)}
                onMouseLeave={() => setHoveredPoint(false)}
                style={{
                  borderRadius: "14px",
                  padding: "14px 18px",
                  background: hoveredPoint ? "#0f172a" : "#f8fafc",
                  border: "2px solid #e2e8f0",
                  cursor: "default",
                  transition: "all 0.15s ease",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <span
                    style={{
                      fontSize: "12px",
                      fontWeight: "600",
                      color: hoveredPoint ? "#94a3b8" : "#94a3b8",
                      textTransform: "uppercase",
                      letterSpacing: "0.06em",
                    }}
                  >
                    Point
                  </span>
                  <span
                    style={{
                      fontSize: "18px",
                      fontWeight: "700",
                      color: hoveredPoint ? "#ffffff" : "#334155",
                      fontFamily: "monospace",
                    }}
                  >
                    ({Number.isInteger(x) ? x : x.toFixed(1)},{" "}
                    {Number.isInteger(result) ? result : result.toFixed(2)})
                  </span>
                </div>
                {hoveredPoint && (
                  <p style={{ margin: "8px 0 0 0", fontSize: "12px", color: "#94a3b8", lineHeight: 1.4 }}>
                    x is the input &nbsp;·&nbsp; y = f(x) is the output
                  </p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Grid */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "12px" }}>
          <p
            style={{
              fontSize: "11px",
              fontWeight: "600",
              color: "#94a3b8",
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              margin: "0",
            }}
          >
            Coordinate plane
          </p>
          <div
            style={{
              borderRadius: "16px",
              overflow: "hidden",
              border: "1.5px solid #e2e8f0",
              boxShadow: "0 1px 8px rgba(0,0,0,0.06)",
              background: "#ffffff",
            }}
          >
            <svg width={gridSize} height={gridSize}>
              {gridLines}
              {tickLabels}

              {/* Axis labels */}
              <text x={gridSize - 8} y={center - 6} fontSize="11" fontWeight="700" fill="#334155" textAnchor="end">
                x
              </text>
              <text x={center + 8} y={10} fontSize="11" fontWeight="700" fill="#334155">
                y
              </text>

              {/* Function curve */}
              <path d={curvePath} fill="none" stroke={currentFn.color} strokeWidth="2" strokeLinecap="round" opacity="0.45" />

              {/* Dashed lines to axes */}
              {isValid && pointInView && (
                <>
                  <line
                    x1={pointCanvas.px}
                    y1={pointCanvas.py}
                    x2={pointCanvas.px}
                    y2={center}
                    stroke={currentFn.color}
                    strokeWidth="1"
                    strokeDasharray="4,3"
                    opacity="0.5"
                  />
                  <line
                    x1={pointCanvas.px}
                    y1={pointCanvas.py}
                    x2={center}
                    y2={pointCanvas.py}
                    stroke={showYNotation ? "#f59e0b" : currentFn.color}
                    strokeWidth="1"
                    strokeDasharray="4,3"
                    opacity="0.5"
                  />
                  {/* x-axis tick */}
                  <circle cx={pointCanvas.px} cy={center} r="3" fill={currentFn.color} opacity="0.7" />
                  {/* y-axis tick */}
                  <circle cx={center} cy={pointCanvas.py} r="3" fill={showYNotation ? "#f59e0b" : currentFn.color} opacity="0.7" />
                </>
              )}

              {/* Main point */}
              {isValid && pointInView && (
                <>
                  <circle cx={pointCanvas.px} cy={pointCanvas.py} r="8" fill={currentFn.color} opacity="0.15" />
                  <circle cx={pointCanvas.px} cy={pointCanvas.py} r="5" fill={currentFn.color} />
                  <circle cx={pointCanvas.px} cy={pointCanvas.py} r="5" fill="none" stroke="#ffffff" strokeWidth="1.5" />
                </>
              )}

              {/* Out of range indicator */}
              {isValid && !pointInView && (
                <text x={center} y={center + 4} textAnchor="middle" fontSize="11" fill="#94a3b8">
                  point out of view
                </text>
              )}

              {/* Placeholder text */}
              {!isValid && (
                <text x={center} y={center + 4} textAnchor="middle" fontSize="11" fill="#cbd5e1">
                  enter x to plot
                </text>
              )}
            </svg>
          </div>

          {/* Legend */}
          {isValid && pointInView && (
            <div
              style={{
                display: "flex",
                gap: "16px",
                fontSize: "11px",
                color: "#94a3b8",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
                <div
                  style={{
                    width: "12px",
                    height: "2px",
                    background: currentFn.color,
                    opacity: 0.5,
                  }}
                />
                <span>x → axis</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
                <div
                  style={{
                    width: "12px",
                    height: "2px",
                    background: showYNotation ? "#f59e0b" : currentFn.color,
                    opacity: 0.5,
                  }}
                />
                <span>{showYNotation ? "y" : "f(x)"} → axis</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom hint */}
      <div
        style={{
          marginTop: "40px",
          padding: "12px 20px",
          borderRadius: "10px",
          background: "#f8fafc",
          border: "1px solid #f1f5f9",
          maxWidth: "480px",
          textAlign: "center",
        }}
      >
        <p style={{ margin: 0, fontSize: "13px", color: "#94a3b8", lineHeight: 1.5 }}>
          Hover the output cards for explanations · Toggle <strong style={{ color: "#f59e0b" }}>y =</strong> to see both notations side by side
        </p>
      </div>
    </div>
  );
}