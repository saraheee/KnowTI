import { useState, useCallback } from "react";

const EXPRESSIONS = [
  {
    id: "fx",
    label: "f(x)",
    correctBin: "function",
    hint: "f names the function; x is the input variable",
    detail: "f(x) means: apply function f to input x. The f is the function's name.",
    color: "#6366f1",
  },
  {
    id: "gx",
    label: "g(x)",
    correctBin: "function",
    hint: "g names the function; x is the input variable",
    detail: "g(x) is another function named g. Functions can have any letter as a name.",
    color: "#6366f1",
  },
  {
    id: "hx",
    label: "h(x)",
    correctBin: "function",
    hint: "h names the function; x is the input variable",
    detail: "h(x) follows the same pattern — h is the function name, x is the argument.",
    color: "#6366f1",
  },
  {
    id: "3x",
    label: "3(x)",
    correctBin: "multiplication",
    hint: "3 is a number, not a function name",
    detail: "3(x) means 3 × x. A number next to parentheses means multiplication.",
    color: "#f59e0b",
  },
  {
    id: "2x",
    label: "2(x)",
    correctBin: "multiplication",
    hint: "2 is a number, not a function name",
    detail: "2(x) = 2 × x. Numbers can't be function names — they always mean multiply.",
    color: "#f59e0b",
  },
  {
    id: "neg1x",
    label: "−1(x)",
    correctBin: "multiplication",
    hint: "−1 is a number, not a function name",
    detail: "−1(x) = −1 × x = −x. Still multiplication, even with a negative number.",
    color: "#f59e0b",
  },
  {
    id: "sinx",
    label: "sin(x)",
    correctBin: "function",
    hint: "sin names the sine function",
    detail: "sin(x) is function notation — sin is a named function applied to x.",
    color: "#6366f1",
  },
  {
    id: "xparen",
    label: "x(x)",
    correctBin: "multiplication",
    hint: "x here acts as a multiplier",
    detail: "x(x) = x × x = x². When a variable is followed by (x), it's multiplication.",
    color: "#f59e0b",
  },
  {
    id: "fx2",
    label: "f(2)",
    correctBin: "function",
    hint: "Evaluating function f at input 2",
    detail: "f(2) means: plug in x = 2 into function f. Not 'f times 2'.",
    color: "#6366f1",
  },
];

const BINS = [
  {
    id: "function",
    label: "Function Notation",
    sublabel: "e.g. f(x), g(3)",
    color: "#6366f1",
    bg: "#eef2ff",
    border: "#c7d2fe",
    activeBg: "#e0e7ff",
  },
  {
    id: "multiplication",
    label: "Multiplication",
    sublabel: "e.g. 3(x) = 3×x",
    color: "#f59e0b",
    bg: "#fffbeb",
    border: "#fde68a",
    activeBg: "#fef3c7",
  },
];

export default function App() {
  const [placed, setPlaced] = useState({});
  const [dragging, setDragging] = useState(null);
  const [hoveredCard, setHoveredCard] = useState(null);
  const [hoveredBin, setHoveredBin] = useState(null);
  const [feedback, setFeedback] = useState({});
  const [dragOverBin, setDragOverBin] = useState(null);

  const unplaced = EXPRESSIONS.filter((e) => !(e.id in placed));

  const getPlacedInBin = useCallback(
    (binId) => EXPRESSIONS.filter((e) => placed[e.id] === binId),
    [placed]
  );

  const handleDragStart = useCallback((e, expr) => {
    setDragging(expr.id);
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", expr.id);
  }, []);

  const handleDragEnd = useCallback(() => {
    setDragging(null);
    setDragOverBin(null);
  }, []);

  const handleDrop = useCallback(
    (e, binId) => {
      e.preventDefault();
      const id = e.dataTransfer.getData("text/plain");
      const expr = EXPRESSIONS.find((ex) => ex.id === id);
      if (!expr) return;
      const isCorrect = expr.correctBin === binId;
      setPlaced((prev) => ({ ...prev, [id]: binId }));
      setFeedback((prev) => ({ ...prev, [id]: isCorrect ? "correct" : "wrong" }));
      setDragOverBin(null);
      setDragging(null);
    },
    []
  );

  const handleDragOver = useCallback((e, binId) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setDragOverBin(binId);
  }, []);

  const handleDragLeave = useCallback(() => {
    setDragOverBin(null);
  }, []);

  const handleRemove = useCallback((id) => {
    setPlaced((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
    setFeedback((prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  }, []);

  const handleReset = useCallback(() => {
    setPlaced({});
    setFeedback({});
    setHoveredCard(null);
    setDragging(null);
  }, []);

  const score = Object.values(feedback).filter((v) => v === "correct").length;
  const total = EXPRESSIONS.length;
  const allDone = Object.keys(placed).length === total;

  return (
    <div
      style={{
        background: "#ffffff",
        width: "100%",
        minHeight: "100vh",
        fontFamily: "'Inter', system-ui, sans-serif",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "40px 24px",
        boxSizing: "border-box",
      }}
    >
      {/* Header */}
      <div style={{ textAlign: "center", marginBottom: "12px" }}>
        <h1
          style={{
            fontSize: "clamp(22px, 4vw, 32px)",
            fontWeight: 700,
            color: "#1e1b4b",
            margin: 0,
            letterSpacing: "-0.5px",
          }}
        >
          Interpretation Sorter
        </h1>
        <p
          style={{
            fontSize: "15px",
            color: "#6b7280",
            marginTop: "8px",
            marginBottom: 0,
          }}
        >
          Drag each expression into the correct bin. Hover a card to learn more.
        </p>
      </div>

      {/* Score */}
      {Object.keys(placed).length > 0 && (
        <div
          style={{
            fontSize: "13px",
            color: "#6b7280",
            marginBottom: "16px",
            display: "flex",
            alignItems: "center",
            gap: "12px",
          }}
        >
          <span>
            {score}/{total} correct
          </span>
          {allDone && (
            <span
              style={{
                background: score === total ? "#dcfce7" : "#fef2f2",
                color: score === total ? "#16a34a" : "#dc2626",
                borderRadius: "20px",
                padding: "2px 12px",
                fontWeight: 600,
                fontSize: "13px",
              }}
            >
              {score === total ? "Perfect! 🎉" : "Some errors — check red cards"}
            </span>
          )}
          <button
            onClick={handleReset}
            style={{
              background: "none",
              border: "1px solid #e5e7eb",
              borderRadius: "8px",
              padding: "3px 12px",
              fontSize: "13px",
              color: "#6b7280",
              cursor: "pointer",
            }}
          >
            Reset
          </button>
        </div>
      )}

      {/* Card Pool */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "12px",
          justifyContent: "center",
          marginBottom: "32px",
          minHeight: "80px",
          maxWidth: "700px",
          width: "100%",
        }}
      >
        {unplaced.length === 0 && (
          <div
            style={{
              color: "#9ca3af",
              fontSize: "14px",
              alignSelf: "center",
              fontStyle: "italic",
            }}
          >
            All expressions sorted
          </div>
        )}
        {unplaced.map((expr) => (
          <ExprCard
            key={expr.id}
            expr={expr}
            isDragging={dragging === expr.id}
            isHovered={hoveredCard === expr.id}
            onDragStart={handleDragStart}
            onDragEnd={handleDragEnd}
            onMouseEnter={() => setHoveredCard(expr.id)}
            onMouseLeave={() => setHoveredCard(null)}
          />
        ))}
      </div>

      {/* Bins */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
          gap: "24px",
          width: "100%",
          maxWidth: "700px",
        }}
      >
        {BINS.map((bin) => {
          const items = getPlacedInBin(bin.id);
          const isOver = dragOverBin === bin.id;
          return (
            <div
              key={bin.id}
              onDrop={(e) => handleDrop(e, bin.id)}
              onDragOver={(e) => handleDragOver(e, bin.id)}
              onDragLeave={handleDragLeave}
              onMouseEnter={() => setHoveredBin(bin.id)}
              onMouseLeave={() => setHoveredBin(null)}
              style={{
                borderRadius: "16px",
                border: `2px dashed ${isOver ? bin.color : bin.border}`,
                background: isOver ? bin.activeBg : bin.bg,
                padding: "20px",
                minHeight: "180px",
                transition: "border-color 0.15s, background 0.15s",
                display: "flex",
                flexDirection: "column",
                gap: "12px",
              }}
            >
              <div>
                <div
                  style={{
                    fontWeight: 700,
                    fontSize: "15px",
                    color: bin.color,
                    marginBottom: "2px",
                  }}
                >
                  {bin.label}
                </div>
                <div style={{ fontSize: "12px", color: "#9ca3af" }}>
                  {bin.sublabel}
                </div>
              </div>

              {/* Bin explanation (show on hover) */}
              {hoveredBin === bin.id && (
                <div
                  style={{
                    fontSize: "12px",
                    color: "#374151",
                    background: "#ffffff",
                    borderRadius: "8px",
                    padding: "8px 12px",
                    border: `1px solid ${bin.border}`,
                    lineHeight: "1.5",
                  }}
                >
                  {bin.id === "function"
                    ? "A letter (like f, g, h) followed by (x) means: apply that named function to x. The letter is the function's name."
                    : "A number followed by (x) always means multiplication. Numbers cannot name functions."}
                </div>
              )}

              {/* Placed items */}
              <div
                style={{
                  display: "flex",
                  flexWrap: "wrap",
                  gap: "8px",
                }}
              >
                {items.map((expr) => {
                  const result = feedback[expr.id];
                  return (
                    <PlacedCard
                      key={expr.id}
                      expr={expr}
                      result={result}
                      isHovered={hoveredCard === `placed-${expr.id}`}
                      onMouseEnter={() => setHoveredCard(`placed-${expr.id}`)}
                      onMouseLeave={() => setHoveredCard(null)}
                      onRemove={() => handleRemove(expr.id)}
                    />
                  );
                })}
              </div>

              {items.length === 0 && (
                <div
                  style={{
                    color: "#d1d5db",
                    fontSize: "13px",
                    marginTop: "8px",
                    fontStyle: "italic",
                  }}
                >
                  Drop expressions here
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Key insight */}
      <div
        style={{
          marginTop: "40px",
          maxWidth: "600px",
          width: "100%",
          background: "#f8fafc",
          borderRadius: "12px",
          padding: "20px 24px",
          borderLeft: "4px solid #6366f1",
        }}
      >
        <div style={{ fontWeight: 600, color: "#1e1b4b", fontSize: "14px", marginBottom: "8px" }}>
          Why does this matter?
        </div>
        <div style={{ fontSize: "13px", color: "#4b5563", lineHeight: "1.7" }}>
          <span style={{ fontWeight: 600, color: "#6366f1" }}>f(x)</span> and{" "}
          <span style={{ fontWeight: 600, color: "#f59e0b" }}>3(x)</span> look almost identical,
          but mean completely different things. In <em>function notation</em>, the letter before the
          parentheses is a <em>name</em> — not a multiplier. Understanding this distinction is
          essential for reading algebra, calculus, and beyond.
        </div>
      </div>
    </div>
  );
}

function ExprCard({
  expr,
  isDragging,
  isHovered,
  onDragStart,
  onDragEnd,
  onMouseEnter,
  onMouseLeave,
}) {
  return (
    <div
      draggable
      onDragStart={(e) => onDragStart(e, expr)}
      onDragEnd={onDragEnd}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      style={{
        position: "relative",
        background: "#ffffff",
        border: `2px solid ${isHovered ? expr.color : "#e5e7eb"}`,
        borderRadius: "12px",
        padding: "14px 20px",
        cursor: "grab",
        opacity: isDragging ? 0.4 : 1,
        transform: isHovered ? "translateY(-2px)" : "none",
        boxShadow: isHovered
          ? `0 8px 24px -4px ${expr.color}33`
          : "0 1px 4px rgba(0,0,0,0.06)",
        transition: "border-color 0.15s, transform 0.15s, box-shadow 0.15s",
        userSelect: "none",
        minWidth: "70px",
        textAlign: "center",
      }}
    >
      <div
        style={{
          fontSize: "22px",
          fontWeight: 700,
          color: "#1e1b4b",
          fontFamily: "'Georgia', serif",
          letterSpacing: "0.5px",
        }}
      >
        {expr.label}
      </div>

      {/* Tooltip on hover */}
      {isHovered && (
        <div
          style={{
            position: "absolute",
            bottom: "calc(100% + 10px)",
            left: "50%",
            transform: "translateX(-50%)",
            background: "#1e1b4b",
            color: "#fff",
            borderRadius: "8px",
            padding: "8px 12px",
            fontSize: "12px",
            whiteSpace: "nowrap",
            zIndex: 10,
            pointerEvents: "none",
            maxWidth: "220px",
            whiteSpace: "normal",
            lineHeight: "1.5",
            textAlign: "left",
            boxShadow: "0 4px 16px rgba(0,0,0,0.18)",
          }}
        >
          <div style={{ fontWeight: 600, marginBottom: "3px", color: expr.color === "#6366f1" ? "#a5b4fc" : "#fcd34d" }}>
            {expr.label}
          </div>
          {expr.detail}
          <div
            style={{
              position: "absolute",
              top: "100%",
              left: "50%",
              transform: "translateX(-50%)",
              borderLeft: "6px solid transparent",
              borderRight: "6px solid transparent",
              borderTop: "6px solid #1e1b4b",
            }}
          />
        </div>
      )}
    </div>
  );
}

function PlacedCard({ expr, result, isHovered, onMouseEnter, onMouseLeave, onRemove }) {
  const isCorrect = result === "correct";
  const borderColor = isCorrect ? "#86efac" : "#fca5a5";
  const bg = isCorrect ? "#f0fdf4" : "#fef2f2";
  const textColor = isCorrect ? "#15803d" : "#dc2626";

  return (
    <div
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      onClick={onRemove}
      style={{
        position: "relative",
        background: bg,
        border: `2px solid ${isHovered ? textColor : borderColor}`,
        borderRadius: "10px",
        padding: "10px 14px",
        cursor: "pointer",
        transition: "border-color 0.15s, transform 0.1s",
        transform: isHovered ? "scale(0.97)" : "none",
        display: "flex",
        alignItems: "center",
        gap: "8px",
      }}
      title="Click to return to pool"
    >
      <span
        style={{
          fontSize: "18px",
          fontWeight: 700,
          color: "#1e1b4b",
          fontFamily: "'Georgia', serif",
        }}
      >
        {expr.label}
      </span>
      <span style={{ fontSize: "14px", color: textColor, fontWeight: 700 }}>
        {isCorrect ? "✓" : "✗"}
      </span>

      {isHovered && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 8px)",
            left: "50%",
            transform: "translateX(-50%)",
            background: "#1e1b4b",
            color: "#fff",
            borderRadius: "7px",
            padding: "6px 10px",
            fontSize: "11px",
            whiteSpace: "nowrap",
            zIndex: 10,
            pointerEvents: "none",
            boxShadow: "0 3px 12px rgba(0,0,0,0.18)",
          }}
        >
          {isCorrect ? "Correct! Click to move back." : `Wrong bin! Click to try again.`}
          <div
            style={{
              position: "absolute",
              bottom: "100%",
              left: "50%",
              transform: "translateX(-50%)",
              borderLeft: "5px solid transparent",
              borderRight: "5px solid transparent",
              borderBottom: "5px solid #1e1b4b",
            }}
          />
        </div>
      )}
    </div>
  );
}