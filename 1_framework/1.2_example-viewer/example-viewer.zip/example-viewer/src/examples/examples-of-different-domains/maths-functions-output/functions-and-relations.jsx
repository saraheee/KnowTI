import { useState, useCallback } from "react";

const EXAMPLES = {
  functionsOnly: [
    {
      id: 1,
      title: "f(x) = x²",
      description: "Each input x maps to exactly one output x²",
      why: "For every x, there is exactly one y = x². This is a function AND a relation.",
    },
    {
      id: 2,
      title: "f(x) = 2x + 1",
      description: "Linear function: one output for every input",
      why: "No matter what x you pick, 2x+1 gives one unique result. Functions are a subset of relations.",
    },
    {
      id: 3,
      title: "f(x) = sin(x)",
      description: "Trigonometric function with unique outputs",
      why: "Each angle maps to exactly one sine value. All functions satisfy the definition of a relation too.",
    },
    {
      id: 4,
      title: "f(x) = |x|",
      description: "Absolute value: one non-negative output per input",
      why: "Both 3 and -3 give |x|=3, but each input still has exactly one output. It's a function.",
    },
  ],
  relationsOnly: [
    {
      id: 5,
      title: "x² + y² = 25",
      description: "Circle of radius 5: two y-values for most x-values",
      why: "At x=3, both y=4 and y=-4 satisfy the equation. One input → multiple outputs means NOT a function.",
    },
    {
      id: 6,
      title: "x = y²",
      description: "Sideways parabola: fails the vertical line test",
      why: "At x=4, y=2 and y=-2 both work. Since one x maps to two y's, this is a relation but not a function.",
    },
    {
      id: 7,
      title: "{(1,2),(1,3),(2,4)}",
      description: "Set with repeated input: 1 maps to both 2 and 3",
      why: "The input 1 has two different outputs (2 and 3). This violates the definition of a function.",
    },
    {
      id: 8,
      title: "x ≤ y",
      description: "Inequality relation: half-plane of paired values",
      why: "For x=1, y can be 1, 2, 3, or any number ≥ 1. Many outputs per input → relation, not function.",
    },
  ],
};

const TOOLTIP_TEXT =
  "Every function is a relation because a function IS a set of ordered pairs (x, y). But a relation only becomes a function when each input (x) maps to exactly ONE output (y). The Vertical Line Test captures this: if any vertical line crosses a graph more than once, it's not a function.";

export default function App() {
  const [activeRegion, setActiveRegion] = useState(null);
  const [selectedExample, setSelectedExample] = useState(null);
  const [showTooltip, setShowTooltip] = useState(false);
  const [hoveredExample, setHoveredExample] = useState(null);

  const handleRegionClick = useCallback(
    (region) => {
      if (activeRegion === region) {
        setActiveRegion(null);
        setSelectedExample(null);
      } else {
        setActiveRegion(region);
        setSelectedExample(null);
      }
    },
    [activeRegion]
  );

  const handleExampleClick = useCallback(
    (example) => {
      if (selectedExample?.id === example.id) {
        setSelectedExample(null);
      } else {
        setSelectedExample(example);
      }
    },
    [selectedExample]
  );

  const currentExamples =
    activeRegion === "functions"
      ? EXAMPLES.functionsOnly
      : activeRegion === "relations"
      ? EXAMPLES.relationsOnly
      : [];

  const outerCircleColor =
    activeRegion === "relations" ? "#e8d5ff" : "rgba(180, 130, 255, 0.12)";
  const innerCircleColor =
    activeRegion === "functions" ? "#c7e8ff" : "rgba(80, 170, 255, 0.12)";
  const outerStroke =
    activeRegion === "relations" ? "#8b3dff" : "#a855f7";
  const innerStroke =
    activeRegion === "functions" ? "#0077cc" : "#3b82f6";

  return (
    <div
      style={{
        width: "100%",
        minHeight: "100vh",
        background: "#ffffff",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "32px 16px 48px",
        boxSizing: "border-box",
        fontFamily: "'Segoe UI', system-ui, sans-serif",
      }}
    >
      {/* Header */}
      <div style={{ textAlign: "center", marginBottom: "8px" }}>
        <h1
          style={{
            fontSize: "clamp(1.4rem, 3vw, 2rem)",
            fontWeight: 700,
            color: "#1a1a2e",
            margin: 0,
            letterSpacing: "-0.5px",
          }}
        >
          Functions & Relations
        </h1>
        <p
          style={{
            fontSize: "0.95rem",
            color: "#666",
            margin: "6px 0 0",
          }}
        >
          Click a region of the diagram to explore examples
        </p>
      </div>

      {/* Main layout */}
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          alignItems: "flex-start",
          justifyContent: "center",
          gap: "32px",
          width: "100%",
          maxWidth: "960px",
          flexWrap: "wrap",
          marginTop: "16px",
        }}
      >
        {/* Venn Diagram */}
        <div
          style={{
            position: "relative",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <svg
            width="340"
            height="340"
            viewBox="0 0 340 340"
            style={{ overflow: "visible", display: "block" }}
          >
            {/* Outer circle: Relations */}
            <circle
              cx="170"
              cy="170"
              r="155"
              fill={outerCircleColor}
              stroke={outerStroke}
              strokeWidth={activeRegion === "relations" ? 3 : 2}
              style={{ cursor: "pointer", transition: "fill 0.25s, stroke 0.25s" }}
              onClick={() => handleRegionClick("relations")}
            />

            {/* Inner circle: Functions */}
            <circle
              cx="170"
              cy="195"
              r="90"
              fill={innerCircleColor}
              stroke={innerStroke}
              strokeWidth={activeRegion === "functions" ? 3 : 2}
              style={{ cursor: "pointer", transition: "fill 0.25s, stroke 0.25s" }}
              onClick={(e) => {
                e.stopPropagation();
                handleRegionClick("functions");
              }}
            />

            {/* Label: Relations (top-left of outer, outside inner) */}
            <text
              x="68"
              y="110"
              textAnchor="middle"
              fontSize="15"
              fontWeight={activeRegion === "relations" ? "700" : "600"}
              fill={activeRegion === "relations" ? "#6b00e0" : "#7c3aed"}
              style={{ pointerEvents: "none", userSelect: "none" }}
            >
              Relations
            </text>
            <text
              x="68"
              y="128"
              textAnchor="middle"
              fontSize="11"
              fill={activeRegion === "relations" ? "#6b00e0" : "#9c6ddd"}
              style={{ pointerEvents: "none", userSelect: "none" }}
            >
              (not functions)
            </text>

            {/* Label: Functions (inside inner circle) */}
            <text
              x="170"
              y="185"
              textAnchor="middle"
              fontSize="15"
              fontWeight={activeRegion === "functions" ? "700" : "600"}
              fill={activeRegion === "functions" ? "#004a99" : "#1d4ed8"}
              style={{ pointerEvents: "none", userSelect: "none" }}
            >
              Functions
            </text>
            <text
              x="170"
              y="203"
              textAnchor="middle"
              fontSize="11"
              fill={activeRegion === "functions" ? "#004a99" : "#4070cc"}
              style={{ pointerEvents: "none", userSelect: "none" }}
            >
              (also relations)
            </text>

            {/* Click hint dots in outer ring area */}
            {activeRegion !== "relations" && (
              <>
                <circle cx="68" cy="145" r="3" fill="#a855f7" opacity="0.5" style={{ pointerEvents: "none" }} />
                <circle cx="272" cy="145" r="3" fill="#a855f7" opacity="0.5" style={{ pointerEvents: "none" }} />
              </>
            )}
          </svg>

          {/* "Why?" button */}
          <button
            onClick={() => setShowTooltip((v) => !v)}
            style={{
              position: "absolute",
              bottom: "-8px",
              right: "-8px",
              width: "36px",
              height: "36px",
              borderRadius: "50%",
              border: "2px solid #a855f7",
              background: showTooltip ? "#a855f7" : "#fff",
              color: showTooltip ? "#fff" : "#a855f7",
              fontSize: "16px",
              fontWeight: "700",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 2px 8px rgba(168,85,247,0.2)",
              transition: "background 0.2s, color 0.2s",
            }}
            title="Why is every function a relation?"
          >
            ?
          </button>
        </div>

        {/* Right panel */}
        <div
          style={{
            flex: "1",
            minWidth: "260px",
            maxWidth: "440px",
            display: "flex",
            flexDirection: "column",
            gap: "16px",
          }}
        >
          {/* Tooltip panel */}
          {showTooltip && (
            <div
              style={{
                background: "#faf5ff",
                border: "1.5px solid #c084fc",
                borderRadius: "12px",
                padding: "16px 18px",
                fontSize: "0.88rem",
                color: "#3b1673",
                lineHeight: 1.65,
                boxShadow: "0 4px 20px rgba(168,85,247,0.1)",
              }}
            >
              <div
                style={{
                  fontWeight: 700,
                  fontSize: "0.92rem",
                  marginBottom: "6px",
                  color: "#7c3aed",
                }}
              >
                Why every function is a relation
              </div>
              {TOOLTIP_TEXT}
            </div>
          )}

          {/* No region selected */}
          {!activeRegion && !showTooltip && (
            <div
              style={{
                background: "#f8f8f8",
                borderRadius: "12px",
                padding: "24px 20px",
                color: "#888",
                fontSize: "0.93rem",
                textAlign: "center",
                border: "1.5px dashed #ddd",
              }}
            >
              <div style={{ fontSize: "2rem", marginBottom: "8px" }}>👆</div>
              Click the <strong style={{ color: "#7c3aed" }}>outer ring</strong> for
              relations-only examples, or the{" "}
              <strong style={{ color: "#1d4ed8" }}>inner circle</strong> for
              function examples.
            </div>
          )}

          {/* Region selected: examples list */}
          {activeRegion && (
            <div>
              <div
                style={{
                  fontWeight: 700,
                  fontSize: "1rem",
                  color: activeRegion === "functions" ? "#1d4ed8" : "#7c3aed",
                  marginBottom: "10px",
                  paddingBottom: "6px",
                  borderBottom: `2px solid ${
                    activeRegion === "functions" ? "#bfdbfe" : "#e9d5ff"
                  }`,
                }}
              >
                {activeRegion === "functions"
                  ? "Functions (all are also relations)"
                  : "Relations that are NOT functions"}
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                {currentExamples.map((ex) => {
                  const isSelected = selectedExample?.id === ex.id;
                  const isHovered = hoveredExample === ex.id;
                  const accent =
                    activeRegion === "functions" ? "#1d4ed8" : "#7c3aed";
                  const accentLight =
                    activeRegion === "functions" ? "#eff6ff" : "#faf5ff";
                  const accentBorder =
                    activeRegion === "functions" ? "#bfdbfe" : "#e9d5ff";

                  return (
                    <div
                      key={ex.id}
                      onClick={() => handleExampleClick(ex)}
                      onMouseEnter={() => setHoveredExample(ex.id)}
                      onMouseLeave={() => setHoveredExample(null)}
                      style={{
                        borderRadius: "10px",
                        border: `1.5px solid ${
                          isSelected ? accent : isHovered ? accentBorder : "#e5e7eb"
                        }`,
                        background: isSelected
                          ? accentLight
                          : isHovered
                          ? "#fafafa"
                          : "#fff",
                        padding: "12px 14px",
                        cursor: "pointer",
                        transition: "border-color 0.15s, background 0.15s",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                        }}
                      >
                        <span
                          style={{
                            fontWeight: 600,
                            fontSize: "0.97rem",
                            color: isSelected ? accent : "#1a1a2e",
                            fontFamily: "monospace",
                          }}
                        >
                          {ex.title}
                        </span>
                        <span
                          style={{
                            fontSize: "0.75rem",
                            color: accent,
                            opacity: isSelected ? 1 : 0.5,
                            fontWeight: 600,
                          }}
                        >
                          {isSelected ? "▲" : "▼"}
                        </span>
                      </div>

                      <div
                        style={{
                          fontSize: "0.83rem",
                          color: "#666",
                          marginTop: "2px",
                        }}
                      >
                        {ex.description}
                      </div>

                      {isSelected && (
                        <div
                          style={{
                            marginTop: "10px",
                            paddingTop: "10px",
                            borderTop: `1px solid ${accentBorder}`,
                            fontSize: "0.85rem",
                            color: "#3b3b5c",
                            lineHeight: 1.6,
                          }}
                        >
                          <span
                            style={{
                              fontWeight: 700,
                              color: accent,
                              marginRight: "4px",
                            }}
                          >
                            Why:
                          </span>
                          {ex.why}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Key rule callout */}
          <div
            style={{
              background: "#f0fdf4",
              border: "1.5px solid #86efac",
              borderRadius: "10px",
              padding: "12px 16px",
              fontSize: "0.85rem",
              color: "#166534",
              lineHeight: 1.6,
            }}
          >
            <strong>The Rule:</strong> A relation becomes a function when every
            input has <em>exactly one</em> output.
          </div>
        </div>
      </div>

      {/* Bottom legend */}
      <div
        style={{
          display: "flex",
          gap: "24px",
          marginTop: "28px",
          flexWrap: "wrap",
          justifyContent: "center",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <div
            style={{
              width: "18px",
              height: "18px",
              borderRadius: "50%",
              background: "rgba(168,85,247,0.2)",
              border: "2px solid #a855f7",
            }}
          />
          <span style={{ fontSize: "0.85rem", color: "#555" }}>
            Relations (all ordered pairs)
          </span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <div
            style={{
              width: "18px",
              height: "18px",
              borderRadius: "50%",
              background: "rgba(59,130,246,0.2)",
              border: "2px solid #3b82f6",
            }}
          />
          <span style={{ fontSize: "0.85rem", color: "#555" }}>
            Functions (one output per input)
          </span>
        </div>
      </div>
    </div>
  );
}