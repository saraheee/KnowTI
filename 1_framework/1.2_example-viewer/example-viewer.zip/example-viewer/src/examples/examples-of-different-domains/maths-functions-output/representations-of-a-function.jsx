import { useState, useCallback, useMemo } from "react";

const functions = [
  {
    id: "f1",
    rule: "f(x) = 2x + 1",
    table: [
      { x: 0, y: 1 },
      { x: 1, y: 3 },
      { x: 2, y: 5 },
      { x: 3, y: 7 },
    ],
    pairs: "{(0,1), (1,3), (2,5), (3,7)}",
    color: "#6366f1",
    lightColor: "#eef2ff",
  },
  {
    id: "f2",
    rule: "f(x) = x² − 1",
    table: [
      { x: 0, y: -1 },
      { x: 1, y: 0 },
      { x: 2, y: 3 },
      { x: 3, y: 8 },
    ],
    pairs: "{(0,−1), (1,0), (2,3), (3,8)}",
    color: "#f59e0b",
    lightColor: "#fffbeb",
  },
  {
    id: "f3",
    rule: "f(x) = 3x",
    table: [
      { x: 0, y: 0 },
      { x: 1, y: 3 },
      { x: 2, y: 6 },
      { x: 3, y: 9 },
    ],
    pairs: "{(0,0), (1,3), (2,6), (3,9)}",
    color: "#10b981",
    lightColor: "#ecfdf5",
  },
  {
    id: "f4",
    rule: "f(x) = 5 − x",
    table: [
      { x: 0, y: 5 },
      { x: 1, y: 4 },
      { x: 2, y: 3 },
      { x: 3, y: 2 },
    ],
    pairs: "{(0,5), (1,4), (2,3), (3,2)}",
    color: "#ec4899",
    lightColor: "#fdf2f8",
  },
];

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function App() {
  const [shuffledRules] = useState(() => shuffle(functions));
  const [shuffledTables] = useState(() => shuffle(functions));
  const [shuffledPairs] = useState(() => shuffle(functions));

  const [selected, setSelected] = useState({ rule: null, table: null, pair: null });
  const [matched, setMatched] = useState([]);
  const [hoveredItem, setHoveredItem] = useState(null);
  const [wrongFlash, setWrongFlash] = useState(false);
  const [score, setScore] = useState(0);

  const remainingFunctions = useMemo(() => {
    return functions.filter((f) => !matched.includes(f.id));
  }, [matched]);

  const isComplete = matched.length === functions.length;

  const handleSelect = useCallback(
    (type, id) => {
      if (matched.includes(id)) return;

      setSelected((prev) => {
        const next = { ...prev, [type]: prev[type] === id ? null : id };

        const ruleId = type === "rule" ? next.rule : prev.rule;
        const tableId = type === "table" ? next.table : prev.table;
        const pairId = type === "pair" ? next.pair : prev.pair;

        if (ruleId && tableId && pairId) {
          if (ruleId === tableId && tableId === pairId) {
            setTimeout(() => {
              setMatched((m) => [...m, ruleId]);
              setScore((s) => s + 1);
              setSelected({ rule: null, table: null, pair: null });
            }, 300);
          } else {
            setWrongFlash(true);
            setTimeout(() => {
              setWrongFlash(false);
              setSelected({ rule: null, table: null, pair: null });
            }, 700);
          }
        }

        return next;
      });
    },
    [matched]
  );

  const handleReset = () => {
    setSelected({ rule: null, table: null, pair: null });
    setMatched([]);
    setScore(0);
    setWrongFlash(false);
  };

  const getItemState = (type, id) => {
    if (matched.includes(id)) return "matched";
    if (selected[type] === id) return "selected";
    return "idle";
  };

  const getFunctionById = (id) => functions.find((f) => f.id === id);

  const columnStyle = {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
    flex: 1,
    minWidth: 0,
  };

  const columnHeaderStyle = {
    textAlign: "center",
    fontWeight: 700,
    fontSize: "13px",
    letterSpacing: "0.08em",
    textTransform: "uppercase",
    color: "#64748b",
    paddingBottom: "8px",
    borderBottom: "2px solid #e2e8f0",
    marginBottom: "4px",
  };

  const getCardStyle = (type, id) => {
    const state = getItemState(type, id);
    const fn = getFunctionById(id);
    const isHovered = hoveredItem?.type === type && hoveredItem?.id === id;

    const base = {
      borderRadius: "12px",
      padding: "14px 16px",
      cursor: matched.includes(id) ? "default" : "pointer",
      transition: "all 0.18s ease",
      border: "2.5px solid",
      userSelect: "none",
      position: "relative",
      overflow: "hidden",
    };

    if (state === "matched") {
      return {
        ...base,
        background: fn.lightColor,
        borderColor: fn.color,
        opacity: 0.7,
        cursor: "default",
      };
    }

    if (state === "selected") {
      return {
        ...base,
        background: fn.lightColor,
        borderColor: fn.color,
        boxShadow: `0 0 0 3px ${fn.color}40`,
        transform: "scale(1.025)",
      };
    }

    return {
      ...base,
      background: isHovered ? "#f8fafc" : "#ffffff",
      borderColor: isHovered ? "#94a3b8" : "#e2e8f0",
      boxShadow: isHovered ? "0 4px 12px rgba(0,0,0,0.08)" : "0 1px 3px rgba(0,0,0,0.04)",
      transform: isHovered ? "scale(1.01)" : "scale(1)",
    };
  };

  const matchedIndicatorStyle = (fn) => ({
    position: "absolute",
    top: "6px",
    right: "8px",
    width: "18px",
    height: "18px",
    borderRadius: "50%",
    background: fn.color,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "11px",
    color: "#fff",
    fontWeight: 700,
  });

  const selectedDotStyle = (fn) => ({
    position: "absolute",
    top: "8px",
    right: "10px",
    width: "10px",
    height: "10px",
    borderRadius: "50%",
    background: fn.color,
  });

  return (
    <div
      style={{
        width: "100%",
        minHeight: "100vh",
        background: "#ffffff",
        fontFamily: "'Inter', system-ui, sans-serif",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "960px",
          padding: "40px 24px 60px",
          boxSizing: "border-box",
        }}
      >
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "36px" }}>
          <h1
            style={{
              fontSize: "28px",
              fontWeight: 800,
              color: "#0f172a",
              margin: 0,
              letterSpacing: "-0.02em",
            }}
          >
            Match the Representations
          </h1>
          <p
            style={{
              marginTop: "8px",
              color: "#64748b",
              fontSize: "15px",
              maxWidth: "500px",
              marginLeft: "auto",
              marginRight: "auto",
            }}
          >
            Click one card from each column to match the rule, table, and ordered pairs for the same function.
          </p>

          {/* Score + progress */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "16px",
              marginTop: "20px",
            }}
          >
            {functions.map((fn) => (
              <div
                key={fn.id}
                style={{
                  width: "32px",
                  height: "8px",
                  borderRadius: "4px",
                  background: matched.includes(fn.id) ? fn.color : "#e2e8f0",
                  transition: "background 0.3s ease",
                }}
              />
            ))}
          </div>
          <p
            style={{
              marginTop: "8px",
              fontSize: "13px",
              color: "#94a3b8",
            }}
          >
            {score} / {functions.length} matched
          </p>
        </div>

        {/* Selection status */}
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: "24px",
            marginBottom: "28px",
            minHeight: "32px",
            alignItems: "center",
          }}
        >
          {(["rule", "table", "pair"]).map((type) => {
            const selId = selected[type];
            const fn = selId ? getFunctionById(selId) : null;
            return (
              <div
                key={type}
                style={{
                  padding: "5px 14px",
                  borderRadius: "20px",
                  fontSize: "12px",
                  fontWeight: 600,
                  letterSpacing: "0.05em",
                  textTransform: "uppercase",
                  background: fn ? fn.lightColor : "#f1f5f9",
                  color: fn ? fn.color : "#94a3b8",
                  border: `1.5px solid ${fn ? fn.color : "#e2e8f0"}`,
                  transition: "all 0.2s ease",
                }}
              >
                {type}: {fn ? "✓" : "—"}
              </div>
            );
          })}
        </div>

        {/* Wrong flash banner */}
        <div
          style={{
            textAlign: "center",
            marginBottom: wrongFlash ? "12px" : "0",
            height: wrongFlash ? "32px" : "0",
            overflow: "hidden",
            transition: "height 0.2s ease",
          }}
        >
          <span
            style={{
              display: "inline-block",
              padding: "5px 16px",
              borderRadius: "8px",
              background: "#fef2f2",
              color: "#ef4444",
              fontWeight: 600,
              fontSize: "13px",
              border: "1px solid #fecaca",
            }}
          >
            These don't match — try again!
          </span>
        </div>

        {/* Columns */}
        <div
          style={{
            display: "flex",
            gap: "20px",
            alignItems: "flex-start",
          }}
        >
          {/* Rules Column */}
          <div style={columnStyle}>
            <div style={columnHeaderStyle}>Function Rule</div>
            {shuffledRules.map((fn) => {
              const state = getItemState("rule", fn.id);
              return (
                <div
                  key={fn.id}
                  style={getCardStyle("rule", fn.id)}
                  onClick={() => state !== "matched" && handleSelect("rule", fn.id)}
                  onMouseEnter={() => state !== "matched" && setHoveredItem({ type: "rule", id: fn.id })}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  {state === "matched" && (
                    <div style={matchedIndicatorStyle(fn)}>✓</div>
                  )}
                  {state === "selected" && (
                    <div style={selectedDotStyle(fn)} />
                  )}
                  <div
                    style={{
                      fontFamily: "'Courier New', monospace",
                      fontWeight: 700,
                      fontSize: "17px",
                      color: state === "idle" ? "#1e293b" : fn.color,
                      textAlign: "center",
                      padding: "6px 0",
                      transition: "color 0.18s",
                    }}
                  >
                    {fn.rule}
                  </div>
                  <div
                    style={{
                      fontSize: "11px",
                      color: "#94a3b8",
                      textAlign: "center",
                      marginTop: "4px",
                      opacity: hoveredItem?.id === fn.id && hoveredItem?.type === "rule" ? 1 : 0,
                      transition: "opacity 0.2s",
                    }}
                  >
                    algebraic form
                  </div>
                </div>
              );
            })}
          </div>

          {/* Divider hint */}
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              paddingTop: "48px",
              gap: "8px",
              color: "#cbd5e1",
              fontSize: "20px",
              flexShrink: 0,
            }}
          >
            ⟷
          </div>

          {/* Tables Column */}
          <div style={columnStyle}>
            <div style={columnHeaderStyle}>Table of Values</div>
            {shuffledTables.map((fn) => {
              const state = getItemState("table", fn.id);
              const isHov = hoveredItem?.type === "table" && hoveredItem?.id === fn.id;
              return (
                <div
                  key={fn.id}
                  style={getCardStyle("table", fn.id)}
                  onClick={() => state !== "matched" && handleSelect("table", fn.id)}
                  onMouseEnter={() => state !== "matched" && setHoveredItem({ type: "table", id: fn.id })}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  {state === "matched" && (
                    <div style={matchedIndicatorStyle(fn)}>✓</div>
                  )}
                  {state === "selected" && (
                    <div style={selectedDotStyle(fn)} />
                  )}
                  <table
                    style={{
                      width: "100%",
                      borderCollapse: "collapse",
                      fontSize: "13px",
                    }}
                  >
                    <thead>
                      <tr>
                        <th
                          style={{
                            padding: "3px 6px",
                            textAlign: "center",
                            fontWeight: 700,
                            color: state !== "idle" ? fn.color : "#475569",
                            borderBottom: `2px solid ${state !== "idle" ? fn.color : "#e2e8f0"}`,
                            width: "50%",
                          }}
                        >
                          x
                        </th>
                        <th
                          style={{
                            padding: "3px 6px",
                            textAlign: "center",
                            fontWeight: 700,
                            color: state !== "idle" ? fn.color : "#475569",
                            borderBottom: `2px solid ${state !== "idle" ? fn.color : "#e2e8f0"}`,
                            width: "50%",
                          }}
                        >
                          y
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {fn.table.map((row, i) => (
                        <tr key={i}>
                          <td
                            style={{
                              padding: "4px 6px",
                              textAlign: "center",
                              color: "#334155",
                              background: i % 2 === 0 ? "transparent" : "rgba(0,0,0,0.02)",
                            }}
                          >
                            {row.x}
                          </td>
                          <td
                            style={{
                              padding: "4px 6px",
                              textAlign: "center",
                              color: "#334155",
                              fontWeight: 600,
                              background: i % 2 === 0 ? "transparent" : "rgba(0,0,0,0.02)",
                            }}
                          >
                            {row.y}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <div
                    style={{
                      fontSize: "11px",
                      color: "#94a3b8",
                      textAlign: "center",
                      marginTop: "6px",
                      opacity: isHov ? 1 : 0,
                      transition: "opacity 0.2s",
                    }}
                  >
                    input → output
                  </div>
                </div>
              );
            })}
          </div>

          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              paddingTop: "48px",
              gap: "8px",
              color: "#cbd5e1",
              fontSize: "20px",
              flexShrink: 0,
            }}
          >
            ⟷
          </div>

          {/* Ordered Pairs Column */}
          <div style={columnStyle}>
            <div style={columnHeaderStyle}>Ordered Pairs</div>
            {shuffledPairs.map((fn) => {
              const state = getItemState("pair", fn.id);
              const isHov = hoveredItem?.type === "pair" && hoveredItem?.id === fn.id;
              return (
                <div
                  key={fn.id}
                  style={getCardStyle("pair", fn.id)}
                  onClick={() => state !== "matched" && handleSelect("pair", fn.id)}
                  onMouseEnter={() => state !== "matched" && setHoveredItem({ type: "pair", id: fn.id })}
                  onMouseLeave={() => setHoveredItem(null)}
                >
                  {state === "matched" && (
                    <div style={matchedIndicatorStyle(fn)}>✓</div>
                  )}
                  {state === "selected" && (
                    <div style={selectedDotStyle(fn)} />
                  )}
                  <div
                    style={{
                      fontFamily: "'Courier New', monospace",
                      fontSize: "12.5px",
                      color: state !== "idle" ? fn.color : "#334155",
                      textAlign: "center",
                      lineHeight: 1.7,
                      padding: "4px 0",
                      transition: "color 0.18s",
                      wordBreak: "break-all",
                    }}
                  >
                    {fn.pairs.split(", ").map((pair, i, arr) => (
                      <span key={i}>
                        <span
                          style={{
                            display: "inline-block",
                            padding: "1px 5px",
                            borderRadius: "4px",
                            background: (isHov || state !== "idle") ? `${fn.color}18` : "transparent",
                            transition: "background 0.2s",
                          }}
                        >
                          {i === 0 ? pair.replace("{", "") : i === arr.length - 1 ? pair.replace("}", "") : pair}
                        </span>
                        {i < arr.length - 1 && (
                          <span style={{ color: "#94a3b8" }}>, </span>
                        )}
                      </span>
                    ))}
                  </div>
                  <div
                    style={{
                      fontSize: "11px",
                      color: "#94a3b8",
                      textAlign: "center",
                      marginTop: "6px",
                      opacity: isHov ? 1 : 0,
                      transition: "opacity 0.2s",
                    }}
                  >
                    (x, y) points
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Completion state */}
        {isComplete && (
          <div
            style={{
              marginTop: "40px",
              textAlign: "center",
              padding: "32px",
              borderRadius: "16px",
              background: "linear-gradient(135deg, #f0fdf4, #ecfdf5)",
              border: "2px solid #86efac",
            }}
          >
            <div style={{ fontSize: "36px", marginBottom: "8px" }}>🎉</div>
            <h2
              style={{
                fontSize: "22px",
                fontWeight: 800,
                color: "#166534",
                margin: "0 0 8px",
              }}
            >
              All Functions Matched!
            </h2>
            <p style={{ color: "#4ade80", fontWeight: 600, margin: "0 0 20px" }}>
              You correctly identified all three representations of every function.
            </p>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                gap: "16px",
                flexWrap: "wrap",
                marginBottom: "24px",
              }}
            >
              {functions.map((fn) => (
                <div
                  key={fn.id}
                  style={{
                    padding: "10px 16px",
                    borderRadius: "10px",
                    background: fn.lightColor,
                    border: `2px solid ${fn.color}`,
                    fontSize: "13px",
                    fontFamily: "monospace",
                    fontWeight: 700,
                    color: fn.color,
                  }}
                >
                  {fn.rule}
                </div>
              ))}
            </div>
            <button
              onClick={handleReset}
              style={{
                padding: "10px 28px",
                borderRadius: "8px",
                background: "#166534",
                color: "#ffffff",
                fontWeight: 700,
                fontSize: "14px",
                border: "none",
                cursor: "pointer",
                letterSpacing: "0.03em",
              }}
            >
              Play Again
            </button>
          </div>
        )}

        {/* Hint footer */}
        {!isComplete && (
          <p
            style={{
              textAlign: "center",
              marginTop: "32px",
              fontSize: "12px",
              color: "#cbd5e1",
            }}
          >
            Hover over a card to learn about each representation · Select one from each column to make a match
          </p>
        )}
      </div>
    </div>
  );
}