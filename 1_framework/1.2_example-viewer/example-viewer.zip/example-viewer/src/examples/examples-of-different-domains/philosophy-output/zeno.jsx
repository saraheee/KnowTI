import { useState, useEffect, useRef, useCallback } from "react";

const STEPS = [
  { frac:"½",     val:0.5,        series:"½",                          label:"Achilles reaches the halfway point." },
  { frac:"¾",     val:0.75,       series:"½ + ¼",                      label:"Half the remaining gap — ¼ of the total." },
  { frac:"⅞",     val:0.875,      series:"½ + ¼ + ⅛",                  label:"Again, half the remaining distance." },
  { frac:"15∕16", val:0.9375,     series:"½ + ¼ + ⅛ + 1∕16",          label:"Infinitely many steps still remain." },
  { frac:"31∕32", val:0.96875,    series:"½ + ¼ + ⅛ + 1∕16 + 1∕32",  label:"Zeno insists: you can never arrive." },
  { frac:"63∕64", val:0.984375,   series:"½ + ¼ + … + 1∕64",          label:"The gaps shrink — but never vanish?" },
  { frac:"→ 1",   val:0.9960938,  series:"½ + ¼ + ⅛ + … = 1",         label:"And yet — Achilles crosses the finish line." },
];

const TRACK_W = 520; const PAD = 20;

export default function App() {
  const [playing,  setPlaying]  = useState(false);
  const [step,     setStep]     = useState(-1);
  const [speed,    setSpeed]    = useState(1);
  const [hovered,  setHovered]  = useState(null);
  const timerRef = useRef(null);
  const LAST = STEPS.length - 1;

  const advance = useCallback(() => {
    setStep(s => { if (s >= LAST) { setPlaying(false); return s; } return s + 1; });
  }, []);

  useEffect(() => {
    clearInterval(timerRef.current);
    if (playing) timerRef.current = setInterval(advance, 1600 / speed);
    return () => clearInterval(timerRef.current);
  }, [playing, speed, advance]);

  const reset = () => { setPlaying(false); setStep(-1); };
  const toggle = () => {
    if (step >= LAST) { reset(); return; }
    setPlaying(p => !p);
  };

  const pos  = step < 0 ? 0 : STEPS[step].val;
  const done = step === LAST;
  const cur  = step >= 0 ? STEPS[step] : null;

  const trackX = (v) => PAD + v * (TRACK_W - PAD * 2);

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"20px 36px 16px",borderBottom:"1px solid #f0f0f0"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
          <div>
            <h1 style={{fontSize:22,fontWeight:700,color:"#0f172a",margin:0,letterSpacing:"-0.02em"}}>Zeno's Dichotomy Paradox</h1>
            <p style={{fontSize:11,color:"#94a3b8",margin:"3px 0 0",letterSpacing:"0.04em"}}>Elea, c. 450 BCE — Can motion ever begin if every journey requires infinite steps?</p>
          </div>
          {step >= 0 && (
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:10,color:"#94a3b8",letterSpacing:"0.08em",marginBottom:2}}>POSITION</div>
              <div style={{fontSize:26,fontWeight:700,color:"#7c3aed",letterSpacing:"-0.02em",lineHeight:1}}>{STEPS[step].frac}</div>
            </div>
          )}
        </div>
      </div>

      <div style={{flex:1,display:"flex",flexDirection:"column",padding:"20px 36px 24px",gap:18,minHeight:0}}>

        {/* Paradox quote */}
        <div style={{background:"#f8fafc",borderRadius:10,padding:"14px 18px",border:"1px solid #e2e8f0"}}>
          <p style={{fontSize:13,color:"#475569",lineHeight:1.7,margin:0,fontStyle:"italic"}}>
            "Before Achilles can reach the goal, he must first reach the halfway point. Before that, the quarter. Before that, the eighth — and so on <em>infinitely</em>. Since there are infinitely many sub-tasks, Achilles{" "}
            <span style={{color:"#ef4444",fontStyle:"normal",fontWeight:600}}>cannot move at all.</span>"
          </p>
        </div>

        {/* Track visualization */}
        <div style={{flex:1,display:"flex",flexDirection:"column",justifyContent:"center",gap:28}}>

          {/* SVG track */}
          <div style={{position:"relative"}}>
            <svg viewBox={`0 0 ${TRACK_W} 110`} style={{width:"100%",height:"auto",overflow:"visible"}}>

              {/* Track line */}
              <line x1={PAD} y1={55} x2={TRACK_W-PAD} y2={55} stroke="#e2e8f0" strokeWidth={3} strokeLinecap="round"/>

              {/* Completed portion */}
              <line x1={PAD} y1={55} x2={trackX(pos)} y2={55} stroke="#7c3aed" strokeWidth={3} strokeLinecap="round"
                style={{transition:"x2 0.7s cubic-bezier(0.4,0,0.2,1)"}}/>

              {/* Step markers */}
              {STEPS.map((s,i) => {
                const reached = step >= i;
                const x = trackX(s.val);
                return (
                  <g key={i} style={{cursor:"pointer"}}
                    onMouseEnter={()=>setHovered(i)}
                    onMouseLeave={()=>setHovered(null)}
                    onClick={()=>{ setPlaying(false); setStep(i); }}>
                    <circle cx={x} cy={55} r={reached?7:5}
                      fill={reached?"#7c3aed":"#fff"}
                      stroke={reached?"#7c3aed":"#cbd5e1"} strokeWidth={2}
                      style={{transition:"all 0.4s"}}/>
                    {/* Fraction label above */}
                    {(reached || hovered===i) && (
                      <text x={x} y={34} textAnchor="middle" fontSize={10} fill="#7c3aed" fontWeight={600}>
                        {s.frac}
                      </text>
                    )}
                    {/* Step number below */}
                    <text x={x} y={80} textAnchor="middle" fontSize={9} fill={reached?"#94a3b8":"#e2e8f0"} fontWeight={500}>
                      {i+1}
                    </text>
                    {/* Hover tooltip */}
                    {hovered===i && (
                      <g>
                        <rect x={x-70} y={4} width={140} height={22} rx={4} fill="#0f172a"/>
                        <text x={x} y={19} textAnchor="middle" fontSize={9} fill="#fff">{s.label}</text>
                      </g>
                    )}
                  </g>
                );
              })}

              {/* Start label */}
              <text x={PAD} y={96} textAnchor="middle" fontSize={10} fill="#94a3b8" fontWeight={600}>0</text>
              {/* Goal line */}
              <line x1={TRACK_W-PAD} y1={38} x2={TRACK_W-PAD} y2={72} stroke="#f59e0b" strokeWidth={2.5}/>
              <text x={TRACK_W-PAD} y={96} textAnchor="middle" fontSize={10} fill="#f59e0b" fontWeight={700}>1</text>

              {/* Achilles dot */}
              <circle cx={trackX(pos)} cy={55} r={11}
                fill={done?"#10b981":"#7c3aed"}
                style={{filter:"drop-shadow(0 2px 6px rgba(124,58,237,0.3))",transition:"cx 0.7s cubic-bezier(0.4,0,0.2,1), fill 0.4s"}}/>
            </svg>
          </div>

          {/* Step info card */}
          <div style={{minHeight:80}}>
            {cur ? (
              <div style={{
                padding:"16px 20px",borderRadius:10,
                background: done?"#ecfdf5":"#f5f3ff",
                border: `1.5px solid ${done?"#a7f3d0":"#ddd6fe"}`,
                display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:20,
              }}>
                <div>
                  <p style={{fontSize:10,fontWeight:700,letterSpacing:"0.1em",textTransform:"uppercase",color:done?"#065f46":"#6d28d9",margin:"0 0 6px"}}>
                    {done?"Resolution (Aristotle)":"Step "+( step+1)+" of "+STEPS.length}
                  </p>
                  <p style={{fontSize:13.5,color:"#1e293b",lineHeight:1.7,margin:0}}>
                    {done
                      ? "An infinite series can have a finite sum. ½ + ¼ + ⅛ + … converges to exactly 1. Zeno confused infinitely many mathematical divisions with infinite duration. Each step takes half the time of the previous — so all steps together take finite time. Motion is not paradoxical."
                      : cur.label}
                  </p>
                </div>
                <div style={{textAlign:"right",flexShrink:0}}>
                  <div style={{fontSize:10,color:"#94a3b8",marginBottom:4}}>Series</div>
                  <div style={{fontSize:12,color:done?"#065f46":"#6d28d9",fontWeight:600,lineHeight:1.6}}>
                    {cur.series}
                  </div>
                  <div style={{fontSize:12,color:"#94a3b8",marginTop:2}}>= {pos.toFixed(6)}…</div>
                </div>
              </div>
            ) : (
              <div style={{padding:"16px 20px",borderRadius:10,background:"#f8fafc",border:"1px solid #e2e8f0",textAlign:"center"}}>
                <p style={{fontSize:13,color:"#94a3b8",margin:0}}>Press ▶ to start the animation, or click any marker on the track to jump to that step.</p>
              </div>
            )}
          </div>
        </div>

        {/* Controls */}
        <div style={{
          display:"flex",alignItems:"center",gap:14,padding:"14px 18px",
          background:"#f8fafc",border:"1px solid #e2e8f0",borderRadius:10,
        }}>
          <button onClick={toggle} style={{
            width:40,height:40,borderRadius:8,border:"none",cursor:"pointer",
            background:playing?"#7c3aed":"#0f172a",color:"#fff",fontSize:18,
            display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,transition:"background 0.2s",
          }}>
            {playing?"⏸": done?"↺":"▶"}
          </button>
          <button onClick={reset} style={{
            width:40,height:40,borderRadius:8,border:"1px solid #e2e8f0",
            background:"#fff",color:"#64748b",fontSize:15,cursor:"pointer",flexShrink:0,
            display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.15s",
          }}
            onMouseEnter={e=>{e.currentTarget.style.borderColor="#94a3b8";e.currentTarget.style.color="#374151";}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor="#e2e8f0";e.currentTarget.style.color="#64748b";}}
          >↺</button>

          <div style={{flex:1,display:"flex",alignItems:"center",gap:10}}>
            <span style={{fontSize:11,color:"#94a3b8",fontWeight:600,letterSpacing:"0.06em",whiteSpace:"nowrap"}}>SPEED</span>
            <input type="range" min={0.5} max={3} step={0.5} value={speed}
              onChange={e=>setSpeed(+e.target.value)}
              style={{flex:1,accentColor:"#7c3aed",cursor:"pointer",height:4}}/>
            <span style={{fontSize:12,fontWeight:700,color:"#7c3aed",minWidth:28,textAlign:"right"}}>{speed}×</span>
          </div>

          <div style={{fontSize:11,color:"#94a3b8",letterSpacing:"0.04em",flexShrink:0,textAlign:"right"}}>
            {step < 0 ? "Not started" : done ? "Complete" : `Step ${step+1} / ${STEPS.length}`}
          </div>
        </div>
      </div>
    </div>
  );
}
