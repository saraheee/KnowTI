import { useState, useEffect, useRef, useCallback } from "react";

/* ─── Geometry ──────────────────────────────────────────────────────────── */
const G = {
  startX:65, mainY:95,
  forkX:355, branchX:452,
  branchY:162, endStraight:710, endBranch:685,
};

function cubicB(p0,p1,p2,p3,t){const u=1-t;return u*u*u*p0+3*u*u*t*p1+3*u*t*t*p2+t*t*t*p3;}
function cubicD(p0,p1,p2,p3,t){const u=1-t;return 3*(u*u*(p1-p0)+2*u*t*(p2-p1)+t*t*(p3-p2));}

function trolleyPosAt(p, pulled) {
  if (!pulled) return { x:G.startX+p*(G.endStraight-G.startX), y:G.mainY, a:0 };
  const S1=0.50, S2=0.68;
  if (p<=S1) return { x:G.startX+(p/S1)*(G.forkX-G.startX), y:G.mainY, a:0 };
  if (p<=S2) {
    const t=(p-S1)/(S2-S1);
    const x=cubicB(G.forkX,G.forkX+58,G.branchX-20,G.branchX,t);
    const y=cubicB(G.mainY,G.mainY,G.branchY,G.branchY,t);
    return { x, y, a:Math.atan2(cubicD(G.mainY,G.mainY,G.branchY,G.branchY,t),
                                  cubicD(G.forkX,G.forkX+58,G.branchX-20,G.branchX,t))*180/Math.PI };
  }
  return { x:G.branchX+((p-S2)/(1-S2))*(G.endBranch-G.branchX), y:G.branchY, a:0 };
}

/* ─── Frameworks ────────────────────────────────────────────────────────── */
const FW = [
  {
    key:"utilitarian", label:"Utilitarian", sub:"Bentham · Mill",
    color:"#2563eb", light:"#eff6ff", border:"#bfdbfe",
    action:"pull",
    tagline:"Pull — five lives outweigh one.",
    verdict:{
      pull:"Correct action. Five lives outweigh one. Maximising welfare demands it — inaction that allows five deaths when a single act saves them is itself a moral failure.",
      stay:"Wrong outcome. Five people die when one pull could have saved them. The utilitarian calculus is unambiguous: passivity that allows greater harm is not morally neutral.",
    },
  },
  {
    key:"kantian", label:"Kantian", sub:"Immanuel Kant",
    color:"#7c3aed", light:"#f5f3ff", border:"#ddd6fe",
    action:"stay",
    tagline:"Do nothing — don't use a person as a means.",
    verdict:{
      pull:"Impermissible. Pulling uses one person as a mere means to save others — a direct violation of the categorical imperative. Dignity cannot be sacrificed for any outcome calculus.",
      stay:"Permissible. You did not set the trolley in motion. The doctrine of doing and allowing holds you responsible only for your own acts, not every harm you could theoretically prevent.",
    },
  },
  {
    key:"virtue", label:"Virtue Ethics", sub:"Aristotle",
    color:"#059669", light:"#ecfdf5", border:"#a7f3d0",
    action:"stay",
    tagline:"No formula — only the weight of character.",
    verdict:{
      pull:"A person of practical wisdom (φρόνησις) who pulls still carries the weight of that one death. Virtue ethics finds no formula here — only the quality of character revealed in how you bear the decision.",
      stay:"A person of practical wisdom (φρόνησις) who does nothing carries the weight of five deaths. Virtue ethics finds no formula — only the quality of character revealed in how you live with the outcome.",
    },
  },
];

/* ─── Person ─────────────────────────────────────────────────────────────── */
function Person({x,y,alive,highlight}){
  const c=alive?"#1e293b":"#fca5a5", s=alive?"#1e293b":"#ef4444";
  return (
    <g opacity={alive?1:0.65}>
      {highlight&&<circle cx={x} cy={y-8} r={11} fill="none" stroke="#f59e0b" strokeWidth={1.5} opacity={0.75}/>}
      <circle cx={x} cy={y-8} r={5.5} fill={c}/>
      <line x1={x} y1={y-2} x2={x} y2={y+10} stroke={s} strokeWidth={2.5} strokeLinecap="round"/>
      <line x1={x-7} y1={y+3} x2={x+7} y2={y+3} stroke={s} strokeWidth={2} strokeLinecap="round"/>
      <line x1={x} y1={y+10} x2={x-5} y2={y+21} stroke={s} strokeWidth={2} strokeLinecap="round"/>
      <line x1={x} y1={y+10} x2={x+5} y2={y+21} stroke={s} strokeWidth={2} strokeLinecap="round"/>
    </g>
  );
}

/* ─── Track scene ────────────────────────────────────────────────────────── */
function Scene({animAction, progress, playing, arrived}){
  const pulled    = animAction==="pull";
  const pos       = animAction ? trolleyPosAt(progress,pulled) : {x:G.startX,y:G.mainY,a:0};
  const fiveAlive = !(arrived&&!pulled);
  const oneAlive  = !(arrived&&pulled);
  const mainC     = arrived&&!pulled ? "#ef4444" : "#94a3b8";
  const branchC   = arrived&&pulled  ? "#ef4444" : "#94a3b8";

  return (
    <svg viewBox="0 0 780 205" width="100%" style={{display:"block",maxHeight:178,overflow:"visible"}}>
      {/* Main track */}
      {[-5,5].map(o=><line key={o} x1={G.startX} y1={G.mainY+o} x2={G.endStraight} y2={G.mainY+o} stroke={mainC} strokeWidth={3} style={{transition:"stroke 0.5s"}}/>)}
      {Array.from({length:27},(_,i)=>G.startX+22+i*24).map(x=>(
        <line key={x} x1={x} y1={G.mainY-8} x2={x} y2={G.mainY+8} stroke={mainC} strokeWidth={1.8} opacity={0.5} style={{transition:"stroke 0.5s"}}/>
      ))}
      {/* Lower branch curve */}
      {[0,8].map(o=>(
        <path key={o} d={`M${G.forkX},${G.mainY+o} Q${G.forkX+62},${G.mainY+o} ${G.branchX},${G.branchY+o}`}
          fill="none" stroke={branchC} strokeWidth={3} style={{transition:"stroke 0.5s"}}/>
      ))}
      {[0,8].map(o=><line key={o} x1={G.branchX} y1={G.branchY+o} x2={G.endBranch} y2={G.branchY+o} stroke={branchC} strokeWidth={3} style={{transition:"stroke 0.5s"}}/>)}
      {Array.from({length:9},(_,i)=>G.branchX+22+i*26).map(x=>(
        <line key={x} x1={x} y1={G.branchY-3} x2={x} y2={G.branchY+11} stroke={branchC} strokeWidth={1.8} opacity={0.5} style={{transition:"stroke 0.5s"}}/>
      ))}
      {/* Lever */}
      <circle cx={G.forkX} cy={G.mainY} r={7} fill={animAction?(pulled?"#2563eb":"#7c3aed"):"#64748b"} style={{transition:"fill 0.5s"}}/>
      <line x1={G.forkX} y1={G.mainY}
        x2={animAction?(pulled?G.forkX-8:G.forkX+8):G.forkX} y2={G.mainY-16}
        stroke={animAction?(pulled?"#2563eb":"#7c3aed"):"#64748b"} strokeWidth={3.5} strokeLinecap="round" style={{transition:"all 0.5s"}}/>
      {/* 5 people */}
      {[487,520,553,586,619].map((x,i)=><Person key={i} x={x} y={G.mainY+3} alive={fiveAlive} highlight={arrived&&!pulled}/>)}
      <text x={553} y={G.mainY-22} textAnchor="middle" fontSize={11} fontWeight={700}
        fill={arrived&&!pulled?"#ef4444":"#64748b"} fontFamily="system-ui,sans-serif">
        {arrived&&!pulled?"✕  5 lives lost":"5 people"}
      </text>
      {/* 1 person */}
      <Person x={612} y={G.branchY+3} alive={oneAlive} highlight={arrived&&pulled}/>
      <text x={612} y={G.branchY+30} textAnchor="middle" fontSize={11} fontWeight={700}
        fill={arrived&&pulled?"#ef4444":"#64748b"} fontFamily="system-ui,sans-serif">
        {arrived&&pulled?"✕  1 life lost":"1 person"}
      </text>
      {/* Trolley */}
      <g transform={`translate(${pos.x-28},${pos.y-17}) rotate(${pos.a*0.42},28,17)`}>
        <rect x={0} y={0} width={56} height={34} rx={5} fill="#0f172a"/>
        <rect x={5}  y={6} width={18} height={12} rx={2} fill="#fbbf24" opacity={0.9}/>
        <rect x={29} y={6} width={18} height={12} rx={2} fill="#fbbf24" opacity={0.9}/>
        <rect x={0}  y={0} width={7}  height={34} rx={3} fill="#ef4444" opacity={animAction?0.9:0.25} style={{transition:"opacity 0.4s"}}/>
        <circle cx={11} cy={36} r={7} fill="#334155"/><circle cx={11} cy={36} r={3} fill="#475569"/>
        <circle cx={45} cy={36} r={7} fill="#334155"/><circle cx={45} cy={36} r={3} fill="#475569"/>
        {playing&&<>
          <line x1={-10} y1={9}  x2={-2} y2={9}  stroke="#cbd5e1" strokeWidth={1.5} opacity={0.6}/>
          <line x1={-14} y1={17} x2={-3} y2={17} stroke="#cbd5e1" strokeWidth={1.5} opacity={0.4}/>
          <line x1={-10} y1={25} x2={-2} y2={25} stroke="#cbd5e1" strokeWidth={1.5} opacity={0.6}/>
        </>}
      </g>
    </svg>
  );
}

/* ─── Main ───────────────────────────────────────────────────────────────── */
export default function App() {
  const [userChoice,  setUserChoice]  = useState(null);   // "pull"|"stay"
  const [animMode,    setAnimMode]    = useState(null);    // "user"|"theory"
  const [selectedFw,  setSelectedFw]  = useState(null);   // fw key
  const [userArrived, setUserArrived] = useState(false);
  const [fwArrived,   setFwArrived]   = useState(false);
  const [progress,    setProgress]    = useState(0);
  const [playing,     setPlaying]     = useState(false);
  const [speed,       setSpeed]       = useState(1);

  const speedRef=useRef(speed), animRef=useRef(null), prevTsRef=useRef(null);
  const DURATION=5400;
  useEffect(()=>{speedRef.current=speed;},[speed]);

  const animate=useCallback((ts)=>{
    if(prevTsRef.current!==null){
      const dt=ts-prevTsRef.current;
      setProgress(p=>{
        const next=p+(dt*speedRef.current)/DURATION;
        if(next>=1){
          setPlaying(false);
          if(animMode==="user")    setUserArrived(true);
          if(animMode==="theory")  setFwArrived(true);
          return 1;
        }
        return next;
      });
    }
    prevTsRef.current=ts;
    animRef.current=requestAnimationFrame(animate);
  },[animMode]);

  useEffect(()=>{
    if(playing){prevTsRef.current=null;animRef.current=requestAnimationFrame(animate);}
    else cancelAnimationFrame(animRef.current);
    return()=>cancelAnimationFrame(animRef.current);
  },[playing,animate]);

  const startAnim=(mode)=>{setAnimMode(mode);setProgress(0);setPlaying(true);};

  const choose=(c)=>{
    setUserChoice(c); setSelectedFw(null);
    setUserArrived(false); setFwArrived(false);
    startAnim("user");
  };

  const selectFw=(key)=>{
    setSelectedFw(key); setFwArrived(false);
    startAnim("theory");
  };

  const reset=()=>{
    setUserChoice(null); setSelectedFw(null); setAnimMode(null);
    setUserArrived(false); setFwArrived(false);
    setProgress(0); setPlaying(false);
  };

  const fw        = FW.find(f=>f.key===selectedFw);
  const animAction = animMode==="user" ? userChoice : animMode==="theory" ? fw?.action : null;
  const arrived    = animMode==="user" ? (userArrived&&animMode==="user") : (fwArrived&&animMode==="theory");
  const showTheories = userArrived;

  // Controls bar (shared between phases)
  const ControlsBar=({label, accentColor})=>(
    <div style={{display:"flex",alignItems:"center",gap:12,width:"100%",
      background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,
      padding:"9px 14px",boxSizing:"border-box"}}>
      <div style={{fontSize:12,fontWeight:600,color:"#1e293b",flex:1}}>{label}</div>
      <button onClick={()=>setPlaying(p=>!p)} style={{
        width:32,height:32,borderRadius:8,border:"none",fontSize:13,cursor:"pointer",
        background:playing?"#64748b":"#0f172a",color:"#fff",
        display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
        {playing?"⏸":"▶"}
      </button>
      <div style={{display:"flex",alignItems:"center",gap:8,flexShrink:0}}>
        <span style={{fontSize:10,color:"#94a3b8",fontWeight:700,letterSpacing:"0.08em"}}>SPEED</span>
        <input type="range" min={0.25} max={3} step={0.25} value={speed}
          onChange={e=>setSpeed(+e.target.value)}
          style={{width:76,accentColor:accentColor||"#0f172a",cursor:"pointer"}}/>
        <span style={{fontSize:12,fontWeight:800,color:accentColor||"#0f172a",minWidth:24}}>{speed}×</span>
      </div>
    </div>
  );

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"15px 28px 11px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:820,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <h1 style={{fontSize:19,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>The Trolley Problem</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>Philippa Foot · 1967</p>
          </div>
          {userChoice&&(
            <button onClick={reset} style={{padding:"5px 13px",border:"1px solid #e2e8f0",borderRadius:8,
              background:"#fff",color:"#64748b",fontSize:11,fontWeight:600,cursor:"pointer"}}>↺ Reset</button>
          )}
        </div>
      </div>

      {/* Body */}
      <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",overflow:"auto",
        padding:"8px 28px 14px",maxWidth:820,margin:"0 auto",width:"100%",boxSizing:"border-box",gap:9}}>

        {/* Progress bar */}
        <div style={{width:"100%",height:3,background:"#f1f5f9",borderRadius:2,overflow:"hidden",flexShrink:0}}>
          {animAction&&<div style={{height:"100%",borderRadius:2,
            background:animMode==="theory"?(fw?.color||"#0f172a"):(animAction==="pull"?"#2563eb":"#7c3aed"),
            width:`${progress*100}%`,transition:playing?"none":"width 0.1s"}}/>}
        </div>

        {/* Track */}
        <div style={{width:"100%",flexShrink:0}}>
          <Scene animAction={animAction} progress={progress} playing={playing}
            arrived={animMode==="user"?userArrived:fwArrived}/>
        </div>

        {/* ── Phase 1: Question ── */}
        {!userChoice&&(
          <div style={{textAlign:"center",display:"flex",flexDirection:"column",alignItems:"center",gap:12,paddingTop:4}}>
            <p style={{fontSize:14,color:"#1e293b",margin:0,lineHeight:1.6,maxWidth:500}}>
              A runaway trolley heads toward <strong>5 people</strong> on the main track.
              Pulling a lever diverts it to a lower branch — where <strong>1 person</strong> is tied.
            </p>
            <p style={{fontSize:12,color:"#64748b",margin:0,fontStyle:"italic"}}>What do you do?</p>
            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>choose("pull")} style={{
                padding:"11px 24px",background:"#0f172a",color:"#fff",border:"none",
                borderRadius:10,fontSize:13,fontWeight:700,cursor:"pointer",
                letterSpacing:"0.05em",boxShadow:"0 4px 14px rgba(15,23,42,0.18)",transition:"transform 0.15s"}}
                onMouseEnter={e=>e.currentTarget.style.transform="translateY(-1px)"}
                onMouseLeave={e=>e.currentTarget.style.transform=""}>
                Pull the Lever
              </button>
              <button onClick={()=>choose("stay")} style={{
                padding:"11px 24px",background:"#fff",color:"#0f172a",
                border:"2px solid #e2e8f0",borderRadius:10,fontSize:13,fontWeight:700,
                cursor:"pointer",letterSpacing:"0.05em",transition:"border-color 0.15s"}}
                onMouseEnter={e=>e.currentTarget.style.borderColor="#94a3b8"}
                onMouseLeave={e=>e.currentTarget.style.borderColor="#e2e8f0"}>
                Do Nothing
              </button>
            </div>
          </div>
        )}

        {/* ── Phase 2: User animation controls ── */}
        {animMode==="user"&&!userArrived&&(
          <ControlsBar
            label={userChoice==="pull"
              ? "You pull the lever — trolley diverts to the lower branch…"
              : "You do nothing — trolley stays on the main track…"}
            accentColor={userChoice==="pull"?"#2563eb":"#7c3aed"}
          />
        )}

        {/* ── Phase 3: Theories (shown after user animation + optionally during/after theory anim) ── */}
        {showTheories&&(
          <div style={{width:"100%",display:"flex",flexDirection:"column",gap:9}}>

            {/* User outcome badge */}
            <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
              <span style={{fontSize:11,color:"#94a3b8"}}>Your choice:</span>
              <span style={{padding:"3px 11px",borderRadius:20,fontSize:11,fontWeight:700,
                background:userChoice==="pull"?"#1e293b":"#f1f5f9",
                color:userChoice==="pull"?"#fff":"#475569"}}>
                {userChoice==="pull"?"Pull → 1 life lost":"Do nothing → 5 lives lost"}
              </span>
              <span style={{fontSize:11,color:"#94a3b8"}}>· Select a framework to see its recommendation played out:</span>
            </div>

            {/* Theory cards */}
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:9}}>
              {FW.map(f=>{
                const isSelected = selectedFw===f.key;
                const isPlaying  = isSelected && animMode==="theory" && !fwArrived;
                const isDone     = isSelected && animMode==="theory" && fwArrived;
                return (
                  <div key={f.key} onClick={()=>selectFw(f.key)}
                    style={{padding:"13px",border:`2px solid ${isSelected?f.color:f.border}`,
                      borderRadius:12,background:isSelected?f.light:"#fff",
                      cursor:"pointer",transition:"all 0.2s",
                      boxShadow:isSelected?"0 4px 18px rgba(0,0,0,0.07)":"none",
                      position:"relative",overflow:"hidden"}}>
                    {/* Playing pulse */}
                    {isPlaying&&(
                      <div style={{position:"absolute",inset:0,background:`${f.color}08`,
                        animation:"pulse 1.4s ease-in-out infinite"}}/>
                    )}
                    <div style={{fontSize:10,fontWeight:800,letterSpacing:"0.1em",
                      color:f.color,textTransform:"uppercase",marginBottom:1}}>{f.label}</div>
                    <div style={{fontSize:10,color:"#94a3b8",marginBottom:7}}>{f.sub}</div>
                    <div style={{fontSize:11,fontWeight:600,color:isSelected?f.color:"#64748b",marginBottom:isDone?8:0}}>
                      {isPlaying ? "▶ Playing…" : f.tagline}
                    </div>
                    {isDone&&(
                      <p style={{fontSize:12,lineHeight:1.65,color:"#1e293b",margin:0,fontStyle:"italic"}}>
                        {f.verdict[userChoice]}
                      </p>
                    )}
                    {!isSelected&&(
                      <div style={{fontSize:10,color:f.color,marginTop:4,fontWeight:500}}>Click to animate ▶</div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Theory animation controls */}
            {animMode==="theory"&&!fwArrived&&fw&&(
              <ControlsBar
                label={`${fw.label}: ${fw.action==="pull"?"pulling the lever → 1 person affected":"doing nothing → 5 people affected"}`}
                accentColor={fw.color}
              />
            )}

            {/* After theory done: replay + try other choice */}
            {fwArrived&&(
              <div style={{display:"flex",gap:9,flexWrap:"wrap"}}>
                <button onClick={()=>selectFw(selectedFw)} style={{padding:"7px 16px",border:`1px solid ${fw?.border}`,
                  background:fw?.light,color:fw?.color,borderRadius:8,fontSize:11,fontWeight:700,cursor:"pointer"}}>
                  ▶ Replay this theory
                </button>
                <button onClick={reset} style={{padding:"7px 16px",border:"1px solid #e2e8f0",
                  background:"#fff",color:"#64748b",borderRadius:8,fontSize:11,fontWeight:600,cursor:"pointer"}}>
                  ↺ Try the other choice
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      <style>{`@keyframes pulse{0%,100%{opacity:0}50%{opacity:1}}`}</style>
    </div>
  );
}
