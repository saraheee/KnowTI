import { useState } from "react";

const ELEMENTS = {
  shadows: {
    zone:"illusion", title:"The Shadows",
    quote:"They see only their own shadows, or the shadows of one another.",
    body:"The shadows represent δόξα — mere opinion and sensory appearance. Plato asks: how much of what we call 'knowledge' is only the shadow of a deeper truth? The prisoners are not foolish — they are expert interpreters of shadows. That is precisely the problem.",
  },
  prisoner: {
    zone:"illusion", title:"The Prisoner",
    quote:"Fettered since childhood, they cannot turn their heads.",
    body:"The chains are not physical — they are habit, convention, and the comfort of the familiar. Most people never question the reality they were born into. Plato compares this to living your entire life watching a cinema, mistaking the film for the world.",
  },
  fire: {
    zone:"opinion", title:"The Fire",
    quote:"A fire is burning above and behind them.",
    body:"The fire is the lesser light — it represents political power, rhetoric, and the world of shifting opinion. Those who carry objects in front of it are sophists and politicians who shape what 'reality' looks like. They stand between truth and the prisoners without the prisoners ever knowing.",
  },
  carrier: {
    zone:"opinion", title:"The Object Carrier",
    quote:"Men pass along carrying objects, whose shadows are cast on the wall.",
    body:"The carriers represent those who manufacture consensus — priests, educators, media, rulers. Plato's critique of democracy runs deep here: most citizens vote based on shadow-shows, not on truth. The carriers are not necessarily malicious. Often, they are themselves prisoners of a slightly higher cave.",
  },
  exit: {
    zone:"truth", title:"The Cave Exit",
    quote:"With great pain, he is dragged toward the light and forced to look at it.",
    body:"The threshold of philosophy. The freed prisoner's first experience of reality is not wonder but pain — the light blinds him. True education does not fill an empty mind; it turns the whole soul. The crisis of doubt before awakening is not a flaw in the process. It is the process.",
  },
  sun: {
    zone:"truth", title:"The Form of the Good",
    quote:"The sun provides the seasons, the years, and is the cause of all that is visible.",
    body:"τὸ ἀγαθόν — the highest Form, the source of all truth, being, and beauty. For Plato it is not a god but a principle: the reason anything exists or can be known at all. The philosopher who glimpses it faces an obligation to return to the cave and govern — even knowing the prisoners may kill them for it.",
  },
};

const ZONE_STYLE = {
  illusion: { color:"#475569", bg:"#f1f5f9", dot:"#94a3b8", label:"World of Illusion" },
  opinion:  { color:"#b45309", bg:"#fffbeb", dot:"#f59e0b", label:"World of Opinion" },
  truth:    { color:"#1d4ed8", bg:"#eff6ff", dot:"#3b82f6", label:"World of Truth" },
};

export default function App() {
  const [sel, setSel]   = useState(null);
  const [mode, setMode] = useState("prisoner");
  const info = sel ? ELEMENTS[sel] : null;
  const zs   = info ? ZONE_STYLE[info.zone] : null;

  const hit = (id) => setSel(p => p===id ? null : id);
  const ringColor = (id) => {
    if (sel!==id) return "transparent";
    const z = ELEMENTS[id].zone;
    return ZONE_STYLE[z].dot;
  };

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"18px 28px 14px",display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:"1px solid #f0f0f0"}}>
        <div>
          <h1 style={{fontSize:20,fontWeight:700,color:"#0f172a",margin:0,letterSpacing:"-0.02em"}}>Plato's Allegory of the Cave</h1>
          <p style={{fontSize:11,color:"#94a3b8",margin:"2px 0 0",letterSpacing:"0.05em"}}>The Republic · Book VII · Click any element to explore its meaning</p>
        </div>
        <div style={{display:"flex",gap:3,background:"#f8fafc",borderRadius:8,padding:3,border:"1px solid #e2e8f0"}}>
          {[["prisoner","Prisoner's View"],["philosopher","Philosopher's View"]].map(([m,l])=>(
            <button key={m} onClick={()=>setMode(m)} style={{
              padding:"6px 14px",border:"none",borderRadius:6,fontSize:11,fontWeight:600,cursor:"pointer",transition:"all 0.18s",
              background:mode===m?"#fff":"transparent",color:mode===m?"#0f172a":"#64748b",
              boxShadow:mode===m?"0 1px 3px rgba(0,0,0,0.1)":"none",
            }}>{l}</button>
          ))}
        </div>
      </div>

      {/* Body */}
      <div style={{flex:1,display:"flex",minHeight:0}}>

        {/* SVG cave diagram */}
        <div style={{flex:"0 0 58%",position:"relative"}}>
          <svg viewBox="0 0 580 380" style={{width:"100%",height:"100%"}} onClick={e=>{if(e.target===e.currentTarget)setSel(null);}}>

            {/* Zone backgrounds */}
            <rect x={0}   y={0} width={195} height={380} fill="#f8fafc"/>
            <rect x={195} y={0} width={160} height={380} fill={mode==="philosopher"?"#fffbeb":"#f8fafc"}/>
            <rect x={355} y={0} width={225} height={380} fill={mode==="philosopher"?"#eff6ff":"#f8fafc"} opacity={mode==="prisoner"?0.35:1}/>

            {/* Zone dividers */}
            <line x1={195} y1={0} x2={195} y2={380} stroke="#e2e8f0" strokeWidth={1}/>
            <line x1={355} y1={0} x2={355} y2={380} stroke="#e2e8f0" strokeWidth={1} opacity={mode==="prisoner"?0.3:1}/>

            {/* Zone labels (philosopher mode) */}
            {mode==="philosopher" && <>
              <text x={97}  y={22} textAnchor="middle" fontSize={9} fill="#94a3b8" letterSpacing="0.12em" fontWeight={600}>ILLUSION</text>
              <text x={275} y={22} textAnchor="middle" fontSize={9} fill="#d97706" letterSpacing="0.12em" fontWeight={600}>OPINION</text>
              <text x={467} y={22} textAnchor="middle" fontSize={9} fill="#2563eb" letterSpacing="0.12em" fontWeight={600}>TRUTH</text>
            </>}

            {/* Cave walls */}
            <path d="M0,0 L0,145 Q55,110 80,165 Q105,220 145,170 L145,0Z" fill="#e2e8f0"/>
            <path d="M0,380 L0,230 Q40,260 60,320 L0,380Z" fill="#e2e8f0"/>

            {/* Wall / screen */}
            <rect x={28} y={110} width={105} height={190} rx={3} fill="#cbd5e1" stroke="#94a3b8" strokeWidth={1}/>
            <text x={80} y={325} textAnchor="middle" fontSize={8} fill="#94a3b8">THE WALL</text>

            {/* Shadows on wall */}
            <g style={{cursor:"pointer"}} onClick={()=>hit("shadows")}>
              <ellipse cx={80} cy={175} rx={22} ry={32} fill="#94a3b8" opacity={0.75}/>
              <ellipse cx={80} cy={248} rx={26} ry={14} fill="#94a3b8" opacity={0.5}/>
              <circle  cx={80} cy={175} r={26} fill="none" stroke={ringColor("shadows")} strokeWidth={2.5} strokeDasharray={sel==="shadows"?"none":"4,2"}/>
            </g>

            {/* Prisoner */}
            <g style={{cursor:"pointer"}} onClick={()=>hit("prisoner")}>
              <circle cx={163} cy={240} r={13} fill="#475569"/>
              <rect x={156} y={253} width={14} height={26} rx={3} fill="#475569"/>
              <path d="M163,279 Q152,300 148,318" stroke="#94a3b8" strokeWidth={1.5} strokeDasharray="3,2" fill="none"/>
              <circle cx={163} cy={260} r={18} fill="none" stroke={ringColor("prisoner")} strokeWidth={2.5}/>
            </g>
            {mode==="philosopher"&&<text x={163} y={336} textAnchor="middle" fontSize={8} fill="#64748b">prisoner</text>}

            {/* Light rays (philosopher mode) */}
            {mode==="philosopher"&&<>
              <line x1={267} y1={295} x2={115} y2={195} stroke="#fbbf24" strokeWidth={1} strokeDasharray="5,4" opacity={0.5}/>
              <line x1={267} y1={295} x2={108} y2={168} stroke="#fbbf24" strokeWidth={1} strokeDasharray="5,4" opacity={0.5}/>
            </>}

            {/* Fire */}
            <g style={{cursor:"pointer"}} onClick={()=>hit("fire")}>
              <ellipse cx={267} cy={340} rx={24} ry={8} fill="#fde68a" opacity={0.7}/>
              <path d="M267,255 Q256,290 253,340 Q267,310 281,340 Q278,290 267,255Z" fill="#fbbf24"/>
              <path d="M267,272 Q260,305 258,340 Q267,318 276,340 Q274,305 267,272Z" fill="#f97316"/>
              <path d="M267,300 Q263,325 262,340 Q267,328 272,340 Q271,325 267,300Z" fill="#fff7ed"/>
              <ellipse cx={267} cy={290} rx={30} ry={55} fill="none" stroke={ringColor("fire")} strokeWidth={2.5}/>
            </g>
            {mode==="philosopher"&&<text x={267} y={356} textAnchor="middle" fontSize={8} fill="#d97706">fire</text>}

            {/* Object carrier */}
            <g style={{cursor:"pointer",opacity:mode==="philosopher"?1:0.18}} onClick={()=>hit("carrier")}>
              <circle cx={232} cy={225} r={11} fill={sel==="carrier"?"#d97706":"#f59e0b"}/>
              <rect x={225} y={236} width={14} height={24} rx={3} fill={sel==="carrier"?"#d97706":"#f59e0b"}/>
              <rect x={238} y={220} width={36} height={20} rx={3} fill="#78716c"/>
              <circle cx={232} cy={225} r={16} fill="none" stroke={ringColor("carrier")} strokeWidth={2.5}/>
            </g>
            {mode==="philosopher"&&<text x={250} y={272} textAnchor="middle" fontSize={8} fill="#d97706">carrier</text>}

            {/* Cave opening / exit */}
            <g style={{cursor:"pointer",opacity:mode==="prisoner"?0.35:1}} onClick={()=>hit("exit")}>
              <ellipse cx={420} cy={195} rx={58} ry={105} fill={mode==="philosopher"?"#dbeafe":"#e2e8f0"} stroke={mode==="philosopher"?"#3b82f6":"#cbd5e1"} strokeWidth={1.5}/>
              <ellipse cx={420} cy={195} rx={62} ry={109} fill="none" stroke={ringColor("exit")} strokeWidth={2.5}/>
              {mode==="philosopher"&&<text x={420} y={200} textAnchor="middle" fontSize={10} fill="#2563eb" fontWeight={600}>EXIT</text>}
            </g>

            {/* Sun */}
            <g style={{cursor:"pointer",opacity:mode==="prisoner"?0.18:1}} onClick={()=>hit("sun")}>
              <circle cx={515} cy={100} r={26} fill="#fef9c3"/>
              <circle cx={515} cy={100} r={19} fill="#fde047"/>
              {[0,45,90,135,180,225,270,315].map(d=>(
                <line key={d}
                  x1={515+Math.cos(d*Math.PI/180)*25} y1={100+Math.sin(d*Math.PI/180)*25}
                  x2={515+Math.cos(d*Math.PI/180)*35} y2={100+Math.sin(d*Math.PI/180)*35}
                  stroke="#facc15" strokeWidth={2.5} strokeLinecap="round"/>
              ))}
              <circle cx={515} cy={100} r={33} fill="none" stroke={ringColor("sun")} strokeWidth={2.5}/>
            </g>
            {mode==="philosopher"&&<text x={515} y={148} textAnchor="middle" fontSize={8} fill="#1d4ed8" fontWeight={600}>The Good</text>}

            {/* Freed philosopher */}
            {mode==="philosopher"&&<>
              <circle cx={378} cy={210} r={10} fill="#3b82f6"/>
              <rect x={372} y={220} width={12} height={20} rx={3} fill="#3b82f6"/>
              <text x={378} y={254} textAnchor="middle" fontSize={8} fill="#3b82f6">freed</text>
            </>}
          </svg>
        </div>

        {/* Info panel */}
        <div style={{flex:1,padding:"28px 28px 20px",borderLeft:"1px solid #f0f0f0",overflowY:"auto",display:"flex",flexDirection:"column",justifyContent:info?"flex-start":"center"}}>
          {info ? (
            <div>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:18}}>
                <div style={{width:9,height:9,borderRadius:"50%",background:zs.dot,flexShrink:0}}/>
                <span style={{fontSize:10,fontWeight:700,letterSpacing:"0.14em",textTransform:"uppercase",color:zs.color}}>{zs.label}</span>
              </div>
              <h2 style={{fontSize:22,fontWeight:700,color:"#0f172a",margin:"0 0 14px",letterSpacing:"-0.01em"}}>{info.title}</h2>
              <blockquote style={{margin:"0 0 18px",padding:"12px 16px",background:zs.bg,borderLeft:`3px solid ${zs.dot}`,borderRadius:"0 8px 8px 0"}}>
                <p style={{fontSize:13,fontStyle:"italic",color:"#475569",lineHeight:1.65,margin:0}}>"{info.quote}"</p>
              </blockquote>
              <p style={{fontSize:13.5,color:"#334155",lineHeight:1.8,margin:0}}>{info.body}</p>
              <button onClick={()=>setSel(null)} style={{marginTop:20,background:"none",border:"1px solid #e2e8f0",borderRadius:7,color:"#64748b",fontSize:11,padding:"6px 14px",cursor:"pointer",fontFamily:"inherit"}}>← Back to diagram</button>
            </div>
          ) : (
            <div>
              <p style={{fontSize:14,color:"#64748b",lineHeight:1.7,margin:"0 0 22px"}}>Click any element in the cave diagram to uncover its philosophical meaning. Use the toggle above to switch between perspectives.</p>
              <div style={{display:"flex",flexDirection:"column",gap:6}}>
                {Object.entries(ELEMENTS).map(([k,v])=>{
                  const z = ZONE_STYLE[v.zone];
                  return (
                    <button key={k} onClick={()=>setSel(k)} style={{
                      display:"flex",alignItems:"center",gap:10,padding:"9px 12px",
                      background:"#f8fafc",border:"1px solid #e2e8f0",borderRadius:8,
                      cursor:"pointer",textAlign:"left",transition:"all 0.15s",
                    }}
                      onMouseEnter={e=>{e.currentTarget.style.background=z.bg;e.currentTarget.style.borderColor=z.dot;}}
                      onMouseLeave={e=>{e.currentTarget.style.background="#f8fafc";e.currentTarget.style.borderColor="#e2e8f0";}}
                    >
                      <div style={{width:7,height:7,borderRadius:"50%",background:z.dot,flexShrink:0}}/>
                      <span style={{fontSize:12,fontWeight:600,color:"#0f172a"}}>{v.title}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
