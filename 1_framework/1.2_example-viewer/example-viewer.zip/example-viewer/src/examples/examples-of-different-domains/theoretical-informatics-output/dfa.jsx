import { useState, useEffect, useRef } from "react";

/* ─── DFA Definitions ─────────────────────────────────────────────────── */
const DFAS = [
  {
    id:"ends_ab", title:'Ends in "ab"',
    desc:'L = { w ∈ {a,b}* | w ends with "ab" }',
    states:{ q0:{x:110,y:155,start:true,accept:false}, q1:{x:290,y:155,start:false,accept:false}, q2:{x:470,y:155,start:false,accept:true} },
    δ:{ q0:{a:"q1",b:"q0"}, q1:{a:"q1",b:"q2"}, q2:{a:"q1",b:"q0"} },
    start:"q0", accepting:["q2"],
    examples:["ab","aab","bab","abab","ba","b","a","abb"],
    info:"Three states track progress toward 'ab'. q0 = no progress, q1 = last char was 'a', q2 = last two chars were 'ab' (accept). Each new character either advances or resets progress.",
    arrows:[
      {path:"M 55,155 L 82,155",      label:null,  lx:0,   ly:0,   type:"start"},
      {path:"M 98,129 A 18,18 0 1,1 122,129", label:"b", lx:110, ly:98,  type:"loop"},
      {path:"M 138,155 L 262,155",    label:"a",   lx:200, ly:143, type:"fwd"},
      {path:"M 278,129 A 18,18 0 1,1 302,129", label:"a", lx:290, ly:98, type:"loop"},
      {path:"M 318,155 L 442,155",    label:"b",   lx:380, ly:143, type:"fwd"},
      {path:"M 446,141 C 395,100 345,100 313,141", label:"a", lx:378,ly:92, type:"back"},
      {path:"M 447,167 C 340,218 190,218 137,167", label:"b", lx:295,ly:222,type:"back"},
    ],
    activeArrow:(from,to,sym)=>`${from}-${to}-${sym}`,
    arrowKey:(arr,i)=>{const keys=["","q0-q0-b","q0-q1-a","q1-q1-a","q1-q2-b","q2-q1-a","q2-q0-b"];return keys[i];},
  },
  {
    id:"even_a", title:"Even # of a's",
    desc:"L = { w ∈ {a,b}* | |w|_a ≡ 0 (mod 2) }",
    states:{ qE:{x:160,y:155,start:true,accept:true}, qO:{x:400,y:155,start:false,accept:false} },
    δ:{ qE:{a:"qO",b:"qE"}, qO:{a:"qE",b:"qO"} },
    start:"qE", accepting:["qE"],
    alphabet:["a","b"],
    examples:["","aa","bba","ab","abb","aabb","a","b","aba"],
    info:"Two states track parity of a's. qE = even count (accepting start), qO = odd count. Every 'a' flips parity; 'b' leaves it unchanged. Simple but powerful — parity is the key invariant.",
    arrows:[
      {path:"M 80,155 L 132,155",     label:null,  lx:0,  ly:0,   type:"start"},
      {path:"M 148,129 A 18,18 0 1,1 172,129", label:"b",  lx:160,ly:98,  type:"loop"},
      {path:"M 188,147 L 372,147",    label:"a",   lx:280,ly:134, type:"fwd"},
      {path:"M 372,163 L 188,163",    label:"a",   lx:280,ly:176, type:"back"},
      {path:"M 388,129 A 18,18 0 1,1 412,129", label:"b",  lx:400,ly:98,  type:"loop"},
    ],
    arrowKey:(arr,i)=>{const keys=["","qE-qE-b","qE-qO-a","qO-qE-a","qO-qO-b"];return keys[i];},
  },
];

const PSEUDOCODE = [
  {line:"procedure DFA(w = w₁w₂…wₙ):",     t:[]},
  {line:"  q ← q₀  // start state",         t:['init']},
  {line:"  for i ← 1 to n:",                t:['step']},
  {line:"    q ← δ(q, wᵢ)  // transition",  t:['step']},
  {line:"  if q ∈ F: accept",               t:['accept']},
  {line:"  else:    reject",                 t:['reject']},
];

function processInput(dfa, input) {
  const S=[], δ=dfa.δ, accepting=dfa.accepting;
  let state=dfa.start;
  S.push({state,pos:-1,char:null,type:'init',from:null,desc:`q ← ${dfa.start} (start state)`});
  for(let i=0;i<input.length;i++){
    const ch=input[i];
    if(!dfa.δ[state]?.[ch]){
      S.push({state,pos:i,char:ch,type:'reject',from:state,desc:`δ(${state},'${ch}') undefined → stuck → reject`});
      return S;
    }
    const next=dfa.δ[state][ch], prev=state;
    state=next;
    const last=i===input.length-1;
    S.push({state,pos:i,char:ch,from:prev,
      type:last?(accepting.includes(state)?'accept':'reject'):'step',
      desc:`δ(${prev}, '${ch}') = ${state}`,
    });
  }
  if(S.length===1){// empty string
    const acc=accepting.includes(state);
    S.push({state,pos:0,char:'ε',from:state,type:acc?'accept':'reject',desc:`Empty string: state ${state} ${acc?'∈ F → accept':'∉ F → reject'}`});
  }
  return S;
}

export default function App(){
  const [dfaIdx, setDfaIdx] = useState(0);
  const [input,  setInput]  = useState("abab");
  const [steps,  setSteps]  = useState([]);
  const [idx,    setIdx]    = useState(0);
  const [playing,setPlay]   = useState(false);
  const [speed,  setSpeed]  = useState(1);
  const timerRef=useRef(null), speedRef=useRef(speed);
  useEffect(()=>{speedRef.current=speed;},[speed]);

  const dfa=DFAS[dfaIdx];

  useEffect(()=>{
    const s=processInput(dfa,input);
    setSteps(s);setIdx(0);setPlay(false);
  },[dfaIdx,input]);

  useEffect(()=>{
    clearInterval(timerRef.current);
    if(playing) timerRef.current=setInterval(()=>{
      setIdx(i=>{if(i>=steps.length-1){setPlay(false);return steps.length-1;}return i+1;});
    },Math.max(350,1200/speedRef.current));
    return()=>clearInterval(timerRef.current);
  },[playing,steps,speed]);

  const cur=steps[idx]||{state:dfa.start,pos:-1,char:null,type:'init',from:null,desc:'Click ▶ to start'};
  const done=cur.type==='accept'||cur.type==='reject';
  const arrowActive=(from,to,sym)=>cur.from===from&&cur.state===to&&cur.char===sym;

  return(
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>
      {/* Header */}
      <div style={{padding:"14px 22px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:900,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
          <div>
            <h1 style={{fontSize:19,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Finite Automaton (DFA)</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>Regular languages · step-by-step simulation</p>
          </div>
          <div style={{display:"flex",background:"#f1f5f9",borderRadius:10,padding:3,gap:2}}>
            {DFAS.map((d,i)=>(
              <button key={d.id} onClick={()=>setDfaIdx(i)}
                style={{padding:"5px 14px",borderRadius:8,border:"none",fontSize:11,fontWeight:700,
                  background:dfaIdx===i?"#fff":"transparent",color:dfaIdx===i?"#2563eb":"#64748b",
                  boxShadow:dfaIdx===i?"0 1px 4px rgba(0,0,0,0.1)":"none",cursor:"pointer",transition:"all 0.2s"}}>
                {d.title}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",overflow:"hidden",maxWidth:900,margin:"0 auto",width:"100%",padding:"8px 18px 12px",boxSizing:"border-box",gap:14}}>
        {/* Left: automaton + tape */}
        <div style={{flex:1,display:"flex",flexDirection:"column",gap:10,minWidth:0}}>
          {/* DFA Graph */}
          <div style={{background:"#fafafa",border:"1px solid #f1f5f9",borderRadius:12,overflow:"hidden",flexShrink:0}}>
            <svg viewBox="0 0 590 230" width="100%" style={{display:"block",maxHeight:195}}>
              <defs>
                <marker id="arr" markerWidth="8" markerHeight="7" refX="7" refY="3.5" orient="auto">
                  <polygon points="0 0, 8 3.5, 0 7" fill="#94a3b8"/>
                </marker>
                <marker id="arrActive" markerWidth="8" markerHeight="7" refX="7" refY="3.5" orient="auto">
                  <polygon points="0 0, 8 3.5, 0 7" fill="#2563eb"/>
                </marker>
                <marker id="arrAccept" markerWidth="8" markerHeight="7" refX="7" refY="3.5" orient="auto">
                  <polygon points="0 0, 8 3.5, 0 7" fill="#059669"/>
                </marker>
                <marker id="arrReject" markerWidth="8" markerHeight="7" refX="7" refY="3.5" orient="auto">
                  <polygon points="0 0, 8 3.5, 0 7" fill="#dc2626"/>
                </marker>
              </defs>

              {/* Arrows */}
              {dfa.arrows.map((arr,i)=>{
                const key=dfa.arrowKey(arr,i);
                const [f,t,s]=key?key.split('-'):[];
                const active=key&&arrowActive(f,t,s);
                const isAccept=active&&cur.type==='accept', isReject=active&&cur.type==='reject';
                const color=isAccept?"#059669":isReject?"#dc2626":active?"#2563eb":"#cbd5e1";
                const marker=isAccept?"arrAccept":isReject?"arrReject":active?"arrActive":"arr";
                return(
                  <g key={i}>
                    <path d={arr.path} fill="none" stroke={color} strokeWidth={active?2.5:1.5}
                      markerEnd={arr.type!=="start"&&arr.type!=="loop"?`url(#${marker})`:""}
                      markerMid={arr.type==="loop"?`url(#${marker})`:""}
                      style={{transition:"stroke 0.2s"}}/>
                    {arr.type==="loop"&&<polygon points={`${arr.lx-4},${arr.ly+14} ${arr.lx+4},${arr.ly+14} ${arr.lx},${arr.ly+20}`} fill={color}/>}
                    {arr.label&&(
                      <g>
                        <rect x={arr.lx-7} y={arr.ly-9} width={14} height={14} rx={3} fill={active?color+"22":"#fff"} stroke={color} strokeWidth={0.8}/>
                        <text x={arr.lx} y={arr.ly+2} textAnchor="middle" fontSize={10} fontWeight={700}
                          fill={color} fontFamily="monospace">{arr.label}</text>
                      </g>
                    )}
                  </g>
                );
              })}

              {/* States */}
              {Object.entries(dfa.states).map(([id,s])=>{
                const isCur=cur.state===id;
                const isDone=done&&isCur;
                const fill=isDone&&cur.type==='accept'?"#dcfce7":isDone&&cur.type==='reject'?"#fef2f2":isCur?"#eff6ff":"#fff";
                const stroke=isDone&&cur.type==='accept'?"#059669":isDone&&cur.type==='reject'?"#dc2626":isCur?"#2563eb":"#e2e8f0";
                const sw=isCur?2.5:1.5;
                return(
                  <g key={id}>
                    <circle cx={s.x} cy={s.y} r={28} fill={fill} stroke={stroke} strokeWidth={sw} style={{transition:"all 0.25s"}}/>
                    {s.accept&&<circle cx={s.x} cy={s.y} r={22} fill="none" stroke={stroke} strokeWidth={1} style={{transition:"stroke 0.25s"}}/>}
                    <text x={s.x} y={s.y+5} textAnchor="middle" fontSize={13} fontWeight={700}
                      fill={isCur?(isDone&&cur.type==='accept'?"#059669":isDone?"#dc2626":"#2563eb"):"#475569"}
                      fontFamily="system-ui,sans-serif" style={{transition:"fill 0.25s"}}>{id}</text>
                    {s.accept&&(
                      <text x={s.x} y={s.y+40} textAnchor="middle" fontSize={8} fill="#059669" fontFamily="system-ui,sans-serif">accept</text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Input tape */}
          <div style={{background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,padding:"10px 14px"}}>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:8}}>Input tape</div>
            <div style={{display:"flex",gap:3,flexWrap:"wrap",marginBottom:8}}>
              {(input||"ε").split("").map((ch,i)=>{
                const processed=i<=cur.pos;
                const current=i===cur.pos;
                return(
                  <div key={i} style={{
                    width:30,height:30,border:`2px solid ${current?"#2563eb":processed?"#bfdbfe":"#e2e8f0"}`,
                    borderRadius:6,display:"flex",alignItems:"center",justifyContent:"center",
                    background:current?"#eff6ff":processed?"#f8faff":"#fff",
                    fontSize:14,fontWeight:700,fontFamily:"monospace",
                    color:current?"#2563eb":processed?"#94a3b8":"#1e293b",
                    transition:"all 0.2s",
                  }}>{ch}</div>
                );
              })}
              {!input&&<div style={{fontSize:12,color:"#94a3b8",fontStyle:"italic",padding:"4px 8px"}}>ε (empty string)</div>}
              {/* Acceptance indicator */}
              {done&&(
                <div style={{marginLeft:8,padding:"4px 12px",borderRadius:8,fontSize:12,fontWeight:700,
                  background:cur.type==='accept'?"#dcfce7":"#fef2f2",
                  color:cur.type==='accept'?"#059669":"#dc2626"}}>
                  {cur.type==='accept'?"✓ ACCEPTED":"✗ REJECTED"}
                </div>
              )}
            </div>
            <div style={{fontSize:11,color:"#475569",fontStyle:"italic"}}>{cur.desc}</div>
          </div>

          {/* Example strings */}
          <div>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:6}}>
              Test strings — click to load:
            </div>
            <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
              {dfa.examples.map(ex=>(
                <button key={ex} onClick={()=>setInput(ex)}
                  style={{padding:"4px 11px",borderRadius:8,border:`1.5px solid ${input===ex?"#2563eb":"#e2e8f0"}`,
                    background:input===ex?"#eff6ff":"#fff",color:input===ex?"#2563eb":"#475569",
                    fontSize:12,fontWeight:600,fontFamily:"monospace",cursor:"pointer"}}>
                  {ex===''?'ε':ex}
                </button>
              ))}
              <input value={input} onChange={e=>setInput(e.target.value.replace(/[^ab01]/g,""))}
                placeholder="type own…"
                style={{padding:"4px 10px",borderRadius:8,border:"1.5px solid #e2e8f0",fontSize:12,
                  fontFamily:"monospace",width:100,outline:"none"}}/>
            </div>
          </div>

          {/* Controls */}
          <div style={{display:"flex",alignItems:"center",gap:8,background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,padding:"8px 13px"}}>
            <button onClick={()=>{setIdx(0);setPlay(false);}} style={{padding:"5px 10px",border:"1px solid #e2e8f0",borderRadius:7,background:"#fff",color:"#64748b",fontSize:12,cursor:"pointer"}}>⏮</button>
            <button onClick={()=>setIdx(i=>Math.max(0,i-1))} style={{padding:"5px 10px",border:"1px solid #e2e8f0",borderRadius:7,background:"#fff",color:"#64748b",fontSize:14,cursor:"pointer"}}>‹</button>
            <button onClick={()=>{if(idx<steps.length-1)setPlay(p=>!p);}}
              style={{width:32,height:32,borderRadius:8,border:"none",fontSize:14,cursor:"pointer",
                background:playing?"#64748b":"#2563eb",color:"#fff",display:"flex",alignItems:"center",justifyContent:"center"}}>
              {playing?"⏸":"▶"}
            </button>
            <button onClick={()=>setIdx(i=>Math.min(steps.length-1,i+1))} style={{padding:"5px 10px",border:"1px solid #e2e8f0",borderRadius:7,background:"#fff",color:"#64748b",fontSize:14,cursor:"pointer"}}>›</button>
            <div style={{flex:1,display:"flex",alignItems:"center",gap:7}}>
              <span style={{fontSize:9,color:"#94a3b8",fontWeight:700,letterSpacing:"0.08em"}}>SPEED</span>
              <input type="range" min={0.5} max={4} step={0.5} value={speed} onChange={e=>setSpeed(+e.target.value)}
                style={{flex:1,accentColor:"#2563eb",cursor:"pointer"}}/>
              <span style={{fontSize:11,fontWeight:800,color:"#2563eb",minWidth:20}}>{speed}×</span>
            </div>
            <span style={{fontSize:10,color:"#94a3b8"}}>Step {idx}/{steps.length-1}</span>
          </div>
        </div>

        {/* Right: pseudocode + transition table */}
        <div style={{width:210,display:"flex",flexDirection:"column",gap:9,flexShrink:0}}>
          <div style={{background:"#eff6ff",border:"1.5px solid #bfdbfe",borderRadius:10,padding:"10px 12px"}}>
            <div style={{fontSize:11,fontWeight:800,color:"#2563eb",marginBottom:4}}>{dfa.desc}</div>
            <p style={{fontSize:11,lineHeight:1.6,color:"#334155",margin:0}}>{dfa.info}</p>
          </div>

          {/* Pseudocode */}
          <div>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:5}}>Algorithm</div>
            <div style={{background:"#f8fafc",borderRadius:10,padding:"7px",border:"1px solid #f1f5f9"}}>
              {PSEUDOCODE.map((l,i)=>{
                const on=l.t.includes(cur.type);
                return(
                  <div key={i} style={{display:"flex",gap:5,padding:"2px 5px",borderRadius:4,margin:"1px 0",
                    background:on?"#2563eb1a":"transparent",border:`1px solid ${on?"#2563eb55":"transparent"}`,transition:"all 0.15s"}}>
                    <span style={{fontSize:8.5,color:"#e2e8f0",minWidth:10,paddingTop:2,fontFamily:"monospace"}}>{i+1}</span>
                    <span style={{fontSize:10,fontFamily:"'Courier New',monospace",color:on?"#2563eb":"#94a3b8",fontWeight:on?700:400,whiteSpace:"pre"}}>{l.line}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Transition table */}
          <div>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:5}}>Transition table δ</div>
            <table style={{width:"100%",borderCollapse:"collapse",fontSize:11}}>
              <thead>
                <tr>
                  <th style={{padding:"4px 8px",background:"#f8fafc",borderRadius:"6px 0 0 0",border:"1px solid #f1f5f9",color:"#94a3b8",fontWeight:700}}>q</th>
                  {(dfa.alphabet||[]).map(sym=>(
                    <th key={sym} style={{padding:"4px 8px",background:"#f8fafc",border:"1px solid #f1f5f9",color:"#94a3b8",fontWeight:700,fontFamily:"monospace"}}>{sym}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {Object.entries(dfa.δ).map(([state,trans])=>{
                  const isActive=cur.state===state&&!done;
                  return(
                    <tr key={state} style={{background:isActive?"#eff6ff":"#fff",transition:"background 0.2s"}}>
                      <td style={{padding:"4px 8px",border:"1px solid #f1f5f9",fontWeight:700,color:isActive?"#2563eb":"#475569",fontFamily:"monospace"}}>
                        {dfa.states[state]?.accept?"(("+state+"))":state}
                      </td>
                      {(dfa.alphabet||[]).map(sym=>(
                        <td key={sym} style={{padding:"4px 8px",border:"1px solid #f1f5f9",textAlign:"center",
                          fontFamily:"monospace",color:isActive&&cur.char===sym?"#2563eb":"#64748b",
                          fontWeight:isActive&&cur.char===sym?700:400}}>
                          {trans[sym]||"—"}
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
