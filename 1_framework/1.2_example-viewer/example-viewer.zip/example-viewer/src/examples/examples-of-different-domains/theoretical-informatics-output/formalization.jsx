import { useState } from "react";

/* ─── Atomic propositions ────────────────────────────────────────────────── */
const ATOMS = [
  { sym:"p", def:"It rains",          color:"#2563eb" },
  { sym:"q", def:"The sun shines",    color:"#d97706" },
  { sym:"r", def:"The streets are wet",color:"#059669" },
  { sym:"w", def:"It is warm",        color:"#7c3aed" },
];

/* ─── Connectives reference ──────────────────────────────────────────────── */
const CONN = [
  { sym:"¬",  name:"negation",     en:'"not …"  /  "it is not the case that …"',          color:"#dc2626" },
  { sym:"∧",  name:"conjunction",  en:'"… and …"  /  "… but …"  /  "both … and …"',       color:"#2563eb" },
  { sym:"∨",  name:"disjunction",  en:'"… or …"  /  "either … or …"  (inclusive)',         color:"#059669" },
  { sym:"→",  name:"implication",  en:'"if … then …"  /  "… only if …"  /  "… implies …"',color:"#7c3aed" },
  { sym:"↔",  name:"biconditional",en:'"… if and only if …"  /  "… exactly when …"',       color:"#0891b2" },
];

/* ─── Items: natural language ↔ formula ─────────────────────────────────── */
const ITEMS = [
  { id:"f1",  nl:"It rains and the sun shines",
               fm:"p ∧ q",       hint:'"and" → ∧',
               why:"'and' is conjunction ∧. Both p and q must be true." },
  { id:"f2",  nl:"It rains or the sun shines (or both)",
               fm:"p ∨ q",       hint:'"or" → ∨',
               why:"Inclusive disjunction ∨. True if at least one of p, q holds." },
  { id:"f3",  nl:"It does not rain",
               fm:"¬p",          hint:'"not" → ¬',
               why:"Negation ¬p is true exactly when p is false." },
  { id:"f4",  nl:"If it rains, then the streets are wet",
               fm:"p → r",       hint:'"if … then" → →',
               why:"Implication p → r. False only when p is true and r is false." },
  { id:"f5",  nl:"It rains if and only if the streets are wet",
               fm:"p ↔ r",       hint:'"if and only if" → ↔',
               why:"Biconditional ↔: true when p and r share the same truth value." },
  { id:"f6",  nl:"It rains but the streets are not wet",
               fm:"p ∧ ¬r",      hint:'"but" → ∧  and  "not" → ¬',
               why:"'but' = ∧, 'not wet' = ¬r. Combine: p ∧ ¬r." },
  { id:"f7",  nl:"Neither does it rain nor does the sun shine",
               fm:"¬p ∧ ¬q",     hint:'"neither … nor" → ¬… ∧ ¬…',
               why:"'Neither A nor B' = ¬A ∧ ¬B. Equivalent to ¬(p ∨ q) by De Morgan." },
  { id:"f8",  nl:"If it rains or the sun shines, then it is warm",
               fm:"(p ∨ q) → w", hint:'parentheses bind ∨ before →',
               why:"The antecedent is (p ∨ q). Parentheses group the disjunction before →." },
  { id:"f9",  nl:"Not both: it rains and the sun shines",
               fm:"¬(p ∧ q)",    hint:'"not both" → ¬(∧)',
               why:"Negation scopes over the whole conjunction. By De Morgan: ¬p ∨ ¬q." },
  { id:"f10", nl:"The sun shines only if it is warm",
               fm:"q → w",       hint:'"only if" marks the consequent  →',
               why:"'A only if B' means A → B. 'Only if' points to the right side of →." },
];

/* ─── Formula evaluator ──────────────────────────────────────────────────── */
function matchParen(s,i){let d=0;for(;i<s.length;i++){if(s[i]==='(')d++;if(s[i]===')')d--;if(d===0)return i;}return -1;}
function parseProp(f){
  f=f.replace(/\s/g,'');
  if(!f)return['F'];
  if('pqrw'.includes(f)&&f.length===1)return[f];
  if(f[0]==='('&&matchParen(f,0)===f.length-1)return parseProp(f.slice(1,-1));
  // ↔
  for(let i=0,d=0;i<f.length;i++){if(f[i]==='(')d++;else if(f[i]===')')d--;else if(d===0&&f[i]==='↔')return['↔',parseProp(f.slice(0,i)),parseProp(f.slice(i+1))];}
  // →
  for(let i=f.length-1,d=0;i>=0;i--){if(f[i]===')')d++;else if(f[i]==='(')d--;else if(d===0&&f[i]==='→')return['→',parseProp(f.slice(0,i)),parseProp(f.slice(i+1))];}
  // ∨
  for(let i=f.length-1,d=0;i>=0;i--){if(f[i]===')')d++;else if(f[i]==='(')d--;else if(d===0&&f[i]==='∨')return['∨',parseProp(f.slice(0,i)),parseProp(f.slice(i+1))];}
  // ∧
  for(let i=f.length-1,d=0;i>=0;i--){if(f[i]===')')d++;else if(f[i]==='(')d--;else if(d===0&&f[i]==='∧')return['∧',parseProp(f.slice(0,i)),parseProp(f.slice(i+1))];}
  if(f[0]==='¬')return['¬',parseProp(f.slice(1))];
  return[f];
}
function evalAST(a,v){
  if(!a)return false;
  if(a[0]==='¬')return!evalAST(a[1],v);
  if(a[0]==='∧')return evalAST(a[1],v)&&evalAST(a[2],v);
  if(a[0]==='∨')return evalAST(a[1],v)||evalAST(a[2],v);
  if(a[0]==='→')return!evalAST(a[1],v)||evalAST(a[2],v);
  if(a[0]==='↔')return evalAST(a[1],v)===evalAST(a[2],v);
  return v[a[0]]??false;
}
function truthTable(formula){
  const vars=[...new Set(formula.replace(/[^pqrw]/g,'').split(''))].sort();
  const ast=parseProp(formula.replace(/\s/g,''));
  const n=vars.length;
  return{vars,rows:Array.from({length:Math.pow(2,n)},(_,i)=>{
    const vals={};vars.forEach((v,j)=>{vals[v]=Boolean((i>>(n-1-j))&1);});
    return{vals,result:evalAST(ast,vals)};
  })};
}

/* ─── Helpers ────────────────────────────────────────────────────────────── */
function shuffle(a){const b=[...a];for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]];}return b;}

function colorizeFormula(fm){
  // Color each connective symbol differently
  return fm.split('').map((ch,i)=>{
    const c=CONN.find(c=>c.sym===ch);
    return c?<span key={i} style={{color:c.color,fontWeight:800}}>{ch}</span>:<span key={i}>{ch}</span>;
  });
}

function TruthTable({formula}){
  const {vars,rows}=truthTable(formula);
  const tcount=rows.filter(r=>r.result).length;
  return(
    <div>
      <table style={{borderCollapse:"collapse",width:"100%",marginTop:6}}>
        <thead>
          <tr>
            {vars.map(v=>{
              const a=ATOMS.find(a=>a.sym===v);
              return <th key={v} style={{padding:"3px 7px",background:"#f1f5f9",border:"1px solid #e2e8f0",fontSize:10,fontFamily:"monospace",fontWeight:700,color:a?.color||"#475569"}}>{v}</th>;
            })}
            <th style={{padding:"3px 7px",background:"#f1f5f9",border:"1px solid #e2e8f0",fontSize:10,fontFamily:"monospace",color:"#0f172a",fontWeight:700}}>
              {formula}
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row,i)=>(
            <tr key={i}>
              {vars.map(v=>(
                <td key={v} style={{padding:"3px 7px",border:"1px solid #f1f5f9",textAlign:"center",
                  fontSize:10,fontFamily:"monospace",color:row.vals[v]?"#1e293b":"#94a3b8"}}>
                  {row.vals[v]?"T":"F"}
                </td>
              ))}
              <td style={{padding:"3px 7px",border:"1px solid #f1f5f9",textAlign:"center",
                fontSize:11,fontWeight:800,fontFamily:"monospace",
                background:row.result?"#dcfce7":"#fef2f2",
                color:row.result?"#059669":"#dc2626"}}>
                {row.result?"T":"F"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div style={{fontSize:9,color:"#94a3b8",marginTop:4}}>
        True in {tcount}/{rows.length} assignments
        {tcount===rows.length?" (tautology)":tcount===0?" (contradiction)":""}
      </div>
    </div>
  );
}

/* ─── Main ───────────────────────────────────────────────────────────────── */
export default function App(){
  const [pool,     setPool]    = useState(()=>shuffle(ITEMS));
  const [placed,   setPlaced]  = useState({});   // {formulaId: itemId}
  const [feedback, setFeedback]= useState({});   // {itemId: "correct"|"wrong"}
  const [dragId,   setDragId]  = useState(null);
  const [expanded, setExpanded]= useState({});   // {formulaId: bool}
  const [tooltip,  setTooltip] = useState(null);

  const score=Object.keys(placed).length;

  const onDrop=(fmId)=>{
    if(!dragId)return;
    setDragId(null);
    const item=ITEMS.find(i=>i.id===dragId);
    if(!item)return;
    const correct=item.id===fmId;
    setFeedback(f=>({...f,[dragId]:correct?"correct":"wrong"}));
    if(correct){
      setPool(p=>p.filter(i=>i.id!==dragId));
      setPlaced(p=>({...p,[fmId]:dragId}));
      setExpanded(e=>({...e,[fmId]:false})); // collapsed by default, click to expand
    } else {
      setTimeout(()=>setFeedback(f=>{const n={...f};delete n[dragId];return n;}),1200);
    }
  };

  const reset=()=>{setPool(shuffle(ITEMS));setPlaced({});setFeedback({});setDragId(null);setExpanded({});};

  return(
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"13px 20px 9px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:1040,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
          <div>
            <h1 style={{fontSize:19,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Formalizing Propositions</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>
              Propositional logic · drag each statement onto its formula
            </p>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{fontSize:13,fontWeight:700,color:"#0f172a"}}>
              {score}<span style={{fontWeight:400,color:"#94a3b8"}}>/{ITEMS.length} matched</span>
            </div>
            <button onClick={reset} style={{padding:"5px 12px",border:"1px solid #e2e8f0",borderRadius:8,background:"#fff",color:"#64748b",fontSize:11,fontWeight:600,cursor:"pointer"}}>↺ Reset</button>
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",overflow:"hidden",maxWidth:1040,margin:"0 auto",width:"100%",
        padding:"8px 18px 12px",boxSizing:"border-box",gap:14}}>

        {/* Left sidebar */}
        <div style={{width:190,flexShrink:0,display:"flex",flexDirection:"column",gap:9,overflow:"auto"}}>
          {/* Atomic propositions */}
          <div style={{background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,padding:"10px 12px"}}>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:8}}>Atoms</div>
            {ATOMS.map(a=>(
              <div key={a.sym} style={{display:"flex",gap:8,alignItems:"flex-start",marginBottom:5}}>
                <span style={{fontSize:15,fontWeight:800,fontFamily:"monospace",color:a.color,minWidth:14}}>{a.sym}</span>
                <span style={{fontSize:11,color:"#475569",lineHeight:1.4}}>{a.def}</span>
              </div>
            ))}
          </div>
          {/* Connectives */}
          <div style={{background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,padding:"10px 12px",flex:1}}>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:8}}>Connectives</div>
            {CONN.map(c=>(
              <div key={c.sym} style={{marginBottom:9}}>
                <div style={{display:"flex",gap:7,alignItems:"center",marginBottom:2}}>
                  <span style={{fontSize:17,fontWeight:800,fontFamily:"monospace",color:c.color}}>{c.sym}</span>
                  <span style={{fontSize:11,fontWeight:700,color:c.color}}>{c.name}</span>
                </div>
                <div style={{fontSize:10,color:"#64748b",lineHeight:1.45,paddingLeft:4,fontStyle:"italic"}}>{c.en}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Main area */}
        <div style={{flex:1,display:"flex",flexDirection:"column",gap:10,minWidth:0,overflow:"hidden"}}>

          {/* Formula grid */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8,overflow:"auto",flex:1,minHeight:0}}>
            {ITEMS.map(item=>{
              const placedId=placed[item.id];
              const isPlaced=!!placedId;
              const isExpanded=expanded[item.id];
              const stmt=ITEMS.find(i=>i.id===placedId);
              return(
                <div key={item.id}
                  onDragOver={e=>e.preventDefault()}
                  onDrop={()=>onDrop(item.id)}
                  onClick={()=>isPlaced&&setExpanded(e=>({...e,[item.id]:!e[item.id]}))}
                  style={{
                    border:`2px solid ${isPlaced?"#a7f3d0":"#f1f5f9"}`,
                    borderRadius:12,padding:"10px 12px",
                    background:isPlaced?"#f0fdf4":"#fafafa",
                    transition:"all 0.2s",
                    cursor:isPlaced?"pointer":"default",
                    display:"flex",flexDirection:"column",gap:4,
                  }}>
                  {/* Formula */}
                  <div style={{fontSize:18,fontWeight:800,fontFamily:"'Courier New',monospace",letterSpacing:"0.04em",color:"#0f172a"}}>
                    {colorizeFormula(item.fm)}
                  </div>
                  <div style={{fontSize:9,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase"}}>
                    {isPlaced?"matched · click to see truth table":"drop statement here"}
                  </div>
                  {/* Dropped statement */}
                  {isPlaced&&(
                    <div style={{marginTop:2,padding:"6px 9px",background:"#fff",borderRadius:8,border:"1px solid #a7f3d0"}}>
                      <div style={{fontSize:11,color:"#059669",fontWeight:600,lineHeight:1.4}}>{stmt?.nl}</div>
                      <div style={{fontSize:10,color:"#94a3b8",marginTop:2,fontStyle:"italic"}}>{stmt?.hint}</div>
                    </div>
                  )}
                  {/* Expanded: explanation + truth table */}
                  {isPlaced&&isExpanded&&(
                    <div style={{marginTop:4,paddingTop:8,borderTop:"1px solid #d1fae5"}}>
                      <p style={{fontSize:11,color:"#334155",lineHeight:1.6,margin:"0 0 6px",fontStyle:"italic"}}>{stmt?.why}</p>
                      <TruthTable formula={item.fm}/>
                    </div>
                  )}
                  {/* Empty hint */}
                  {!isPlaced&&(
                    <div style={{color:"#e2e8f0",fontSize:10,fontStyle:"italic",marginTop:2}}>← drag here</div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Statement pool */}
          <div style={{flexShrink:0}}>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:7}}>
              Natural language statements — hover for a hint, drag to the matching formula:
            </div>
            {score===ITEMS.length?(
              <div style={{fontSize:13,fontWeight:700,color:"#059669",padding:"8px 0"}}>
                🎉 All {ITEMS.length} statements correctly formalized! Click any matched formula to see its truth table.
              </div>
            ):(
              <div style={{display:"flex",flexWrap:"wrap",gap:7}}>
                {pool.map(item=>{
                  const wrong=feedback[item.id]==="wrong";
                  const isDrag=dragId===item.id;
                  return(
                    <div key={item.id}
                      draggable
                      onDragStart={()=>setDragId(item.id)}
                      onDragEnd={()=>setDragId(null)}
                      onMouseEnter={()=>setTooltip(item.id)}
                      onMouseLeave={()=>setTooltip(null)}
                      style={{
                        background:wrong?"#fef2f2":isDrag?"#f0f9ff":"#f8fafc",
                        border:`1.5px solid ${wrong?"#fecaca":isDrag?"#bae6fd":"#e2e8f0"}`,
                        borderRadius:9,padding:"7px 12px",cursor:"grab",
                        transition:"all 0.12s",userSelect:"none",position:"relative",
                        boxShadow:wrong?"0 0 0 2px #fca5a5":isDrag?"0 4px 14px rgba(14,165,233,0.15)":"none",
                        opacity:isDrag?0.6:1,
                      }}>
                      <div style={{fontSize:12,fontWeight:600,color:wrong?"#dc2626":"#1e293b",lineHeight:1.4}}>{item.nl}</div>
                      {wrong&&<div style={{fontSize:9,color:"#dc2626",marginTop:1}}>✗ wrong formula — try again</div>}
                      {tooltip===item.id&&!wrong&&(
                        <div style={{position:"absolute",bottom:"calc(100% + 6px)",left:0,
                          background:"#0f172a",color:"#fff",borderRadius:8,padding:"8px 11px",
                          minWidth:200,fontSize:11,lineHeight:1.6,zIndex:60,pointerEvents:"none",
                          boxShadow:"0 8px 24px rgba(0,0,0,0.2)"}}>
                          <div style={{fontWeight:700,marginBottom:2,color:"#94a3b8",fontSize:9,textTransform:"uppercase",letterSpacing:"0.06em"}}>Key connective</div>
                          {item.hint}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
