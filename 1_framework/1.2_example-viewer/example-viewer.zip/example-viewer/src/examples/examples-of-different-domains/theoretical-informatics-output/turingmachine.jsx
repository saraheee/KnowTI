import { useState, useEffect, useRef, useCallback } from "react";

/* ─── TM for aⁿbⁿ ─────────────────────────────────────────────────────── */
// Language: {aⁿbⁿ | n ≥ 0}
const TRANSITIONS = {
  // (state,symbol) → [write, direction, nextState]
  'q0,a': ['X','R','q1'],  // mark 'a', go find matching 'b'
  'q0,Y': ['Y','R','q3'],  // all a's matched, check remaining
  'q0,B': ['B','R','qa'],  // empty string → accept (n=0)
  'q1,a': ['a','R','q1'],  // skip over unmarked a's
  'q1,Y': ['Y','R','q1'],  // skip over marked Y's
  'q1,b': ['Y','L','q2'],  // mark 'b', go back left
  'q1,B': ['B','R','qr'],  // no b found → reject
  'q2,a': ['a','L','q2'],  // move left past a's
  'q2,Y': ['Y','L','q2'],  // move left past Y's
  'q2,X': ['X','R','q0'],  // found leftmost X, step right to next round
  'q3,Y': ['Y','R','q3'],  // skip over Y's (verification pass)
  'q3,B': ['B','R','qa'],  // all b's matched → accept
  'q3,b': ['b','R','qr'],  // unmatched b → reject
};

const STATE_DESCS = {
  q0:"Scan right for next unmarked 'a'",
  q1:"Found 'a' (marked X) — scan right for matching 'b'",
  q2:"Found 'b' (marked Y) — scan left for next X",
  q3:"Verification: ensure no unmatched b's remain",
  qa:"ACCEPT — all a's and b's matched",
  qr:"REJECT — unequal counts or wrong structure",
};

function tmRun(input) {
  const tape=[...(input||[]),'B','B','B'];
  let head=0, state='q0', steps=[], iter=0;
  steps.push({tape:[...tape],head,state,trans:null,desc:`Initial: input "${input||'ε'}"`,type:'init'});
  while(state!=='qa'&&state!=='qr'&&iter<200){
    iter++;
    const sym=tape[head]||'B';
    const key=`${state},${sym}`;
    const tr=TRANSITIONS[key];
    if(!tr){state='qr';steps.push({tape:[...tape],head,state,trans:null,desc:`No transition for (${state},'${sym}') → reject`,type:'reject'});break;}
    const [w,dir,ns]=tr;
    const from=state;
    tape[head]=w;
    head+=dir==='R'?1:-1;
    if(head<0){tape.unshift('B');head=0;}
    while(head>=tape.length)tape.push('B');
    state=ns;
    steps.push({tape:[...tape],head,state,trans:{from,sym,w,dir,ns},
      desc:`(${from},'${sym}') → write '${w}', move ${dir}, → ${ns}`,
      type:state==='qa'?'accept':state==='qr'?'reject':'step'});
  }
  return steps;
}

const EXAMPLES=[
  {label:"ε",  val:"",  expect:true},
  {label:"ab", val:"ab",expect:true},
  {label:"aabb",val:"aabb",expect:true},
  {label:"aaabbb",val:"aaabbb",expect:true},
  {label:"aab", val:"aab", expect:false},
  {label:"abb", val:"abb", expect:false},
  {label:"ba",  val:"ba",  expect:false},
  {label:"aabbb",val:"aabbb",expect:false},
];

const PSEUDO=[
  {line:"TM M = (Q, Σ, Γ, δ, q₀, qa, qr):",  t:[]},
  {line:"  Σ={a,b}, Γ={a,b,X,Y,B}",            t:['init']},
  {line:"q0: scan for 'a' → write X, → q1",    t:['q0']},
  {line:"q1: scan right for 'b' → write Y, ← q2",t:['q1']},
  {line:"q2: scan left to X → step right, → q0",t:['q2']},
  {line:"q0,Y: no more a's → verify → q3",      t:['q3_init']},
  {line:"q3: scan Y's, if B: accept",            t:['q3']},
  {line:"else: reject (unmatched b's)",           t:['qr']},
];

export default function App(){
  const [input,  setInput]  = useState("aabb");
  const [steps,  setSteps]  = useState([]);
  const [idx,    setIdx]    = useState(0);
  const [playing,setPlay]   = useState(false);
  const [speed,  setSpeed]  = useState(1);
  const timerRef=useRef(null), speedRef=useRef(speed);
  useEffect(()=>{speedRef.current=speed;},[speed]);

  useEffect(()=>{
    const s=tmRun(input.trim().toLowerCase());
    setSteps(s);setIdx(0);setPlay(false);
  },[input]);

  useEffect(()=>{
    clearInterval(timerRef.current);
    if(playing) timerRef.current=setInterval(()=>{
      setIdx(i=>{if(i>=steps.length-1){setPlay(false);return steps.length-1;}return i+1;});
    },Math.max(320,1300/speedRef.current));
    return()=>clearInterval(timerRef.current);
  },[playing,steps,speed]);

  const cur=steps[idx]||{tape:['B'],head:0,state:'q0',trans:null,desc:'',type:'init'};
  const tape=cur.tape||['B'];
  // Show window around head
  const WIN=8, start=Math.max(0,cur.head-3), end=Math.min(tape.length-1,cur.head+WIN);
  const shown=tape.slice(start,end+1);
  const SYMBOL_COLOR={a:"#2563eb",b:"#7c3aed",X:"#059669",Y:"#d97706",B:"#e2e8f0"};

  const pseudoT=cur.state==='q0'?'q0':cur.state==='q1'?'q1':cur.state==='q2'?'q2':
    (cur.state==='q3'&&cur.trans?.sym==='Y')?'q3':(cur.state==='q3')?'q3_init':
    cur.state==='qa'?'q3':cur.state==='qr'?'qr':'';

  const done=cur.type==='accept'||cur.type==='reject';

  return(
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>
      <div style={{padding:"14px 22px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:900,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
          <div>
            <h1 style={{fontSize:19,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Turing Machine</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>
              L = &#123;aⁿbⁿ | n ≥ 0&#125; · a non-regular context-free language
            </p>
          </div>
          <div style={{fontSize:11,color:"#64748b",fontStyle:"italic"}}>
            Why not DFA? aⁿbⁿ requires counting — DFAs have no memory.
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",overflow:"hidden",maxWidth:900,margin:"0 auto",width:"100%",padding:"8px 18px 12px",boxSizing:"border-box",gap:14}}>
        {/* Left: tape + controls */}
        <div style={{flex:1,display:"flex",flexDirection:"column",gap:10,minWidth:0}}>
          {/* State badge */}
          <div style={{display:"flex",alignItems:"center",gap:12,flexWrap:"wrap"}}>
            <div style={{
              padding:"8px 18px",borderRadius:10,fontSize:14,fontWeight:800,
              background:done&&cur.type==='accept'?"#dcfce7":done&&cur.type==='reject'?"#fef2f2":
                cur.state==='q1'?"#eff6ff":cur.state==='q2'?"#f5f3ff":cur.state==='q3'?"#fffbeb":"#f8fafc",
              color:done&&cur.type==='accept'?"#059669":done&&cur.type==='reject'?"#dc2626":
                cur.state==='q1'?"#2563eb":cur.state==='q2'?"#7c3aed":cur.state==='q3'?"#d97706":"#475569",
              border:`2px solid ${done&&cur.type==='accept'?"#a7f3d0":done&&cur.type==='reject'?"#fecaca":"#e2e8f0"}`,
              transition:"all 0.3s",
            }}>
              State: {cur.state}
            </div>
            <div style={{flex:1,fontSize:11,color:"#475569",fontStyle:"italic"}}>{STATE_DESCS[cur.state]||""}</div>
          </div>

          {/* Tape */}
          <div style={{background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:12,padding:"18px 14px",flexShrink:0}}>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:12}}>Tape</div>
            <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:3,overflowX:"auto"}}>
              {start>0&&<span style={{fontSize:10,color:"#e2e8f0"}}>…</span>}
              {shown.map((sym,i)=>{
                const absIdx=start+i;
                const isHead=absIdx===cur.head;
                const c=SYMBOL_COLOR[sym]||"#475569";
                return(
                  <div key={absIdx} style={{
                    width:38,height:48,border:`2.5px solid ${isHead?"#f97316":sym==='B'?"#f1f5f9":"#e2e8f0"}`,
                    borderRadius:8,display:"flex",alignItems:"center",justifyContent:"center",
                    background:isHead?"#fff7ed":sym==='B'?"#fafafa":"#fff",
                    flexShrink:0,position:"relative",
                    boxShadow:isHead?"0 0 0 3px #fed7aa":undefined,
                    transition:"all 0.25s",
                  }}>
                    <span style={{fontSize:sym==='B'?10:18,fontWeight:700,fontFamily:"monospace",color:sym==='B'?"#e2e8f0":c,transition:"color 0.2s"}}>
                      {sym==='B'?'□':sym}
                    </span>
                    {isHead&&(
                      <div style={{position:"absolute",bottom:-24,left:"50%",transform:"translateX(-50%)",
                        fontSize:8,fontWeight:800,color:"#f97316",whiteSpace:"nowrap"}}>
                        ▲ head
                      </div>
                    )}
                  </div>
                );
              })}
              <span style={{fontSize:10,color:"#e2e8f0"}}>…</span>
            </div>
          </div>

          {/* Transition info */}
          {cur.trans&&(
            <div style={{background:"#fffbeb",border:"1px solid #fde68a",borderRadius:10,padding:"10px 14px"}}>
              <div style={{fontSize:9,fontWeight:700,color:"#d97706",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:4}}>Applied transition</div>
              <div style={{fontFamily:"monospace",fontSize:13,color:"#1e293b",fontWeight:700}}>
                δ({cur.trans.from}, '{cur.trans.sym}') = (write '{cur.trans.w}', move {cur.trans.dir}, → {cur.trans.ns})
              </div>
            </div>
          )}
          {done&&(
            <div style={{background:cur.type==='accept'?"#dcfce7":"#fef2f2",border:`1.5px solid ${cur.type==='accept'?"#a7f3d0":"#fecaca"}`,borderRadius:10,padding:"12px 14px",textAlign:"center"}}>
              <div style={{fontSize:16,fontWeight:800,color:cur.type==='accept'?"#059669":"#dc2626"}}>
                {cur.type==='accept'?`✓  "${input||"ε"}" ∈ L (aⁿbⁿ accepted)`:`✗  "${input}" ∉ L (rejected)`}
              </div>
              <div style={{fontSize:11,color:cur.type==='accept'?"#065f46":"#991b1b",marginTop:4}}>
                {cur.type==='accept'?"Equal number of a's and b's confirmed.":"Unequal counts or wrong structure."}
              </div>
            </div>
          )}

          {/* Examples + input */}
          <div>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:6}}>Test strings</div>
            <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:8}}>
              {EXAMPLES.map(ex=>(
                <button key={ex.val} onClick={()=>setInput(ex.val)}
                  style={{padding:"4px 11px",borderRadius:8,
                    border:`1.5px solid ${input===ex.val?"#475569":"#e2e8f0"}`,
                    background:input===ex.val?"#0f172a":"#fff",
                    color:input===ex.val?"#fff":"#475569",
                    fontSize:12,fontWeight:600,fontFamily:"monospace",cursor:"pointer"}}>
                  {ex.label}
                  <span style={{fontSize:9,marginLeft:4,opacity:0.7}}>{ex.expect?"✓":"✗"}</span>
                </button>
              ))}
              <input value={input} onChange={e=>setInput(e.target.value.replace(/[^ab]/g,""))}
                placeholder="type aⁿbⁿ…"
                style={{padding:"4px 10px",borderRadius:8,border:"1.5px solid #e2e8f0",fontSize:12,fontFamily:"monospace",width:100,outline:"none"}}/>
            </div>
          </div>

          {/* Controls */}
          <div style={{display:"flex",alignItems:"center",gap:8,background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,padding:"8px 13px"}}>
            <button onClick={()=>{setIdx(0);setPlay(false);}} style={{padding:"5px 10px",border:"1px solid #e2e8f0",borderRadius:7,background:"#fff",color:"#64748b",fontSize:12,cursor:"pointer"}}>⏮</button>
            <button onClick={()=>setIdx(i=>Math.max(0,i-1))} style={{padding:"5px 10px",border:"1px solid #e2e8f0",borderRadius:7,background:"#fff",color:"#64748b",fontSize:14,cursor:"pointer"}}>‹</button>
            <button onClick={()=>{if(idx<steps.length-1)setPlay(p=>!p);}}
              style={{width:32,height:32,borderRadius:8,border:"none",fontSize:14,cursor:"pointer",
                background:playing?"#64748b":"#0f172a",color:"#fff",display:"flex",alignItems:"center",justifyContent:"center"}}>
              {playing?"⏸":"▶"}
            </button>
            <button onClick={()=>setIdx(i=>Math.min(steps.length-1,i+1))} style={{padding:"5px 10px",border:"1px solid #e2e8f0",borderRadius:7,background:"#fff",color:"#64748b",fontSize:14,cursor:"pointer"}}>›</button>
            <div style={{flex:1,display:"flex",alignItems:"center",gap:7}}>
              <span style={{fontSize:9,color:"#94a3b8",fontWeight:700,letterSpacing:"0.08em"}}>SPEED</span>
              <input type="range" min={0.5} max={4} step={0.5} value={speed} onChange={e=>setSpeed(+e.target.value)}
                style={{flex:1,accentColor:"#0f172a",cursor:"pointer"}}/>
              <span style={{fontSize:11,fontWeight:800,color:"#0f172a",minWidth:20}}>{speed}×</span>
            </div>
            <span style={{fontSize:10,color:"#94a3b8"}}>Step {idx}/{steps.length-1}</span>
          </div>
        </div>

        {/* Right panel */}
        <div style={{width:210,flexShrink:0,display:"flex",flexDirection:"column",gap:9}}>
          <div style={{background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,padding:"11px"}}>
            <div style={{fontSize:10,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:6}}>Tape alphabet Γ</div>
            {[["a","Input symbol","#2563eb"],["b","Input symbol","#7c3aed"],["X","Marked a","#059669"],["Y","Marked b","#d97706"],["□ B","Blank","#94a3b8"]].map(([s,d,c])=>(
              <div key={s} style={{display:"flex",alignItems:"center",gap:7,marginBottom:4}}>
                <span style={{fontSize:13,fontWeight:700,fontFamily:"monospace",color:c,minWidth:16}}>{s}</span>
                <span style={{fontSize:10,color:"#64748b"}}>{d}</span>
              </div>
            ))}
          </div>
          <div>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:5}}>High-level algorithm</div>
            <div style={{background:"#f8fafc",borderRadius:10,padding:"7px",border:"1px solid #f1f5f9"}}>
              {PSEUDO.map((l,i)=>{
                const on=l.t.includes(pseudoT);
                return(
                  <div key={i} style={{display:"flex",gap:5,padding:"2px 5px",borderRadius:4,margin:"1px 0",
                    background:on?"#0f172a1a":"transparent",border:`1px solid ${on?"#0f172a55":"transparent"}`,transition:"all 0.15s"}}>
                    <span style={{fontSize:8.5,color:"#e2e8f0",minWidth:10,paddingTop:2,fontFamily:"monospace"}}>{i+1}</span>
                    <span style={{fontSize:9.5,fontFamily:"'Courier New',monospace",color:on?"#0f172a":"#94a3b8",fontWeight:on?700:400,whiteSpace:"pre",lineHeight:1.5}}>{l.line}</span>
                  </div>
                );
              })}
            </div>
          </div>
          <div style={{background:"#f0fdf4",border:"1px solid #a7f3d0",borderRadius:10,padding:"10px 12px"}}>
            <div style={{fontSize:10,fontWeight:700,color:"#059669",marginBottom:5}}>Chomsky Hierarchy</div>
            {[["Type 3","Regular","DFA/NFA","aⁿ","✗"],["Type 2","Context-free","PDA","aⁿbⁿ","✓"],["Type 1","Context-sensitive","LBA",""],["Type 0","Recursively enum.","TM","aⁿbⁿcⁿ"]].map(([t,n,m,l],i)=>(
              <div key={t} style={{display:"flex",justifyContent:"space-between",padding:"3px 6px",borderRadius:4,
                background:i===1?"#dcfce7":"transparent",marginBottom:2}}>
                <span style={{fontSize:9,fontWeight:i===1?700:400,color:i===1?"#059669":"#64748b"}}>{t}: {n}</span>
                <span style={{fontSize:9,color:i===1?"#059669":"#94a3b8",fontFamily:"monospace"}}>{m}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
