import { useState } from "react";

/* ─── Grammar: S → aSb | ε  (language: aⁿbⁿ) ─────────────────────────── */
const GRAMMAR = {
  rules: { S: [["a","S","b"], []] },  // S → aSb | ε
  start: "S",
  terminals: new Set(["a","b"]),
};

const GOALS = [
  { label:"ε (n=0)",  target:[],                    desc:"S ⇒* ε   (one step: S → ε)" },
  { label:"ab (n=1)", target:["a","b"],              desc:"S ⇒* ab   (two steps)" },
  { label:"aabb",     target:["a","a","b","b"],      desc:"S ⇒* aabb (three steps)" },
  { label:"aaabbb",   target:["a","a","a","b","b","b"], desc:"S ⇒* aaabbb (four steps)" },
];

const PRODUCTIONS = [
  { label:"S → aSb", rule:["a","S","b"] },
  { label:"S → ε",   rule:[] },
];

const AXIOMS = [
  {line:"Context-Free Grammar G = (V, Σ, R, S):",t:[]},
  {line:"  V = {S}  (non-terminals)",             t:['init']},
  {line:"  Σ = {a, b}  (terminals)",              t:['init']},
  {line:"  R: S → aSb | ε  (production rules)",   t:['init']},
  {line:"  S = start symbol",                      t:['init']},
  {line:"Derivation: α ⇒ β if S in α,",           t:['derive']},
  {line:"  replace S with right-hand side",         t:['derive']},
  {line:"w ∈ L(G) iff S ⇒* w  (⇒* = 0+ steps)",  t:['check']},
];

export default function App(){
  const [goalIdx, setGoalIdx] = useState(1);
  const [form,    setForm]    = useState(["S"]);   // current sentential form
  const [history, setHistory] = useState([["S"]]); // derivation steps
  const [popup,   setPopup]   = useState(false);   // show production chooser
  const [done,    setDone]    = useState(false);
  const [phase,   setPhase]   = useState('init');

  const goal = GOALS[goalIdx];
  const target = goal.target;

  const reset = (gi=goalIdx) => {
    setForm(["S"]); setHistory([["S"]]); setPopup(false); setDone(false); setPhase('init');
    setGoalIdx(gi);
  };

  const apply = (rule) => {
    setPopup(false);
    // Find first S
    const i = form.indexOf("S");
    if(i===-1) return;
    const newForm = [...form.slice(0,i), ...rule, ...form.slice(i+1)];
    setForm(newForm);
    setHistory(h=>[...h, newForm]);
    setPhase('derive');
    // Check if done (no more S's)
    const hasSMore = newForm.includes("S");
    if(!hasSMore){
      const matches = JSON.stringify(newForm)===JSON.stringify(target);
      setDone(true);
      setPhase(matches?'check':'error');
    }
  };

  const formStr = form.length===0?"ε":form.join("");
  const targetStr = target.length===0?"ε":target.join("");
  const hasSym = form.includes("S");
  const isCorrect = done && phase==='check';
  const isError   = done && phase==='error';

  return(
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>
      <div style={{padding:"14px 22px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:900,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
          <div>
            <h1 style={{fontSize:19,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Context-Free Grammar</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>
              G: S → aSb | ε · Derive strings step-by-step
            </p>
          </div>
          {/* Goal selector */}
          <div style={{display:"flex",gap:6}}>
            {GOALS.map((g,i)=>(
              <button key={i} onClick={()=>reset(i)}
                style={{padding:"5px 12px",borderRadius:8,border:`1.5px solid ${goalIdx===i?"#7c3aed":"#e2e8f0"}`,
                  background:goalIdx===i?"#f5f3ff":"#fff",color:goalIdx===i?"#7c3aed":"#64748b",
                  fontSize:11,fontWeight:700,fontFamily:"monospace",cursor:"pointer"}}>
                {g.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",overflow:"hidden",maxWidth:900,margin:"0 auto",width:"100%",padding:"8px 18px 12px",boxSizing:"border-box",gap:14}}>

        {/* Left: derivation */}
        <div style={{flex:1,display:"flex",flexDirection:"column",gap:10,minWidth:0}}>

          {/* Goal */}
          <div style={{background:"#f5f3ff",border:"1.5px solid #ddd6fe",borderRadius:10,padding:"10px 14px",display:"flex",alignItems:"center",gap:12}}>
            <div>
              <div style={{fontSize:9,fontWeight:700,color:"#7c3aed",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:2}}>Derive this string:</div>
              <div style={{fontSize:20,fontWeight:800,fontFamily:"monospace",color:"#4c1d95",letterSpacing:"0.08em"}}>{targetStr}</div>
            </div>
            <div style={{flex:1,fontSize:11,color:"#6d28d9",fontStyle:"italic"}}>{goal.desc}</div>
            <div style={{fontSize:12,fontWeight:700,color:isCorrect?"#059669":isError?"#dc2626":"#94a3b8"}}>
              {isCorrect?"✓ Derived!":isError?"✗ Wrong string — reset":done?"":"Step "+(history.length-1)}
            </div>
          </div>

          {/* Current sentential form */}
          <div style={{background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:12,padding:"16px 14px",position:"relative"}}>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:12}}>
              Current sentential form — click S to expand
            </div>
            <div style={{display:"flex",gap:6,flexWrap:"wrap",alignItems:"center",minHeight:48}}>
              {form.length===0 && (
                <div style={{padding:"8px 18px",borderRadius:10,border:"2px dashed #e2e8f0",
                  fontSize:18,fontFamily:"monospace",color:"#94a3b8",fontStyle:"italic"}}>
                  ε (empty string)
                </div>
              )}
              {form.map((sym,i)=>{
                const isNT = sym==="S";
                return(
                  <div key={i}
                    onClick={isNT&&!done?()=>setPopup(true):undefined}
                    style={{
                      padding:"8px 16px",borderRadius:10,
                      border:`2.5px solid ${isNT?"#7c3aed":"#e2e8f0"}`,
                      background:isNT?"#f5f3ff":"#fff",
                      fontSize:22,fontWeight:800,fontFamily:"monospace",
                      color:isNT?"#7c3aed":"#1e293b",
                      cursor:isNT&&!done?"pointer":"default",
                      boxShadow:isNT?"0 2px 8px rgba(124,58,237,0.15)":undefined,
                      transition:"all 0.15s",
                      userSelect:"none",
                    }}
                    onMouseEnter={e=>{if(isNT&&!done)e.currentTarget.style.transform="scale(1.08)";}}
                    onMouseLeave={e=>{e.currentTarget.style.transform="scale(1)";}}
                  >
                    {sym}
                  </div>
                );
              })}
            </div>

            {/* Production chooser popup */}
            {popup&&(
              <div style={{position:"absolute",top:80,left:14,background:"#fff",border:"2px solid #7c3aed",
                borderRadius:12,padding:"12px",boxShadow:"0 8px 32px rgba(124,58,237,0.2)",zIndex:30,display:"flex",flexDirection:"column",gap:8}}>
                <div style={{fontSize:11,fontWeight:700,color:"#7c3aed",marginBottom:2}}>Choose production for S:</div>
                {PRODUCTIONS.map((p,i)=>(
                  <button key={i} onClick={()=>apply(p.rule)}
                    style={{padding:"10px 20px",borderRadius:9,border:"1.5px solid #ddd6fe",
                      background:"#f5f3ff",color:"#6d28d9",fontSize:14,fontWeight:700,
                      fontFamily:"monospace",cursor:"pointer",textAlign:"left",transition:"all 0.1s"}}
                    onMouseEnter={e=>{e.currentTarget.style.background="#ede9fe";}}
                    onMouseLeave={e=>{e.currentTarget.style.background="#f5f3ff";}}>
                    {p.label}
                  </button>
                ))}
                <button onClick={()=>setPopup(false)} style={{padding:"4px",border:"none",background:"none",color:"#94a3b8",fontSize:11,cursor:"pointer"}}>cancel</button>
              </div>
            )}
          </div>

          {/* Result banner */}
          {done&&(
            <div style={{background:isCorrect?"#dcfce7":"#fef2f2",border:`1.5px solid ${isCorrect?"#a7f3d0":"#fecaca"}`,
              borderRadius:10,padding:"12px 16px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <div style={{fontSize:14,fontWeight:800,color:isCorrect?"#059669":"#dc2626"}}>
                  {isCorrect?`S ⇒* "${targetStr}" ✓ — string is in L(G)`:`"${formStr}" ≠ "${targetStr}" — try again`}
                </div>
                {isCorrect&&<div style={{fontSize:11,color:"#065f46",marginTop:3}}>Derivation: {history.map(f=>f.length===0?"ε":f.join("")).join(" ⇒ ")}</div>}
              </div>
              <button onClick={()=>reset()} style={{padding:"6px 14px",border:"1.5px solid",borderRadius:8,fontWeight:700,fontSize:11,cursor:"pointer",
                borderColor:isCorrect?"#a7f3d0":"#fecaca",background:"#fff",color:isCorrect?"#059669":"#dc2626"}}>
                Reset
              </button>
            </div>
          )}

          {/* Instructions */}
          {!done&&!popup&&(
            <div style={{fontSize:11,color:"#94a3b8",fontStyle:"italic",textAlign:"center"}}>
              {hasSym?"Click the purple S to apply a production rule.":"No S left — derivation complete."}
            </div>
          )}

          {/* Derivation history */}
          <div style={{flex:1,overflow:"auto",minHeight:0}}>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:7}}>
              Derivation steps
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:5}}>
              {history.map((f,i)=>{
                const fs=f.length===0?"ε":f.join("");
                const isLast=i===history.length-1;
                return(
                  <div key={i} style={{display:"flex",alignItems:"center",gap:10}}>
                    <span style={{fontSize:9,color:"#e2e8f0",minWidth:14,fontFamily:"monospace"}}>{i}</span>
                    <div style={{display:"flex",alignItems:"center",gap:6,padding:"6px 12px",borderRadius:8,
                      background:isLast?"#f5f3ff":"#f8fafc",
                      border:`1px solid ${isLast?"#ddd6fe":"#f1f5f9"}`,flex:1}}>
                      {i>0&&<span style={{fontSize:10,color:"#7c3aed",marginRight:4}}>⇒</span>}
                      <div style={{display:"flex",gap:4}}>
                        {f.length===0?<span style={{fontSize:13,fontFamily:"monospace",color:"#94a3b8",fontStyle:"italic"}}>ε</span>:
                          f.map((sym,si)=>(
                            <span key={si} style={{fontSize:13,fontWeight:700,fontFamily:"monospace",
                              color:sym==="S"?"#7c3aed":"#1e293b"}}>{sym}</span>
                          ))}
                      </div>
                      {i>0&&(
                        <span style={{fontSize:9,color:"#94a3b8",marginLeft:4,fontStyle:"italic"}}>
                          (used S → {history[i-1].includes("S")?history[i].slice(history[i-1].indexOf("S"), history[i-1].indexOf("S")+3).join("")||"ε":"?"})
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right: grammar + theory */}
        <div style={{width:210,flexShrink:0,display:"flex",flexDirection:"column",gap:9}}>
          {/* Grammar card */}
          <div style={{background:"#f5f3ff",border:"1.5px solid #ddd6fe",borderRadius:10,padding:"12px"}}>
            <div style={{fontSize:10,fontWeight:700,color:"#7c3aed",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:8}}>Grammar G</div>
            <div style={{fontFamily:"monospace",fontSize:12,lineHeight:1.8,color:"#4c1d95"}}>
              <div><b>G</b> = (V, Σ, R, S)</div>
              <div>V = &#123;S&#125;</div>
              <div>Σ = &#123;a, b&#125;</div>
              <div style={{marginTop:6,fontWeight:800}}>R:</div>
              <div style={{paddingLeft:8}}>S → aSb</div>
              <div style={{paddingLeft:8}}>S → ε</div>
              <div style={{marginTop:6}}>Start: S</div>
            </div>
          </div>

          {/* Pseudocode */}
          <div>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:5}}>Formal definition</div>
            <div style={{background:"#f8fafc",borderRadius:10,padding:"7px",border:"1px solid #f1f5f9"}}>
              {AXIOMS.map((l,i)=>{
                const on=l.t.includes(phase);
                return(
                  <div key={i} style={{display:"flex",gap:5,padding:"2px 5px",borderRadius:4,margin:"1px 0",
                    background:on?"#7c3aed1a":"transparent",border:`1px solid ${on?"#7c3aed55":"transparent"}`,transition:"all 0.15s"}}>
                    <span style={{fontSize:8.5,color:"#e2e8f0",minWidth:10,paddingTop:2,fontFamily:"monospace"}}>{i+1}</span>
                    <span style={{fontSize:9.5,fontFamily:"'Courier New',monospace",color:on?"#7c3aed":"#94a3b8",fontWeight:on?700:400,whiteSpace:"pre",lineHeight:1.5}}>{l.line}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Chomsky Normal Form note */}
          <div style={{background:"#f8fafc",borderRadius:10,padding:"10px 12px",border:"1px solid #f1f5f9",flex:1}}>
            <div style={{fontSize:10,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:6}}>L(G) = &#123;aⁿbⁿ | n≥0&#125;</div>
            <p style={{fontSize:11,lineHeight:1.6,color:"#475569",margin:"0 0 8px"}}>This grammar is context-free but <em>not regular</em>. No DFA can recognise aⁿbⁿ — it requires memory (counting) beyond DFA's finite states.</p>
            <p style={{fontSize:11,lineHeight:1.6,color:"#475569",margin:0}}>A pushdown automaton (PDA) can recognise it by pushing a's and popping for each b.</p>
            <div style={{marginTop:10,padding:"7px 10px",background:"#fff",borderRadius:8,border:"1px solid #e2e8f0"}}>
              <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",marginBottom:4}}>Parse tree for "aabb":</div>
              <pre style={{fontSize:10,fontFamily:"monospace",color:"#475569",margin:0,lineHeight:1.6}}>
{`    S
   /|\\
  a S b
   /|\\
  a S b
    |
    ε`}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
