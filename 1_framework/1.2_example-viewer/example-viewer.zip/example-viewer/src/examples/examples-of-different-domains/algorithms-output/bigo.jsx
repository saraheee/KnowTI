import { useState } from "react";

const CLASSES = [
  { id:"o1",     label:"O(1)",        sub:"Constant",       color:"#059669", light:"#ecfdf5", border:"#a7f3d0", desc:"Execution time is fixed regardless of input size." },
  { id:"ologn",  label:"O(log n)",    sub:"Logarithmic",    color:"#2563eb", light:"#eff6ff", border:"#bfdbfe", desc:"Input is halved each step. Found in divide-and-conquer." },
  { id:"on",     label:"O(n)",        sub:"Linear",         color:"#0891b2", light:"#f0f9ff", border:"#bae6fd", desc:"One operation per element. Must touch all input once." },
  { id:"onlogn", label:"O(n log n)",  sub:"Linearithmic",   color:"#7c3aed", light:"#f5f3ff", border:"#ddd6fe", desc:"n items each needing log n work. Optimal for comparison sort." },
  { id:"on2",    label:"O(n²)",       sub:"Quadratic",      color:"#d97706", light:"#fffbeb", border:"#fde68a", desc:"Nested loops over n elements. Quickly impractical for large n." },
  { id:"o2n",    label:"O(2ⁿ)",       sub:"Exponential",    color:"#dc2626", light:"#fef2f2", border:"#fecaca", desc:"Doubles per added element. Only feasible for very small n." },
];

const ITEMS = [
  { id:"i1",  label:"Array access by index",      cls:"o1",    hint:"Memory address computed directly from index." },
  { id:"i2",  label:"Hash table lookup (avg)",     cls:"o1",    hint:"Key is hashed to a bucket in constant time." },
  { id:"i3",  label:"Stack push / pop",            cls:"o1",    hint:"Only the top of the stack is touched." },
  { id:"i4",  label:"Binary search",               cls:"ologn", hint:"Each step halves the remaining search space." },
  { id:"i5",  label:"BST search (balanced)",       cls:"ologn", hint:"Height of a balanced tree is ⌊log₂ n⌋." },
  { id:"i6",  label:"Heap insert",                 cls:"ologn", hint:"Sifts up at most log n levels." },
  { id:"i7",  label:"Linear search",               cls:"on",    hint:"May examine every element before finding it." },
  { id:"i8",  label:"Finding min in unsorted array",cls:"on",   hint:"Must compare all n elements." },
  { id:"i9",  label:"Merge sort",                  cls:"onlogn",hint:"Divides n items into log n levels of n work." },
  { id:"i10", label:"Heap sort",                   cls:"onlogn",hint:"n extractions each taking O(log n) time." },
  { id:"i11", label:"Bubble sort (worst)",         cls:"on2",   hint:"n−1 passes each up to n−1 comparisons." },
  { id:"i12", label:"Selection sort",              cls:"on2",   hint:"n times: scan remaining n−i elements." },
  { id:"i13", label:"Insertion sort (worst)",      cls:"on2",   hint:"Each insertion may shift all sorted elements." },
  { id:"i14", label:"Naive Fibonacci (recursive)", cls:"o2n",   hint:"fib(n) calls fib(n−1) and fib(n−2) — exponential calls." },
  { id:"i15", label:"Enumerate all subsets",       cls:"o2n",   hint:"A set of n elements has exactly 2ⁿ subsets." },
];

function shuffle(a){const b=[...a];for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]];}return b;}

export default function App() {
  const [pool,     setPool]     = useState(()=>shuffle(ITEMS));
  const [placed,   setPlaced]   = useState({});
  const [feedback, setFeedback] = useState({});
  const [tooltip,  setTooltip]  = useState(null);
  const [dragId,   setDragId]   = useState(null);
  const [hovCls,   setHovCls]   = useState(null);

  const score=Object.values(feedback).filter(v=>v==="correct").length;

  const onDrop=(cls)=>{
    if(!dragId) return;
    setDragId(null);
    const item=ITEMS.find(i=>i.id===dragId);
    if(!item) return;
    const ok=item.cls===cls;
    setFeedback(f=>({...f,[dragId]:ok?"correct":"wrong"}));
    if(ok){
      setPool(p=>p.filter(i=>i.id!==dragId));
      setPlaced(p=>({...p,[cls]:[...(p[cls]||[]),dragId]}));
    } else {
      setTimeout(()=>setFeedback(f=>{const n={...f};delete n[dragId];return n;}),1300);
    }
  };

  const reset=()=>{setPool(shuffle(ITEMS));setPlaced({});setFeedback({});setTooltip(null);};
  const tip=ITEMS.find(i=>i.id===tooltip);
  const tipCls=tip?CLASSES.find(c=>c.id===tip.cls):null;

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      <div style={{padding:"14px 22px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:1060,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
          <div>
            <h1 style={{fontSize:20,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Asymptotic Complexity</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>Big-O · drag each operation to its complexity class</p>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <span style={{fontSize:13,fontWeight:700,color:"#0f172a"}}>
              {score}<span style={{fontWeight:400,color:"#94a3b8"}}>/{ITEMS.length}</span>
            </span>
            <button onClick={reset} style={{padding:"5px 12px",border:"1px solid #e2e8f0",borderRadius:8,
              background:"#fff",color:"#64748b",fontSize:11,fontWeight:600,cursor:"pointer"}}>↺ Reset</button>
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",
        padding:"10px 18px 12px",maxWidth:1060,margin:"0 auto",width:"100%",boxSizing:"border-box",gap:9}}>

        {/* Complexity class columns */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(6,1fr)",gap:7,flex:1,overflow:"hidden",minHeight:0}}>
          {CLASSES.map(cls=>{
            const ids=placed[cls.id]||[];
            const isHov=hovCls===cls.id;
            return (
              <div key={cls.id}
                onDragOver={e=>{e.preventDefault();setHovCls(cls.id);}}
                onDragLeave={()=>setHovCls(null)}
                onDrop={()=>{setHovCls(null);onDrop(cls.id);}}
                style={{display:"flex",flexDirection:"column",gap:5,overflow:"hidden"}}>
                {/* Header */}
                <div style={{background:cls.light,border:`2px solid ${isHov?cls.color:cls.border}`,
                  borderRadius:10,padding:"8px 10px",textAlign:"center",flexShrink:0,
                  transition:"border-color 0.15s",cursor:"default"}}
                  onMouseEnter={()=>setHovCls(cls.id)} onMouseLeave={()=>setHovCls(null)}>
                  <div style={{fontSize:15,fontWeight:900,color:cls.color,letterSpacing:"-0.01em"}}>{cls.label}</div>
                  <div style={{fontSize:9,color:cls.color,opacity:0.7,marginTop:1,letterSpacing:"0.04em",textTransform:"uppercase"}}>{cls.sub}</div>
                  {isHov&&<p style={{fontSize:9,color:"#475569",margin:"5px 0 0",lineHeight:1.45,fontStyle:"italic"}}>{cls.desc}</p>}
                </div>
                {/* Drop zone */}
                <div style={{flex:1,background:"#fafafa",border:`2px dashed ${isHov?cls.color:cls.border}`,
                  borderRadius:10,padding:6,display:"flex",flexDirection:"column",gap:5,
                  overflow:"auto",transition:"border-color 0.15s",minHeight:50}}>
                  {ids.map(id=>{
                    const it=ITEMS.find(i=>i.id===id);
                    return(
                      <div key={id}
                        onMouseEnter={()=>setTooltip(id)} onMouseLeave={()=>setTooltip(null)}
                        style={{background:cls.light,border:`1px solid ${cls.border}`,borderRadius:8,
                          padding:"6px 8px",position:"relative",cursor:"default"}}>
                        <div style={{fontSize:9,fontWeight:700,color:cls.color}}>✓</div>
                        <div style={{fontSize:10,fontWeight:600,color:"#334155",lineHeight:1.3}}>{it.label}</div>
                        {tooltip===id&&tip&&(
                          <div style={{position:"absolute",left:"calc(100%+6px)",top:0,zIndex:60,
                            background:"#0f172a",color:"#fff",borderRadius:8,padding:"9px 11px",
                            width:200,fontSize:10,lineHeight:1.6,pointerEvents:"none",
                            boxShadow:"0 8px 24px rgba(0,0,0,0.2)"}}>
                            <div style={{fontWeight:700,marginBottom:3,color:tipCls?.color}}>{tipCls?.label} — why?</div>
                            {tip.hint}
                          </div>
                        )}
                      </div>
                    );
                  })}
                  {ids.length===0&&(
                    <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",
                      fontSize:9,color:"#e2e8f0",fontStyle:"italic"}}>drop here</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Item pool */}
        <div style={{flexShrink:0}}>
          <div style={{fontSize:10,color:"#94a3b8",fontWeight:700,letterSpacing:"0.08em",
            textTransform:"uppercase",marginBottom:7}}>
            Operations — hover for a hint, drag to the correct Big-O class:
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
            {pool.map(it=>{
              const wrong=feedback[it.id]==="wrong";
              const isDragging=dragId===it.id;
              return(
                <div key={it.id}
                  draggable
                  onDragStart={()=>setDragId(it.id)}
                  onDragEnd={()=>setDragId(null)}
                  onMouseEnter={()=>setTooltip(it.id)} onMouseLeave={()=>setTooltip(null)}
                  style={{
                    background:wrong?"#fef2f2":isDragging?"#f0f9ff":"#f8fafc",
                    border:`1.5px solid ${wrong?"#fecaca":isDragging?"#bae6fd":"#e2e8f0"}`,
                    borderRadius:8,padding:"6px 12px",cursor:"grab",
                    transition:"all 0.12s",userSelect:"none",position:"relative",
                    boxShadow:wrong?"0 0 0 2px #fca5a5":isDragging?"0 4px 14px rgba(14,165,233,0.2)":"none",
                    opacity:isDragging?0.6:1,
                  }}>
                  <div style={{fontSize:12,fontWeight:600,color:wrong?"#dc2626":"#1e293b"}}>{it.label}</div>
                  {wrong&&<div style={{fontSize:9,color:"#dc2626",marginTop:1}}>✗ wrong class</div>}
                  {tooltip===it.id&&!wrong&&(
                    <div style={{position:"absolute",bottom:"calc(100%+6px)",left:0,zIndex:60,
                      background:"#0f172a",color:"#fff",borderRadius:8,padding:"9px 12px",
                      width:230,fontSize:11,lineHeight:1.6,pointerEvents:"none",
                      boxShadow:"0 8px 24px rgba(0,0,0,0.2)"}}>
                      💡 {it.hint}
                    </div>
                  )}
                </div>
              );
            })}
            {pool.length===0&&(
              <div style={{fontSize:13,fontWeight:700,color:"#059669",padding:"6px 0"}}>
                🎉 All {ITEMS.length} operations correctly classified!
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
