import { useState, useEffect, useRef } from "react";

/* ─── Step generators ─────────────────────────────────────────────────── */
function bubbleSteps(a) {
  const s=[], arr=[...a], n=arr.length, sorted=new Set();
  for(let i=0;i<n-1;i++){
    for(let j=0;j<n-i-1;j++){
      s.push({arr:[...arr],hi:[j,j+1],sorted:new Set(sorted),pivot:-1,t:'cmp'});
      if(arr[j]>arr[j+1]){[arr[j],arr[j+1]]=[arr[j+1],arr[j]];
        s.push({arr:[...arr],hi:[j,j+1],sorted:new Set(sorted),pivot:-1,t:'swp'});}
    }
    sorted.add(n-1-i);
  }
  sorted.add(0);
  s.push({arr:[...arr],hi:[],sorted:new Set(sorted),pivot:-1,t:'done'});
  return s;
}

function insertionSteps(a) {
  const s=[], arr=[...a], n=arr.length, sorted=new Set([0]);
  for(let i=1;i<n;i++){
    let j=i;
    s.push({arr:[...arr],hi:[j],sorted:new Set(sorted),pivot:i,t:'pick'});
    while(j>0){
      s.push({arr:[...arr],hi:[j-1,j],sorted:new Set(sorted),pivot:i,t:'cmp'});
      if(arr[j-1]>arr[j]){[arr[j-1],arr[j]]=[arr[j],arr[j-1]];
        s.push({arr:[...arr],hi:[j-1,j],sorted:new Set(sorted),pivot:i,t:'swp'});j--;}
      else break;
    }
    sorted.add(i);
  }
  s.push({arr:[...arr],hi:[],sorted:new Set(Array.from({length:a.length},(_,i)=>i)),pivot:-1,t:'done'});
  return s;
}

function mergeSteps(a) {
  const s=[], arr=[...a];
  function merge(arr,l,m,r){
    const L=arr.slice(l,m+1), R=arr.slice(m+1,r+1);
    let i=0,j=0,k=l;
    while(i<L.length&&j<R.length){
      s.push({arr:[...arr],hi:[l+i,m+1+j],sorted:new Set(),pivot:-1,t:'cmp',range:[l,r]});
      arr[k++]=L[i]<=R[j]?L[i++]:R[j++];
      s.push({arr:[...arr],hi:[k-1],sorted:new Set(),pivot:-1,t:'place',range:[l,r]});
    }
    while(i<L.length){arr[k++]=L[i++];s.push({arr:[...arr],hi:[k-1],sorted:new Set(),pivot:-1,t:'place',range:[l,r]});}
    while(j<R.length){arr[k++]=R[j++];s.push({arr:[...arr],hi:[k-1],sorted:new Set(),pivot:-1,t:'place',range:[l,r]});}
  }
  function ms(arr,l,r){if(l>=r)return;const m=Math.floor((l+r)/2);ms(arr,l,m);ms(arr,m+1,r);merge(arr,l,m,r);}
  ms(arr,0,arr.length-1);
  s.push({arr:[...arr],hi:[],sorted:new Set(Array.from({length:arr.length},(_,i)=>i)),pivot:-1,t:'done',range:[]});
  return s;
}

/* ─── Algorithm metadata & pseudocode ───────────────────────────────────── */
const ALGOS = [
  { key:"bubble",    label:"Bubble Sort",    color:"#2563eb", O:"O(n²)",
    pseudo:[
      { line:"procedure BubbleSort(arr):",       active:[] },
      { line:"  for i ← 0 to n−2:",              active:['all'] },
      { line:"    for j ← 0 to n−i−2:",          active:['cmp','swp'] },
      { line:"      if arr[j] > arr[j+1]:",       active:['cmp'] },   // 3
      { line:"        swap arr[j], arr[j+1]",     active:['swp'] },   // 4
      { line:"  ✓ arr[n−1−i] now in place",       active:['done'] },  // 5
    ],
    note:"Compare adjacent pairs; bubble largest to end each pass.",
  },
  { key:"insertion", label:"Insertion Sort", color:"#7c3aed", O:"O(n²)",
    pseudo:[
      { line:"procedure InsertionSort(arr):",     active:[] },
      { line:"  for i ← 1 to n−1:",              active:['all'] },
      { line:"    key ← arr[i]",                 active:['pick'] },   // 2
      { line:"    j ← i",                         active:['pick'] },   // 3
      { line:"    while j>0, arr[j−1]>key:",      active:['cmp','swp'] }, // 4
      { line:"      arr[j] ← arr[j−1]  // shift",active:['swp'] },   // 5
      { line:"      j ← j − 1",                   active:['swp'] },   // 6
      { line:"    arr[j] ← key  // insert ✓",     active:['done'] },  // 7
    ],
    note:"Build sorted portion left-to-right; shift elements to make room.",
  },
  { key:"merge",     label:"Merge Sort",     color:"#059669", O:"O(n log n)",
    pseudo:[
      { line:"procedure Merge(arr, l, m, r):",   active:[] },
      { line:"  left  ← arr[l..m]",              active:['all'] },
      { line:"  right ← arr[m+1..r]",            active:['all'] },
      { line:"  while left ∧ right not empty:",   active:['cmp','place'] },
      { line:"    compare left[i] vs right[j]",   active:['cmp'] },   // 4
      { line:"    place smaller into arr",         active:['place'] },  // 5
      { line:"  copy remaining elements",          active:['place'] },  // 6
      { line:"  ✓ arr[l..r] fully merged",        active:['done'] },  // 7
    ],
    note:"Divide → recursively sort halves → merge. Always O(n log n).",
  },
];

/* ─── Helpers ─────────────────────────────────────────────────────────── */
function genArr(n=28){return Array.from({length:n},()=>Math.floor(Math.random()*88)+12);}

function PseudoCode({ steps:lines, curT, color }) {
  return (
    <div style={{background:"#f8fafc",borderRadius:10,padding:"8px",border:"1px solid #f1f5f9",flex:1}}>
      {lines.map((l,i)=>{
        const on=l.active.includes('all')||l.active.includes(curT);
        return (
          <div key={i} style={{display:"flex",gap:5,alignItems:"flex-start",
            padding:"2px 6px",borderRadius:5,margin:"1px 0",
            background:on?color+"18":"transparent",
            border:`1px solid ${on?color+"55":"transparent"}`,
            transition:"all 0.18s"}}>
            <span style={{fontSize:9,color:"#cbd5e1",minWidth:12,paddingTop:2,fontFamily:"monospace",flexShrink:0}}>{i+1}</span>
            <span style={{fontSize:10.5,fontFamily:"'Courier New',monospace",lineHeight:1.5,
              color:on?color:"#94a3b8",fontWeight:on?700:400,whiteSpace:"pre",transition:"all 0.18s"}}>
              {l.line}
            </span>
          </div>
        );
      })}
    </div>
  );
}

/* ─── Main ────────────────────────────────────────────────────────────── */
export default function App() {
  const [algo,    setAlgo]   = useState("bubble");
  const [baseArr, setBase]   = useState(()=>genArr());
  const [steps,   setSteps]  = useState([]);
  const [idx,     setIdx]    = useState(0);
  const [playing, setPlay]   = useState(false);
  const [speed,   setSpeed]  = useState(1);

  const speedRef=useRef(speed), timerRef=useRef(null);
  useEffect(()=>{speedRef.current=speed;},[speed]);

  useEffect(()=>{
    const s=algo==="bubble"?bubbleSteps(baseArr):algo==="insertion"?insertionSteps(baseArr):mergeSteps(baseArr);
    setSteps(s);setIdx(0);setPlay(false);
  },[algo,baseArr]);

  useEffect(()=>{
    clearInterval(timerRef.current);
    if(playing) timerRef.current=setInterval(()=>{
      setIdx(i=>{if(i>=steps.length-1){setPlay(false);return steps.length-1;}return i+1;});
    },Math.max(28,260/speedRef.current));
    return()=>clearInterval(timerRef.current);
  },[playing,steps,speed]);

  const al=ALGOS.find(a=>a.key===algo);
  const cur=steps[idx]||{arr:baseArr,hi:[],sorted:new Set(),pivot:-1,t:'idle',range:[]};
  const A=cur.arr||baseArr;
  const maxV=Math.max(...A);
  const n=A.length, BW=Math.floor(555/n)-2;
  const cmps=steps.slice(0,idx+1).filter(s=>s.t==='cmp').length;
  const swps=steps.slice(0,idx+1).filter(s=>['swp','place'].includes(s.t)).length;

  function barColor(i){
    if(cur.t==='done'||cur.sorted?.has(i)) return "#bbf7d0";
    if(cur.pivot===i) return "#dc2626";
    if(cur.hi?.includes(i)) return cur.t==='swp'||cur.t==='place'?"#f97316":"#fbbf24";
    if(cur.range&&i>=cur.range[0]&&i<=cur.range[1]) return al.color+"44";
    return al.color+"33";
  }

  const statusMsg = {
    cmp:"Comparing highlighted elements…",
    swp:"Swapping — out of order!",
    pick:"Picking next unsorted element (key)…",
    place:"Placing into merged position…",
    done:"✓ Fully sorted!",
    idle:al.note,
  }[cur.t]||al.note;

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"14px 22px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:900,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
          <div>
            <h1 style={{fontSize:19,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Sorting Algorithms</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>step-by-step with pseudocode</p>
          </div>
          <div style={{display:"flex",gap:6}}>
            {ALGOS.map(a=>(
              <button key={a.key} onClick={()=>setAlgo(a.key)}
                style={{padding:"5px 12px",borderRadius:16,border:`1.5px solid ${algo===a.key?a.color:"#e2e8f0"}`,
                  background:algo===a.key?a.color+"18":"#fff",color:algo===a.key?a.color:"#64748b",
                  fontSize:11,fontWeight:700,cursor:"pointer",transition:"all 0.15s"}}>
                {a.label} <span style={{opacity:0.65,fontSize:10}}>{a.O}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",overflow:"hidden",maxWidth:900,margin:"0 auto",
        width:"100%",padding:"10px 20px 12px",boxSizing:"border-box",gap:14}}>

        {/* Left: bars */}
        <div style={{flex:1,display:"flex",flexDirection:"column",gap:10,minWidth:0}}>
          {/* Stats row */}
          <div style={{display:"flex",gap:14,alignItems:"center",flexWrap:"wrap"}}>
            {[["Comparisons",cmps,"#fbbf24"],["Swaps/Merges",swps,"#f97316"],["Step",`${idx}/${steps.length-1}`,"#94a3b8"]].map(([l,v,c])=>(
              <div key={l} style={{textAlign:"center"}}>
                <div style={{fontSize:17,fontWeight:800,color:c}}>{v}</div>
                <div style={{fontSize:9,color:"#94a3b8",letterSpacing:"0.06em",textTransform:"uppercase"}}>{l}</div>
              </div>
            ))}
            <div style={{flex:1,padding:"7px 11px",background:al.color+"10",border:`1px solid ${al.color}33`,
              borderRadius:8,fontSize:11,color:"#334155",fontStyle:"italic",minWidth:120}}>
              {statusMsg}
            </div>
          </div>

          {/* Bars SVG */}
          <div style={{flex:1,minHeight:0}}>
            <svg viewBox="0 0 560 185" width="100%" style={{display:"block",maxHeight:200}}>
              {A.map((v,i)=>{
                const h=Math.round((v/maxV)*165)+5, x=i*(BW+2);
                return <rect key={i} x={x} y={185-h} width={BW} height={h} rx={2}
                  fill={barColor(i)} style={{transition:"fill 0.07s"}}/>;
              })}
            </svg>
          </div>

          {/* Legend */}
          <div style={{display:"flex",gap:14,justifyContent:"center",flexWrap:"wrap"}}>
            {[["Comparing","#fbbf24"],["Swapping","#f97316"],["Key/Pivot","#dc2626"],["Sorted","#bbf7d0"]].map(([l,c])=>(
              <div key={l} style={{display:"flex",alignItems:"center",gap:4,fontSize:11,color:"#64748b"}}>
                <div style={{width:11,height:11,borderRadius:2,background:c}}/>
                {l}
              </div>
            ))}
          </div>

          {/* Controls */}
          <div style={{display:"flex",alignItems:"center",gap:8,background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,padding:"8px 13px"}}>
            <button onClick={()=>{setIdx(0);setPlay(false);}} style={{padding:"5px 10px",border:"1px solid #e2e8f0",borderRadius:7,background:"#fff",color:"#64748b",fontSize:12,cursor:"pointer"}}>⏮</button>
            <button onClick={()=>setIdx(i=>Math.max(0,i-1))} style={{padding:"5px 10px",border:"1px solid #e2e8f0",borderRadius:7,background:"#fff",color:"#64748b",fontSize:13,cursor:"pointer"}}>‹</button>
            <button onClick={()=>{if(idx<steps.length-1)setPlay(p=>!p);}}
              style={{width:32,height:32,borderRadius:8,border:"none",fontSize:14,cursor:"pointer",
                background:playing?"#64748b":al.color,color:"#fff",display:"flex",alignItems:"center",justifyContent:"center"}}>
              {playing?"⏸":"▶"}
            </button>
            <button onClick={()=>setIdx(i=>Math.min(steps.length-1,i+1))} style={{padding:"5px 10px",border:"1px solid #e2e8f0",borderRadius:7,background:"#fff",color:"#64748b",fontSize:13,cursor:"pointer"}}>›</button>
            <div style={{flex:1,display:"flex",alignItems:"center",gap:7}}>
              <span style={{fontSize:9,color:"#94a3b8",fontWeight:700,letterSpacing:"0.08em"}}>SPEED</span>
              <input type="range" min={0.5} max={10} step={0.5} value={speed}
                onChange={e=>setSpeed(+e.target.value)}
                style={{flex:1,accentColor:al.color,cursor:"pointer"}}/>
              <span style={{fontSize:11,fontWeight:800,color:al.color,minWidth:24}}>{speed}×</span>
            </div>
            <button onClick={()=>{setBase(genArr());}} style={{padding:"5px 12px",border:"1px solid #e2e8f0",borderRadius:7,background:"#fff",color:"#64748b",fontSize:11,fontWeight:600,cursor:"pointer"}}>
              🔀 Shuffle
            </button>
          </div>
        </div>

        {/* Right: pseudocode */}
        <div style={{width:215,flexShrink:0,display:"flex",flexDirection:"column",gap:8}}>
          <div style={{fontSize:10,fontWeight:700,color:"#94a3b8",letterSpacing:"0.1em",textTransform:"uppercase"}}>
            Pseudocode — active step highlighted
          </div>
          <PseudoCode steps={al.pseudo} curT={cur.t} color={al.color}/>
          <div style={{background:al.color+"10",border:`1px solid ${al.color}22`,borderRadius:8,padding:"10px 12px"}}>
            <div style={{fontSize:10,fontWeight:700,color:al.color,letterSpacing:"0.06em",marginBottom:4}}>
              Complexity
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:4}}>
              {[["Best","O(n)"],["Avg",al.O],["Worst",al.O],["Space","O(1)"]].map(([l,v])=>(
                <div key={l}>
                  <div style={{fontSize:9,color:"#94a3b8",letterSpacing:"0.04em"}}>{l}</div>
                  <div style={{fontSize:11,fontWeight:700,color:al.color,fontFamily:"monospace"}}>{v}</div>
                </div>
              ))}
            </div>
            {algo==="merge"&&<div style={{fontSize:9,color:"#94a3b8",marginTop:4}}>* Space = O(n) for merge</div>}
            {algo==="bubble"&&<div style={{fontSize:9,color:"#94a3b8",marginTop:4}}>* Best = O(n) when already sorted</div>}
            {algo==="insertion"&&<div style={{fontSize:9,color:"#94a3b8",marginTop:4}}>* Best = O(n) when nearly sorted</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
