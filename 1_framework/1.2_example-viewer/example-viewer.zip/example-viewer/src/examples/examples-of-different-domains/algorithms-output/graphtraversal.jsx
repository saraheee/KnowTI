import { useState, useEffect, useRef, useCallback } from "react";

/* ─── Graph ──────────────────────────────────────────────────────────────── */
const NODES = {
  A:{x:82, y:172,label:"A"}, B:{x:192,y:70, label:"B"}, C:{x:192,y:274,label:"C"},
  D:{x:312,y:172,label:"D"}, E:{x:312,y:44, label:"E"}, F:{x:428,y:274,label:"F"},
  G:{x:428,y:70, label:"G"}, H:{x:544,y:172,label:"H"},
};
const EDGES_W=[
  ["A","B",4],["A","C",2],["B","D",3],["B","E",1],["B","G",8],
  ["C","D",5],["C","F",6],["D","G",2],["D","F",1],["E","G",3],["F","H",4],["G","H",2]
];
const ADJ={}, WADJ={};
Object.keys(NODES).forEach(n=>{ADJ[n]=[];WADJ[n]=[];});
EDGES_W.forEach(([a,b,w])=>{
  ADJ[a].push(b);ADJ[b].push(a);
  WADJ[a].push({n:b,w});WADJ[b].push({n:a,w});
});
Object.keys(ADJ).forEach(n=>{ADJ[n].sort();WADJ[n].sort((a,b)=>a.n<b.n?-1:1);});

/* ─── Step generators ────────────────────────────────────────────────────── */
function bfsSteps(start){
  const S=[], visited=new Set(), inQ=new Set([start]), Q=[start];
  S.push({visited:new Set(),current:null,frontier:new Set([start]),struct:[start],edge:null,type:'init',dist:{},settled:new Set(),desc:`Enqueue ${start}. Begin.`});
  while(Q.length){
    const u=Q.shift(); visited.add(u);
    S.push({visited:new Set(visited),current:u,frontier:new Set(inQ),struct:[...Q],edge:null,type:'deq',dist:{},settled:new Set(),desc:`Dequeue ${u} — visit & mark.`});
    for(const v of ADJ[u]){
      if(!inQ.has(v)){
        inQ.add(v);Q.push(v);
        S.push({visited:new Set(visited),current:u,frontier:new Set(inQ),struct:[...Q],edge:[u,v],type:'enq',dist:{},settled:new Set(),desc:`${u}→${v}: not visited — enqueue ${v}.`});
      } else if(!visited.has(v)){
        S.push({visited:new Set(visited),current:u,frontier:new Set(inQ),struct:[...Q],edge:[u,v],type:'skip',dist:{},settled:new Set(),desc:`${u}→${v}: ${v} already queued, skip.`});
      }
    }
  }
  S.push({visited:new Set(visited),current:null,frontier:new Set(),struct:[],edge:null,type:'done',dist:{},settled:new Set(),desc:`BFS complete. Visited in breadth-first order.`});
  return S;
}

function dfsSteps(start){
  const S=[], visited=new Set(), onStack=new Set([start]), stack=[start];
  S.push({visited:new Set(),current:null,frontier:new Set([start]),struct:[start],edge:null,type:'init',dist:{},settled:new Set(),desc:`Push ${start} onto stack.`});
  while(stack.length){
    const u=stack.pop();
    if(visited.has(u)){
      S.push({visited:new Set(visited),current:null,frontier:new Set(onStack),struct:[...stack],edge:null,type:'skip',dist:{},settled:new Set(),desc:`Pop ${u} — already visited, skip.`});
      continue;
    }
    visited.add(u); onStack.delete(u);
    S.push({visited:new Set(visited),current:u,frontier:new Set(onStack),struct:[...stack],edge:null,type:'pop',dist:{},settled:new Set(),desc:`Pop ${u} — mark visited.`});
    const unvis=[...WADJ[u].map(e=>e.n)].filter(v=>!visited.has(v)).reverse();
    for(const v of unvis){
      if(!onStack.has(v)){onStack.add(v);stack.push(v);}
      S.push({visited:new Set(visited),current:u,frontier:new Set(onStack),struct:[...stack],edge:[u,v],type:'push',dist:{},settled:new Set(),desc:`${u}→${v}: push ${v}.`});
    }
  }
  S.push({visited:new Set(visited),current:null,frontier:new Set(),struct:[],edge:null,type:'done',dist:{},settled:new Set(),desc:`DFS complete. Visited in depth-first order.`});
  return S;
}

function dijkstraSteps(start){
  const S=[], dist={}, prev={}, settled=new Set();
  Object.keys(NODES).forEach(n=>{dist[n]=n===start?0:Infinity;prev[n]=null;});
  const remaining=new Set(Object.keys(NODES));
  S.push({visited:new Set(),current:null,frontier:new Set(),struct:[],edge:null,type:'init',dist:{...dist},settled:new Set(settled),desc:`Init: dist[${start}]=0, all others=∞.`});
  while(remaining.size>0){
    const u=[...remaining].reduce((a,b)=>dist[a]<=dist[b]?a:b);
    if(dist[u]===Infinity)break;
    remaining.delete(u); settled.add(u);
    S.push({visited:new Set(settled),current:u,frontier:new Set(remaining),struct:[...remaining].sort((a,b)=>(dist[a]??Infinity)-(dist[b]??Infinity)),edge:null,type:'extract',dist:{...dist},settled:new Set(settled),desc:`Extract-min: ${u} (dist=${dist[u]}).`});
    for(const {n:v,w} of WADJ[u]){
      const nd=dist[u]+w;
      S.push({visited:new Set(settled),current:u,frontier:new Set(remaining),struct:[...remaining].sort((a,b)=>(dist[a]??Infinity)-(dist[b]??Infinity)),edge:[u,v],type:'examine',dist:{...dist},settled:new Set(settled),desc:`Examine ${u}→${v}: ${dist[u]}+${w}=${nd} ${nd<dist[v]?'<':'≥'} ${dist[v]===Infinity?'∞':dist[v]}`});
      if(nd<dist[v]){
        dist[v]=nd; prev[v]=u;
        S.push({visited:new Set(settled),current:u,frontier:new Set(remaining),struct:[...remaining].sort((a,b)=>(dist[a]??Infinity)-(dist[b]??Infinity)),edge:[u,v],type:'relax',dist:{...dist},settled:new Set(settled),desc:`RELAX! dist[${v}] ← ${nd} via ${u}.`});
      }
    }
  }
  S.push({visited:new Set(settled),current:null,frontier:new Set(),struct:[],edge:null,type:'done',dist:{...dist},settled:new Set(settled),desc:`Done. All shortest paths from ${start} found.`});
  return S;
}

/* ─── Algorithm metadata & pseudocode ───────────────────────────────────── */
const AM={
  bfs:{label:"Breadth-First Search",color:"#2563eb",light:"#eff6ff",border:"#bfdbfe",structLabel:"Queue (FIFO)",
    note:"Explores level by level. Finds shortest path by hops in unweighted graphs.",
    pseudo:[
      {line:"procedure BFS(G, s):",            t:[]},
      {line:"  Q ← ∅; enqueue(Q, s)",         t:['init']},
      {line:"  visited[s] ← true",             t:['init']},
      {line:"  while Q ≠ ∅:",                  t:['deq','enq','skip']},
      {line:"    u ← dequeue(Q)",               t:['deq']},
      {line:"    for each v ∈ adj(u):",         t:['enq','skip']},
      {line:"      if not visited[v]:",          t:['enq','skip']},
      {line:"        visited[v] ← true",         t:['enq']},
      {line:"        enqueue(Q, v)",             t:['enq']},
    ]},
  dfs:{label:"Depth-First Search",color:"#7c3aed",light:"#f5f3ff",border:"#ddd6fe",structLabel:"Stack (LIFO)",
    note:"Goes as deep as possible before backtracking. Used in topological sort & cycle detection.",
    pseudo:[
      {line:"procedure DFS(G, s):",             t:[]},
      {line:"  S ← ∅; push(S, s)",             t:['init']},
      {line:"  while S ≠ ∅:",                   t:['pop','push','skip']},
      {line:"    u ← pop(S)",                    t:['pop','skip']},
      {line:"    if not visited[u]: return",      t:['pop','skip']},
      {line:"      visited[u] ← true",            t:['pop']},
      {line:"      for each v ∈ adj(u):",         t:['push']},
      {line:"        push(S, v)",                 t:['push']},
    ]},
  dijkstra:{label:"Dijkstra's Algorithm",color:"#d97706",light:"#fffbeb",border:"#fde68a",structLabel:"Priority Queue (min-dist)",
    note:"Shortest path in weighted graphs (non-negative weights). Greedy: always extract the closest unvisited node.",
    pseudo:[
      {line:"procedure Dijkstra(G, s):",         t:[]},
      {line:"  dist[s]←0; dist[v]←∞ ∀v≠s",    t:['init']},
      {line:"  Q ← all nodes (min-heap)",        t:['init']},
      {line:"  while Q ≠ ∅:",                    t:['extract','examine','relax']},
      {line:"    u ← extract-min(Q)",             t:['extract']},
      {line:"    for each (v,w) ∈ adj(u):",       t:['examine','relax']},
      {line:"      if dist[u]+w < dist[v]:",       t:['examine']},
      {line:"        dist[v] ← dist[u]+w",         t:['relax']},
      {line:"        prev[v] ← u  // update path",t:['relax']},
    ]},
};

function PseudoCode({lines,curT,color}){
  return(
    <div style={{background:"#f8fafc",borderRadius:10,padding:"7px",border:"1px solid #f1f5f9"}}>
      {lines.map((l,i)=>{
        const on=l.t.includes(curT);
        return(
          <div key={i} style={{display:"flex",gap:5,alignItems:"flex-start",padding:"2px 5px",borderRadius:4,margin:"1px 0",
            background:on?color+"1a":"transparent",border:`1px solid ${on?color+"55":"transparent"}`,transition:"all 0.15s"}}>
            <span style={{fontSize:8.5,color:"#e2e8f0",minWidth:10,paddingTop:2,fontFamily:"monospace",flexShrink:0}}>{i+1}</span>
            <span style={{fontSize:10,fontFamily:"'Courier New',monospace",lineHeight:1.5,
              color:on?color:"#94a3b8",fontWeight:on?700:400,whiteSpace:"pre",transition:"all 0.15s"}}>
              {l.line}
            </span>
          </div>
        );
      })}
    </div>
  );
}

export default function App(){
  const [algo,   setAlgo]  = useState("bfs");
  const [start,  setStart] = useState(null);
  const [steps,  setSteps] = useState([]);
  const [idx,    setIdx]   = useState(0);
  const [play,   setPlay]  = useState(false);
  const [speed,  setSpeed] = useState(1);

  const timerRef=useRef(null), speedRef=useRef(speed);
  useEffect(()=>{speedRef.current=speed;},[speed]);

  const launch=useCallback((s,a)=>{
    const fn=(a||algo)==="bfs"?bfsSteps:(a||algo)==="dfs"?dfsSteps:dijkstraSteps;
    setSteps(fn(s)); setIdx(0); setPlay(false); setStart(s);
  },[algo]);

  useEffect(()=>{if(start)launch(start,algo);},[algo]);

  useEffect(()=>{
    clearInterval(timerRef.current);
    if(play) timerRef.current=setInterval(()=>{
      setIdx(i=>{if(i>=steps.length-1){setPlay(false);return steps.length-1;}return i+1;});
    },Math.max(380,1500/speedRef.current));
    return()=>clearInterval(timerRef.current);
  },[play,steps,speed]);

  const am=AM[algo];
  const cur=steps[idx]||{visited:new Set(),current:null,frontier:new Set(),struct:[],edge:null,type:'',dist:{},settled:new Set(),desc:"Click any node to begin."};
  const isDijk=algo==="dijkstra";

  function nodeColor(id){
    if(cur.current===id) return "#f97316";
    if(isDijk){
      if(cur.settled?.has(id)) return am.color;
      if(cur.frontier&&!cur.frontier.has(id)&&cur.settled&&!cur.settled.has(id)) return "#f8fafc";
      return am.light;
    }
    if(cur.visited?.has(id)) return am.color;
    if(cur.frontier?.has(id)) return am.light;
    return "#f8fafc";
  }
  function nodeText(id){
    const c=nodeColor(id);
    return c===am.color||c==="#f97316"?"#fff":"#334155";
  }
  function edgeColor(a,b){
    const ae=cur.edge;
    if(ae&&((ae[0]===a&&ae[1]===b)||(ae[0]===b&&ae[1]===a))) return cur.type==='relax'?"#10b981":"#f97316";
    if(isDijk){
      const sa=cur.settled?.has(a), sb=cur.settled?.has(b);
      return sa&&sb?am.color+"88":"#e2e8f0";
    }
    return (cur.visited?.has(a)&&cur.visited?.has(b))?am.color+"88":"#e2e8f0";
  }
  function edgeW(a,b){return EDGES_W.find(e=>(e[0]===a&&e[1]===b)||(e[0]===b&&e[1]===a))?.[2];}

  return(
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"14px 22px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:920,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
          <div>
            <h1 style={{fontSize:19,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Graph Traversal</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>BFS · DFS · Dijkstra · click a node to start</p>
          </div>
          <div style={{display:"flex",background:"#f1f5f9",borderRadius:10,padding:3,gap:2}}>
            {Object.entries(AM).map(([k,v])=>(
              <button key={k} onClick={()=>setAlgo(k)}
                style={{padding:"5px 14px",borderRadius:8,border:"none",fontSize:11,fontWeight:700,
                  background:algo===k?"#fff":"transparent",color:algo===k?v.color:"#64748b",
                  boxShadow:algo===k?"0 1px 4px rgba(0,0,0,0.1)":"none",
                  cursor:"pointer",transition:"all 0.2s"}}>
                {k==="dijkstra"?"Dijkstra":k.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",overflow:"hidden",maxWidth:920,margin:"0 auto",width:"100%",
        padding:"8px 18px 12px",boxSizing:"border-box",gap:14}}>

        {/* Left: graph + pseudocode */}
        <div style={{flex:1,display:"flex",flexDirection:"column",gap:8,minWidth:0}}>
          <svg viewBox="0 0 630 320" width="100%" style={{display:"block",maxHeight:250}}>
            {/* Edge weights */}
            {EDGES_W.map(([a,b,w])=>{
              const na=NODES[a],nb=NODES[b];
              const mx=(na.x+nb.x)/2, my=(na.y+nb.y)/2;
              const ec=edgeColor(a,b);
              return(
                <g key={`${a}${b}`}>
                  <line x1={na.x} y1={na.y} x2={nb.x} y2={nb.y}
                    stroke={ec} strokeWidth={ec!=="#e2e8f0"?2.5:1.5}
                    style={{transition:"stroke 0.3s"}}/>
                  {/* Weight label */}
                  <rect x={mx-7} y={my-8} width={14} height={14} rx={3} fill="#fff" stroke="#e2e8f0" strokeWidth={1}/>
                  <text x={mx} y={my+4} textAnchor="middle" fontSize={9} fontWeight={700}
                    fill={ec!=="#e2e8f0"?ec:"#94a3b8"} fontFamily="system-ui,sans-serif"
                    style={{transition:"fill 0.3s"}}>{w}</text>
                </g>
              );
            })}
            {/* Nodes */}
            {Object.entries(NODES).map(([id,n])=>{
              const bg=nodeColor(id), fg=nodeText(id);
              const dist=isDijk?cur.dist?.[id]:null;
              const distStr=dist===undefined||dist===null?'':(dist===Infinity?'∞':dist);
              return(
                <g key={id} style={{cursor:"pointer"}} onClick={()=>launch(id)}>
                  <circle cx={n.x} cy={n.y} r={22} fill={bg}
                    stroke={id===start?am.color:"#e2e8f0"} strokeWidth={id===start?2.5:1.5}
                    style={{transition:"fill 0.3s"}}/>
                  <text x={n.x} y={n.y+(isDijk?-1:5)} textAnchor="middle" fontSize={13} fontWeight={700}
                    fill={fg} fontFamily="system-ui,sans-serif" style={{pointerEvents:"none",transition:"fill 0.3s"}}>
                    {id}
                  </text>
                  {isDijk&&distStr&&(
                    <text x={n.x} y={n.y+12} textAnchor="middle" fontSize={9} fontWeight={700}
                      fill={bg===am.color||bg==="#f97316"?"rgba(255,255,255,0.9)":am.color}
                      fontFamily="monospace" style={{pointerEvents:"none"}}>
                      {distStr}
                    </text>
                  )}
                </g>
              );
            })}
          </svg>

          {/* Legend */}
          <div style={{display:"flex",gap:12,justifyContent:"center",flexWrap:"wrap"}}>
            {[["Current","#f97316"],
              isDijk?["Settled",am.color]:["Visited",am.color],
              isDijk?["Remaining",am.light]:["In Queue/Stack",am.light],
              ["Unvisited","#f8fafc"]].map(([l,c])=>(
              <div key={l} style={{display:"flex",alignItems:"center",gap:4,fontSize:10,color:"#64748b"}}>
                <div style={{width:12,height:12,borderRadius:"50%",background:c,border:"1.5px solid #e2e8f0"}}/>
                {l}
              </div>
            ))}
            {isDijk&&<div style={{display:"flex",alignItems:"center",gap:4,fontSize:10,color:"#10b981"}}>
              <div style={{width:18,height:2,background:"#10b981",borderRadius:1}}/>Relaxed edge
            </div>}
          </div>

          {/* Pseudocode */}
          <div>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:4}}>
              Algorithm — active step highlighted
            </div>
            <PseudoCode lines={am.pseudo} curT={cur.type} color={am.color}/>
          </div>
        </div>

        {/* Right panel */}
        <div style={{width:218,display:"flex",flexDirection:"column",gap:8,flexShrink:0}}>
          {/* Algorithm info */}
          <div style={{background:am.light,border:`1.5px solid ${am.border}`,borderRadius:10,padding:"11px"}}>
            <div style={{fontSize:11,fontWeight:800,color:am.color,marginBottom:3}}>{am.label}</div>
            <p style={{fontSize:11,lineHeight:1.6,color:"#334155",margin:0}}>{am.note}</p>
          </div>

          {/* Struct panel */}
          <div style={{background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,padding:"10px",flex:1,overflow:"hidden"}}>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:7}}>
              {am.structLabel}
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:4,overflow:"auto",maxHeight:160}}>
              {cur.struct.map((n,i)=>{
                const d=isDijk?(cur.dist?.[n]===Infinity?'∞':cur.dist?.[n]):null;
                return(
                  <div key={`${n}${i}`} style={{display:"flex",justifyContent:"space-between",alignItems:"center",
                    background:am.light,border:`1px solid ${am.border}`,borderRadius:7,
                    padding:"4px 9px",fontSize:12,fontWeight:700,color:am.color}}>
                    <span>{n}</span>
                    {isDijk&&d!==null&&<span style={{fontSize:10,opacity:0.8}}>dist={d}</span>}
                  </div>
                );
              })}
              {cur.struct.length===0&&<span style={{fontSize:10,color:"#e2e8f0",fontStyle:"italic"}}>empty</span>}
            </div>
            {isDijk&&cur.settled?.size>0&&(
              <div style={{marginTop:8,paddingTop:7,borderTop:"1px solid #f1f5f9"}}>
                <div style={{fontSize:9,fontWeight:700,color:am.color,letterSpacing:"0.06em",textTransform:"uppercase",marginBottom:4}}>
                  Settled
                </div>
                <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
                  {[...cur.settled].map(n=>(
                    <span key={n} style={{background:am.color,color:"#fff",borderRadius:6,
                      padding:"2px 8px",fontSize:11,fontWeight:700}}>{n}</span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Step description */}
          <div style={{background:"#fff",border:"1px solid #f1f5f9",borderRadius:10,padding:"9px 11px"}}>
            <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:4}}>
              Step {idx} / {Math.max(0,steps.length-1)}
            </div>
            <p style={{fontSize:11,lineHeight:1.6,color:"#334155",margin:0,minHeight:32}}>
              {cur.desc}
            </p>
          </div>

          {/* Controls */}
          <div style={{display:"flex",flexDirection:"column",gap:6}}>
            <div style={{display:"flex",gap:5}}>
              <button onClick={()=>{setIdx(0);setPlay(false);}} style={{flex:1,padding:"6px",border:"1px solid #e2e8f0",borderRadius:8,background:"#fff",color:"#64748b",fontSize:12,cursor:"pointer"}}>⏮</button>
              <button onClick={()=>setIdx(i=>Math.max(0,i-1))} style={{flex:1,padding:"6px",border:"1px solid #e2e8f0",borderRadius:8,background:"#fff",color:"#64748b",fontSize:13,cursor:"pointer"}}>‹</button>
              <button onClick={()=>{if(steps.length&&idx<steps.length-1)setPlay(p=>!p);}}
                style={{flex:1,padding:"6px",borderRadius:8,border:"none",fontSize:13,cursor:"pointer",
                  background:play?"#64748b":am.color,color:"#fff",transition:"background 0.2s"}}>
                {play?"⏸":"▶"}
              </button>
              <button onClick={()=>setIdx(i=>Math.min(steps.length-1,i+1))} style={{flex:1,padding:"6px",border:"1px solid #e2e8f0",borderRadius:8,background:"#fff",color:"#64748b",fontSize:13,cursor:"pointer"}}>›</button>
            </div>
            <div style={{display:"flex",alignItems:"center",gap:7}}>
              <span style={{fontSize:9,color:"#94a3b8",fontWeight:700,letterSpacing:"0.08em"}}>SPEED</span>
              <input type="range" min={0.5} max={4} step={0.5} value={speed}
                onChange={e=>setSpeed(+e.target.value)}
                style={{flex:1,accentColor:am.color,cursor:"pointer"}}/>
              <span style={{fontSize:11,fontWeight:800,color:am.color,minWidth:20}}>{speed}×</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
