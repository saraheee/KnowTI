import { useState } from "react";

/* ─── Connective colours ──────────────────────────────────────────────── */
const TC = { "¬":"#dc2626","∧":"#2563eb","∨":"#059669","→":"#7c3aed","↔":"#0891b2" };
const atomColor = s => ({p:"#2563eb",q:"#059669",r:"#d97706",s:"#7c3aed",w:"#0891b2",a:"#dc2626",b:"#d97706",c:"#6366f1",d:"#10b981",f:"#ef4444",h:"#059669",l:"#2563eb",m:"#dc2626"}[s]||"#475569");

function colorToken(tok) {
  if(TC[tok]) return TC[tok];
  if(tok.length===1) return atomColor(tok);
  return "#475569";
}
function ColoredFormula({ fm }) {
  return <>{[...fm].map((ch,i)=><span key={i} style={{color:colorToken(ch),fontWeight:TC[ch]?800:600}}>{ch}</span>)}</>;
}

/* ─── Puzzles ─────────────────────────────────────────────────────────── */
// blanks: array of string (fixed display token) or {opts:[...]} (blank slot)
const PUZZLES = [
  { nl:"It rains and the streets are wet.",
    atoms:[{s:"p",d:"it rains"},{s:"r",d:"the streets are wet"}],
    answer:"p∧r", palette:["p","r","¬","∧","∨","→","↔","(",")"],
    blanks:[{opts:["p","r","¬p"]},"∧",{opts:["r","p","¬r"]}],
    hint:"'and' translates to ∧. One atomic proposition on each side.",
    explain:"p ∧ r — conjunction. True only when both p and r are true." },
  { nl:"If the alarm sounds, the police arrive.",
    atoms:[{s:"a",d:"the alarm sounds"},{s:"p",d:"the police arrive"}],
    answer:"a→p", palette:["a","p","¬","∧","∨","→","↔","(",")"],
    blanks:["a",{opts:["→","∧","∨","↔"]},"p"],
    hint:"'If … then' is material implication →. The alarm is the antecedent (left of →).",
    explain:"a → p — false only when the alarm sounds (a=T) but no police arrive (p=F)." },
  { nl:"The server fails only if power is cut.",
    atoms:[{s:"f",d:"the server fails"},{s:"p",d:"power is cut"}],
    answer:"f→p", palette:["f","p","¬","∧","∨","→","↔","(",")"],
    blanks:["f",{opts:["→","↔","∧","∨"]},"p"],
    hint:"'A only if B' means A → B. 'Only if' marks the right side — the consequent.",
    explain:"f → p — 'only if power is cut' puts p on the right of →." },
  { nl:"Neither the light is on nor the door is open.",
    atoms:[{s:"l",d:"the light is on"},{s:"d",d:"the door is open"}],
    answer:"¬l∧¬d", palette:["l","d","¬","∧","∨","→","(",")"],
    blanks:["¬l",{opts:["∧","∨","→"]},"¬d"],
    hint:"'Neither A nor B' = ¬A ∧ ¬B — negate each, then join with ∧.",
    explain:"¬l ∧ ¬d — equivalent to ¬(l ∨ d) by De Morgan's law." },
  { nl:"If it is cold and raining, we stay indoors.",
    atoms:[{s:"c",d:"it is cold"},{s:"r",d:"it is raining"},{s:"s",d:"we stay indoors"}],
    answer:"(c∧r)→s", palette:["c","r","s","¬","∧","∨","→","(",")"],
    blanks:["(c∧r)",{opts:["→","∧","↔","∨"]},"s"],
    hint:"The compound antecedent (c∧r) needs parentheses before the →.",
    explain:"(c∧r) → s — both conditions together imply staying indoors." },
  { nl:"You pass if and only if you study and attend.",
    atoms:[{s:"p",d:"you pass"},{s:"s",d:"you study"},{s:"a",d:"you attend"}],
    answer:"p↔(s∧a)", palette:["p","s","a","¬","∧","∨","→","↔","(",")"],
    blanks:["p",{opts:["↔","→","∧","∨"]},"(s∧a)"],
    hint:"'If and only if' → biconditional ↔. The right side is a conjunction in parentheses.",
    explain:"p ↔ (s∧a) — passing and (studying and attending) always have the same truth value." },
];

const MSGS = { correct:["✓ Correct!","⭐ Nailed it!","✓ Exactly right!","⭐ Perfect!"], wrong:["✗ Not quite — try again.","✗ Check the connective.","✗ Almost — look at the hint."] };

export default function App() {
  const [mode,   setMode]   = useState("build"); // "build" | "blanks"
  const [pi,     setPi]     = useState(0);
  const [built,  setBuilt]  = useState("");
  const [blanks, setBlanks] = useState({});   // {blankIdx: chosenOpt}
  const [result, setResult] = useState(null); // null|"correct"|"wrong"
  const [hint,   setHint]   = useState(false);
  const [score,  setScore]  = useState(0);

  const puzz = PUZZLES[pi];

  const resetPuzzle = (newPi=pi, newMode=mode) => {
    setPi(newPi); setBuilt(""); setBlanks({}); setResult(null); setHint(false); setMode(newMode);
  };

  const check = () => {
    const target = puzz.answer;
    let attempt;
    if(mode==="build") {
      attempt = built.replace(/\s/g,"");
    } else {
      // reconstruct from blanks template
      let bIdx=0;
      attempt = puzz.blanks.map(t=>{
        if(typeof t==="string") return t;
        const val = blanks[bIdx++]||"";
        return val;
      }).join("").replace(/\s/g,"");
    }
    const ok = attempt === target;
    setResult(ok?"correct":"wrong");
    if(ok) setScore(s=>s+1);
  };

  const next = () => {
    if(pi<PUZZLES.length-1) resetPuzzle(pi+1);
    else resetPuzzle(0);
  };

  // Blanks mode helpers
  const blankCount = puzz.blanks.filter(t=>typeof t!=="string").length;
  const blanksFilled = Object.keys(blanks).length === blankCount;
  const cycleBlanks = (idx) => {
    const slot = puzz.blanks.filter(t=>typeof t!=="string")[idx];
    if(!slot) return;
    const opts = slot.opts;
    const cur = blanks[idx];
    const ci = opts.indexOf(cur);
    setBlanks(b=>({...b,[idx]:opts[(ci+1)%opts.length]}));
    setResult(null);
  };

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"13px 22px 9px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:820,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
          <div>
            <h1 style={{fontSize:19,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Propositional Logic</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>Translate English statements into logic formulas</p>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{fontSize:12,color:"#94a3b8"}}>
              ⭐ <span style={{fontWeight:700,color:"#0f172a"}}>{score}</span> correct
            </div>
            <div style={{display:"flex",background:"#f1f5f9",borderRadius:10,padding:3,gap:2}}>
              {[["build","🔨 Build"],["blanks","🧩 Complete"]].map(([m,l])=>(
                <button key={m} onClick={()=>resetPuzzle(pi,m)}
                  style={{padding:"5px 13px",borderRadius:8,border:"none",fontSize:11,fontWeight:700,
                    background:mode===m?"#fff":"transparent",color:mode===m?"#0f172a":"#64748b",
                    boxShadow:mode===m?"0 1px 4px rgba(0,0,0,0.1)":"none",cursor:"pointer",transition:"all 0.2s"}}>
                  {l}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",flexDirection:"column",padding:"12px 22px",maxWidth:820,margin:"0 auto",width:"100%",boxSizing:"border-box",gap:12,overflow:"auto"}}>

        {/* Progress dots */}
        <div style={{display:"flex",gap:6,justifyContent:"center"}}>
          {PUZZLES.map((_,i)=>(
            <div key={i} onClick={()=>resetPuzzle(i)}
              style={{width:i===pi?24:8,height:8,borderRadius:4,cursor:"pointer",
                background:i===pi?"#0f172a":i<pi?"#a7f3d0":"#f1f5f9",transition:"all 0.3s"}}/>
          ))}
        </div>

        {/* Puzzle card */}
        <div style={{background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:14,padding:"18px 20px"}}>
          <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:8}}>
            Statement {pi+1} of {PUZZLES.length}
          </div>
          <p style={{fontSize:17,fontWeight:700,color:"#0f172a",margin:"0 0 14px",lineHeight:1.4,fontStyle:"italic"}}>
            "{puzz.nl}"
          </p>
          {/* Atom legend */}
          <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
            {puzz.atoms.map(a=>(
              <div key={a.s} style={{display:"flex",alignItems:"center",gap:5,padding:"4px 11px",borderRadius:8,
                background:"#fff",border:`1.5px solid ${atomColor(a.s)}22`,}}>
                <span style={{fontSize:14,fontWeight:800,fontFamily:"monospace",color:atomColor(a.s)}}>{a.s}</span>
                <span style={{fontSize:11,color:"#475569"}}>= {a.d}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── BUILD MODE ── */}
        {mode==="build"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            {/* Formula display */}
            <div style={{background:"#1e1e2e",borderRadius:12,padding:"14px 18px",minHeight:56,
              display:"flex",alignItems:"center",flexWrap:"wrap",gap:4}}>
              {built
                ? <span style={{fontFamily:"'Courier New',monospace",fontSize:22,letterSpacing:"0.05em"}}>
                    <ColoredFormula fm={built}/>
                  </span>
                : <span style={{color:"#585b70",fontSize:13,fontStyle:"italic"}}>Click symbols below to build your formula…</span>}
            </div>
            {/* Palette */}
            <div style={{display:"flex",gap:6,flexWrap:"wrap",alignItems:"center"}}>
              {puzz.palette.map(tok=>(
                <button key={tok} onClick={()=>{setBuilt(b=>b+tok);setResult(null);}}
                  style={{padding:"8px 14px",borderRadius:9,border:`1.5px solid ${colorToken(tok)}44`,
                    background:colorToken(tok)+"11",color:colorToken(tok),
                    fontSize:TC[tok]?18:16,fontWeight:800,fontFamily:"monospace",cursor:"pointer",
                    transition:"all 0.1s",minWidth:36,textAlign:"center"}}>
                  {tok}
                </button>
              ))}
              <button onClick={()=>{setBuilt(b=>b.slice(0,-1));setResult(null);}}
                style={{padding:"8px 12px",borderRadius:9,border:"1px solid #e2e8f0",background:"#fff",color:"#64748b",fontSize:14,cursor:"pointer"}}>⌫</button>
              <button onClick={()=>{setBuilt("");setResult(null);}}
                style={{padding:"8px 12px",borderRadius:9,border:"1px solid #e2e8f0",background:"#fff",color:"#64748b",fontSize:14,cursor:"pointer"}}>✕</button>
            </div>
          </div>
        )}

        {/* ── BLANKS MODE ── */}
        {mode==="blanks"&&(
          <div style={{display:"flex",flexDirection:"column",gap:10}}>
            <div style={{fontSize:11,color:"#64748b",fontStyle:"italic"}}>
              Fixed tokens are shown — click the <span style={{fontWeight:700,color:"#7c3aed"}}>purple slots</span> to cycle through options:
            </div>
            <div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap",padding:"14px 18px",
              background:"#f8fafc",borderRadius:12,border:"1px solid #f1f5f9",minHeight:56}}>
              {(()=>{let bi=0; return puzz.blanks.map((t,i)=>{
                if(typeof t==="string") return(
                  <span key={i} style={{fontFamily:"monospace",fontSize:20,fontWeight:700}}>
                    <ColoredFormula fm={t}/>
                  </span>
                );
                const idx=bi++;
                const chosen=blanks[idx];
                return(
                  <button key={i} onClick={()=>{cycleBlanks(idx);setResult(null);}}
                    style={{padding:"6px 14px",borderRadius:8,fontFamily:"monospace",fontSize:20,fontWeight:800,
                      border:`2px solid ${chosen?"#7c3aed44":"#7c3aed"}`,
                      background:chosen?"#f5f3ff":"#fff",color:chosen?colorToken(chosen):"#7c3aed",
                      cursor:"pointer",minWidth:40,textAlign:"center"}}>
                    {chosen||"?"}
                  </button>
                );
              });})()}
            </div>
            <div style={{fontSize:10,color:"#94a3b8",fontStyle:"italic"}}>
              Options for each slot cycle on each click. Fill all slots then check.
            </div>
          </div>
        )}

        {/* Hint */}
        {hint&&(
          <div style={{background:"#fffbeb",border:"1px solid #fde68a",borderRadius:10,padding:"10px 14px",fontSize:12,color:"#92400e",fontStyle:"italic"}}>
            💡 {puzz.hint}
          </div>
        )}

        {/* Result */}
        {result==="correct"&&(
          <div style={{background:"#f0fdf4",border:"1.5px solid #a7f3d0",borderRadius:12,padding:"14px 18px"}}>
            <div style={{fontSize:15,fontWeight:800,color:"#059669",marginBottom:6}}>
              {MSGS.correct[pi%MSGS.correct.length]}  <span style={{fontFamily:"monospace",fontSize:17}}><ColoredFormula fm={puzz.answer}/></span>
            </div>
            <p style={{fontSize:12,color:"#065f46",margin:0,lineHeight:1.6}}>{puzz.explain}</p>
          </div>
        )}
        {result==="wrong"&&(
          <div style={{background:"#fef2f2",border:"1px solid #fecaca",borderRadius:10,padding:"10px 14px",fontSize:12,color:"#dc2626"}}>
            {MSGS.wrong[pi%MSGS.wrong.length]}
          </div>
        )}

        {/* Action buttons */}
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          {!result&&(
            <>
              <button onClick={check} disabled={mode==="build"?!built:!blanksFilled}
                style={{padding:"10px 24px",borderRadius:10,border:"none",fontSize:13,fontWeight:700,
                  background:(mode==="build"?built:blanksFilled)?"#0f172a":"#e2e8f0",
                  color:(mode==="build"?built:blanksFilled)?"#fff":"#94a3b8",cursor:(mode==="build"?built:blanksFilled)?"pointer":"not-allowed"}}>
                Check →
              </button>
              <button onClick={()=>setHint(true)}
                style={{padding:"10px 18px",borderRadius:10,border:"1px solid #fde68a",background:"#fffbeb",color:"#d97706",fontSize:13,fontWeight:600,cursor:"pointer"}}>
                💡 Hint
              </button>
            </>
          )}
          {result==="correct"&&(
            <button onClick={next}
              style={{padding:"10px 24px",borderRadius:10,border:"none",background:"#059669",color:"#fff",fontSize:13,fontWeight:700,cursor:"pointer"}}>
              {pi<PUZZLES.length-1?"Next puzzle →":"Start over ↺"}
            </button>
          )}
          {result==="wrong"&&(
            <button onClick={()=>{setResult(null);if(mode==="build")setBuilt(""); else setBlanks({});}}
              style={{padding:"10px 18px",borderRadius:10,border:"1px solid #e2e8f0",background:"#fff",color:"#64748b",fontSize:13,fontWeight:600,cursor:"pointer"}}>
              Try again
            </button>
          )}
        </div>

        {/* Connective cheatsheet */}
        <div style={{display:"flex",gap:12,flexWrap:"wrap",padding:"10px 14px",background:"#f8fafc",borderRadius:10,border:"1px solid #f1f5f9"}}>
          {Object.entries(TC).map(([sym,col])=>{
            const name={"¬":"not","∧":"and","∨":"or","→":"if…then","↔":"iff"}[sym];
            return <span key={sym} style={{fontSize:11,color:"#64748b"}}>
              <span style={{fontFamily:"monospace",fontWeight:800,color:col,fontSize:14}}>{sym}</span>
              {" = "}{name}
            </span>;
          })}
        </div>
      </div>
    </div>
  );
}
