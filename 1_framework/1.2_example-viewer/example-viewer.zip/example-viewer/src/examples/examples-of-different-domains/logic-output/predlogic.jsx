import { useState } from "react";

/* ─── Colours ─────────────────────────────────────────────────────────── */
const QC = { "∀":"#7c3aed","∃":"#d97706" };
const CONNC = { "¬":"#dc2626","∧":"#2563eb","∨":"#059669","→":"#7c3aed","↔":"#0891b2" };
const VARC = { x:"#e11d48",y:"#0891b2",z:"#10b981" };
const PREDC = { H:"#2563eb",M:"#dc2626",G:"#d97706",L:"#059669",S:"#7c3aed",P:"#0891b2",C:"#059669",T:"#f59e0b",F:"#6366f1",K:"#ec4899" };
function tokColor(t){
  if(QC[t]) return QC[t];
  if(CONNC[t]) return CONNC[t];
  if(VARC[t]) return VARC[t];
  if(PREDC[t]) return PREDC[t];
  return "#64748b";
}
function ColoredFm({ fm }){
  const tokens = fm.match(/∀|∃|¬|∧|∨|→|↔|[A-Z]|[xyz]|[(),≠]/g)||[];
  return <>{tokens.map((t,i)=><span key={i} style={{color:tokColor(t),fontWeight:QC[t]||CONNC[t]?800:600}}>{t}</span>)}</>;
}

/* ─── Puzzles ─────────────────────────────────────────────────────────── */
// tokens: tokenised answer for reorder mode (use same chars as answer)
const PUZZLES = [
  { nl:"All humans are mortal.",
    preds:[{s:"H",arity:1,d:"is human"},{s:"M",arity:1,d:"is mortal"}],
    answer:"∀x(H(x)→M(x))", palette:["∀","∃","x","y","H","M","¬","∧","∨","→","↔","(",")",""],
    tokens:["∀","x","(","H","(","x",")","→","M","(","x",")",")"],
    hint:"Start with ∀x (for all x), then express 'if x is human, then x is mortal' with →.",
    explain:"∀x(H(x) → M(x)): for every object x, if H(x) then M(x). The standard translation of 'All A are B'.",
    note:"'All A are B' always uses ∀ with →, never with ∧!" },
  { nl:"Some human is not mortal.",
    preds:[{s:"H",arity:1,d:"is human"},{s:"M",arity:1,d:"is mortal"}],
    answer:"∃x(H(x)∧¬M(x))", palette:["∀","∃","x","y","H","M","¬","∧","∨","→","(",")",""],
    tokens:["∃","x","(","H","(","x",")","∧","¬","M","(","x",")",")"],
    hint:"Use ∃ for 'some'. Combine 'is human' AND 'is NOT mortal' with ∧.",
    explain:"∃x(H(x) ∧ ¬M(x)): there exists an x that is both human and not mortal.",
    note:"'Some A is B' uses ∃ with ∧, not →!" },
  { nl:"Everyone loves at least one person.",
    preds:[{s:"L",arity:2,d:"loves (x loves y)"}],
    answer:"∀x∃yL(x,y)", palette:["∀","∃","x","y","L","¬","∧","∨","→","(",")",""],
    tokens:["∀","x","∃","y","L","(","x",",","y",")"],
    hint:"For every x (∀x), there exists some y (∃y) such that x loves y.",
    explain:"∀x∃y L(x,y): each person x can love a different y — ∃y is inside ∀x.",
    note:"Quantifier order matters! Compare with the next puzzle." },
  { nl:"There is someone who is loved by everyone.",
    preds:[{s:"L",arity:2,d:"loves (x loves y)"}],
    answer:"∃y∀xL(x,y)", palette:["∀","∃","x","y","L","¬","∧","∨","→","(",")",""],
    tokens:["∃","y","∀","x","L","(","x",",","y",")"],
    hint:"First fix one specific y (∃y), then say all x love that very y (∀x).",
    explain:"∃y∀x L(x,y): the same y is loved by everyone — ∃y is outside ∀x.",
    note:"∃y∀x ≠ ∀x∃y — this is a stronger, different claim!" },
  { nl:"No one loves themselves.",
    preds:[{s:"L",arity:2,d:"loves (x loves y)"}],
    answer:"∀x¬L(x,x)", palette:["∀","∃","x","y","L","¬","∧","∨","→","(",")",""],
    tokens:["∀","x","¬","L","(","x",",","x",")"],
    hint:"'No one' = 'for all x, NOT'. Apply ¬ directly to L(x,x).",
    explain:"∀x ¬L(x,x): for every x, it is not the case that x loves x." ,
    note:"'No one is A' = ∀x ¬A(x). Equivalent to ¬∃x A(x)." },
  { nl:"Every tall student knows at least one professor.",
    preds:[{s:"T",arity:1,d:"is tall"},{s:"S",arity:1,d:"is a student"},{s:"P",arity:1,d:"is a professor"},{s:"K",arity:2,d:"knows (x knows y)"}],
    answer:"∀x((T(x)∧S(x))→∃y(P(y)∧K(x,y)))", palette:["∀","∃","x","y","T","S","P","K","¬","∧","∨","→","(",")",""],
    tokens:["∀","x","(","(","T","(","x",")","∧","S","(","x",")",")","→","∃","y","(","P","(","y",")","∧","K","(","x",",","y",")",")",")" ],
    hint:"Antecedent: x is tall AND a student (T(x)∧S(x)). Consequent: ∃y such that y is a professor AND x knows y.",
    explain:"∀x((T(x)∧S(x)) → ∃y(P(y)∧K(x,y))): complex but follows the 'All A are B' and 'Some A is B' patterns.",
    note:"Compound predicates in the antecedent are joined with ∧." },
];

export default function App() {
  const [mode,   setMode]   = useState("build");
  const [pi,     setPi]     = useState(0);
  const [built,  setBuilt]  = useState("");
  const [source, setSource] = useState(()=>shuffled(PUZZLES[0].tokens));
  const [placed, setPlaced] = useState([]);
  const [result, setResult] = useState(null);
  const [hint,   setHint]   = useState(false);
  const [score,  setScore]  = useState(0);

  const puzz = PUZZLES[pi];

  function shuffled(arr){ const a=[...arr]; for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a.map((t,i)=>({t,k:i})); }

  const resetPuzzle = (newPi=pi, newMode=mode) => {
    const p = PUZZLES[newPi];
    setPi(newPi); setBuilt(""); setResult(null); setHint(false); setMode(newMode);
    setSource(shuffled(p.tokens)); setPlaced([]);
  };

  const check = () => {
    const attempt = (mode==="build"?built:placed.map(t=>t.t).join("")).replace(/\s/g,"");
    const target  = puzz.answer.replace(/\s/g,"");
    const ok = attempt === target;
    setResult(ok?"correct":"wrong");
    if(ok) setScore(s=>s+1);
  };

  // Reorder helpers
  const addToken = (tok) => {
    setPlaced(p=>[...p,tok]);
    setSource(s=>s.filter(t=>t.k!==tok.k));
    setResult(null);
  };
  const removeToken = (tok) => {
    setPlaced(p=>p.filter(t=>t.k!==tok.k));
    setSource(s=>[...s,tok]);
    setResult(null);
  };

  return(
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"13px 22px 9px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:860,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
          <div>
            <h1 style={{fontSize:19,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Predicate Logic</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>First-order logic · quantifiers · predicates</p>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <div style={{fontSize:12,color:"#94a3b8"}}>⭐ <span style={{fontWeight:700,color:"#0f172a"}}>{score}</span></div>
            <div style={{display:"flex",background:"#f1f5f9",borderRadius:10,padding:3,gap:2}}>
              {[["build","🔨 Build"],["reorder","🔀 Arrange"]].map(([m,l])=>(
                <button key={m} onClick={()=>resetPuzzle(pi,m)}
                  style={{padding:"5px 12px",borderRadius:8,border:"none",fontSize:11,fontWeight:700,
                    background:mode===m?"#fff":"transparent",color:mode===m?"#0f172a":"#64748b",
                    boxShadow:mode===m?"0 1px 4px rgba(0,0,0,0.1)":"none",cursor:"pointer",transition:"all 0.2s"}}>
                  {l}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",flexDirection:"column",padding:"10px 22px",maxWidth:860,margin:"0 auto",width:"100%",boxSizing:"border-box",gap:10,overflow:"auto"}}>

        {/* Progress */}
        <div style={{display:"flex",gap:6,justifyContent:"center"}}>
          {PUZZLES.map((_,i)=>(
            <div key={i} onClick={()=>resetPuzzle(i)}
              style={{width:i===pi?24:8,height:8,borderRadius:4,cursor:"pointer",
                background:i===pi?"#7c3aed":i<pi?"#ddd6fe":"#f1f5f9",transition:"all 0.3s"}}/>
          ))}
        </div>

        {/* Puzzle card */}
        <div style={{background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:14,padding:"16px 18px"}}>
          <div style={{fontSize:9,fontWeight:700,color:"#94a3b8",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:6}}>
            Puzzle {pi+1} / {PUZZLES.length}
          </div>
          <p style={{fontSize:16,fontWeight:700,color:"#0f172a",margin:"0 0 12px",lineHeight:1.4,fontStyle:"italic"}}>
            "{puzz.nl}"
          </p>
          {/* Predicates */}
          <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
            {puzz.preds.map(p=>(
              <div key={p.s} style={{display:"flex",alignItems:"center",gap:5,padding:"4px 11px",borderRadius:8,
                background:"#fff",border:`1.5px solid ${PREDC[p.s]}33`}}>
                <span style={{fontSize:14,fontWeight:800,fontFamily:"monospace",color:PREDC[p.s]}}>
                  {p.s}({p.arity===1?"x":"x,y"})
                </span>
                <span style={{fontSize:11,color:"#475569"}}>= {p.d}</span>
              </div>
            ))}
            {/* Variable legend */}
            <div style={{display:"flex",gap:6,alignItems:"center",marginLeft:4}}>
              {[["x","#e11d48"],["y","#0891b2"]].map(([v,c])=>(
                <span key={v} style={{fontSize:13,fontWeight:800,fontFamily:"monospace",color:c}}>{v}</span>
              ))}
              <span style={{fontSize:10,color:"#94a3b8"}}>= variables ranging over domain</span>
            </div>
          </div>
        </div>

        {/* ── BUILD MODE ── */}
        {mode==="build"&&(
          <div style={{display:"flex",flexDirection:"column",gap:9}}>
            <div style={{background:"#1e1e2e",borderRadius:12,padding:"12px 16px",minHeight:52,
              display:"flex",alignItems:"center",flexWrap:"wrap"}}>
              {built
                ? <span style={{fontFamily:"'Courier New',monospace",fontSize:19,letterSpacing:"0.04em"}}>
                    <ColoredFm fm={built}/>
                  </span>
                : <span style={{color:"#585b70",fontSize:12,fontStyle:"italic"}}>Click symbols to build your formula…</span>}
            </div>
            <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
              {/* Quantifiers */}
              {["∀","∃"].map(q=>(
                <button key={q} onClick={()=>{setBuilt(b=>b+q);setResult(null);}}
                  style={{padding:"7px 14px",borderRadius:9,border:`2px solid ${QC[q]}44`,
                    background:QC[q]+"11",color:QC[q],fontSize:18,fontWeight:900,fontFamily:"monospace",cursor:"pointer",minWidth:38}}>
                  {q}
                </button>
              ))}
              <div style={{width:1,background:"#f1f5f9",margin:"0 4px"}}/>
              {/* Variables */}
              {["x","y"].map(v=>(
                <button key={v} onClick={()=>{setBuilt(b=>b+v);setResult(null);}}
                  style={{padding:"7px 12px",borderRadius:9,border:`1.5px solid ${VARC[v]}55`,
                    background:VARC[v]+"11",color:VARC[v],fontSize:16,fontWeight:800,fontFamily:"monospace",cursor:"pointer"}}>
                  {v}
                </button>
              ))}
              <div style={{width:1,background:"#f1f5f9",margin:"0 4px"}}/>
              {/* Predicates */}
              {puzz.preds.map(p=>(
                <button key={p.s} onClick={()=>{setBuilt(b=>b+p.s);setResult(null);}}
                  style={{padding:"7px 12px",borderRadius:9,border:`1.5px solid ${PREDC[p.s]}55`,
                    background:PREDC[p.s]+"11",color:PREDC[p.s],fontSize:16,fontWeight:800,fontFamily:"monospace",cursor:"pointer"}}>
                  {p.s}
                </button>
              ))}
              <div style={{width:1,background:"#f1f5f9",margin:"0 4px"}}/>
              {/* Connectives */}
              {["¬","∧","∨","→","↔","(",")","," ].map(c=>(
                <button key={c} onClick={()=>{setBuilt(b=>b+c);setResult(null);}}
                  style={{padding:"7px 12px",borderRadius:9,border:`1.5px solid ${CONNC[c]?CONNC[c]+"44":"#e2e8f0"}`,
                    background:CONNC[c]?CONNC[c]+"11":"#f8fafc",color:CONNC[c]||"#64748b",
                    fontSize:CONNC[c]?18:15,fontWeight:CONNC[c]?800:600,fontFamily:"monospace",cursor:"pointer",minWidth:34}}>
                  {c}
                </button>
              ))}
              <button onClick={()=>{setBuilt(b=>b.slice(0,-1));setResult(null);}} style={{padding:"7px 11px",borderRadius:9,border:"1px solid #e2e8f0",background:"#fff",color:"#64748b",fontSize:14,cursor:"pointer"}}>⌫</button>
              <button onClick={()=>{setBuilt("");setResult(null);}} style={{padding:"7px 11px",borderRadius:9,border:"1px solid #e2e8f0",background:"#fff",color:"#64748b",fontSize:14,cursor:"pointer"}}>✕</button>
            </div>
          </div>
        )}

        {/* ── REORDER MODE ── */}
        {mode==="reorder"&&(
          <div style={{display:"flex",flexDirection:"column",gap:9}}>
            <div style={{fontSize:11,color:"#64748b",fontStyle:"italic"}}>
              Click tokens below to place them in sequence. Click a placed token to remove it.
            </div>
            {/* Placed tokens (target sequence) */}
            <div style={{background:"#1e1e2e",borderRadius:12,padding:"12px 16px",minHeight:52,
              display:"flex",alignItems:"center",gap:4,flexWrap:"wrap"}}>
              {placed.length>0
                ? placed.map((tok,i)=>(
                    <button key={tok.k} onClick={()=>removeToken(tok)}
                      style={{padding:"4px 9px",borderRadius:7,border:`1.5px solid ${tokColor(tok.t)}66`,
                        background:tokColor(tok.t)+"22",color:tokColor(tok.t),
                        fontSize:17,fontWeight:700,fontFamily:"monospace",cursor:"pointer"}}>
                      {tok.t}
                    </button>
                  ))
                : <span style={{color:"#585b70",fontSize:12,fontStyle:"italic"}}>Click tokens below to build the formula…</span>}
            </div>
            {/* Source tokens (shuffled) */}
            <div style={{display:"flex",gap:6,flexWrap:"wrap",padding:"12px 14px",
              background:"#f8fafc",borderRadius:12,border:"1px dashed #e2e8f0",minHeight:52}}>
              {source.length>0
                ? source.map(tok=>(
                    <button key={tok.k} onClick={()=>addToken(tok)}
                      style={{padding:"6px 12px",borderRadius:9,border:`1.5px solid ${tokColor(tok.t)}44`,
                        background:"#fff",color:tokColor(tok.t),
                        fontSize:17,fontWeight:700,fontFamily:"monospace",cursor:"pointer",
                        boxShadow:"0 1px 4px rgba(0,0,0,0.06)"}}>
                      {tok.t}
                    </button>
                  ))
                : <span style={{fontSize:11,color:"#cbd5e1",fontStyle:"italic"}}>all tokens placed</span>}
            </div>
          </div>
        )}

        {/* Hint */}
        {hint&&(
          <div style={{background:"#fffbeb",border:"1px solid #fde68a",borderRadius:10,padding:"10px 14px",fontSize:12,color:"#92400e",fontStyle:"italic"}}>
            💡 {puzz.hint}
          </div>
        )}

        {/* Result */}
        {result==="correct"&&(
          <div style={{background:"#f5f3ff",border:"1.5px solid #ddd6fe",borderRadius:12,padding:"14px 18px"}}>
            <div style={{fontSize:14,fontWeight:800,color:"#7c3aed",marginBottom:4}}>
              ✓ Correct! &nbsp;<span style={{fontFamily:"monospace",fontSize:16}}><ColoredFm fm={puzz.answer}/></span>
            </div>
            <p style={{fontSize:12,color:"#4c1d95",lineHeight:1.65,margin:"0 0 6px"}}>{puzz.explain}</p>
            <div style={{fontSize:11,background:"#fff",borderRadius:8,padding:"7px 11px",border:"1px solid #ddd6fe",color:"#6d28d9",fontWeight:600}}>📌 {puzz.note}</div>
          </div>
        )}
        {result==="wrong"&&(
          <div style={{background:"#fef2f2",border:"1px solid #fecaca",borderRadius:10,padding:"10px 14px",fontSize:12,color:"#dc2626"}}>
            ✗ Not quite. Check quantifier choice and order carefully.
          </div>
        )}

        {/* Buttons */}
        <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          {!result&&(
            <>
              <button onClick={check}
                disabled={mode==="build"?!built:placed.length===0}
                style={{padding:"9px 22px",borderRadius:10,border:"none",fontSize:13,fontWeight:700,
                  background:(mode==="build"?built:placed.length>0)?"#7c3aed":"#e2e8f0",
                  color:(mode==="build"?built:placed.length>0)?"#fff":"#94a3b8",
                  cursor:(mode==="build"?built:placed.length>0)?"pointer":"not-allowed"}}>
                Check →
              </button>
              <button onClick={()=>setHint(true)} style={{padding:"9px 16px",borderRadius:10,border:"1px solid #fde68a",background:"#fffbeb",color:"#d97706",fontSize:13,fontWeight:600,cursor:"pointer"}}>
                💡 Hint
              </button>
            </>
          )}
          {result==="correct"&&(
            <button onClick={()=>resetPuzzle(pi<PUZZLES.length-1?pi+1:0)}
              style={{padding:"9px 22px",borderRadius:10,border:"none",background:"#7c3aed",color:"#fff",fontSize:13,fontWeight:700,cursor:"pointer"}}>
              {pi<PUZZLES.length-1?"Next →":"Start over ↺"}
            </button>
          )}
          {result==="wrong"&&(
            <button onClick={()=>{setResult(null);if(mode==="build")setBuilt("");else{setPlaced([]);setSource(shuffled(puzz.tokens));}}}
              style={{padding:"9px 16px",borderRadius:10,border:"1px solid #e2e8f0",background:"#fff",color:"#64748b",fontSize:13,fontWeight:600,cursor:"pointer"}}>
              Try again
            </button>
          )}
        </div>

        {/* Quantifier cheatsheet */}
        <div style={{display:"flex",gap:16,flexWrap:"wrap",padding:"9px 14px",background:"#f8fafc",borderRadius:10,border:"1px solid #f1f5f9",fontSize:11,color:"#64748b"}}>
          <span><span style={{fontWeight:800,color:"#7c3aed",fontFamily:"monospace",fontSize:14}}>∀</span> = "for all" (universal)</span>
          <span><span style={{fontWeight:800,color:"#d97706",fontFamily:"monospace",fontSize:14}}>∃</span> = "there exists" (existential)</span>
          <span style={{color:"#dc2626",fontWeight:600}}>All A are B → ∀x(A(x)→B(x))</span>
          <span style={{color:"#059669",fontWeight:600}}>Some A is B → ∃x(A(x)∧B(x))</span>
        </div>
      </div>
    </div>
  );
}
