import { useState, useEffect, useRef, useCallback } from 'react';

export default function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [animationStep, setAnimationStep] = useState(0);
  const [showPositive, setShowPositive] = useState(true);
  const [connections, setConnections] = useState([]);
  const [hoveredPerson, setHoveredPerson] = useState(null);
  const animationRef = useRef();
  const stepRef = useRef(0);

  const people = [
    { id: 1, x: 300, y: 200, name: "Alex", isInitiator: true },
    { id: 2, x: 500, y: 150, name: "Sam" },
    { id: 3, x: 450, y: 280, name: "Jordan" },
    { id: 4, x: 200, y: 300, name: "Riley" },
    { id: 5, x: 350, y: 350, name: "Casey" },
    { id: 6, x: 600, y: 250, name: "Morgan" },
    { id: 7, x: 150, y: 150, name: "Taylor" },
    { id: 8, x: 550, y: 380, name: "Avery" }
  ];

  const connectionSequence = [
    { from: 1, to: 2, step: 1 },
    { from: 1, to: 4, step: 2 },
    { from: 2, to: 3, step: 3 },
    { from: 2, to: 6, step: 4 },
    { from: 4, to: 7, step: 5 },
    { from: 3, to: 5, step: 6 },
    { from: 6, to: 8, step: 7 },
    { from: 5, to: 8, step: 8 },
    { from: 7, to: 4, step: 9 }
  ];

  const reset = useCallback(() => {
    setIsPlaying(false);
    setAnimationStep(0);
    setConnections([]);
    stepRef.current = 0;
    if (animationRef.current) {
      clearTimeout(animationRef.current);
    }
  }, []);

  const animate = useCallback(() => {
    if (stepRef.current >= connectionSequence.length) {
      setIsPlaying(false);
      return;
    }

    const currentConnection = connectionSequence[stepRef.current];
    setConnections(prev => [...prev, currentConnection]);
    setAnimationStep(stepRef.current + 1);
    stepRef.current += 1;

    animationRef.current = setTimeout(() => {
      animate();
    }, 1000 / speed);
  }, [speed]);

  useEffect(() => {
    if (isPlaying) {
      animate();
    } else {
      if (animationRef.current) {
        clearTimeout(animationRef.current);
      }
    }

    return () => {
      if (animationRef.current) {
        clearTimeout(animationRef.current);
      }
    };
  }, [isPlaying, animate]);

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const getPersonState = (personId) => {
    if (!showPositive) return 'negative';
    if (personId === 1) return 'initiator';
    const hasConnection = connections.some(conn => conn.from === personId || conn.to === personId);
    return hasConnection ? 'connected' : 'neutral';
  };

  const getStepLabel = () => {
    if (!showPositive) return "Without Friendliness: Isolation & Disconnection";
    if (animationStep === 0) return "Step 1: Someone decides to be genuinely friendly";
    if (animationStep <= 2) return "Step 2: Direct connections form from friendly acts";
    if (animationStep <= 5) return "Step 3: Recipients pass friendliness to others";
    if (animationStep <= 8) return "Step 4: Network of positive connections grows";
    return "Step 5: Community happiness emerges from simple friendly acts";
  };

  return (
    <div style={{ 
      width: '100%', 
      height: '100vh', 
      backgroundColor: '#ffffff',
      position: 'relative',
      overflow: 'hidden',
      fontFamily: 'system-ui, sans-serif'
    }}>
      <style>
        {`
          @keyframes ripple {
            0% { transform: scale(1); opacity: 1; }
            100% { transform: scale(2); opacity: 0; }
          }
          @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
          }
        `}
      </style>

      {/* Controls */}
      <div style={{
        position: 'absolute',
        top: 20,
        left: 20,
        display: 'flex',
        gap: 15,
        alignItems: 'center',
        backgroundColor: 'rgba(0,0,0,0.05)',
        padding: '10px 15px',
        borderRadius: 8,
        zIndex: 100
      }}>
        <button
          onClick={togglePlayPause}
          style={{
            background: '#007bff',
            color: 'white',
            border: 'none',
            borderRadius: 4,
            padding: '8px 12px',
            cursor: 'pointer',
            fontSize: 14
          }}
        >
          {isPlaying ? '⏸' : '▶'}
        </button>

        <button
          onClick={reset}
          style={{
            background: '#6c757d',
            color: 'white',
            border: 'none',
            borderRadius: 4,
            padding: '8px 12px',
            cursor: 'pointer',
            fontSize: 12
          }}
        >
          Reset
        </button>

        <label style={{ fontSize: 12, color: '#666' }}>
          Speed:
          <input
            type="range"
            min="0.5"
            max="3"
            step="0.5"
            value={speed}
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            style={{ marginLeft: 5, width: 60 }}
          />
          {speed}×
        </label>

        <button
          onClick={() => setShowPositive(!showPositive)}
          style={{
            background: showPositive ? '#28a745' : '#dc3545',
            color: 'white',
            border: 'none',
            borderRadius: 4,
            padding: '8px 12px',
            cursor: 'pointer',
            fontSize: 12
          }}
        >
          {showPositive ? 'Friendly Mode' : 'Unfriendly Mode'}
        </button>
      </div>

      {/* Step Label */}
      <div style={{
        position: 'absolute',
        top: 20,
        right: 20,
        backgroundColor: showPositive ? 'rgba(40, 167, 69, 0.1)' : 'rgba(220, 53, 69, 0.1)',
        padding: '15px 20px',
        borderRadius: 8,
        maxWidth: 300,
        fontSize: 14,
        fontWeight: 600,
        color: showPositive ? '#155724' : '#721c24'
      }}>
        {getStepLabel()}
      </div>

      {/* Main Animation Area */}
      <svg style={{ width: '100%', height: '100%' }}>
        {/* Connections */}
        {showPositive && connections.map((conn, index) => {
          const fromPerson = people.find(p => p.id === conn.from);
          const toPerson = people.find(p => p.id === conn.to);
          
          return (
            <g key={`${conn.from}-${conn.to}`}>
              <line
                x1={fromPerson.x}
                y1={fromPerson.y}
                x2={toPerson.x}
                y2={toPerson.y}
                stroke="#28a745"
                strokeWidth="3"
                opacity="0.7"
                style={{
                  animation: 'pulse 2s ease-in-out infinite'
                }}
              />
              
              {/* Connection ripple effect */}
              <circle
                cx={(fromPerson.x + toPerson.x) / 2}
                cy={(fromPerson.y + toPerson.y) / 2}
                r="5"
                fill="#28a745"
                opacity="0.5"
                style={{
                  animation: 'ripple 1.5s ease-out infinite'
                }}
              />
            </g>
          );
        })}

        {/* People */}
        {people.map(person => {
          const state = getPersonState(person.id);
          let color, size;
          
          switch (state) {
            case 'initiator':
              color = '#007bff';
              size = 25;
              break;
            case 'connected':
              color = '#28a745';
              size = 20;
              break;
            case 'negative':
              color = '#6c757d';
              size = 15;
              break;
            default:
              color = '#ffc107';
              size = 15;
          }

          return (
            <g key={person.id}>
              {/* Happiness aura for connected people */}
              {showPositive && state !== 'neutral' && (
                <circle
                  cx={person.x}
                  cy={person.y}
                  r={size + 15}
                  fill={color}
                  opacity="0.1"
                  style={{
                    animation: 'ripple 3s ease-out infinite'
                  }}
                />
              )}
              
              {/* Person circle */}
              <circle
                cx={person.x}
                cy={person.y}
                r={size}
                fill={color}
                style={{
                  cursor: 'pointer',
                  animation: state === 'initiator' ? 'pulse 1.5s ease-in-out infinite' : 'none'
                }}
                onMouseEnter={() => setHoveredPerson(person.id)}
                onMouseLeave={() => setHoveredPerson(null)}
              />
              
              {/* Name label */}
              <text
                x={person.x}
                y={person.y + size + 20}
                textAnchor="middle"
                fontSize="12"
                fill="#333"
                fontWeight="500"
              >
                {person.name}
              </text>

              {/* Hover details */}
              {hoveredPerson === person.id && (
                <g>
                  <rect
                    x={person.x - 60}
                    y={person.y - size - 40}
                    width="120"
                    height="25"
                    fill="rgba(0,0,0,0.8)"
                    rx="4"
                  />
                  <text
                    x={person.x}
                    y={person.y - size - 22}
                    textAnchor="middle"
                    fontSize="11"
                    fill="white"
                  >
                    {state === 'initiator' && 'Starting friendliness!'}
                    {state === 'connected' && 'Feeling happy & connected'}
                    {state === 'negative' && 'Isolated & disconnected'}
                    {state === 'neutral' && 'Waiting for connection...'}
                  </text>
                </g>
              )}
            </g>
          );
        })}
      </svg>

      {/* Bottom explanation */}
      <div style={{
        position: 'absolute',
        bottom: 20,
        left: '50%',
        transform: 'translateX(-50%)',
        backgroundColor: 'rgba(255,255,255,0.95)',
        padding: '15px 25px',
        borderRadius: 8,
        textAlign: 'center',
        maxWidth: 600,
        fontSize: 14,
        color: '#333',
        boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
      }}>
        <strong>How Friendliness Spreads:</strong> Watch how one person's genuine friendly behavior creates a ripple effect, 
        building connections and happiness throughout the community. 
        {showPositive ? ' Each friendly act encourages others to be friendly too!' : ' Without friendliness, people remain isolated.'}
      </div>
    </div>
  );
}