import React, { useState, useRef } from 'react';

export default function App() {
  const [connections, setConnections] = useState([]);
  const [selectedInjustice, setSelectedInjustice] = useState(null);
  const [selectedResentment, setSelectedResentment] = useState(null);
  const [hoveredItem, setHoveredItem] = useState(null);
  const [showLiberated, setShowLiberated] = useState(false);
  const [dragStart, setDragStart] = useState(null);
  const [dragEnd, setDragEnd] = useState(null);
  const svgRef = useRef(null);

  const injustices = [
    {
      id: 'i1',
      title: 'Workplace Discrimination',
      description: 'Witnessed unfair treatment of colleagues based on identity',
      position: { x: 100, y: 150 }
    },
    {
      id: 'i2',
      title: 'Family Betrayal',
      description: 'Saw a family member hurt another through deception',
      position: { x: 100, y: 250 }
    },
    {
      id: 'i3',
      title: 'Social Injustice',
      description: 'Observed systemic unfairness affecting vulnerable groups',
      position: { x: 100, y: 350 }
    },
    {
      id: 'i4',
      title: 'Friend\'s Abuse',
      description: 'Witnessed emotional or physical harm toward someone close',
      position: { x: 100, y: 450 }
    }
  ];

  const resentmentNodes = [
    {
      id: 'r1',
      title: 'Chronic Anger',
      description: 'Persistent rage about injustices creates mental tension',
      position: { x: 600, y: 150 }
    },
    {
      id: 'r2',
      title: 'Trust Issues',
      description: 'Difficulty trusting others based on witnessed betrayals',
      position: { x: 600, y: 250 }
    },
    {
      id: 'r3',
      title: 'Helplessness',
      description: 'Feeling powerless to change unfair situations',
      position: { x: 600, y: 350 }
    },
    {
      id: 'r4',
      title: 'Emotional Burden',
      description: 'Carrying others\' pain as your own mental weight',
      position: { x: 600, y: 450 }
    }
  ];

  const handleInjusticeClick = (injustice) => {
    if (selectedResentment) {
      const newConnection = {
        from: injustice.id,
        to: selectedResentment,
        fromPos: injustice.position,
        toPos: resentmentNodes.find(r => r.id === selectedResentment).position
      };
      setConnections(prev => [...prev, newConnection]);
      setSelectedInjustice(null);
      setSelectedResentment(null);
    } else {
      setSelectedInjustice(injustice.id);
    }
  };

  const handleResentmentClick = (resentmentId) => {
    if (selectedInjustice) {
      const injustice = injustices.find(i => i.id === selectedInjustice);
      const resentment = resentmentNodes.find(r => r.id === resentmentId);
      const newConnection = {
        from: selectedInjustice,
        to: resentmentId,
        fromPos: injustice.position,
        toPos: resentment.position
      };
      setConnections(prev => [...prev, newConnection]);
      setSelectedInjustice(null);
      setSelectedResentment(null);
    } else {
      setSelectedResentment(resentmentId);
    }
  };

  const clearConnections = () => {
    setConnections([]);
    setSelectedInjustice(null);
    setSelectedResentment(null);
  };

  const mentalBurdenPercentage = Math.min(connections.length * 25, 100);

  const getProgressBarColor = (percentage) => {
    if (percentage === 0) return '#e0e0e0';
    if (percentage < 15) return '#4caf50';
    if (percentage < 35) return '#8bc34a';
    if (percentage < 50) return '#ffeb3b';
    if (percentage < 65) return '#ff9800';
    if (percentage < 80) return '#ff5722';
    return '#d32f2f';
  };

  return (
    <div style={{
      width: '100%',
      height: '100vh',
      backgroundColor: '#ffffff',
      fontFamily: 'Arial, sans-serif',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Header */}
      <div style={{
        padding: '20px',
        textAlign: 'center',
        borderBottom: '2px solid #e0e0e0'
      }}>
        <h1 style={{
          margin: '0 0 10px 0',
          fontSize: '24px',
          color: '#333',
          fontWeight: 'bold'
        }}>
          Universal Resentment Web Mapper
        </h1>
        <p style={{
          margin: '10px 0',
          fontSize: '14px',
          color: '#666'
        }}>
          {!showLiberated ? 'Click injustices and resentments to connect them • Toggle to see liberation through forgiveness' : 'See how witnessing injustices can be transformed through universal forgiveness'}
        </p>
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          gap: '20px',
          marginTop: '15px'
        }}>
          <button
            onClick={() => setShowLiberated(false)}
            style={{
              padding: '10px 20px',
              backgroundColor: showLiberated ? '#f0f0f0' : '#d32f2f',
              color: showLiberated ? '#666' : 'white',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            Burdened Mind
          </button>
          <button
            onClick={() => setShowLiberated(true)}
            style={{
              padding: '10px 20px',
              backgroundColor: showLiberated ? '#2e7d32' : '#f0f0f0',
              color: showLiberated ? 'white' : '#666',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            Liberated Mind
          </button>
          {!showLiberated && (
            <button
              onClick={clearConnections}
              style={{
                padding: '10px 20px',
                backgroundColor: '#757575',
                color: 'white',
                border: 'none',
                borderRadius: '5px',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              Clear Connections
            </button>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div style={{
        position: 'relative',
        height: 'calc(100vh - 140px)',
        padding: '40px'
      }}>
        
        {/* Mental Progress Bar */}
        {!showLiberated && (
          <div style={{
            position: 'absolute',
            top: '10px',
            left: '50%',
            transform: 'translateX(-50%)',
            backgroundColor: '#fff',
            padding: '15px 25px',
            borderRadius: '10px',
            border: '2px solid #ddd',
            zIndex: 10,
            textAlign: 'center',
            minWidth: '300px'
          }}>
            <div style={{
              fontSize: '14px',
              color: '#666',
              marginBottom: '8px',
              fontWeight: 'bold'
            }}>
              Mental Burden Level
            </div>
            <div style={{
              width: '250px',
              height: '12px',
              backgroundColor: '#f0f0f0',
              borderRadius: '6px',
              overflow: 'hidden',
              margin: '0 auto 8px auto'
            }}>
              <div style={{
                width: `${mentalBurdenPercentage}%`,
                height: '100%',
                backgroundColor: getProgressBarColor(mentalBurdenPercentage),
                transition: 'width 0.5s ease, background-color 0.5s ease'
              }} />
            </div>
            <div style={{
              fontSize: '12px',
              color: getProgressBarColor(mentalBurdenPercentage),
              fontWeight: 'bold'
            }}>
              {connections.length} connections • {Math.round(mentalBurdenPercentage)}% burden
            </div>
          </div>
        )}

        {/* Column Headers */}
        <div style={{
          position: 'absolute',
          top: '50px',
          left: '100px',
          fontSize: '18px',
          fontWeight: 'bold',
          color: '#d32f2f'
        }}>
          Witnessed Injustices
        </div>
        <div style={{
          position: 'absolute',
          top: '50px',
          left: '600px',
          fontSize: '18px',
          fontWeight: 'bold',
          color: showLiberated ? '#2e7d32' : '#ff6f00'
        }}>
          {showLiberated ? 'Released Burdens' : 'Mental Burdens'}
        </div>

        {/* SVG for connections */}
        <svg
          ref={svgRef}
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            pointerEvents: 'none',
            zIndex: 1
          }}
        >
          {!showLiberated && connections.map((conn, index) => (
            <line
              key={index}
              x1={conn.fromPos.x + 120}
              y1={conn.fromPos.y + 20}
              x2={conn.toPos.x}
              y2={conn.toPos.y + 20}
              stroke="#ff6f00"
              strokeWidth="3"
              strokeDasharray="5,5"
            />
          ))}
        </svg>

        {/* Injustices */}
        {injustices.map(injustice => (
          <div
            key={injustice.id}
            style={{
              position: 'absolute',
              left: injustice.position.x,
              top: injustice.position.y,
              width: '240px',
              height: '60px',
              backgroundColor: selectedInjustice === injustice.id ? '#ffcdd2' : '#f8f9fa',
              border: selectedInjustice === injustice.id ? '3px solid #d32f2f' : '2px solid #e0e0e0',
              borderRadius: '10px',
              padding: '15px',
              cursor: showLiberated ? 'default' : 'pointer',
              zIndex: 2,
              transition: 'all 0.3s ease',
              opacity: showLiberated ? 0.3 : 1
            }}
            onClick={() => !showLiberated && handleInjusticeClick(injustice)}
            onMouseEnter={() => setHoveredItem(injustice.id)}
            onMouseLeave={() => setHoveredItem(null)}
          >
            <div style={{
              fontSize: '16px',
              fontWeight: 'bold',
              color: '#333',
              marginBottom: '5px'
            }}>
              {injustice.title}
            </div>
          </div>
        ))}

        {/* Resentment Nodes */}
        {resentmentNodes.map(resentment => (
          <div
            key={resentment.id}
            style={{
              position: 'absolute',
              left: resentment.position.x,
              top: resentment.position.y,
              width: '240px',
              height: '60px',
              backgroundColor: showLiberated ? '#e8f5e8' : (selectedResentment === resentment.id ? '#fff3e0' : '#fff8e1'),
              border: showLiberated ? '2px solid #2e7d32' : (selectedResentment === resentment.id ? '3px solid #ff6f00' : '2px solid #ffb300'),
              borderRadius: '10px',
              padding: '15px',
              cursor: showLiberated ? 'default' : 'pointer',
              zIndex: 2,
              transition: 'all 0.3s ease'
            }}
            onClick={() => !showLiberated && handleResentmentClick(resentment.id)}
            onMouseEnter={() => setHoveredItem(resentment.id)}
            onMouseLeave={() => setHoveredItem(null)}
          >
            <div style={{
              fontSize: '16px',
              fontWeight: 'bold',
              color: showLiberated ? '#2e7d32' : '#ff6f00',
              marginBottom: '5px'
            }}>
              {showLiberated ? resentment.title.replace('Chronic ', 'Released ').replace('Issues', 'Healing').replace('Burden', 'Freedom') : resentment.title}
            </div>
          </div>
        ))}

        {/* Hover Description Panel */}
        {hoveredItem && (
          <div style={{
            position: 'absolute',
            right: '20px',
            top: '150px',
            width: '250px',
            backgroundColor: '#ffffff',
            border: '2px solid #ddd',
            borderRadius: '10px',
            padding: '15px',
            boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
            zIndex: 10
          }}>
            <div style={{
              fontSize: '14px',
              color: '#333',
              lineHeight: '1.4'
            }}>
              {(() => {
                const item = injustices.find(i => i.id === hoveredItem) || resentmentNodes.find(r => r.id === hoveredItem);
                if (item && showLiberated && resentmentNodes.find(r => r.id === hoveredItem)) {
                  return item.description.replace('creates mental tension', 'transforms into inner peace').replace('Difficulty', 'Growing capacity for').replace('based on witnessed betrayals', 'through understanding human nature').replace('Feeling powerless', 'Accepting what cannot be changed').replace('Carrying others\' pain as your own mental weight', 'Releasing others\' experiences with compassion');
                }
                return item?.description;
              })()}
            </div>
          </div>
        )}

        {/* Liberation Message */}
        {showLiberated && (
          <div style={{
            position: 'absolute',
            top: '70px',
            right: '20px',
            backgroundColor: '#e8f5e8',
            padding: '20px 30px',
            borderRadius: '10px',
            border: '2px solid #2e7d32',
            fontSize: '16px',
            color: '#2e7d32',
            textAlign: 'center',
            maxWidth: '400px',
            fontWeight: 'bold'
          }}>
            Universal forgiveness breaks the web of resentment • Complete mental freedom comes from releasing others' experiences with compassion
          </div>
        )}
      </div>
    </div>
  );
}