import { useState } from 'react';

export default function App() {
  const [selectedScenario, setSelectedScenario] = useState(null);
  const [selectedLayer, setSelectedLayer] = useState('surface');
  const [hoveredElement, setHoveredElement] = useState(null);

  const scenarios = [
    {
      id: 1,
      title: "Friend's Betrayal",
      description: "Your close friend shared your personal secret with others",
      surface: {
        thought: "I forgive you",
        feeling: "Still feels tense around them",
        behavior: "Polite but distant",
        body: "Shoulders tighten when they're near",
        indicators: ["Quick to say 'it's fine'", "Avoids being alone with them", "Brings it up in arguments"]
      },
      deep: {
        thought: "I understand their humanity and my own",
        feeling: "Genuine warmth restored",
        behavior: "Natural, open interaction",
        body: "Relaxed and at ease",
        indicators: ["Can laugh about it", "Shares vulnerably again", "Advocates for them to others"]
      }
    },
    {
      id: 2,
      title: "Partner's Harsh Words",
      description: "Your partner said something cruel during an argument",
      surface: {
        thought: "Let's just move on",
        feeling: "Hurt lingers underneath",
        behavior: "Acts normal but withdrawn",
        body: "Chest feels heavy",
        indicators: ["Says 'I'm over it' repeatedly", "Brings it up weeks later", "Holds back emotionally"]
      },
      deep: {
        thought: "They were hurting and lashed out",
        feeling: "Compassion for their pain",
        behavior: "Openly affectionate again",
        body: "Heart feels open",
        indicators: ["Discusses it with curiosity", "More emotionally available", "Conflict feels safer"]
      }
    },
    {
      id: 3,
      title: "Colleague's Credit Theft",
      description: "A coworker took credit for your idea in a meeting",
      surface: {
        thought: "It doesn't matter anyway",
        feeling: "Resentment simmers",
        behavior: "Professional but guarded",
        body: "Jaw clenches thinking about it",
        indicators: ["Dismisses its importance", "Stops sharing ideas freely", "Makes subtle digs"]
      },
      deep: {
        thought: "Their insecurity led to poor choices",
        feeling: "Confident in own worth",
        behavior: "Collaborative and generous",
        body: "Relaxed and present",
        indicators: ["Continues contributing boldly", "Can work together effectively", "Focuses on team success"]
      }
    }
  ];

  const currentScenario = scenarios.find(s => s.id === selectedScenario);

  return (
    <div style={{ 
      width: '100%', 
      height: '100vh', 
      backgroundColor: '#ffffff',
      fontFamily: 'Arial, sans-serif',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {/* Header */}
      <div style={{ 
        padding: '20px 40px',
        borderBottom: '1px solid #e0e0e0'
      }}>
        <h1 style={{ 
          margin: 0, 
          fontSize: '24px', 
          color: '#333',
          fontWeight: '300'
        }}>
          Surface vs Deep Forgiveness
        </h1>
        <p style={{ 
          margin: '8px 0 0 0', 
          color: '#666', 
          fontSize: '14px',
          opacity: hoveredElement === 'instructions' ? 1 : 0.7
        }}
        onMouseEnter={() => setHoveredElement('instructions')}
        onMouseLeave={() => setHoveredElement(null)}>
          Select a scenario to explore layers of forgiveness
        </p>
      </div>

      <div style={{ 
        flex: 1,
        display: 'flex'
      }}>
        {/* Scenario Selection Panel */}
        <div style={{ 
          width: '300px',
          borderRight: '1px solid #e0e0e0',
          padding: '20px'
        }}>
          <h3 style={{ 
            margin: '0 0 20px 0',
            fontSize: '16px',
            color: '#333',
            fontWeight: '500'
          }}>
            Choose a Scenario
          </h3>
          {scenarios.map(scenario => (
            <div
              key={scenario.id}
              onClick={() => setSelectedScenario(scenario.id)}
              onMouseEnter={() => setHoveredElement(`scenario-${scenario.id}`)}
              onMouseLeave={() => setHoveredElement(null)}
              style={{
                padding: '15px',
                marginBottom: '10px',
                border: selectedScenario === scenario.id ? '2px solid #4a90e2' : '1px solid #ddd',
                borderRadius: '8px',
                cursor: 'pointer',
                backgroundColor: selectedScenario === scenario.id ? '#f0f7ff' : 
                                hoveredElement === `scenario-${scenario.id}` ? '#f9f9f9' : '#ffffff',
                transition: 'all 0.2s ease'
              }}
            >
              <h4 style={{ 
                margin: '0 0 8px 0',
                fontSize: '14px',
                fontWeight: '600',
                color: '#333'
              }}>
                {scenario.title}
              </h4>
              {(hoveredElement === `scenario-${scenario.id}` || selectedScenario === scenario.id) && (
                <p style={{ 
                  margin: 0,
                  fontSize: '12px',
                  color: '#666',
                  lineHeight: '1.4'
                }}>
                  {scenario.description}
                </p>
              )}
            </div>
          ))}
        </div>

        {/* Main Exploration Area */}
        <div style={{ 
          flex: 1,
          display: 'flex',
          flexDirection: 'column'
        }}>
          {!currentScenario ? (
            <div style={{ 
              flex: 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#999'
            }}>
              <p>Select a scenario to begin exploring forgiveness layers</p>
            </div>
          ) : (
            <>
              {/* Layer Toggle */}
              <div style={{ 
                padding: '20px 40px',
                borderBottom: '1px solid #e0e0e0',
                display: 'flex',
                alignItems: 'center',
                gap: '20px'
              }}>
                <h2 style={{ 
                  margin: 0,
                  fontSize: '18px',
                  color: '#333',
                  fontWeight: '400'
                }}>
                  {currentScenario.title}
                </h2>
                <div style={{ 
                  display: 'flex',
                  border: '1px solid #ddd',
                  borderRadius: '6px',
                  overflow: 'hidden'
                }}>
                  <button
                    onClick={() => setSelectedLayer('surface')}
                    style={{
                      padding: '8px 16px',
                      border: 'none',
                      backgroundColor: selectedLayer === 'surface' ? '#ff6b6b' : '#ffffff',
                      color: selectedLayer === 'surface' ? '#ffffff' : '#333',
                      cursor: 'pointer',
                      fontSize: '13px',
                      fontWeight: '500'
                    }}
                  >
                    Surface Level
                  </button>
                  <button
                    onClick={() => setSelectedLayer('deep')}
                    style={{
                      padding: '8px 16px',
                      border: 'none',
                      backgroundColor: selectedLayer === 'deep' ? '#4ecdc4' : '#ffffff',
                      color: selectedLayer === 'deep' ? '#ffffff' : '#333',
                      cursor: 'pointer',
                      fontSize: '13px',
                      fontWeight: '500'
                    }}
                  >
                    Deep Healing
                  </button>
                </div>
              </div>

              {/* Forgiveness Details */}
              <div style={{ 
                flex: 1,
                padding: '40px',
                display: 'grid',
                gridTemplateColumns: '1fr 1fr',
                gap: '30px'
              }}>
                {/* Left Side - Core Elements */}
                <div>
                  <h3 style={{ 
                    margin: '0 0 20px 0',
                    fontSize: '16px',
                    color: selectedLayer === 'surface' ? '#ff6b6b' : '#4ecdc4',
                    fontWeight: '600'
                  }}>
                    {selectedLayer === 'surface' ? 'Surface Forgiveness' : 'Deep Healing'}
                  </h3>
                  
                  {['thought', 'feeling', 'behavior', 'body'].map(aspect => (
                    <div
                      key={aspect}
                      onMouseEnter={() => setHoveredElement(aspect)}
                      onMouseLeave={() => setHoveredElement(null)}
                      style={{
                        padding: '15px',
                        marginBottom: '15px',
                        border: '1px solid #e0e0e0',
                        borderRadius: '8px',
                        backgroundColor: hoveredElement === aspect ? '#fafafa' : '#ffffff',
                        borderLeft: `4px solid ${selectedLayer === 'surface' ? '#ff6b6b' : '#4ecdc4'}`
                      }}
                    >
                      <div style={{ 
                        fontSize: '12px',
                        fontWeight: '600',
                        textTransform: 'uppercase',
                        color: '#888',
                        marginBottom: '5px',
                        letterSpacing: '0.5px'
                      }}>
                        {aspect}
                      </div>
                      <div style={{ 
                        fontSize: '14px',
                        color: '#333',
                        fontWeight: '500'
                      }}>
                        {currentScenario[selectedLayer][aspect]}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Right Side - Indicators */}
                <div>
                  <h3 style={{ 
                    margin: '0 0 20px 0',
                    fontSize: '16px',
                    color: '#666',
                    fontWeight: '600'
                  }}>
                    Signs to Look For
                  </h3>
                  
                  {currentScenario[selectedLayer].indicators.map((indicator, index) => (
                    <div
                      key={index}
                      onMouseEnter={() => setHoveredElement(`indicator-${index}`)}
                      onMouseLeave={() => setHoveredElement(null)}
                      style={{
                        padding: '12px 15px',
                        marginBottom: '10px',
                        backgroundColor: hoveredElement === `indicator-${index}` ? 
                          (selectedLayer === 'surface' ? '#fff5f5' : '#f0fffe') : '#f9f9f9',
                        borderRadius: '6px',
                        fontSize: '13px',
                        color: '#444',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px'
                      }}
                    >
                      <div style={{
                        width: '6px',
                        height: '6px',
                        borderRadius: '50%',
                        backgroundColor: selectedLayer === 'surface' ? '#ff6b6b' : '#4ecdc4'
                      }}></div>
                      {indicator}
                    </div>
                  ))}
                  
                  {hoveredElement && hoveredElement.startsWith('indicator-') && (
                    <div style={{
                      marginTop: '20px',
                      padding: '15px',
                      backgroundColor: '#f0f7ff',
                      borderRadius: '8px',
                      fontSize: '12px',
                      color: '#555',
                      lineHeight: '1.4'
                    }}>
                      {selectedLayer === 'surface' ? 
                        'Surface forgiveness often masks unresolved hurt. These patterns indicate work remains.' :
                        'Deep forgiveness transforms your relationship to the offense. These signs show genuine healing.'}
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}