import { useState, useCallback, useMemo } from 'react';

export default function App() {
  const [innerCriticLevel, setInnerCriticLevel] = useState(70);
  const [selfCompassionLevel, setSelfCompassionLevel] = useState(30);
  const [hoveredElement, setHoveredElement] = useState(null);
  const [showComparison, setShowComparison] = useState(false);
  const [selectedMindArea, setSelectedMindArea] = useState(null);
  const [showInsights, setShowInsights] = useState(false);

  const mentalState = useMemo(() => {
    const criticDominance = innerCriticLevel - selfCompassionLevel;
    
    if (criticDominance > 40) {
      return {
        state: 'Mental Prison',
        color: '#dc2626',
        lightColor: '#fef2f2',
        freedom: 15,
        wellbeing: 20,
        description: 'Trapped in cycles of self-blame and resentment'
      };
    } else if (criticDominance > 10) {
      return {
        state: 'Mental Struggle',
        color: '#ea580c',
        lightColor: '#fff7ed',
        freedom: 40,
        wellbeing: 45,
        description: 'Ongoing internal conflict and emotional turbulence'
      };
    } else if (criticDominance > -10) {
      return {
        state: 'Mental Balance',
        color: '#ca8a04',
        lightColor: '#fffbeb',
        freedom: 65,
        wellbeing: 70,
        description: 'Developing awareness with moments of peace'
      };
    } else if (criticDominance > -30) {
      return {
        state: 'Mental Healing',
        color: '#059669',
        lightColor: '#f0fdf4',
        freedom: 80,
        wellbeing: 85,
        description: 'Growing self-acceptance and emotional freedom'
      };
    } else {
      return {
        state: 'Mental Liberation',
        color: '#0891b2',
        lightColor: '#f0f9ff',
        freedom: 95,
        wellbeing: 95,
        description: 'Deep self-compassion creates lasting inner peace'
      };
    }
  }, [innerCriticLevel, selfCompassionLevel]);

  const comparisonState = useMemo(() => ({
    critic: {
      state: 'High Critic State',
      color: '#dc2626',
      freedom: 20,
      wellbeing: 15,
      patterns: ['Self-blame cycles', 'Rumination loops', 'Emotional reactivity', 'Mental rigidity']
    },
    compassion: {
      state: 'High Compassion State',
      color: '#0891b2',
      freedom: 90,
      wellbeing: 92,
      patterns: ['Self-acceptance', 'Present awareness', 'Emotional regulation', 'Mental flexibility']
    }
  }), []);

  const handleCriticChange = useCallback((e) => {
    setInnerCriticLevel(parseInt(e.target.value));
  }, []);

  const handleCompassionChange = useCallback((e) => {
    setSelfCompassionLevel(parseInt(e.target.value));
  }, []);

  const handleMindClick = (type) => {
    setSelectedMindArea(selectedMindArea === type ? null : type);
  };

  const MentalStateVisualization = ({ state, isComparison = false, comparisonData = null }) => {
    const stateData = isComparison ? comparisonData : state;
    
    return (
      <div style={{
        background: `linear-gradient(135deg, ${stateData.lightColor} 0%, white 50%, ${stateData.lightColor} 100%)`,
        borderRadius: '16px',
        padding: '20px',
        height: '300px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        border: `2px solid ${stateData.color}`,
        position: 'relative',
        transition: 'all 0.3s ease'
      }}>
        <div style={{
          width: '150px',
          height: '150px',
          borderRadius: '50%',
          background: `radial-gradient(circle at 30% 30%, ${stateData.lightColor}, ${stateData.color}30)`,
          border: `3px solid ${stateData.color}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: '15px',
          cursor: 'pointer',
          transform: hoveredElement === 'mind' ? 'scale(1.05)' : 'scale(1)'
        }}
        onClick={() => handleMindClick('main')}
        onMouseEnter={() => setHoveredElement('mind')}
        onMouseLeave={() => setHoveredElement(null)}>
          
          <div style={{
            width: `${stateData.freedom}%`,
            height: `${stateData.freedom}%`,
            borderRadius: '50%',
            background: `linear-gradient(45deg, white, ${stateData.color}20)`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '20px',
            color: stateData.color,
            fontWeight: 'bold'
          }}>
            {stateData.freedom > 70 ? '✓' : stateData.freedom > 40 ? '~' : '✗'}
          </div>
        </div>

        <h3 style={{
          color: stateData.color,
          fontSize: '18px',
          fontWeight: 'bold',
          margin: '0 0 8px 0',
          textAlign: 'center'
        }}>
          {stateData.state}
        </h3>

        {selectedMindArea === 'main' && (
          <div style={{
            position: 'absolute',
            top: '10px',
            left: '10px',
            right: '10px',
            background: 'white',
            border: `2px solid ${stateData.color}`,
            borderRadius: '8px',
            padding: '12px',
            fontSize: '12px',
            color: '#374151',
            boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
            zIndex: 10
          }}>
            <strong>Mental Freedom: {stateData.freedom}%</strong><br/>
            <strong>Wellbeing: {stateData.wellbeing}%</strong><br/>
            {stateData.description}
            {isComparison && comparisonData.patterns && (
              <div style={{ marginTop: '8px' }}>
                {comparisonData.patterns.map((pattern, idx) => (
                  <div key={idx} style={{ fontSize: '11px', margin: '1px 0' }}>
                    • {pattern}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div style={{
      width: '100vw',
      height: '100vh',
      backgroundColor: '#ffffff',
      padding: '20px',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {/* Header */}
      <div style={{
        textAlign: 'center',
        marginBottom: '20px'
      }}>
        <h1 style={{
          fontSize: '28px',
          fontWeight: 'bold',
          color: '#1f2937',
          margin: '0 0 15px 0'
        }}>
          Inner Critic vs Self-Compassion Balance
        </h1>
        
        <div style={{
          display: 'flex',
          gap: '15px',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <button
            onClick={() => setShowComparison(!showComparison)}
            style={{
              background: showComparison ? '#0891b2' : '#6b7280',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              padding: '10px 20px',
              fontSize: '14px',
              fontWeight: '500',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
          >
            {showComparison ? 'Interactive Mode' : 'Comparison Mode'}
          </button>

          <button
            onClick={() => setShowInsights(!showInsights)}
            style={{
              background: showInsights ? '#059669' : '#6b7280',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              padding: '10px 20px',
              fontSize: '14px',
              fontWeight: '500',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
          >
            {showInsights ? 'Hide Insights' : 'Show Insights'}
          </button>
        </div>
      </div>

      <div style={{ flex: 1, display: 'flex', gap: '20px' }}>
        {showComparison ? (
          /* Comparison Mode */
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '30px',
            width: '100%'
          }}>
            <div>
              <h2 style={{
                textAlign: 'center',
                color: '#dc2626',
                fontSize: '18px',
                fontWeight: 'bold',
                marginBottom: '15px'
              }}>
                Critic-Dominated Mind
              </h2>
              <MentalStateVisualization 
                state={null}
                isComparison={true}
                comparisonData={comparisonState.critic}
              />
            </div>
            <div>
              <h2 style={{
                textAlign: 'center',
                color: '#0891b2',
                fontSize: '18px',
                fontWeight: 'bold',
                marginBottom: '15px'
              }}>
                Compassion-Led Mind
              </h2>
              <MentalStateVisualization 
                state={null}
                isComparison={true}
                comparisonData={comparisonState.compassion}
              />
            </div>
          </div>
        ) : (
          /* Interactive Mode */
          <>
            {/* Left Panel - Controls */}
            <div style={{
              width: '350px',
              display: 'flex',
              flexDirection: 'column',
              gap: '20px'
            }}>
              {/* Control Panel */}
              <div style={{
                background: '#f9fafb',
                borderRadius: '12px',
                padding: '20px',
                border: '2px solid #e5e7eb'
              }}>
                {/* Inner Critic Slider */}
                <div style={{ marginBottom: '20px' }}>
                  <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '8px'
                  }}>
                    <span style={{
                      fontSize: '16px',
                      fontWeight: '600',
                      color: '#dc2626'
                    }}>
                      Inner Critic
                    </span>
                    <span style={{
                      fontSize: '18px',
                      fontWeight: 'bold',
                      color: '#dc2626'
                    }}>
                      {innerCriticLevel}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={innerCriticLevel}
                    onChange={handleCriticChange}
                    style={{
                      width: '100%',
                      height: '6px',
                      borderRadius: '3px',
                      background: `linear-gradient(to right, #dc2626 0%, #dc2626 ${innerCriticLevel}%, #e5e7eb ${innerCriticLevel}%, #e5e7eb 100%)`,
                      outline: 'none',
                      cursor: 'pointer'
                    }}
                  />
                </div>

                {/* Self-Compassion Slider */}
                <div>
                  <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '8px'
                  }}>
                    <span style={{
                      fontSize: '16px',
                      fontWeight: '600',
                      color: '#0891b2'
                    }}>
                      Self-Compassion
                    </span>
                    <span style={{
                      fontSize: '18px',
                      fontWeight: 'bold',
                      color: '#0891b2'
                    }}>
                      {selfCompassionLevel}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={selfCompassionLevel}
                    onChange={handleCompassionChange}
                    style={{
                      width: '100%',
                      height: '6px',
                      borderRadius: '3px',
                      background: `linear-gradient(to right, #0891b2 0%, #0891b2 ${selfCompassionLevel}%, #e5e7eb ${selfCompassionLevel}%, #e5e7eb 100%)`,
                      outline: 'none',
                      cursor: 'pointer'
                    }}
                  />
                </div>
              </div>

              {/* Quick Actions */}
              <div style={{
                background: '#f3f4f6',
                borderRadius: '12px',
                padding: '15px'
              }}>
                <h4 style={{ margin: '0 0 10px 0', fontSize: '14px', fontWeight: '600', color: '#374151' }}>
                  Quick Explore
                </h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <button
                    onClick={() => { setInnerCriticLevel(85); setSelfCompassionLevel(15); }}
                    style={{
                      background: '#dc2626',
                      color: 'white',
                      border: 'none',
                      borderRadius: '6px',
                      padding: '8px 12px',
                      fontSize: '12px',
                      cursor: 'pointer'
                    }}
                  >
                    Mental Prison
                  </button>
                  <button
                    onClick={() => { setInnerCriticLevel(50); setSelfCompassionLevel(50); }}
                    style={{
                      background: '#ca8a04',
                      color: 'white',
                      border: 'none',
                      borderRadius: '6px',
                      padding: '8px 12px',
                      fontSize: '12px',
                      cursor: 'pointer'
                    }}
                  >
                    Mental Balance
                  </button>
                  <button
                    onClick={() => { setInnerCriticLevel(15); setSelfCompassionLevel(85); }}
                    style={{
                      background: '#0891b2',
                      color: 'white',
                      border: 'none',
                      borderRadius: '6px',
                      padding: '8px 12px',
                      fontSize: '12px',
                      cursor: 'pointer'
                    }}
                  >
                    Mental Liberation
                  </button>
                </div>
              </div>
            </div>

            {/* Center Panel - Visualization */}
            <div style={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <MentalStateVisualization state={mentalState} />
              <p style={{
                marginTop: '15px',
                fontSize: '14px',
                color: '#6b7280',
                textAlign: 'center',
                fontStyle: 'italic'
              }}>
                Click the mind circle for detailed metrics
              </p>
            </div>

            {/* Right Panel - Insights */}
            {showInsights && (
              <div style={{
                width: '300px',
                background: mentalState.lightColor,
                border: `2px solid ${mentalState.color}`,
                borderRadius: '12px',
                padding: '20px'
              }}>
                <h3 style={{
                  color: mentalState.color,
                  fontSize: '16px',
                  fontWeight: 'bold',
                  marginBottom: '15px'
                }}>
                  Current State Insights
                </h3>

                <div style={{
                  fontSize: '13px',
                  color: '#374151',
                  lineHeight: '1.5'
                }}>
                  <div style={{ marginBottom: '15px' }}>
                    <strong>Mental State:</strong> {mentalState.state}
                  </div>
                  
                  <div style={{ marginBottom: '15px' }}>
                    <strong>Description:</strong><br/>
                    {mentalState.description}
                  </div>

                  <div style={{ marginBottom: '15px' }}>
                    <strong>Freedom Level:</strong> {mentalState.freedom}%<br/>
                    <div style={{
                      width: '100%',
                      height: '8px',
                      background: '#e5e7eb',
                      borderRadius: '4px',
                      overflow: 'hidden',
                      marginTop: '5px'
                    }}>
                      <div style={{
                        width: `${mentalState.freedom}%`,
                        height: '100%',
                        background: mentalState.color,
                        borderRadius: '4px'
                      }}></div>
                    </div>
                  </div>

                  <div style={{ marginBottom: '15px' }}>
                    <strong>Wellbeing:</strong> {mentalState.wellbeing}%<br/>
                    <div style={{
                      width: '100%',
                      height: '8px',
                      background: '#e5e7eb',
                      borderRadius: '4px',
                      overflow: 'hidden',
                      marginTop: '5px'
                    }}>
                      <div style={{
                        width: `${mentalState.wellbeing}%`,
                        height: '100%',
                        background: mentalState.color,
                        borderRadius: '4px'
                      }}></div>
                    </div>
                  </div>

                  <div style={{
                    background: 'white',
                    padding: '12px',
                    borderRadius: '8px',
                    border: `1px solid ${mentalState.color}`,
                    fontSize: '12px'
                  }}>
                    <strong>Path Forward:</strong><br/>
                    {mentalState.state === 'Mental Prison' 
                      ? 'Begin by acknowledging self-critical patterns without judgment. Small increases in self-compassion create significant shifts.'
                      : mentalState.state === 'Mental Liberation'
                      ? 'Maintain this balance through consistent self-compassion practice and mindful awareness.'
                      : 'Continue developing self-compassion to transform your relationship with internal judgment.'
                    }
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}