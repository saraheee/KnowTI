import { useState, useCallback } from 'react';

export default function App() {
  const [draggedItem, setDraggedItem] = useState(null);
  const [droppedItems, setDroppedItems] = useState({});
  const [feedback, setFeedback] = useState('');
  const [feedbackType, setFeedbackType] = useState('');
  const [showDetails, setShowDetails] = useState({});
  const [viewMode, setViewMode] = useState('healthy'); // 'healthy' or 'broken'

  const foundationItems = [
    {
      id: 'acceptance',
      label: 'Accept Parents as Imperfect Humans',
      category: 'foundation',
      explanation: 'This forms the bedrock - recognizing parents\' humanity allows us to see others\' humanity too.',
      tier: 1
    },
    {
      id: 'boundaries',
      label: 'Set Healthy Boundaries',
      category: 'foundation', 
      explanation: 'Boundaries with parents teach us how to protect ourselves while still forgiving.',
      tier: 1
    },
    {
      id: 'release',
      label: 'Release Need for Parental Perfection',
      category: 'foundation',
      explanation: 'Letting go of the "perfect parent" fantasy frees us from unrealistic expectations of others.',
      tier: 1
    }
  ];

  const higherSkills = [
    {
      id: 'friends',
      label: 'Forgive Friends',
      category: 'relationships',
      explanation: 'With a solid foundation, forgiving friends becomes more natural and sustainable.',
      tier: 2,
      dependsOn: ['acceptance']
    },
    {
      id: 'romantic',
      label: 'Forgive Romantic Partners',
      category: 'relationships', 
      explanation: 'Parent forgiveness work prevents us from projecting family issues onto partners.',
      tier: 2,
      dependsOn: ['boundaries']
    },
    {
      id: 'self',
      label: 'Forgive Yourself',
      category: 'personal',
      explanation: 'Learning self-compassion often starts with understanding our parents\' struggles.',
      tier: 3,
      dependsOn: ['release']
    },
    {
      id: 'strangers',
      label: 'Forgive Strangers & Society',
      category: 'universal',
      explanation: 'The highest level - extending grace broadly, rooted in foundational parent work.',
      tier: 4,
      dependsOn: ['self']
    }
  ];

  const allItems = [...foundationItems, ...higherSkills];

  const dropZones = {
    foundation: { tier: 1, label: 'Parental Foundation', color: '#8B4513' },
    relationships: { tier: 2, label: 'Close Relationships', color: '#4682B4' },
    personal: { tier: 3, label: 'Self-Forgiveness', color: '#228B22' },
    universal: { tier: 4, label: 'Universal Forgiveness', color: '#9932CC' }
  };

  const handleDragStart = useCallback((e, item) => {
    setDraggedItem(item);
    e.dataTransfer.effectAllowed = 'move';
  }, []);

  const handleDragOver = useCallback((e, zone) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  }, []);

  const handleDrop = useCallback((e, zone) => {
    e.preventDefault();
    if (!draggedItem) return;

    if (zone === 'foundation' && draggedItem.category === 'foundation') {
      // Add to foundation array instead of replacing
      setDroppedItems(prev => ({
        ...prev,
        foundation: [...(prev.foundation || []), draggedItem]
      }));
      setFeedback(draggedItem.explanation);
      setFeedbackType('success');
    } else if (zone === 'relationships' && draggedItem.category === 'relationships') {
      // Add to relationships array instead of replacing
      setDroppedItems(prev => ({
        ...prev,
        relationships: [...(prev.relationships || []), draggedItem]
      }));
      setFeedback(draggedItem.explanation);
      setFeedbackType('success');
    } else {
      const isCorrectZone = draggedItem.category === zone;
      
      // Check dependencies for higher tier items
      let dependenciesMet = true;
      if (draggedItem.dependsOn) {
        const foundationItems = droppedItems.foundation || [];
        dependenciesMet = draggedItem.dependsOn.every(dep => 
          foundationItems.some(item => item.id === dep) ||
          Object.values(droppedItems).some(item => item && item.id === dep)
        );
      }

      if (isCorrectZone && dependenciesMet) {
        setDroppedItems(prev => ({
          ...prev,
          [zone]: draggedItem
        }));
        setFeedback(draggedItem.explanation);
        setFeedbackType('success');
      } else if (!dependenciesMet) {
        setFeedback('Foundation must be built first! Start with parental forgiveness work before building higher levels.');
        setFeedbackType('error');
      } else {
        setFeedback(`This belongs in the ${draggedItem.category} level. ${draggedItem.explanation}`);
        setFeedbackType('error');
      }
    }

    setDraggedItem(null);
    setTimeout(() => {
      setFeedback('');
      setFeedbackType('');
    }, 3000);
  }, [draggedItem, droppedItems]);

  const handleReset = useCallback(() => {
    setDroppedItems({});
    setFeedback('');
    setFeedbackType('');
    setShowDetails({});
  }, []);

  const toggleDetails = useCallback((id) => {
    setShowDetails(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  }, []);

  const getAvailableItems = () => {
    const foundationItemsPlaced = droppedItems.foundation || [];
    const relationshipItemsPlaced = droppedItems.relationships || [];
    return allItems.filter(item => {
      if (item.category === 'foundation') {
        return !foundationItemsPlaced.find(dropped => dropped.id === item.id);
      }
      if (item.category === 'relationships') {
        return !relationshipItemsPlaced.find(dropped => dropped.id === item.id);
      }
      return !Object.values(droppedItems).find(dropped => dropped && dropped.id === item.id);
    });
  };

  const foundationComplete = foundationItems.every(item => {
    const foundationItemsPlaced = droppedItems.foundation || [];
    return foundationItemsPlaced.find(dropped => dropped.id === item.id);
  });

  return (
    <div style={{
      width: '100%',
      height: '100vh',
      backgroundColor: '#ffffff',
      display: 'flex',
      flexDirection: 'column',
      fontFamily: 'Arial, sans-serif'
    }}>
      {/* Header */}
      <div style={{
        padding: '20px',
        borderBottom: '2px solid #e0e0e0',
        textAlign: 'center'
      }}>
        <h1 style={{ margin: '0 0 10px 0', color: '#333' }}>Forgiveness Foundation Builder</h1>
        <p style={{ margin: 0, color: '#666' }}>Drag all three parental forgiveness skills to build your foundation, then stack other skills on top</p>
        
        <div style={{ marginTop: '15px' }}>
          <button
            onClick={() => setViewMode(viewMode === 'healthy' ? 'broken' : 'healthy')}
            style={{
              padding: '8px 16px',
              marginRight: '10px',
              backgroundColor: viewMode === 'healthy' ? '#228B22' : '#DC143C',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            View: {viewMode === 'healthy' ? 'Stable Foundation' : 'Broken Foundation'}
          </button>
          
          <button
            onClick={handleReset}
            style={{
              padding: '8px 16px',
              backgroundColor: '#666',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Reset
          </button>
        </div>
      </div>

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Left Panel - Available Items */}
        <div style={{
          width: '300px',
          backgroundColor: '#f8f9fa',
          padding: '20px',
          borderRight: '2px solid #e0e0e0',
          overflowY: 'auto'
        }}>
          <h3 style={{ marginTop: 0, color: '#333' }}>Available Skills</h3>
          
          {getAvailableItems().map(item => (
            <div
              key={item.id}
              draggable
              onDragStart={(e) => handleDragStart(e, item)}
              onClick={() => toggleDetails(item.id)}
              style={{
                padding: '12px',
                margin: '8px 0',
                backgroundColor: item.tier === 1 ? '#FFF8DC' : 
                               item.tier === 2 ? '#E6F3FF' :
                               item.tier === 3 ? '#F0FFF0' : '#F5F0FF',
                border: `2px solid ${item.tier === 1 ? '#8B4513' : 
                                   item.tier === 2 ? '#4682B4' :
                                   item.tier === 3 ? '#228B22' : '#9932CC'}`,
                borderRadius: '8px',
                cursor: 'grab',
                userSelect: 'none',
                opacity: draggedItem?.id === item.id ? 0.5 : 1
              }}
            >
              <div style={{ fontWeight: 'bold', fontSize: '14px' }}>{item.label}</div>
              {showDetails[item.id] && (
                <div style={{ 
                  marginTop: '8px', 
                  fontSize: '12px', 
                  color: '#666',
                  fontStyle: 'italic'
                }}>
                  {item.explanation}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Main Building Area */}
        <div style={{
          flex: 1,
          padding: '20px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          position: 'relative'
        }}>
          {/* Foundation Visualization */}
          <div style={{
            display: 'flex',
            flexDirection: 'column-reverse',
            alignItems: 'center',
            height: '400px',
            justifyContent: 'flex-start'
          }}>
            {/* Tier 4 - Universal */}
            <div
              onDragOver={(e) => handleDragOver(e, 'universal')}
              onDrop={(e) => handleDrop(e, 'universal')}
              style={{
                width: '200px',
                height: '60px',
                border: droppedItems.universal ? 'none' : '2px dashed #9932CC',
                backgroundColor: droppedItems.universal ? '#9932CC' : 'transparent',
                color: droppedItems.universal ? 'white' : '#9932CC',
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '4px',
                fontSize: '12px',
                textAlign: 'center',
                opacity: viewMode === 'broken' ? 0.3 : 1,
                transform: viewMode === 'broken' ? 'rotate(-5deg)' : 'none'
              }}
            >
              {droppedItems.universal?.label || 'Universal Forgiveness'}
            </div>

            {/* Tier 3 - Self */}
            <div
              onDragOver={(e) => handleDragOver(e, 'personal')}
              onDrop={(e) => handleDrop(e, 'personal')}
              style={{
                width: '250px',
                height: '60px',
                border: droppedItems.personal ? 'none' : '2px dashed #228B22',
                backgroundColor: droppedItems.personal ? '#228B22' : 'transparent',
                color: droppedItems.personal ? 'white' : '#228B22',
                borderRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '4px',
                fontSize: '12px',
                textAlign: 'center',
                opacity: viewMode === 'broken' ? 0.4 : 1,
                transform: viewMode === 'broken' ? 'rotate(3deg)' : 'none'
              }}
            >
              {droppedItems.personal?.label || 'Self-Forgiveness'}
            </div>

            {/* Tier 2 - Relationships */}
            <div
              onDragOver={(e) => handleDragOver(e, 'relationships')}
              onDrop={(e) => handleDrop(e, 'relationships')}
              style={{
                width: '300px',
                minHeight: '80px',
                border: (droppedItems.relationships && droppedItems.relationships.length > 0) ? 'none' : '2px dashed #4682B4',
                backgroundColor: (droppedItems.relationships && droppedItems.relationships.length > 0) ? '#4682B4' : 'transparent',
                color: (droppedItems.relationships && droppedItems.relationships.length > 0) ? 'white' : '#4682B4',
                borderRadius: '8px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '4px',
                padding: '10px',
                fontSize: '12px',
                textAlign: 'center',
                opacity: viewMode === 'broken' ? 0.5 : 1,
                transform: viewMode === 'broken' ? 'rotate(-2deg)' : 'none'
              }}
            >
              {droppedItems.relationships && droppedItems.relationships.length > 0 ? (
                <>
                  <div style={{ fontWeight: 'bold', marginBottom: '5px', fontSize: '13px' }}>RELATIONSHIPS</div>
                  {droppedItems.relationships.map((item, index) => (
                    <div key={item.id} style={{ margin: '2px 0', fontSize: '11px' }}>
                      • {item.label}
                    </div>
                  ))}
                </>
              ) : (
                'Close Relationships\n(Drop relationship skills here)'
              )}
            </div>

            {/* Tier 1 - Foundation */}
            <div
              onDragOver={(e) => handleDragOver(e, 'foundation')}
              onDrop={(e) => handleDrop(e, 'foundation')}
              style={{
                width: '400px',
                minHeight: '120px',
                border: (droppedItems.foundation && droppedItems.foundation.length > 0) ? 'none' : '3px dashed #8B4513',
                backgroundColor: (droppedItems.foundation && droppedItems.foundation.length > 0) ? '#8B4513' : 'transparent',
                color: (droppedItems.foundation && droppedItems.foundation.length > 0) ? 'white' : '#8B4513',
                borderRadius: '8px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '4px',
                padding: '10px',
                fontSize: '12px',
                textAlign: 'center',
                opacity: viewMode === 'broken' ? 0.6 : 1,
                transform: viewMode === 'broken' ? 'rotate(1deg)' : 'none'
              }}
            >
              {droppedItems.foundation && droppedItems.foundation.length > 0 ? (
                <>
                  <div style={{ fontWeight: 'bold', marginBottom: '8px', fontSize: '14px' }}>PARENTAL FOUNDATION</div>
                  {droppedItems.foundation.map((item, index) => (
                    <div key={item.id} style={{ margin: '2px 0', fontSize: '11px' }}>
                      • {item.label}
                    </div>
                  ))}
                  <div style={{ marginTop: '5px', fontSize: '10px', opacity: 0.8 }}>
                    ({droppedItems.foundation.length}/3 complete)
                  </div>
                </>
              ) : (
                'PARENTAL FOUNDATION\n(Drop all 3 parental skills here)'
              )}
            </div>
          </div>

          {/* Status Messages */}
          {!foundationComplete && (
            <div style={{
              marginTop: '20px',
              padding: '10px',
              backgroundColor: '#FFF3CD',
              border: '1px solid #FFEAA7',
              borderRadius: '4px',
              color: '#856404',
              textAlign: 'center'
            }}>
              Place all 3 parental forgiveness skills in the foundation ({(droppedItems.foundation || []).length}/3 complete)
            </div>
          )}

          {foundationComplete && (
            <div style={{
              marginTop: '20px',
              padding: '10px',
              backgroundColor: '#D4EDDA',
              border: '1px solid #C3E6CB',
              borderRadius: '4px',
              color: '#155724',
              textAlign: 'center'
            }}>
              Foundation complete! Now build higher levels of forgiveness
            </div>
          )}

          {viewMode === 'broken' && (
            <div style={{
              marginTop: '20px',
              padding: '15px',
              backgroundColor: '#F8D7DA',
              border: '1px solid #F5C6CB',
              borderRadius: '4px',
              color: '#721C24',
              textAlign: 'center',
              maxWidth: '400px'
            }}>
              <strong>Broken Foundation Effect:</strong><br />
              Without resolving parental relationships, all other forgiveness becomes unstable and may collapse under pressure.
            </div>
          )}

          {/* Feedback */}
          {feedback && (
            <div style={{
              position: 'absolute',
              bottom: '20px',
              padding: '15px',
              backgroundColor: feedbackType === 'success' ? '#D4EDDA' : '#F8D7DA',
              border: `1px solid ${feedbackType === 'success' ? '#C3E6CB' : '#F5C6CB'}`,
              color: feedbackType === 'success' ? '#155724' : '#721C24',
              borderRadius: '8px',
              maxWidth: '400px',
              textAlign: 'center'
            }}>
              {feedback}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}