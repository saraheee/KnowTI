import { useState, useEffect, useRef, useCallback } from 'react';

export default function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [phase, setPhase] = useState('initial');
  const [showingForgiveness, setShowingForgiveness] = useState(false);
  const [hoveredArea, setHoveredArea] = useState(null);
  const animationRef = useRef(null);
  const startTimeRef = useRef(null);

  const lifeAreas = [
    { id: 'relationships', name: 'Relationships', x: 200, y: 150, color: '#FF6B6B', impact: 'Trust issues, isolation, fear of intimacy' },
    { id: 'work', name: 'Work/Career', x: 500, y: 180, color: '#4ECDC4', impact: 'Difficulty concentrating, reduced performance, absenteeism' },
    { id: 'health', name: 'Physical Health', x: 350, y: 300, color: '#45B7D1', impact: 'Chronic stress, sleep issues, weakened immune system' },
    { id: 'mental', name: 'Mental Health', x: 150, y: 400, color: '#96CEB4', impact: 'Anxiety, depression, PTSD symptoms, hypervigilance' },
    { id: 'spiritual', name: 'Spiritual Life', x: 550, y: 350, color: '#FFEAA7', impact: 'Loss of meaning, questioning beliefs, spiritual emptiness' },
    { id: 'future', name: 'Future Planning', x: 400, y: 480, color: '#DDA0DD', impact: 'Inability to envision future, fear-based decisions' }
  ];

  const phases = [
    { name: 'initial', duration: 2000, label: 'Before Trauma' },
    { name: 'impact', duration: 3000, label: 'Trauma Impact' },
    { name: 'ripples', duration: 4000, label: 'Ripple Effects Spread' },
    { name: 'chaos', duration: 3000, label: 'Life Areas Disrupted' },
    { name: 'forgiveness_start', duration: 2000, label: 'Beginning Forgiveness Work' },
    { name: 'forgiveness_spread', duration: 4000, label: 'Forgiveness Calming Waves' },
    { name: 'healing', duration: 3000, label: 'Deep Healing Process' },
    { name: 'transformation', duration: 2000, label: 'Transformation Complete' }
  ];

  const getWaveIntensity = useCallback(() => {
    if (!showingForgiveness) {
      switch(phase) {
        case 'initial': return 0;
        case 'impact': return 0.3;
        case 'ripples': return 0.7;
        case 'chaos': return 1;
        default: return 1;
      }
    } else {
      switch(phase) {
        case 'forgiveness_start': return 0.8;
        case 'forgiveness_spread': return 0.5;
        case 'healing': return 0.2;
        case 'transformation': return 0;
        default: return 0;
      }
    }
  }, [phase, showingForgiveness]);

  const animate = useCallback(() => {
    if (!isPlaying) return;

    const currentTime = Date.now();
    if (!startTimeRef.current) startTimeRef.current = currentTime;
    
    const elapsed = (currentTime - startTimeRef.current) * speed;
    
    let totalDuration = 0;
    let currentPhaseIndex = 0;
    
    for (let i = 0; i < phases.length; i++) {
      if (elapsed < totalDuration + phases[i].duration) {
        currentPhaseIndex = i;
        break;
      }
      totalDuration += phases[i].duration;
    }

    const newPhase = phases[currentPhaseIndex]?.name || 'transformation';
    if (newPhase !== phase) {
      setPhase(newPhase);
      if (newPhase === 'forgiveness_start') {
        setShowingForgiveness(true);
      }
    }

    if (currentPhaseIndex < phases.length - 1) {
      animationRef.current = requestAnimationFrame(animate);
    } else {
      setIsPlaying(false);
    }
  }, [isPlaying, speed, phase, phases]);

  useEffect(() => {
    if (isPlaying) {
      animationRef.current = requestAnimationFrame(animate);
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    }
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, animate]);

  const handlePlayPause = () => {
    if (isPlaying) {
      setIsPlaying(false);
      startTimeRef.current = null;
    } else {
      setIsPlaying(true);
      startTimeRef.current = Date.now();
    }
  };

  const handleReset = () => {
    setIsPlaying(false);
    setPhase('initial');
    setShowingForgiveness(false);
    startTimeRef.current = null;
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  };

  const toggleState = () => {
    setShowingForgiveness(!showingForgiveness);
    if (!showingForgiveness) {
      setPhase('forgiveness_start');
    } else {
      setPhase('impact');
    }
  };

  const currentPhaseLabel = phases.find(p => p.name === phase)?.label || '';
  const waveIntensity = getWaveIntensity();

  return (
    <div style={{
      width: '100%',
      height: '100vh',
      backgroundColor: '#ffffff',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Toolbar */}
      <div style={{
        position: 'absolute',
        top: '20px',
        left: '20px',
        display: 'flex',
        gap: '15px',
        alignItems: 'center',
        background: 'rgba(255, 255, 255, 0.9)',
        padding: '10px 15px',
        borderRadius: '8px',
        boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
        zIndex: 100
      }}>
        <button
          onClick={handlePlayPause}
          style={{
            background: '#4ECDC4',
            border: 'none',
            borderRadius: '4px',
            padding: '8px 12px',
            color: 'white',
            cursor: 'pointer',
            fontSize: '14px'
          }}
        >
          {isPlaying ? '⏸' : '▶'}
        </button>
        
        <button
          onClick={handleReset}
          style={{
            background: '#FF6B6B',
            border: 'none',
            borderRadius: '4px',
            padding: '8px 12px',
            color: 'white',
            cursor: 'pointer',
            fontSize: '12px'
          }}
        >
          Reset
        </button>

        <label style={{ fontSize: '12px', display: 'flex', alignItems: 'center', gap: '5px' }}>
          Speed:
          <input
            type="range"
            min="0.5"
            max="3"
            step="0.1"
            value={speed}
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            style={{ width: '60px' }}
          />
          <span style={{ fontSize: '11px', minWidth: '25px' }}>{speed}×</span>
        </label>

        <button
          onClick={toggleState}
          style={{
            background: showingForgiveness ? '#96CEB4' : '#DDA0DD',
            border: 'none',
            borderRadius: '4px',
            padding: '8px 12px',
            color: 'white',
            cursor: 'pointer',
            fontSize: '11px'
          }}
        >
          {showingForgiveness ? 'Show Trauma' : 'Show Forgiveness'}
        </button>
      </div>

      {/* Phase Label */}
      {currentPhaseLabel && (
        <div style={{
          position: 'absolute',
          top: '100px',
          left: '50%',
          transform: 'translateX(-50%)',
          background: showingForgiveness ? 'rgba(150, 206, 180, 0.9)' : 'rgba(255, 107, 107, 0.9)',
          color: 'white',
          padding: '10px 20px',
          borderRadius: '20px',
          fontSize: '16px',
          fontWeight: 'bold',
          zIndex: 50
        }}>
          {currentPhaseLabel}
        </div>
      )}

      {/* Trauma Center */}
      <div style={{
        position: 'absolute',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        width: '60px',
        height: '60px',
        borderRadius: '50%',
        background: showingForgiveness ? 
          `radial-gradient(circle, rgba(150, 206, 180, ${0.3 + waveIntensity * 0.4}), rgba(150, 206, 180, 0.1))` :
          `radial-gradient(circle, rgba(255, 107, 107, ${0.3 + waveIntensity * 0.7}), rgba(255, 107, 107, 0.1))`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'white',
        fontSize: '12px',
        fontWeight: 'bold',
        zIndex: 40,
        boxShadow: showingForgiveness ? 
          `0 0 ${20 + waveIntensity * 40}px rgba(150, 206, 180, 0.6)` :
          `0 0 ${20 + waveIntensity * 60}px rgba(255, 107, 107, 0.8)`
      }}>
        {showingForgiveness ? 'HEALING' : 'TRAUMA'}
      </div>

      {/* Ripple Waves */}
      {[1, 2, 3, 4].map(i => (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            width: `${60 + i * 80 * (0.5 + waveIntensity)}px`,
            height: `${60 + i * 80 * (0.5 + waveIntensity)}px`,
            borderRadius: '50%',
            border: `2px solid ${showingForgiveness ? 
              `rgba(150, 206, 180, ${0.3 - i * 0.05})` : 
              `rgba(255, 107, 107, ${0.4 - i * 0.08})`}`,
            opacity: waveIntensity > 0 ? (0.8 - i * 0.15) * waveIntensity : 0,
            transition: 'all 0.3s ease-out',
            zIndex: 30 - i
          }}
        />
      ))}

      {/* Life Areas */}
      {lifeAreas.map(area => {
        const disturbance = waveIntensity * (showingForgiveness ? 0.3 : 1);
        const shake = disturbance * 5;
        
        return (
          <div
            key={area.id}
            onMouseEnter={() => setHoveredArea(area.id)}
            onMouseLeave={() => setHoveredArea(null)}
            style={{
              position: 'absolute',
              left: `${area.x + (Math.random() - 0.5) * shake}px`,
              top: `${area.y + (Math.random() - 0.5) * shake}px`,
              width: '100px',
              height: '80px',
              background: showingForgiveness ? 
                `linear-gradient(135deg, ${area.color}cc, ${area.color}88)` :
                `linear-gradient(135deg, ${area.color}${disturbance > 0.5 ? '66' : 'cc'}, ${area.color}44)`,
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white',
              fontSize: '11px',
              fontWeight: 'bold',
              textAlign: 'center',
              cursor: 'pointer',
              transform: `scale(${1 - disturbance * 0.1}) rotate(${(Math.random() - 0.5) * shake}deg)`,
              transition: 'all 0.2s ease-out',
              boxShadow: showingForgiveness ? 
                `0 4px 15px rgba(150, 206, 180, 0.3)` :
                `0 4px 15px rgba(0, 0, 0, ${0.1 + disturbance * 0.3})`,
              zIndex: hoveredArea === area.id ? 60 : 20,
              opacity: showingForgiveness ? (0.9 + waveIntensity * 0.1) : Math.max(0.4, 1 - disturbance * 0.4)
            }}
          >
            {area.name}
            
            {hoveredArea === area.id && (
              <div style={{
                position: 'absolute',
                bottom: '90px',
                left: '50%',
                transform: 'translateX(-50%)',
                background: 'rgba(0, 0, 0, 0.9)',
                color: 'white',
                padding: '8px 12px',
                borderRadius: '6px',
                fontSize: '11px',
                whiteSpace: 'nowrap',
                maxWidth: '200px',
                whiteSpace: 'normal',
                textAlign: 'left',
                zIndex: 70
              }}>
                <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>{area.name}</div>
                <div>{area.impact}</div>
              </div>
            )}
          </div>
        );
      })}

      {/* Forgiveness Indicators */}
      {showingForgiveness && waveIntensity < 0.8 && (
        <>
          {[1, 2, 3, 4, 5].map(i => (
            <div
              key={`forgiveness-${i}`}
              style={{
                position: 'absolute',
                left: `${200 + i * 120}px`,
                top: `${100 + (i % 2) * 50}px`,
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                background: 'rgba(150, 206, 180, 0.8)',
                opacity: phase === 'healing' || phase === 'transformation' ? 1 : 0,
                transition: 'opacity 0.5s ease-out',
                animation: phase === 'healing' ? `float-${i} 2s ease-in-out infinite` : 'none',
                zIndex: 25
              }}
            />
          ))}
        </>
      )}

      {/* Bottom Explanation */}
      <div style={{
        position: 'absolute',
        bottom: '30px',
        left: '50%',
        transform: 'translateX(-50%)',
        textAlign: 'center',
        color: '#666',
        fontSize: '14px',
        maxWidth: '600px'
      }}>
        <div style={{ fontWeight: 'bold', marginBottom: '8px' }}>
          {showingForgiveness ? 
            'Deep Forgiveness Calms the Waves of Trauma' : 
            'Trauma Creates Ripples Through All Life Areas'}
        </div>
        <div style={{ fontSize: '12px' }}>
          {showingForgiveness ? 
            'Forgiveness work gradually reduces the intensity of trauma\'s impact, bringing peace to disrupted life areas.' : 
            'Serious trauma doesn\'t stay contained—it affects relationships, work, health, and future planning.'}
        </div>
      </div>

      <style>
        {`
          @keyframes float-1 { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-10px); } }
          @keyframes float-2 { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-15px); } }
          @keyframes float-3 { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-8px); } }
          @keyframes float-4 { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-12px); } }
          @keyframes float-5 { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-9px); } }
        `}
      </style>
    </div>
  );
}