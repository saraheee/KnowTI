import React, { useState, useRef, useCallback } from 'react';

export default function App() {
  const [draggedItem, setDraggedItem] = useState(null);
  const [droppedItems, setDroppedItems] = useState({});
  const [feedback, setFeedback] = useState({});
  const [showBrokenState, setShowBrokenState] = useState(true);
  const [dragOverTarget, setDragOverTarget] = useState(null);
  const [hoveredInfo, setHoveredInfo] = useState(null);
  const dragCounter = useRef(0);

  const courageElements = [
    {
      id: 'acknowledge',
      label: 'Acknowledge Harm',
      description: 'Recognizing the impact of your actions on others'
    },
    {
      id: 'responsibility',
      label: 'Take Responsibility',
      description: 'Owning your mistakes without making excuses'
    },
    {
      id: 'vulnerability',
      label: 'Show Vulnerability',
      description: 'Opening yourself to possible rejection or pain'
    },
    {
      id: 'empathy',
      label: 'Express Empathy',
      description: 'Understanding and validating the other person\'s feelings'
    },
    {
      id: 'commitment',
      label: 'Commit to Change',
      description: 'Promising specific actions to prevent future harm'
    }
  ];

  const bridgeTargets = [
    {
      id: 'foundation',
      position: { left: '15%', top: '60%' },
      correctElement: 'acknowledge',
      feedback: 'Acknowledging harm creates the foundation of trust. Without recognition of wrongdoing, no genuine repair can begin.',
      hint: 'Every bridge needs a solid foundation - what must come first in an apology?'
    },
    {
      id: 'support1',
      position: { left: '30%', top: '50%' },
      correctElement: 'responsibility',
      feedback: 'Taking responsibility shows courage to face consequences. It demonstrates you\'re serious about making things right.',
      hint: 'This support beam requires owning your actions without deflecting blame.'
    },
    {
      id: 'arch',
      position: { left: '45%', top: '40%' },
      correctElement: 'vulnerability',
      feedback: 'Vulnerability is the arch that bears the weight of reconciliation. It takes immense courage to risk emotional exposure.',
      hint: 'The strongest part of the bridge requires opening your heart despite fear.'
    },
    {
      id: 'support2',
      position: { left: '60%', top: '50%' },
      correctElement: 'empathy',
      feedback: 'Empathy validates their pain and shows you truly understand the damage. This connection rebuilds emotional trust.',
      hint: 'This support beam connects by truly understanding their perspective.'
    },
    {
      id: 'anchor',
      position: { left: '75%', top: '60%' },
      correctElement: 'commitment',
      feedback: 'Commitment to change anchors the bridge in future hope. It shows your apology leads to lasting transformation.',
      hint: 'The final anchor point looks toward the future - what seals your promise?'
    }
  ];

  const handleDragStart = useCallback((e, element) => {
    setDraggedItem(element);
    e.dataTransfer.effectAllowed = 'move';
  }, []);

  const handleDragEnd = useCallback(() => {
    setDraggedItem(null);
    setDragOverTarget(null);
    dragCounter.current = 0;
  }, []);

  const handleDragOver = useCallback((e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  }, []);

  const handleDragEnter = useCallback((e, targetId) => {
    e.preventDefault();
    dragCounter.current++;
    setDragOverTarget(targetId);
  }, []);

  const handleDragLeave = useCallback((e) => {
    dragCounter.current--;
    if (dragCounter.current === 0) {
      setDragOverTarget(null);
    }
  }, []);

  const handleDrop = useCallback((e, target) => {
    e.preventDefault();
    dragCounter.current = 0;
    setDragOverTarget(null);

    if (!draggedItem) return;

    const isCorrect = draggedItem.id === target.correctElement;
    
    if (isCorrect) {
      setDroppedItems(prev => ({ ...prev, [target.id]: draggedItem }));
      setFeedback(prev => ({ 
        ...prev, 
        [target.id]: { type: 'success', message: target.feedback }
      }));
    } else {
      setFeedback(prev => ({ 
        ...prev, 
        [target.id]: { type: 'error', message: target.hint }
      }));
    }

    setTimeout(() => {
      setFeedback(prev => ({ ...prev, [target.id]: null }));
    }, 3000);
  }, [draggedItem]);

  const resetBridge = useCallback(() => {
    setDroppedItems({});
    setFeedback({});
    setDraggedItem(null);
    setDragOverTarget(null);
  }, []);

  const availableElements = courageElements.filter(element => 
    !Object.values(droppedItems).some(dropped => dropped.id === element.id)
  );

  const isComplete = Object.keys(droppedItems).length === bridgeTargets.length;

  return (
    <div style={{
      width: '100%',
      height: '100vh',
      backgroundColor: '#ffffff',
      fontFamily: 'Arial, sans-serif',
      overflow: 'hidden',
      position: 'relative'
    }}>
      {/* Header */}
      <div style={{
        position: 'absolute',
        top: '20px',
        left: '20px',
        right: '20px',
        zIndex: 100
      }}>
        <h1 style={{
          margin: 0,
          fontSize: '28px',
          fontWeight: 'bold',
          color: '#2c3e50',
          textAlign: 'center'
        }}>
          Relationship Bridge Builder
        </h1>
        <p style={{
          margin: '10px 0',
          fontSize: '16px',
          color: '#7f8c8d',
          textAlign: 'center'
        }}>
          Drag courage elements to build bridges that reconnect broken relationships
        </p>
      </div>

      {/* State Toggle */}
      <button
        onClick={() => setShowBrokenState(!showBrokenState)}
        style={{
          position: 'absolute',
          top: '20px',
          right: '20px',
          padding: '10px 20px',
          backgroundColor: showBrokenState ? '#e74c3c' : '#27ae60',
          color: 'white',
          border: 'none',
          borderRadius: '25px',
          cursor: 'pointer',
          fontSize: '14px',
          fontWeight: 'bold',
          zIndex: 101
        }}
      >
        {showBrokenState ? 'Broken State' : 'Healing State'}
      </button>

      {/* Main Scene */}
      <div style={{
        position: 'absolute',
        top: '120px',
        left: 0,
        right: 0,
        bottom: '120px',
        background: showBrokenState 
          ? 'linear-gradient(to bottom, #34495e 0%, #2c3e50 100%)'
          : 'linear-gradient(to bottom, #74b9ff 0%, #0984e3 100%)'
      }}>
        {/* Chasm */}
        <div style={{
          position: 'absolute',
          left: '20%',
          right: '20%',
          top: '65%',
          height: '35%',
          backgroundColor: '#1a1a1a',
          borderRadius: '10px 10px 0 0',
          boxShadow: 'inset 0 10px 30px rgba(0,0,0,0.7)'
        }} />

        {/* Left Side (Person 1) */}
        <div 
          style={{
            position: 'absolute',
            left: '5%',
            top: '40%',
            width: '80px',
            height: '80px',
            backgroundColor: showBrokenState ? '#e74c3c' : '#27ae60',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '30px',
            color: 'white',
            cursor: 'pointer',
            transform: showBrokenState ? 'rotate(-10deg)' : 'rotate(0deg)',
            transition: 'all 0.3s ease'
          }}
          onMouseEnter={() => setHoveredInfo('person1')}
          onMouseLeave={() => setHoveredInfo(null)}
        >
          😔
        </div>

        {/* Right Side (Person 2) */}
        <div 
          style={{
            position: 'absolute',
            right: '5%',
            top: '40%',
            width: '80px',
            height: '80px',
            backgroundColor: showBrokenState ? '#e74c3c' : '#27ae60',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '30px',
            color: 'white',
            cursor: 'pointer',
            transform: showBrokenState ? 'rotate(10deg)' : 'rotate(0deg)',
            transition: 'all 0.3s ease'
          }}
          onMouseEnter={() => setHoveredInfo('person2')}
          onMouseLeave={() => setHoveredInfo(null)}
        >
          💔
        </div>

        {/* Bridge Targets */}
        {bridgeTargets.map((target) => {
          const isDropped = droppedItems[target.id];
          const isHighlighted = dragOverTarget === target.id;
          const currentFeedback = feedback[target.id];
          
          return (
            <div
              key={target.id}
              style={{
                position: 'absolute',
                left: target.position.left,
                top: target.position.top,
                width: '60px',
                height: '40px',
                border: isDropped 
                  ? '3px solid #27ae60'
                  : isHighlighted
                    ? '3px solid #f39c12'
                    : '3px dashed #95a5a6',
                borderRadius: '8px',
                backgroundColor: isDropped 
                  ? '#27ae60'
                  : isHighlighted 
                    ? 'rgba(243, 156, 18, 0.3)'
                    : 'rgba(255, 255, 255, 0.1)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '10px',
                color: isDropped ? 'white' : '#bdc3c7',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                transform: `translateX(-50%) translateY(-50%) ${isDropped ? 'scale(1.1)' : 'scale(1)'}`,
                zIndex: 10
              }}
              onDragOver={handleDragOver}
              onDragEnter={(e) => handleDragEnter(e, target.id)}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, target)}
              onMouseEnter={() => setHoveredInfo(target.id)}
              onMouseLeave={() => setHoveredInfo(null)}
            >
              {isDropped ? isDropped.label : target.id.toUpperCase()}
              
              {currentFeedback && (
                <div style={{
                  position: 'absolute',
                  top: '-80px',
                  left: '50%',
                  transform: 'translateX(-50%)',
                  backgroundColor: currentFeedback.type === 'success' ? '#27ae60' : '#e74c3c',
                  color: 'white',
                  padding: '8px 12px',
                  borderRadius: '6px',
                  fontSize: '12px',
                  whiteSpace: 'nowrap',
                  maxWidth: '200px',
                  whiteSpace: 'normal',
                  textAlign: 'center',
                  zIndex: 1000
                }}>
                  {currentFeedback.message}
                </div>
              )}
            </div>
          );
        })}

        {/* Completion Effect */}
        {isComplete && (
          <div style={{
            position: 'absolute',
            left: '15%',
            right: '15%',
            top: '40%',
            height: '4px',
            background: 'linear-gradient(90deg, #27ae60, #2ecc71, #27ae60)',
            borderRadius: '2px',
            boxShadow: '0 0 20px rgba(46, 204, 113, 0.6)',
            animation: 'pulse 2s infinite'
          }} />
        )}
      </div>

      {/* Courage Elements Panel */}
      <div style={{
        position: 'absolute',
        bottom: '20px',
        left: '20px',
        right: '20px',
        height: '80px',
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderRadius: '10px',
        padding: '10px',
        boxShadow: '0 -5px 20px rgba(0,0,0,0.1)',
        display: 'flex',
        alignItems: 'center',
        gap: '15px',
        overflowX: 'auto'
      }}>
        <div style={{
          fontSize: '14px',
          fontWeight: 'bold',
          color: '#2c3e50',
          minWidth: 'fit-content'
        }}>
          Courage Elements:
        </div>
        
        {availableElements.map((element) => (
          <div
            key={element.id}
            draggable
            onDragStart={(e) => handleDragStart(e, element)}
            onDragEnd={handleDragEnd}
            onMouseEnter={() => setHoveredInfo(element.id)}
            onMouseLeave={() => setHoveredInfo(null)}
            style={{
              padding: '8px 16px',
              backgroundColor: '#3498db',
              color: 'white',
              borderRadius: '20px',
              cursor: 'grab',
              fontSize: '12px',
              fontWeight: 'bold',
              whiteSpace: 'nowrap',
              opacity: draggedItem?.id === element.id ? 0.5 : 1,
              transform: draggedItem?.id === element.id ? 'scale(0.95)' : 'scale(1)',
              transition: 'all 0.2s ease',
              position: 'relative',
              minWidth: 'fit-content'
            }}
          >
            {element.label}
          </div>
        ))}

        <button
          onClick={resetBridge}
          style={{
            marginLeft: 'auto',
            padding: '8px 16px',
            backgroundColor: '#95a5a6',
            color: 'white',
            border: 'none',
            borderRadius: '20px',
            cursor: 'pointer',
            fontSize: '12px',
            fontWeight: 'bold',
            minWidth: 'fit-content'
          }}
        >
          Reset
        </button>
      </div>

      {/* Hover Information */}
      {hoveredInfo && (
        <div style={{
          position: 'fixed',
          bottom: '120px',
          left: '50%',
          transform: 'translateX(-50%)',
          backgroundColor: '#2c3e50',
          color: 'white',
          padding: '12px 16px',
          borderRadius: '8px',
          fontSize: '14px',
          maxWidth: '300px',
          textAlign: 'center',
          zIndex: 1000,
          pointerEvents: 'none'
        }}>
          {hoveredInfo === 'person1' && (showBrokenState 
            ? "Hurt and distant, unable to bridge the gap alone"
            : "Healing through courageous connection")}
          {hoveredInfo === 'person2' && (showBrokenState 
            ? "Wounded and waiting for genuine repair"
            : "Open to reconciliation through authentic apology")}
          {courageElements.find(el => el.id === hoveredInfo)?.description}
          {bridgeTargets.find(t => t.id === hoveredInfo) && 
            `Bridge component: ${hoveredInfo.charAt(0).toUpperCase() + hoveredInfo.slice(1)}`}
        </div>
      )}

      {/* CSS Animations */}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scaleY(1); }
          50% { opacity: 0.7; transform: scaleY(1.2); }
        }
      `}</style>
    </div>
  );
}