import { useState, useRef, useCallback } from 'react';

export default function App() {
  const [draggedItem, setDraggedItem] = useState(null);
  const [dropTargets, setDropTargets] = useState({
    emotional: { item: null, isCorrect: false, feedback: '' },
    trust: { item: null, isCorrect: false, feedback: '' },
    communication: { item: null, isCorrect: false, feedback: '' },
    boundaries: { item: null, isCorrect: false, feedback: '' }
  });
  const [dragOverTarget, setDragOverTarget] = useState(null);
  const [showFoundation, setShowFoundation] = useState(true);
  const [hoveredItem, setHoveredItem] = useState(null);

  const forgivenessElements = [
    {
      id: 'emotional-healing',
      label: 'Emotional Healing',
      description: 'Processing hurt and pain from parental relationships',
      category: 'emotional'
    },
    {
      id: 'trust-rebuild',
      label: 'Trust Rebuilding',
      description: 'Learning to trust again after parental disappointments',
      category: 'trust'
    },
    {
      id: 'open-dialogue',
      label: 'Open Dialogue',
      description: 'Creating safe spaces for honest conversations',
      category: 'communication'
    },
    {
      id: 'healthy-limits',
      label: 'Healthy Boundaries',
      description: 'Setting appropriate limits while maintaining connection',
      category: 'boundaries'
    },
    {
      id: 'resentment',
      label: 'Resentment',
      description: 'Holding onto anger and hurt (blocks forgiveness)',
      category: 'incorrect'
    },
    {
      id: 'isolation',
      label: 'Isolation',
      description: 'Cutting off all communication (avoids rather than forgives)',
      category: 'incorrect'
    }
  ];

  const correctMappings = {
    emotional: 'emotional-healing',
    trust: 'trust-rebuild',
    communication: 'open-dialogue',
    boundaries: 'healthy-limits'
  };

  const feedbackMessages = {
    'emotional-healing': 'Emotional healing is the cornerstone of parental forgiveness - addressing deep hurts creates space for all other relationships to heal.',
    'trust-rebuild': 'Rebuilding trust with parents teaches us how to navigate broken trust in all relationships - it\'s the template for future forgiveness.',
    'open-dialogue': 'Learning to communicate openly with parents, despite past hurt, builds skills essential for resolving conflicts in any relationship.',
    'healthy-limits': 'Setting boundaries while forgiving parents models how to protect yourself while still choosing love in difficult relationships.'
  };

  const handleDragStart = (e, item) => {
    setDraggedItem(item);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e, targetId) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverTarget(targetId);
  };

  const handleDragLeave = () => {
    setDragOverTarget(null);
  };

  const handleDrop = (e, targetId) => {
    e.preventDefault();
    setDragOverTarget(null);

    if (!draggedItem) return;

    const isCorrect = correctMappings[targetId] === draggedItem.id;
    
    setDropTargets(prev => ({
      ...prev,
      [targetId]: {
        item: draggedItem,
        isCorrect,
        feedback: isCorrect 
          ? feedbackMessages[draggedItem.id]
          : `${draggedItem.label} doesn't build a foundation for forgiveness. Try finding an element that actively promotes healing and growth.`
      }
    }));

    if (!isCorrect) {
      setTimeout(() => {
        setDropTargets(prev => ({
          ...prev,
          [targetId]: { item: null, isCorrect: false, feedback: '' }
        }));
      }, 3000);
    }

    setDraggedItem(null);
  };

  const resetAll = () => {
    setDropTargets({
      emotional: { item: null, isCorrect: false, feedback: '' },
      trust: { item: null, isCorrect: false, feedback: '' },
      communication: { item: null, isCorrect: false, feedback: '' },
      boundaries: { item: null, isCorrect: false, feedback: '' }
    });
    setDraggedItem(null);
    setDragOverTarget(null);
  };

  const getAvailableItems = () => {
    const placedItems = Object.values(dropTargets)
      .filter(target => target.item && target.isCorrect)
      .map(target => target.item.id);
    
    return forgivenessElements.filter(item => !placedItems.includes(item.id));
  };

  const allCorrectlyPlaced = Object.values(dropTargets).every(target => target.isCorrect);

  return (
    <div style={{
      width: '100%',
      height: '100vh',
      backgroundColor: '#ffffff',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {/* Header */}
      <div style={{
        padding: '20px',
        borderBottom: '2px solid #e0e7ff',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <h1 style={{
          margin: 0,
          fontSize: '24px',
          color: '#1e40af',
          fontWeight: '600'
        }}>
          Foundational Forgiveness Builder
        </h1>
        
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
          <button
            onClick={() => setShowFoundation(!showFoundation)}
            style={{
              padding: '8px 16px',
              backgroundColor: showFoundation ? '#10b981' : '#6b7280',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            {showFoundation ? 'Show Without Foundation' : 'Show With Foundation'}
          </button>
          
          <button
            onClick={resetAll}
            style={{
              padding: '8px 16px',
              backgroundColor: '#ef4444',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            Reset
          </button>
        </div>
      </div>

      <div style={{
        flex: 1,
        display: 'flex',
        padding: '20px',
        gap: '20px'
      }}>
        {/* Left Panel - Draggable Items */}
        <div style={{
          width: '300px',
          backgroundColor: '#f8fafc',
          borderRadius: '12px',
          padding: '20px',
          border: '2px solid #e2e8f0'
        }}>
          <h3 style={{
            margin: '0 0 16px 0',
            fontSize: '18px',
            color: '#374151',
            fontWeight: '600'
          }}>
            Forgiveness Elements
          </h3>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {getAvailableItems().map(item => (
              <div
                key={item.id}
                draggable
                onDragStart={(e) => handleDragStart(e, item)}
                onMouseEnter={() => setHoveredItem(item.id)}
                onMouseLeave={() => setHoveredItem(null)}
                style={{
                  padding: '12px',
                  backgroundColor: item.category === 'incorrect' ? '#fef2f2' : '#ffffff',
                  border: `2px solid ${item.category === 'incorrect' ? '#fecaca' : '#e5e7eb'}`,
                  borderRadius: '8px',
                  cursor: 'grab',
                  transition: 'all 0.2s ease',
                  transform: draggedItem?.id === item.id ? 'rotate(5deg)' : 'none',
                  opacity: draggedItem?.id === item.id ? 0.7 : 1,
                  position: 'relative'
                }}
              >
                <div style={{
                  fontSize: '14px',
                  fontWeight: '600',
                  color: item.category === 'incorrect' ? '#dc2626' : '#374151',
                  marginBottom: '4px'
                }}>
                  {item.label}
                </div>
                
                {hoveredItem === item.id && (
                  <div style={{
                    fontSize: '12px',
                    color: '#6b7280',
                    lineHeight: '1.4'
                  }}>
                    {item.description}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Main Area - Foundation Visual */}
        <div style={{
          flex: 1,
          position: 'relative',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center'
        }}>
          {/* Success Message */}
          {allCorrectlyPlaced && (
            <div style={{
              position: 'absolute',
              top: '20px',
              left: '50%',
              transform: 'translateX(-50%)',
              padding: '16px 24px',
              backgroundColor: '#10b981',
              color: 'white',
              borderRadius: '8px',
              fontSize: '16px',
              fontWeight: '600',
              boxShadow: '0 4px 12px rgba(16, 185, 129, 0.3)'
            }}>
              🎉 Foundation Complete! Parental forgiveness now supports all future relationships.
            </div>
          )}

          {/* Foundation Structure */}
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '20px',
            opacity: showFoundation ? 1 : 0.3,
            transition: 'opacity 0.3s ease'
          }}>
            {/* Upper Level - Future Relationships */}
            <div style={{
              padding: '20px',
              backgroundColor: allCorrectlyPlaced ? '#f0fdf4' : '#f9fafb',
              border: `3px solid ${allCorrectlyPlaced ? '#22c55e' : '#d1d5db'}`,
              borderRadius: '12px',
              fontSize: '16px',
              fontWeight: '600',
              color: allCorrectlyPlaced ? '#166534' : '#6b7280',
              textAlign: 'center',
              minWidth: '400px'
            }}>
              Future Forgiveness Relationships
              <div style={{
                fontSize: '12px',
                fontWeight: '400',
                marginTop: '8px',
                color: allCorrectlyPlaced ? '#15803d' : '#9ca3af'
              }}>
                Friends • Partners • Colleagues • Self-Forgiveness
              </div>
            </div>

            {/* Support Beams */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-around',
              width: '100%',
              maxWidth: '600px'
            }}>
              {[1, 2, 3, 4].map(i => (
                <div
                  key={i}
                  style={{
                    width: '8px',
                    height: '60px',
                    backgroundColor: allCorrectlyPlaced ? '#22c55e' : '#d1d5db',
                    transition: 'background-color 0.3s ease'
                  }}
                />
              ))}
            </div>

            {/* Foundation Blocks - Drop Targets */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(2, 1fr)',
              gap: '16px',
              width: '100%',
              maxWidth: '600px'
            }}>
              {[
                { id: 'emotional', label: 'Emotional Foundation', description: 'Processing hurt and pain' },
                { id: 'trust', label: 'Trust Foundation', description: 'Learning to trust again' },
                { id: 'communication', label: 'Communication Foundation', description: 'Safe dialogue spaces' },
                { id: 'boundaries', label: 'Boundary Foundation', description: 'Healthy limits with love' }
              ].map(target => (
                <div
                  key={target.id}
                  onDragOver={(e) => handleDragOver(e, target.id)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, target.id)}
                  style={{
                    minHeight: '120px',
                    border: dropTargets[target.id].item 
                      ? `3px solid ${dropTargets[target.id].isCorrect ? '#22c55e' : '#ef4444'}`
                      : dragOverTarget === target.id 
                        ? '3px solid #3b82f6' 
                        : '3px dashed #d1d5db',
                    borderRadius: '8px',
                    padding: '16px',
                    backgroundColor: dropTargets[target.id].item
                      ? (dropTargets[target.id].isCorrect ? '#f0fdf4' : '#fef2f2')
                      : dragOverTarget === target.id
                        ? '#eff6ff'
                        : '#ffffff',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    textAlign: 'center',
                    transition: 'all 0.2s ease',
                    cursor: draggedItem ? 'copy' : 'default'
                  }}
                >
                  {dropTargets[target.id].item ? (
                    <div>
                      <div style={{
                        fontSize: '14px',
                        fontWeight: '600',
                        color: dropTargets[target.id].isCorrect ? '#166534' : '#dc2626',
                        marginBottom: '8px'
                      }}>
                        {dropTargets[target.id].item.label}
                      </div>
                      <div style={{
                        fontSize: '12px',
                        color: dropTargets[target.id].isCorrect ? '#15803d' : '#b91c1c',
                        lineHeight: '1.4'
                      }}>
                        {dropTargets[target.id].feedback}
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div style={{
                        fontSize: '14px',
                        fontWeight: '600',
                        color: '#6b7280',
                        marginBottom: '4px'
                      }}>
                        {target.label}
                      </div>
                      <div style={{
                        fontSize: '12px',
                        color: '#9ca3af'
                      }}>
                        {target.description}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Foundation Label */}
            <div style={{
              padding: '16px 32px',
              backgroundColor: '#1e40af',
              color: 'white',
              borderRadius: '8px',
              fontSize: '18px',
              fontWeight: '600',
              textAlign: 'center'
            }}>
              PARENTAL FORGIVENESS FOUNDATION
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}