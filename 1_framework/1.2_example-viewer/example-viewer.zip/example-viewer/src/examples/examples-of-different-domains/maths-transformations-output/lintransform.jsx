import { useState, useEffect, useRef } from "react";

const W=440, H=400, CX=220, CY=200, SCALE=52;
function toSvg(x,y,M,t){
  const a=1+(M[0][0]-1)*t, b=M[0][1]*t, c=M[1][0]*t, d=1+(M[1][1]-1)*t;
  return [CX+(a*x+b*y)*SCALE, CY-(c*x+d*y)*SCALE];
}

const PRESETS=[
  { label:"Identity",      key:"id",    M:[[1,0],[0,1]],   color:"#64748b", note:"Every vector maps to itself. The grid doesn't move." },
  { label:"Rotation 45°",  key:"r45",   M:[[0.707,-0.707],[0.707,0.707]], color:"#2563eb", note:"Rotates all vectors 45° counterclockwise. det = 1 → area preserved." },
  { label:"Rotation 90°",  key:"r90",   M:[[0,-1],[1,0]],  color:"#7c3aed", note:"i maps to j, j maps to −i. det = 1 → area preserved." },
  { label:"Shear X",       key:"shx",   M:[[1,1],[0,1]],   color:"#d97706", note:"Horizontal shear. Vertical lines tilt; area unchanged (det = 1)." },
  { label:"Scale 2×",      key:"sc2",   M:[[2,0],[0,2]],   color:"#059669", note:"Uniform scaling. det = 4 → area multiplied by 4." },
  { label:"Reflection Y",  key:"refy",  M:[[-1,0],[0,1]],  color:"#dc2626", note:"Flips across y-axis. det = −1 → orientation reversed." },
  { label:"Squeeze",       key:"sq",    M:[[2,0],[0,0.5]], color:"#0891b2", note:"Horizontal stretch + vertical compression. Area preserved (det = 1)." },
  { label:"Projection X",  key:"proj",  M:[[1,0],[0,0]],   color:"#94a3b8", note:"Collapses all vectors onto the x-axis. det = 0 → not invertible." },
];

export default function App() {
  const [preset,   setPreset]   = useState("id");
  const [t,        setT]        = useState(0);
  const [hov,      setHov]      = useState(null);
  const [showGrid, setShowGrid] = useState(true);
  const [showUnit, setShowUnit] = useState(true);

  const animRef=useRef(null), prevTsRef=useRef(null), targetRef=useRef(0);

  const M = PRESETS.find(p=>p.key===preset)?.M || [[1,0],[0,1]];
  const P = PRESETS.find(p=>p.key===preset);

  const det = M[0][0]*M[1][1] - M[0][1]*M[1][0];

  useEffect(()=>{
    targetRef.current=1;
    setT(0);
    let prev=null;
    const go=(ts)=>{
      if(prev!==null){
        const dt=ts-prev;
        setT(v=>{
          const next=v+dt*0.0018;
          if(next>=1){cancelAnimationFrame(animRef.current);return 1;}
          return next;
        });
      }
      prev=ts;
      animRef.current=requestAnimationFrame(go);
    };
    animRef.current=requestAnimationFrame(go);
    return()=>cancelAnimationFrame(animRef.current);
  },[preset]);

  const RANGE=[-3,-2,-1,0,1,2,3];

  function gridLines(){
    const lines=[];
    if(!showGrid) return lines;
    RANGE.forEach(v=>{
      // Vertical grid line x=v: from y=-3 to y=3
      const [x1,y1]=toSvg(v,-3,M,t), [x2,y2]=toSvg(v,3,M,t);
      lines.push(<line key={`v${v}`} x1={x1} y1={y1} x2={x2} y2={y2}
        stroke={v===0?"#94a3b8":"#e2e8f0"} strokeWidth={v===0?1.5:0.8}/>);
      // Horizontal grid line y=v
      const [x3,y3]=toSvg(-3,v,M,t), [x4,y4]=toSvg(3,v,M,t);
      lines.push(<line key={`h${v}`} x1={x3} y1={y3} x2={x4} y2={y4}
        stroke={v===0?"#94a3b8":"#e2e8f0"} strokeWidth={v===0?1.5:0.8}/>);
    });
    return lines;
  }

  // Unit square (0,0)→(1,0)→(1,1)→(0,1)
  const sq=[[0,0],[1,0],[1,1],[0,1]].map(([x,y])=>toSvg(x,y,M,t));
  const sqPoints=sq.map(p=>p.join(",")).join(" ");

  // Basis vectors
  const [ix,iy]=toSvg(1,0,M,t);
  const [jx,jy]=toSvg(0,1,M,t);
  const ox=CX, oy=CY;

  // Hover point original coords
  const HOVER_PTS=[[-1,2],[2,1],[1,-1],[-2,-1],[2,2],[-1,-2]];

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"15px 24px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:860,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",gap:10,flexWrap:"wrap"}}>
          <div>
            <h1 style={{fontSize:20,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Linear Transformations</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>2×2 matrices acting on ℝ²</p>
          </div>
          <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
            {PRESETS.map(p=>(
              <button key={p.key} onClick={()=>setPreset(p.key)}
                style={{padding:"4px 11px",borderRadius:16,
                  border:`1.5px solid ${preset===p.key?p.color:"#e2e8f0"}`,
                  background:preset===p.key?p.color+"18":"#fff",
                  color:preset===p.key?p.color:"#64748b",
                  fontSize:11,fontWeight:700,cursor:"pointer",transition:"all 0.15s"}}>
                {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",overflow:"hidden",maxWidth:860,margin:"0 auto",width:"100%",
        padding:"10px 20px 12px",boxSizing:"border-box",gap:16}}>

        {/* SVG */}
        <div style={{flex:1,position:"relative"}}>
          <svg viewBox={`0 0 ${W} ${H}`} width="100%" style={{display:"block",maxHeight:360}}>
            {gridLines()}

            {/* Unit square */}
            {showUnit&&<polygon points={sqPoints} fill={P?.color+"22"} stroke={P?.color} strokeWidth={1.5}/>}

            {/* Basis vectors */}
            <defs>
              <marker id="arrI" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 Z" fill="#dc2626"/>
              </marker>
              <marker id="arrJ" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 Z" fill="#16a34a"/>
              </marker>
            </defs>
            <line x1={ox} y1={oy} x2={ix} y2={iy} stroke="#dc2626" strokeWidth={2.5} markerEnd="url(#arrI)"/>
            <line x1={ox} y1={oy} x2={jx} y2={jy} stroke="#16a34a" strokeWidth={2.5} markerEnd="url(#arrJ)"/>
            <text x={ix+6} y={iy+5} fontSize={11} fontWeight={700} fill="#dc2626" fontFamily="system-ui,sans-serif">î</text>
            <text x={jx+6} y={jy+5} fontSize={11} fontWeight={700} fill="#16a34a" fontFamily="system-ui,sans-serif">ĵ</text>

            {/* Hover sample points */}
            {HOVER_PTS.map(([px,py],i)=>{
              const [sx,sy]=toSvg(px,py,M,t);
              const isH=hov===i;
              const [ox0,oy0]=toSvg(px,py,[[1,0],[0,1]],1);
              return (
                <g key={i} style={{cursor:"pointer"}}
                  onMouseEnter={()=>setHov(i)} onMouseLeave={()=>setHov(null)}>
                  <circle cx={sx} cy={sy} r={isH?8:5}
                    fill={isH?"#0f172a":"#94a3b8"}
                    stroke="#fff" strokeWidth={1.5}
                    style={{transition:"r 0.15s"}}/>
                  {isH&&(
                    <g>
                      <line x1={ox0} y1={oy0} x2={sx} y2={sy} stroke="#0f172a" strokeWidth={1} strokeDasharray="3,2" opacity={0.4}/>
                      <rect x={sx+10} y={sy-22} width={110} height={38} rx={6} fill="#0f172a"/>
                      <text x={sx+16} y={sy-9} fontSize={10} fill="#fff" fontFamily="system-ui,sans-serif">
                        ({px},{py}) → ({((M[0][0]*px+M[0][1]*py)*t+(1-t)*px).toFixed(1)}, {((M[1][0]*px+M[1][1]*py)*t+(1-t)*py).toFixed(1)})
                      </text>
                      <text x={sx+16} y={sy+6} fontSize={10} fill="#94a3b8" fontFamily="system-ui,sans-serif">
                        after: ({(M[0][0]*px+M[0][1]*py).toFixed(1)}, {(M[1][0]*px+M[1][1]*py).toFixed(1)})
                      </text>
                    </g>
                  )}
                </g>
              );
            })}
          </svg>
        </div>

        {/* Info panel */}
        <div style={{width:200,display:"flex",flexDirection:"column",gap:12,flexShrink:0}}>
          {/* Matrix display */}
          <div style={{background:"#f8fafc",borderRadius:10,padding:"14px",border:"1px solid #f1f5f9"}}>
            <div style={{fontSize:10,fontWeight:700,color:"#94a3b8",letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:10}}>Matrix</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:4,textAlign:"center",fontFamily:"'Courier New',monospace"}}>
              {M.flat().map((v,i)=>(
                <div key={i} style={{background:"#fff",border:"1px solid #e2e8f0",borderRadius:6,
                  padding:"6px",fontSize:15,fontWeight:700,
                  color:v===0?"#cbd5e1":P?.color}}>
                  {Number(v.toFixed(3))}
                </div>
              ))}
            </div>
            <div style={{marginTop:10,fontSize:11,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span style={{color:"#64748b"}}>det(M)</span>
              <span style={{fontWeight:800,color:Math.abs(det)<0.001?"#dc2626":det<0?"#d97706":"#059669",fontFamily:"monospace"}}>
                {det.toFixed(3)}
              </span>
            </div>
            <div style={{fontSize:10,color:Math.abs(det)<0.001?"#dc2626":det<0?"#d97706":"#64748b",marginTop:3,lineHeight:1.4}}>
              {Math.abs(det)<0.001?"Not invertible — collapses space":det<0?"Reverses orientation":"Area scale factor: "+Math.abs(det).toFixed(2)+"×"}
            </div>
          </div>

          {/* Description */}
          <div style={{background:P?.light||"#f8fafc",border:`1px solid ${P?.border||"#e2e8f0"}`,borderRadius:10,padding:"12px"}}>
            <div style={{fontSize:11,fontWeight:700,color:P?.color,marginBottom:5}}>{P?.label}</div>
            <p style={{fontSize:11,lineHeight:1.65,color:"#334155",margin:0}}>{P?.note}</p>
          </div>

          {/* Toggles */}
          <div style={{display:"flex",flexDirection:"column",gap:6}}>
            {[[showGrid,setShowGrid,"Show grid"],[showUnit,setShowUnit,"Show unit square"]].map(([v,s,l])=>(
              <label key={l} style={{display:"flex",alignItems:"center",gap:7,cursor:"pointer",fontSize:12,color:"#475569"}}>
                <input type="checkbox" checked={v} onChange={e=>s(e.target.checked)} style={{accentColor:P?.color||"#2563eb"}}/>
                {l}
              </label>
            ))}
          </div>
          <p style={{fontSize:11,color:"#94a3b8",margin:0,lineHeight:1.5}}>Hover the grey dots to see how individual points transform.</p>
        </div>
      </div>
    </div>
  );
}
