import { useState, useEffect, useRef, useCallback, useMemo } from "react";

const HARMONICS = [1,3,5,7,9,11,13,15,17,19];
const OMEGA = 1;
const SCALE = 58;
const CX = 155, CY = 160;

function fourierY(t, numTerms) {
  let y = 0;
  for (let i = 0; i < numTerms; i++) {
    const n = HARMONICS[i];
    y += (4/(Math.PI*n)) * Math.sin(n * OMEGA * t);
  }
  return y;
}

function getEpicycles(t, numTerms) {
  let x = CX, y = CY;
  const circles = [{ cx:x, cy:y, r:0 }];
  for (let i = 0; i < numTerms; i++) {
    const n = HARMONICS[i];
    const r = (4/(Math.PI*n)) * SCALE;
    const angle = n * OMEGA * t - Math.PI/2;
    x += r * Math.cos(angle);
    y += r * Math.sin(angle);
    circles.push({ cx:x, cy:y, r, prevX: circles[i].cx, prevY: circles[i].cy });
  }
  return { circles, tipX: x, tipY: y };
}

export default function App() {
  const [time,     setTime]     = useState(0);
  const [playing,  setPlaying]  = useState(true);
  const [speed,    setSpeed]    = useState(1);
  const [numTerms, setNumTerms] = useState(3);
  const [showCirc, setShowCirc] = useState(true);

  const speedRef=useRef(speed), animRef=useRef(null), prevTsRef=useRef(null);
  useEffect(()=>{speedRef.current=speed;},[speed]);

  const animate=useCallback((ts)=>{
    if(prevTsRef.current!==null){
      const dt=ts-prevTsRef.current;
      setTime(t=>(t+dt*speedRef.current*0.0012)%(2*Math.PI));
    }
    prevTsRef.current=ts;
    animRef.current=requestAnimationFrame(animate);
  },[]);

  useEffect(()=>{
    if(playing){prevTsRef.current=null;animRef.current=requestAnimationFrame(animate);}
    else cancelAnimationFrame(animRef.current);
    return()=>cancelAnimationFrame(animRef.current);
  },[playing,animate]);

  const { circles, tipX, tipY } = useMemo(()=>getEpicycles(time,numTerms),[time,numTerms]);

  // Wave history — one full period sampled at 300 points
  const wavePts = useMemo(()=>{
    const N=300;
    return Array.from({length:N},(_,k)=>{
      const t_k = time - k*(2*Math.PI/N);
      const y   = fourierY(t_k, numTerms);
      return { x: 350+(N-k)*1.1, y: CY + y*SCALE };
    });
  },[time,numTerms]);

  const wavePathD = wavePts.map((p,i)=>(i===0?`M${p.x},${p.y}`:`L${p.x},${p.y}`)).join(" ");
  const WAVE_X0   = wavePts[wavePts.length-1]?.x ?? 350;

  const nLabel = HARMONICS.slice(0,numTerms).map(n=>`1/${n}`).join(" + ");

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"16px 28px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:860,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:10}}>
          <div>
            <h1 style={{fontSize:20,fontWeight:800,color:"#0f172a",margin:"0 0 2px",letterSpacing:"-0.02em"}}>Fourier Series</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>Square wave · rotating circle decomposition</p>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:6,alignItems:"flex-end"}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:11,color:"#64748b",fontWeight:600}}>Harmonics:</span>
              {[1,2,3,5,7,10].map(n=>(
                <button key={n} onClick={()=>setNumTerms(n)}
                  style={{padding:"3px 10px",borderRadius:16,border:`1.5px solid ${numTerms===n?"#2563eb":"#e2e8f0"}`,
                    background:numTerms===n?"#eff6ff":"#fff",color:numTerms===n?"#2563eb":"#64748b",
                    fontSize:11,fontWeight:700,cursor:"pointer"}}>
                  {n}
                </button>
              ))}
            </div>
            <div style={{fontSize:11,color:"#94a3b8",fontStyle:"italic"}}>
              f(t) ≈ (4/π)·( {nLabel} )·sin(nωt)
            </div>
          </div>
        </div>
      </div>

      {/* Main SVG */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        <svg viewBox="0 0 700 320" width="100%" style={{flex:1,display:"block",maxHeight:260}}>
          {/* Axes for wave panel */}
          <line x1={350} y1={40} x2={350} y2={280} stroke="#f1f5f9" strokeWidth={1}/>
          <line x1={350} y1={CY} x2={700} y2={CY} stroke="#e2e8f0" strokeWidth={1}/>
          {/* Wave amplitude markers */}
          {[-1,1].map(v=>(
            <g key={v}>
              <line x1={346} y1={CY-v*SCALE} x2={700} y2={CY-v*SCALE} stroke="#f1f5f9" strokeWidth={1} strokeDasharray="3,3"/>
              <text x={342} y={CY-v*SCALE+4} textAnchor="end" fontSize={9} fill="#94a3b8" fontFamily="system-ui,sans-serif">{v}</text>
            </g>
          ))}
          {/* "Now" marker */}
          <line x1={WAVE_X0} y1={40} x2={WAVE_X0} y2={280} stroke="#f0f9ff" strokeWidth={1}/>

          {/* Divider */}
          <line x1={345} y1={30} x2={345} y2={290} stroke="#f1f5f9" strokeWidth={1}/>

          {/* Epicycle area label */}
          <text x={155} y={22} textAnchor="middle" fontSize={9} fill="#94a3b8" letterSpacing="0.06em" fontFamily="system-ui,sans-serif">ROTATING CIRCLES</text>
          <text x={530} y={22} textAnchor="middle" fontSize={9} fill="#94a3b8" letterSpacing="0.06em" fontFamily="system-ui,sans-serif">WAVE OUTPUT</text>

          {/* Circles */}
          {showCirc && circles.slice(1).map((c,i)=>{
            const prev=circles[i];
            const hue=[220,200,180,160,140,120,100,80,60,40][i]||200;
            return (
              <g key={i}>
                <circle cx={prev.cx} cy={prev.cy} r={c.r} fill="none"
                  stroke={`hsl(${hue},70%,70%)`} strokeWidth={1} opacity={0.5}/>
                <line x1={prev.cx} y1={prev.cy} x2={c.cx} y2={c.cy}
                  stroke={`hsl(${hue},70%,55%)`} strokeWidth={1.5}/>
              </g>
            );
          })}

          {/* Tip dot */}
          <circle cx={tipX} cy={tipY} r={4} fill="#2563eb"/>

          {/* Connector to wave */}
          <line x1={tipX} y1={tipY} x2={WAVE_X0} y2={tipY} stroke="#2563eb" strokeWidth={1} strokeDasharray="4,3" opacity={0.5}/>

          {/* Wave path */}
          <path d={wavePathD} fill="none" stroke="#2563eb" strokeWidth={2} strokeLinejoin="round"/>

          {/* Target square wave (ghost) */}
          {(() => {
            const pts=[];
            for(let k=299;k>=0;k--){
              const t_k=time-k*(2*Math.PI/300);
              const sq=Math.sign(Math.sin(OMEGA*t_k));
              pts.push(`${350+(300-k)*1.1},${CY-sq*SCALE}`);
            }
            return <polyline points={pts.join(" ")} fill="none" stroke="#e2e8f0" strokeWidth={1.5} strokeDasharray="3,3"/>;
          })()}
        </svg>

        {/* Legend */}
        <div style={{padding:"4px 28px 0",display:"flex",gap:20,justifyContent:"center"}}>
          <div style={{display:"flex",alignItems:"center",gap:5,fontSize:11,color:"#64748b"}}>
            <div style={{width:18,height:2,background:"#2563eb",borderRadius:1}}/>
            Fourier approximation ({numTerms} term{numTerms!==1?"s":""})
          </div>
          <div style={{display:"flex",alignItems:"center",gap:5,fontSize:11,color:"#94a3b8"}}>
            <div style={{width:18,height:2,background:"#e2e8f0",borderRadius:1,borderTop:"2px dashed #e2e8f0"}}/>
            True square wave
          </div>
          <label style={{display:"flex",alignItems:"center",gap:5,fontSize:11,color:"#64748b",cursor:"pointer"}}>
            <input type="checkbox" checked={showCirc} onChange={e=>setShowCirc(e.target.checked)} style={{accentColor:"#2563eb"}}/>
            Show circles
          </label>
        </div>
      </div>

      {/* Controls */}
      <div style={{padding:"8px 28px 14px",maxWidth:860,margin:"0 auto",width:"100%",boxSizing:"border-box"}}>
        <div style={{display:"flex",alignItems:"center",gap:12,background:"#f8fafc",border:"1px solid #f1f5f9",borderRadius:10,padding:"9px 16px"}}>
          <button onClick={()=>setPlaying(p=>!p)} style={{width:34,height:34,borderRadius:8,border:"none",
            background:playing?"#64748b":"#2563eb",color:"#fff",fontSize:14,cursor:"pointer",
            display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            {playing?"⏸":"▶"}
          </button>
          <button onClick={()=>{setTime(0);setPlaying(true);}} style={{width:30,height:30,borderRadius:7,
            border:"1px solid #e2e8f0",background:"#fff",color:"#94a3b8",fontSize:12,cursor:"pointer",flexShrink:0}}>↺</button>
          <div style={{flex:1,display:"flex",alignItems:"center",gap:8}}>
            <span style={{fontSize:10,color:"#94a3b8",fontWeight:700,letterSpacing:"0.08em"}}>SPEED</span>
            <input type="range" min={0.25} max={3} step={0.25} value={speed}
              onChange={e=>setSpeed(+e.target.value)}
              style={{flex:1,accentColor:"#2563eb",cursor:"pointer"}}/>
            <span style={{fontSize:12,fontWeight:800,color:"#2563eb",minWidth:24}}>{speed}×</span>
          </div>
          <span style={{fontSize:11,color:"#94a3b8",flexShrink:0}}>
            More harmonics → closer to square wave
          </span>
        </div>
      </div>
    </div>
  );
}
