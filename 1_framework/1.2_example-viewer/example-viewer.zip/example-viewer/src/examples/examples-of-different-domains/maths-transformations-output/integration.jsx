import { useState } from "react";

const METHODS=[
  { id:"sub",   label:"u-Substitution",         color:"#2563eb", light:"#eff6ff", border:"#bfdbfe",
    rule:"Spot a function f(g(x))·g′(x). Set u=g(x), du=g′(x)dx." },
  { id:"parts", label:"Integration by Parts",   color:"#7c3aed", light:"#f5f3ff", border:"#ddd6fe",
    rule:"∫u dv = uv − ∫v du. Choose u=LIATE order: Log, Inverse trig, Algebra, Trig, Exp." },
  { id:"pf",    label:"Partial Fractions",       color:"#dc2626", light:"#fef2f2", border:"#fecaca",
    rule:"Rational P(x)/Q(x) with deg P < deg Q. Factor Q, decompose into simpler fractions." },
  { id:"trig",  label:"Trigonometric",           color:"#059669", light:"#ecfdf5", border:"#a7f3d0",
    rule:"Use sin²+cos²=1, double-angle formulas, or x=sin θ / tan θ substitutions." },
];

const INTEGRALS=[
  { id:"i1",  tex:"∫ x · eˣ dx",         method:"parts", hint:"Product of algebraic and exponential. u=x, dv=eˣdx.",        why:"Integration by Parts: u=x, dv=eˣdx → uv−∫v du = xeˣ−eˣ+C." },
  { id:"i2",  tex:"∫ 2x/(x²+1) dx",     method:"sub",   hint:"Numerator is the derivative of the denominator.",            why:"u-Substitution: u=x²+1, du=2x dx → ∫du/u = ln|u|+C = ln(x²+1)+C." },
  { id:"i3",  tex:"∫ 1/((x+1)(x−2)) dx",method:"pf",    hint:"Rational function with factorable denominator.",             why:"Partial Fractions: 1/((x+1)(x−2)) = A/(x+1)+B/(x−2). Solve A=−1/3, B=1/3." },
  { id:"i4",  tex:"∫ sin²(x) dx",        method:"trig",  hint:"Even power of sine — use the power-reduction identity.",     why:"Trig identity: sin²x=(1−cos2x)/2 → x/2 − sin(2x)/4 + C." },
  { id:"i5",  tex:"∫ x · ln(x) dx",      method:"parts", hint:"Product of logarithm and algebraic. Choose u=ln x.",         why:"IBP with u=ln x (L before A in LIATE), dv=x dx → (x²ln x)/2 − x²/4 + C." },
  { id:"i6",  tex:"∫ √(1−x²) dx",        method:"trig",  hint:"Radical of the form √(a²−x²) → trig substitution.",         why:"Let x=sin θ, dx=cos θ dθ, √(1−x²)=cos θ → ∫cos²θ dθ → arcsin(x)/2 + x√(1−x²)/2 + C." },
  { id:"i7",  tex:"∫ 1/(x²−4) dx",       method:"pf",    hint:"Difference of squares in denominator.",                     why:"Partial Fractions: 1/((x−2)(x+2)) = A/(x−2)+B/(x+2), A=B=1/4." },
  { id:"i8",  tex:"∫ eˣ·sin(x) dx",      method:"parts", hint:"Two functions, neither reduces. Apply IBP twice.",           why:"IBP twice: I = eˣsin x−eˣcos x−I → 2I = eˣ(sin x−cos x) → I = eˣ(sin x−cos x)/2+C." },
  { id:"i9",  tex:"∫ cos³(x) dx",        method:"trig",  hint:"Odd power — split off one cosine, use sin²+cos²=1.",         why:"cos³x = cos x·(1−sin²x). Let u=sin x → ∫(1−u²)du = sin x − sin³x/3 + C." },
  { id:"i10", tex:"∫ x/(x²+4x+4) dx",   method:"pf",    hint:"Perfect square denominator; degree of numerator < degree.", why:"(x+4)/((x+2)²) = A/(x+2)+B/(x+2)². Partial fractions then integrate term by term." },
  { id:"i11", tex:"∫ arctan(x) dx",      method:"parts", hint:"Single inverse trig — treat as 1·arctan(x).",               why:"IBP: u=arctan x, dv=dx → x·arctan x − ∫x/(1+x²)dx = x·arctan x − ln(1+x²)/2 + C." },
  { id:"i12", tex:"∫ sin(x)·cos(x) dx",  method:"sub",   hint:"Product of trig functions where one is the derivative of the other.", why:"u=sin x, du=cos x dx → ∫u du = u²/2+C = sin²x/2+C. (Or: use sin(2x)/2.)" },
];

function shuffle(a){const b=[...a];for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]];}return b;}

export default function App() {
  const [pool,     setPool]    = useState(()=>shuffle(INTEGRALS));
  const [placed,   setPlaced]  = useState({});    // {methodId: [integralId...]}
  const [feedback, setFeedback]= useState({});    // {integralId: "correct"|"wrong"}
  const [tooltip,  setTooltip] = useState(null);
  const [dragId,   setDragId]  = useState(null);
  const [hovMethod,setHovMethod]= useState(null);

  const score=Object.values(feedback).filter(v=>v==="correct").length;

  const onDrop=(methodId)=>{
    if(!dragId) return;
    setDragId(null);
    const item=INTEGRALS.find(i=>i.id===dragId);
    if(!item) return;
    const correct=item.method===methodId;
    setFeedback(f=>({...f,[dragId]:correct?"correct":"wrong"}));
    if(correct){
      setPool(p=>p.filter(i=>i.id!==dragId));
      setPlaced(p=>({...p,[methodId]:[...(p[methodId]||[]),dragId]}));
    } else {
      setTimeout(()=>setFeedback(f=>{const n={...f};delete n[dragId];return n;}),1300);
    }
  };

  const reset=()=>{setPool(shuffle(INTEGRALS));setPlaced({});setFeedback({});setTooltip(null);};

  const tipItem=INTEGRALS.find(i=>i.id===tooltip);

  return (
    <div style={{width:"100%",height:"100vh",background:"#fff",display:"flex",flexDirection:"column",
      fontFamily:"system-ui,-apple-system,sans-serif",overflow:"hidden"}}>

      {/* Header */}
      <div style={{padding:"14px 24px 10px",borderBottom:"1px solid #f1f5f9"}}>
        <div style={{maxWidth:1000,margin:"0 auto",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
          <div>
            <h1 style={{fontSize:20,fontWeight:800,color:"#0f172a",margin:"0 0 1px",letterSpacing:"-0.02em"}}>Integration Techniques</h1>
            <p style={{fontSize:10,color:"#94a3b8",margin:0,letterSpacing:"0.08em",textTransform:"uppercase"}}>Drag each integral to its correct method</p>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <span style={{fontSize:13,fontWeight:700,color:"#0f172a"}}>
              {score}<span style={{fontWeight:400,color:"#94a3b8"}}>/{INTEGRALS.length} placed</span>
            </span>
            <button onClick={reset} style={{padding:"5px 13px",border:"1px solid #e2e8f0",borderRadius:8,
              background:"#fff",color:"#64748b",fontSize:11,fontWeight:600,cursor:"pointer"}}>↺ Reset</button>
          </div>
        </div>
      </div>

      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden",
        padding:"10px 20px 12px",maxWidth:1000,margin:"0 auto",width:"100%",boxSizing:"border-box",gap:10}}>

        {/* Method rules (hover to see) */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
          {METHODS.map(m=>{
            const isH=hovMethod===m.id;
            return(
              <div key={m.id}
                onMouseEnter={()=>setHovMethod(m.id)} onMouseLeave={()=>setHovMethod(null)}
                style={{background:m.light,border:`1.5px solid ${m.border}`,borderRadius:10,padding:"9px 12px",cursor:"default",transition:"all 0.15s"}}>
                <div style={{fontSize:11,fontWeight:800,color:m.color,letterSpacing:"0.04em",marginBottom:isH?5:0}}>{m.label}</div>
                {isH&&<p style={{fontSize:10,color:"#475569",margin:0,lineHeight:1.55,fontStyle:"italic"}}>{m.rule}</p>}
              </div>
            );
          })}
        </div>

        {/* Drop zones */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,flex:1,overflow:"hidden",minHeight:0}}>
          {METHODS.map(m=>{
            const ids=placed[m.id]||[];
            return(
              <div key={m.id}
                onDragOver={e=>e.preventDefault()}
                onDrop={()=>onDrop(m.id)}
                style={{background:"#fafafa",border:`2px dashed ${m.border}`,borderRadius:10,
                  padding:8,display:"flex",flexDirection:"column",gap:5,overflow:"auto",minHeight:80}}>
                {ids.map(id=>{
                  const it=INTEGRALS.find(i=>i.id===id);
                  return(
                    <div key={id}
                      onMouseEnter={()=>setTooltip(id)} onMouseLeave={()=>setTooltip(null)}
                      style={{background:m.light,border:`1.5px solid ${m.border}`,borderRadius:8,
                        padding:"7px 10px",position:"relative"}}>
                      <div style={{fontSize:10,fontWeight:700,color:m.color}}>✓</div>
                      <div style={{fontSize:12,fontFamily:"'Georgia',serif",color:"#1e293b",lineHeight:1.4}}>{it.tex}</div>
                      {tooltip===id&&(
                        <div style={{position:"absolute",left:"calc(100%+6px)",top:0,
                          background:"#0f172a",color:"#fff",borderRadius:8,padding:"10px 12px",
                          width:220,fontSize:11,lineHeight:1.6,zIndex:50,pointerEvents:"none",
                          boxShadow:"0 8px 24px rgba(0,0,0,0.2)"}}>
                          {it.why}
                        </div>
                      )}
                    </div>
                  );
                })}
                {ids.length===0&&(
                  <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",
                    fontSize:10,color:"#cbd5e1",fontStyle:"italic"}}>Drop here</div>
                )}
              </div>
            );
          })}
        </div>

        {/* Integral pool */}
        <div style={{flexShrink:0}}>
          <div style={{fontSize:10,color:"#94a3b8",fontWeight:700,letterSpacing:"0.08em",
            textTransform:"uppercase",marginBottom:7}}>
            Integrals — hover for a hint, drag to the correct method:
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:7}}>
            {pool.map(it=>{
              const wrong=feedback[it.id]==="wrong";
              return(
                <div key={it.id}
                  draggable
                  onDragStart={()=>setDragId(it.id)}
                  onDragEnd={()=>setDragId(null)}
                  onMouseEnter={()=>setTooltip(it.id)} onMouseLeave={()=>setTooltip(null)}
                  style={{
                    background:wrong?"#fef2f2":dragId===it.id?"#f0f9ff":"#f8fafc",
                    border:`1.5px solid ${wrong?"#fecaca":dragId===it.id?"#bae6fd":"#e2e8f0"}`,
                    borderRadius:8,padding:"7px 13px",cursor:"grab",
                    transition:"all 0.15s",userSelect:"none",position:"relative",
                    boxShadow:wrong?"0 0 0 2px #fca5a5":dragId===it.id?"0 4px 14px rgba(14,165,233,0.2)":"none",
                  }}>
                  <div style={{fontSize:13,fontFamily:"'Georgia',serif",color:wrong?"#dc2626":"#1e293b"}}>{it.tex}</div>
                  {wrong&&<div style={{fontSize:10,color:"#dc2626",marginTop:2}}>✗ wrong method — try again</div>}
                  {tooltip===it.id&&!wrong&&(
                    <div style={{position:"absolute",bottom:"calc(100%+6px)",left:0,
                      background:"#0f172a",color:"#fff",borderRadius:8,padding:"10px 12px",
                      width:230,fontSize:11,lineHeight:1.6,zIndex:50,pointerEvents:"none",
                      boxShadow:"0 8px 24px rgba(0,0,0,0.2)"}}>
                      💡 {it.hint}
                    </div>
                  )}
                </div>
              );
            })}
            {pool.length===0&&<div style={{fontSize:13,fontWeight:700,color:"#059669",padding:"8px 0"}}>
              🎉 All {INTEGRALS.length} integrals correctly classified!
            </div>}
          </div>
        </div>
      </div>
    </div>
  );
}
