import { useState, useEffect, useRef, useCallback, useMemo } from "react";

const PATIENT_COUNT = 80;
const CANVAS_W = 800;
const CANVAS_H = 500;

function seededRand(seed) {
  let s = seed;
  return function () {
    s = (s * 16807 + 0) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function generatePatients() {
  const r = seededRand(42);
  const patients = [];
  const clusters = [
    { cx: 0.2, cy: 0.3, label: "Low Risk", color: "#22c55e", risk: "low" },
    { cx: 0.55, cy: 0.45, label: "Medium Risk", color: "#f59e0b", risk: "medium" },
    { cx: 0.82, cy: 0.25, label: "High Risk", color: "#ef4444", risk: "high" },
  ];

  for (let i = 0; i < PATIENT_COUNT; i++) {
    const cluster = clusters[i % clusters.length];
    const angle = r() * Math.PI * 2;
    const dist = r() * 0.18;
    const rawX = cluster.cx + Math.cos(angle) * dist;
    const rawY = cluster.cy + Math.sin(angle) * dist;
    const x = Math.max(0.05, Math.min(0.95, rawX));
    const y = Math.max(0.05, Math.min(0.95, rawY));

    const age = Math.floor(30 + r() * 50);
    const bp = Math.floor(100 + r() * 80);
    const glucose = Math.floor(70 + r() * 130);
    const bmi = (18 + r() * 22).toFixed(1);

    patients.push({
      id: i,
      startX: 0.1 + r() * 0.8,
      startY: 0.1 + r() * 0.8,
      targetX: x,
      targetY: y,
      currentX: 0.1 + r() * 0.8,
      currentY: 0.1 + r() * 0.8,
      color: cluster.color,
      risk: cluster.risk,
      label: cluster.label,
      age,
      bp,
      glucose,
      bmi,
      clusterId: i % clusters.length,
    });
  }
  return patients;
}

const INITIAL_PATIENTS = generatePatients();

const CLUSTERS = [
  { cx: 0.2, cy: 0.3, label: "Low Risk", color: "#22c55e", risk: "low", description: "Low cardiovascular risk. Healthy biomarkers, preventive care recommended." },
  { cx: 0.55, cy: 0.45, label: "Medium Risk", color: "#f59e0b", risk: "medium", description: "Moderate risk. Lifestyle intervention and monitoring advised." },
  { cx: 0.82, cy: 0.25, label: "High Risk", color: "#ef4444", risk: "high", description: "Elevated cardiovascular risk. Immediate clinical assessment needed." },
];

export default function App() {
  const [patients, setPatients] = useState(() =>
    INITIAL_PATIENTS.map((p) => ({ ...p, currentX: p.startX, currentY: p.startY }))
  );
  const [phase, setPhase] = useState("idle"); // idle | training | trained
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0); // 0..1
  const [hoveredPatient, setHoveredPatient] = useState(null);
  const [hoveredCluster, setHoveredCluster] = useState(null);
  const [showRaw, setShowRaw] = useState(false);
  const animRef = useRef(null);
  const startTimeRef = useRef(null);
  const DURATION = 2800;
  const canvasRef = useRef(null);

  const easeInOut = (t) => t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
  const easeOutElastic = (t) => {
    if (t === 0 || t === 1) return t;
    return Math.pow(2, -10 * t) * Math.sin((t - 0.075) * (2 * Math.PI) / 0.3) + 1;
  };

  const animate = useCallback((timestamp) => {
    if (!startTimeRef.current) startTimeRef.current = timestamp;
    const elapsed = timestamp - startTimeRef.current;
    const t = Math.min(elapsed / DURATION, 1);
    const eased = easeInOut(t);

    setProgress(t);
    setPatients((prev) =>
      prev.map((p) => ({
        ...p,
        currentX: p.startX + (p.targetX - p.startX) * eased,
        currentY: p.startY + (p.targetY - p.startY) * eased,
      }))
    );

    if (t < 1) {
      animRef.current = requestAnimationFrame(animate);
    } else {
      setPhase("trained");
      setIsPlaying(false);
    }
  }, []);

  const handleTrain = useCallback(() => {
    if (phase === "trained" || isPlaying) return;
    setPhase("training");
    setIsPlaying(true);
    setProgress(0);
    setPatients((prev) =>
      prev.map((p) => ({ ...p, currentX: p.startX, currentY: p.startY }))
    );
    startTimeRef.current = null;
    animRef.current = requestAnimationFrame(animate);
  }, [phase, isPlaying, animate]);

  const handlePause = useCallback(() => {
    if (animRef.current) cancelAnimationFrame(animRef.current);
    setIsPlaying(false);
  }, []);

  const handleResume = useCallback(() => {
    if (phase !== "training" || progress >= 1) return;
    setIsPlaying(true);
    const remaining = (1 - progress) * DURATION;
    startTimeRef.current = null;
    let resumed = false;
    const resumeAnimate = (timestamp) => {
      if (!resumed) {
        startTimeRef.current = timestamp - progress * DURATION;
        resumed = true;
      }
      animate(timestamp);
    };
    animRef.current = requestAnimationFrame(resumeAnimate);
  }, [phase, progress, animate]);

  const handleReset = useCallback(() => {
    if (animRef.current) cancelAnimationFrame(animRef.current);
    setPhase("idle");
    setIsPlaying(false);
    setProgress(0);
    setHoveredPatient(null);
    setHoveredCluster(null);
    setPatients(INITIAL_PATIENTS.map((p) => ({ ...p, currentX: p.startX, currentY: p.startY })));
  }, []);

  useEffect(() => {
    return () => { if (animRef.current) cancelAnimationFrame(animRef.current); };
  }, []);

  const getCanvasCoords = useCallback((e) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return null;
    const scaleX = CANVAS_W / rect.width;
    const scaleY = CANVAS_H / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  }, []);

  const handleMouseMove = useCallback((e) => {
    const coords = getCanvasCoords(e);
    if (!coords) return;
    const nx = coords.x / CANVAS_W;
    const ny = coords.y / CANVAS_H;

    let nearest = null;
    let minDist = Infinity;
    patients.forEach((p) => {
      const dx = p.currentX - nx;
      const dy = p.currentY - ny;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < minDist) { minDist = dist; nearest = p; }
    });
    if (nearest && minDist < 0.04) {
      setHoveredPatient(nearest);
      setHoveredCluster(null);
    } else if (phase === "trained") {
      let nearestCluster = null;
      let minCDist = Infinity;
      CLUSTERS.forEach((c) => {
        const dx = c.cx - nx;
        const dy = c.cy - ny;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < minCDist) { minCDist = dist; nearestCluster = c; }
      });
      if (nearestCluster && minCDist < 0.18) {
        setHoveredCluster(nearestCluster);
      } else {
        setHoveredCluster(null);
      }
      setHoveredPatient(null);
    } else {
      setHoveredPatient(null);
      setHoveredCluster(null);
    }
  }, [patients, phase, getCanvasCoords]);

  const handleMouseLeave = useCallback(() => {
    setHoveredPatient(null);
    setHoveredCluster(null);
  }, []);

  const displayPatients = useMemo(() =>
    showRaw
      ? patients.map((p) => ({ ...p, currentX: p.startX, currentY: p.startY }))
      : patients,
    [patients, showRaw]
  );

  const patientDotColor = (p) => {
    if (phase === "trained" && !showRaw) return p.color;
    return "#94a3b8";
  };

  const patientDotSize = (p) => {
    if (hoveredPatient?.id === p.id) return 10;
    if (phase === "trained" && !showRaw) return 7;
    return 5;
  };

  const tooltipX = hoveredPatient
    ? Math.min(
        Math.max((hoveredPatient.currentX * CANVAS_W) + 14, 10),
        CANVAS_W - 170
      )
    : 0;
  const tooltipY = hoveredPatient
    ? Math.min(
        Math.max((hoveredPatient.currentY * CANVAS_H) - 70, 10),
        CANVAS_H - 140
      )
    : 0;

  const clusterTooltipX = hoveredCluster
    ? Math.min(Math.max(hoveredCluster.cx * CANVAS_W + 14, 10), CANVAS_W - 210)
    : 0;
  const clusterTooltipY = hoveredCluster
    ? Math.min(Math.max(hoveredCluster.cy * CANVAS_H - 60, 10), CANVAS_H - 100)
    : 0;

  const getPhaseLabel = () => {
    if (phase === "idle") return "Raw Patient Data";
    if (phase === "training") return `Training Model… ${Math.round(progress * 100)}%`;
    return "Model Trained — Patterns Discovered";
  };

  const getPhaseColor = () => {
    if (phase === "trained") return "#22c55e";
    if (phase === "training") return "#f59e0b";
    return "#64748b";
  };

  return (
    <div style={{ width: "100%", minHeight: "100vh", background: "#ffffff", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: "'Inter', 'Segoe UI', sans-serif", padding: "24px 16px", boxSizing: "border-box" }}>
      <style>{`
        @keyframes pulse-ring {
          0% { transform: scale(1); opacity: 0.7; }
          100% { transform: scale(2.2); opacity: 0; }
        }
        @keyframes shimmer {
          0% { opacity: 0.4; }
          50% { opacity: 1; }
          100% { opacity: 0.4; }
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(6px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes progress-fill {
          from { width: 0%; }
        }
        .dot-trained { transition: r 0.2s; }
      `}</style>

      {/* Header */}
      <div style={{ textAlign: "center", marginBottom: "28px", maxWidth: 680 }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.12em", color: "#94a3b8", textTransform: "uppercase", marginBottom: 8 }}>
          Virtual Twin Technology · AI/ML Training
        </div>
        <h1 style={{ fontSize: "clamp(20px, 4vw, 30px)", fontWeight: 800, color: "#0f172a", margin: 0, lineHeight: 1.2 }}>
          AI Model Training Simulator
        </h1>
        <p style={{ color: "#64748b", fontSize: 14, marginTop: 10, lineHeight: 1.6, margin: "10px auto 0" }}>
          Watch an AI discover hidden patient clusters from raw data — enabling personalised medicine.
        </p>
      </div>

      {/* Status bar */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16, animation: "fadeIn 0.3s ease" }}>
        <div style={{ width: 8, height: 8, borderRadius: "50%", background: getPhaseColor(), boxShadow: phase === "training" ? `0 0 0 3px ${getPhaseColor()}33` : "none", animation: phase === "training" ? "shimmer 1s infinite" : "none" }} />
        <span style={{ fontSize: 13, fontWeight: 600, color: getPhaseColor() }}>{getPhaseLabel()}</span>
      </div>

      {/* Progress bar */}
      {phase === "training" && (
        <div style={{ width: "min(800px, 100%)", height: 3, background: "#e2e8f0", borderRadius: 2, marginBottom: 16, overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${progress * 100}%`, background: "linear-gradient(90deg, #f59e0b, #ef4444)", borderRadius: 2, transition: "width 0.1s linear" }} />
        </div>
      )}

      {/* Canvas */}
      <div style={{ position: "relative", width: "min(800px, 100%)", background: "#f8fafc", borderRadius: 16, border: "1.5px solid #e2e8f0", overflow: "hidden", boxShadow: "0 4px 24px #0f172a0d", cursor: "crosshair" }}>
        <svg
          ref={canvasRef}
          viewBox={`0 0 ${CANVAS_W} ${CANVAS_H}`}
          style={{ width: "100%", display: "block" }}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          {/* Grid lines */}
          {[0.25, 0.5, 0.75].map((t) => (
            <g key={t}>
              <line x1={t * CANVAS_W} y1={0} x2={t * CANVAS_W} y2={CANVAS_H} stroke="#e2e8f0" strokeWidth="1" strokeDasharray="4 4" />
              <line x1={0} y1={t * CANVAS_H} x2={CANVAS_W} y2={t * CANVAS_H} stroke="#e2e8f0" strokeWidth="1" strokeDasharray="4 4" />
            </g>
          ))}

          {/* Cluster zones (trained only) */}
          {phase === "trained" && !showRaw && CLUSTERS.map((c) => (
            <g key={c.risk}>
              <ellipse
                cx={c.cx * CANVAS_W}
                cy={c.cy * CANVAS_H}
                rx={110}
                ry={85}
                fill={c.color + "14"}
                stroke={c.color + "55"}
                strokeWidth="1.5"
                strokeDasharray="6 4"
                style={{ animation: "fadeIn 0.6s ease" }}
              />
              <text
                x={c.cx * CANVAS_W}
                y={c.cy * CANVAS_H + 100}
                textAnchor="middle"
                fontSize="11"
                fontWeight="700"
                fill={c.color}
                opacity="0.85"
                style={{ animation: "fadeIn 0.8s ease" }}
              >
                {c.label}
              </text>
            </g>
          ))}

          {/* Axis labels */}
          <text x={CANVAS_W / 2} y={CANVAS_H - 8} textAnchor="middle" fontSize="10" fill="#94a3b8" fontWeight="600">CARDIOVASCULAR RISK FACTORS →</text>
          <text x={10} y={CANVAS_H / 2} textAnchor="middle" fontSize="10" fill="#94a3b8" fontWeight="600" transform={`rotate(-90, 10, ${CANVAS_H / 2})`}>METABOLIC INDICATORS →</text>

          {/* Patient dots */}
          {displayPatients.map((p) => {
            const cx = p.currentX * CANVAS_W;
            const cy = p.currentY * CANVAS_H;
            const r = patientDotSize(p);
            const color = patientDotColor(p);
            const isHovered = hoveredPatient?.id === p.id;
            return (
              <g key={p.id}>
                {isHovered && phase === "trained" && (
                  <circle cx={cx} cy={cy} r={r + 6} fill={color} opacity="0.15" />
                )}
                <circle
                  cx={cx}
                  cy={cy}
                  r={r}
                  fill={color}
                  stroke={isHovered ? "#fff" : "none"}
                  strokeWidth={isHovered ? 2 : 0}
                  opacity={phase === "training" ? 0.7 + progress * 0.3 : 1}
                  style={{ transition: "r 0.2s, fill 0.4s" }}
                />
              </g>
            );
          })}

          {/* Patient tooltip */}
          {hoveredPatient && (
            <g style={{ animation: "fadeIn 0.18s ease" }}>
              <rect x={tooltipX} y={tooltipY} width={165} height={128} rx="8" fill="#0f172a" opacity="0.93" />
              <text x={tooltipX + 12} y={tooltipY + 20} fontSize="11" fontWeight="700" fill={hoveredPatient.color}>
                Patient #{hoveredPatient.id + 1} · {hoveredPatient.label}
              </text>
              {[
                ["Age", `${hoveredPatient.age} yrs`],
                ["Blood Pressure", `${hoveredPatient.bp} mmHg`],
                ["Glucose", `${hoveredPatient.glucose} mg/dL`],
                ["BMI", hoveredPatient.bmi],
              ].map(([k, v], i) => (
                <g key={k}>
                  <text x={tooltipX + 12} y={tooltipY + 42 + i * 21} fontSize="10" fill="#94a3b8">{k}</text>
                  <text x={tooltipX + 153} y={tooltipY + 42 + i * 21} fontSize="10" fontWeight="600" fill="#f8fafc" textAnchor="end">{v}</text>
                </g>
              ))}
              {phase === "trained" && (
                <text x={tooltipX + 12} y={tooltipY + 118} fontSize="9" fill={hoveredPatient.color} opacity="0.9">
                  AI-assigned cluster
                </text>
              )}
            </g>
          )}

          {/* Cluster tooltip */}
          {hoveredCluster && !hoveredPatient && (
            <g style={{ animation: "fadeIn 0.18s ease" }}>
              <rect x={clusterTooltipX} y={clusterTooltipY} width={200} height={70} rx="8" fill="#0f172a" opacity="0.93" />
              <text x={clusterTooltipX + 12} y={clusterTooltipY + 22} fontSize="12" fontWeight="700" fill={hoveredCluster.color}>{hoveredCluster.label}</text>
              <foreignObject x={clusterTooltipX + 10} y={clusterTooltipY + 30} width={182} height={36}>
                <div style={{ fontSize: 10, color: "#cbd5e1", lineHeight: 1.5 }}>{hoveredCluster.description}</div>
              </foreignObject>
            </g>
          )}

          {/* Hint text when idle */}
          {phase === "idle" && (
            <text x={CANVAS_W / 2} y={CANVAS_H / 2 + 4} textAnchor="middle" fontSize="13" fill="#94a3b8" fontWeight="500">
              Press Train to watch the AI learn
            </text>
          )}
        </svg>

        {/* Legend overlay (trained) */}
        {phase === "trained" && !showRaw && (
          <div style={{ position: "absolute", top: 14, right: 14, background: "rgba(255,255,255,0.92)", borderRadius: 10, padding: "10px 14px", border: "1px solid #e2e8f0", animation: "fadeIn 0.5s ease" }}>
            {CLUSTERS.map((c) => (
              <div key={c.risk} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4, fontSize: 11, color: "#0f172a", fontWeight: 600 }}>
                <div style={{ width: 10, height: 10, borderRadius: "50%", background: c.color }} />
                {c.label}
              </div>
            ))}
            <div style={{ fontSize: 9, color: "#94a3b8", marginTop: 4 }}>Hover dots for details</div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div style={{ display: "flex", gap: 12, marginTop: 20, flexWrap: "wrap", justifyContent: "center", alignItems: "center" }}>
        {phase === "idle" && (
          <button
            onClick={handleTrain}
            style={{ padding: "10px 28px", borderRadius: 10, border: "none", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", color: "#fff", fontWeight: 700, fontSize: 14, cursor: "pointer", boxShadow: "0 2px 12px #6366f133", letterSpacing: "0.03em" }}
          >
            ▶ Train Model
          </button>
        )}
        {phase === "training" && isPlaying && (
          <button
            onClick={handlePause}
            style={{ padding: "10px 24px", borderRadius: 10, border: "1.5px solid #e2e8f0", background: "#fff", color: "#0f172a", fontWeight: 700, fontSize: 14, cursor: "pointer" }}
          >
            ⏸ Pause
          </button>
        )}
        {phase === "training" && !isPlaying && progress < 1 && (
          <button
            onClick={handleResume}
            style={{ padding: "10px 24px", borderRadius: 10, border: "none", background: "linear-gradient(135deg, #6366f1, #8b5cf6)", color: "#fff", fontWeight: 700, fontSize: 14, cursor: "pointer" }}
          >
            ▶ Resume
          </button>
        )}
        {(phase === "training" || phase === "trained") && (
          <button
            onClick={handleReset}
            style={{ padding: "10px 24px", borderRadius: 10, border: "1.5px solid #e2e8f0", background: "#fff", color: "#64748b", fontWeight: 600, fontSize: 14, cursor: "pointer" }}
          >
            ↺ Reset
          </button>
        )}
        {phase === "trained" && (
          <button
            onClick={() => setShowRaw((v) => !v)}
            style={{ padding: "10px 24px", borderRadius: 10, border: "1.5px solid #e2e8f0", background: showRaw ? "#0f172a" : "#fff", color: showRaw ? "#fff" : "#0f172a", fontWeight: 600, fontSize: 13, cursor: "pointer", transition: "all 0.2s" }}
          >
            {showRaw ? "◑ Show Learned Model" : "◐ Show Raw Data"}
          </button>
        )}
      </div>

      {/* Info cards */}
      <div style={{ display: "flex", gap: 16, marginTop: 28, flexWrap: "wrap", justifyContent: "center", maxWidth: 800, width: "100%" }}>
        {[
          { icon: "🧬", title: "Virtual Twin", desc: "Each dot is a digital patient profile — a data-driven virtual twin capturing key biomarkers." },
          { icon: "🤖", title: "ML Clustering", desc: "The AI uses unsupervised learning to group patients by risk patterns — no labels needed." },
          { icon: "💊", title: "Personalised Medicine", desc: "Cluster membership guides tailored treatments — causal AI links patterns to outcomes." },
        ].map((card) => (
          <div key={card.title} style={{ flex: "1 1 200px", background: "#f8fafc", borderRadius: 12, padding: "16px 18px", border: "1px solid #e2e8f0" }}>
            <div style={{ fontSize: 22, marginBottom: 6 }}>{card.icon}</div>
            <div style={{ fontWeight: 700, fontSize: 13, color: "#0f172a", marginBottom: 4 }}>{card.title}</div>
            <div style={{ fontSize: 12, color: "#64748b", lineHeight: 1.6 }}>{card.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}