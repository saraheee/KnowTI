import React, { useState } from 'react';

const FeatureDistributionExplorer = () => {
  const [selectedFeature, setSelectedFeature] = useState('petTBR');
  const [binCount, setBinCount] = useState(20);
  const [showOutliers, setShowOutliers] = useState(true);
  const [highlightCluster, setHighlightCluster] = useState(null);
  const [hoveredBin, setHoveredBin] = useState(null);
  const [showStats, setShowStats] = useState(true);

  // Generate realistic medical data with 3 clusters
  const generateData = () => {
    const points = [];
    const clusters = [
      { 
        name: 'Low Risk', 
        color: '#10b981',
        petTBR: { mean: 2.5, std: 0.6 },
        age: { mean: 55, std: 8 },
        bmi: { mean: 24, std: 3 },
        glucose: { mean: 95, std: 12 }
      },
      { 
        name: 'Medium Risk', 
        color: '#f59e0b',
        petTBR: { mean: 5.0, std: 1.2 },
        age: { mean: 65, std: 7 },
        bmi: { mean: 28, std: 4 },
        glucose: { mean: 115, std: 15 }
      },
      { 
        name: 'High Risk', 
        color: '#ef4444',
        petTBR: { mean: 8.5, std: 1.5 },
        age: { mean: 72, std: 6 },
        bmi: { mean: 32, std: 5 },
        glucose: { mean: 140, std: 20 }
      }
    ];

    clusters.forEach((cluster, clusterIdx) => {
      const sampleCount = clusterIdx === 1 ? 60 : 45;
      
      for (let i = 0; i < sampleCount; i++) {
        const generateNormal = (mean, std) => {
          const u1 = Math.random();
          const u2 = Math.random();
          const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
          return mean + z * std;
        };

        const isOutlier = Math.random() < 0.05;
        const outlierMultiplier = isOutlier ? (1.5 + Math.random() * 0.5) : 1;

        points.push({
          id: `p-${clusterIdx}-${i}`,
          cluster: clusterIdx,
          clusterName: cluster.name,
          color: cluster.color,
          isOutlier: isOutlier,
          features: {
            petTBR: Math.max(0.5, generateNormal(cluster.petTBR.mean, cluster.petTBR.std) * outlierMultiplier),
            age: Math.max(30, Math.min(90, generateNormal(cluster.age.mean, cluster.age.std))),
            bmi: Math.max(15, Math.min(45, generateNormal(cluster.bmi.mean, cluster.bmi.std))),
            glucose: Math.max(60, Math.min(200, generateNormal(cluster.glucose.mean, cluster.glucose.std)))
          }
        });
      }
    });

    return points;
  };

  const [data] = useState(() => generateData());

  const features = {
    petTBR: { label: 'PET TBR', unit: 'ratio', min: 0, max: 12, desc: 'Tumor-to-Background Ratio' },
    age: { label: 'Age', unit: 'years', min: 30, max: 90, desc: 'Patient Age' },
    bmi: { label: 'BMI', unit: 'kg/m²', min: 15, max: 45, desc: 'Body Mass Index' },
    glucose: { label: 'Glucose', unit: 'mg/dL', min: 60, max: 200, desc: 'Blood Glucose Level' }
  };

  const filteredData = showOutliers ? data : data.filter(p => !p.isOutlier);

  const calculateHistogram = () => {
    const feature = features[selectedFeature];
    const values = filteredData.map(p => p.features[selectedFeature]);
    
    const min = feature.min;
    const max = feature.max;
    const binWidth = (max - min) / binCount;
    
    const bins = Array(binCount).fill(0).map((_, i) => ({
      start: min + i * binWidth,
      end: min + (i + 1) * binWidth,
      count: 0,
      clusterCounts: [0, 0, 0],
      points: []
    }));

    values.forEach((value, idx) => {
      const binIndex = Math.min(Math.floor((value - min) / binWidth), binCount - 1);
      if (binIndex >= 0 && binIndex < binCount) {
        bins[binIndex].count++;
        bins[binIndex].clusterCounts[filteredData[idx].cluster]++;
        bins[binIndex].points.push(filteredData[idx]);
      }
    });

    return bins;
  };

  const bins = calculateHistogram();
  const maxCount = Math.max(...bins.map(b => b.count), 1);

  const calculateStats = () => {
    const values = filteredData.map(p => p.features[selectedFeature]);
    const sorted = [...values].sort((a, b) => a - b);
    
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const median = sorted[Math.floor(sorted.length / 2)];
    const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
    const std = Math.sqrt(variance);
    const min = sorted[0];
    const max = sorted[sorted.length - 1];
    
    const skewness = values.reduce((sum, val) => sum + Math.pow((val - mean) / std, 3), 0) / values.length;
    
    return { mean, median, std, min, max, skewness, count: values.length };
  };

  const stats = calculateStats();

  return (
    <div style={{ 
      width: '100%', 
      minHeight: '100vh', 
      background: 'white',
      padding: '20px',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      <div style={{ textAlign: 'center', marginBottom: '30px' }}>
        <h1 style={{ 
          fontSize: '28px', 
          fontWeight: '700', 
          color: '#1f2937',
          marginBottom: '8px'
        }}>
          Feature Distribution Explorer
        </h1>
        <p style={{ fontSize: '16px', color: '#6b7280' }}>
          Analyze distributions, identify skewness, and spot outliers
        </p>
      </div>

      <div style={{
        maxWidth: '900px',
        margin: '0 auto 30px',
        display: 'flex',
        justifyContent: 'center',
        gap: '10px',
        flexWrap: 'wrap'
      }}>
        {Object.entries(features).map(([key, feature]) => (
          <button
            key={key}
            onClick={() => setSelectedFeature(key)}
            style={{
              padding: '12px 24px',
              background: selectedFeature === key ? '#8b5cf6' : '#f3f4f6',
              color: selectedFeature === key ? 'white' : '#4b5563',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontSize: '15px',
              fontWeight: '600',
              transition: 'all 0.2s',
              boxShadow: selectedFeature === key ? '0 2px 4px rgba(139,92,246,0.3)' : 'none'
            }}
          >
            {feature.label}
          </button>
        ))}
      </div>

      <div style={{
        maxWidth: '1200px',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '20px',
        marginBottom: '30px'
      }}>
        <div style={{
          background: '#f9fafb',
          padding: '20px',
          borderRadius: '12px',
          border: '2px solid #e5e7eb'
        }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '15px', color: '#1f2937' }}>
            Visualization Controls
          </h3>

          <div style={{ marginBottom: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
              <label style={{ fontSize: '14px', fontWeight: '600', color: '#374151' }}>
                Number of Bins
              </label>
              <span style={{ fontSize: '14px', fontWeight: '700', color: '#8b5cf6' }}>
                {binCount}
              </span>
            </div>
            <input
              type="range"
              min="5"
              max="40"
              value={binCount}
              onChange={(e) => setBinCount(parseInt(e.target.value))}
              style={{ width: '100%', accentColor: '#8b5cf6' }}
            />
            <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>
              More bins = finer detail, fewer bins = clearer patterns
            </div>
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '10px',
              fontSize: '14px',
              fontWeight: '600',
              color: '#374151',
              cursor: 'pointer'
            }}>
              <input
                type="checkbox"
                checked={showOutliers}
                onChange={(e) => setShowOutliers(e.target.checked)}
                style={{ width: '18px', height: '18px', cursor: 'pointer' }}
              />
              Show Outliers
            </label>
            <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '6px', marginLeft: '28px' }}>
              Include extreme values in the distribution
            </div>
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '10px',
              fontSize: '14px',
              fontWeight: '600',
              color: '#374151',
              cursor: 'pointer'
            }}>
              <input
                type="checkbox"
                checked={showStats}
                onChange={(e) => setShowStats(e.target.checked)}
                style={{ width: '18px', height: '18px', cursor: 'pointer' }}
              />
              Show Statistics Overlay
            </label>
            <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '6px', marginLeft: '28px' }}>
              Display mean, median, and standard deviation
            </div>
          </div>

          <div>
            <div style={{ fontSize: '14px', fontWeight: '600', color: '#374151', marginBottom: '10px' }}>
              Highlight Cluster
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <button
                onClick={() => setHighlightCluster(null)}
                style={{
                  padding: '8px 12px',
                  background: highlightCluster === null ? '#8b5cf6' : '#f3f4f6',
                  color: highlightCluster === null ? 'white' : '#4b5563',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '13px',
                  fontWeight: '600'
                }}
              >
                All Clusters
              </button>
              {['Low Risk', 'Medium Risk', 'High Risk'].map((name, idx) => (
                <button
                  key={idx}
                  onClick={() => setHighlightCluster(idx)}
                  style={{
                    padding: '8px 12px',
                    background: highlightCluster === idx ? ['#10b981', '#f59e0b', '#ef4444'][idx] : '#f3f4f6',
                    color: highlightCluster === idx ? 'white' : '#4b5563',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: 'pointer',
                    fontSize: '13px',
                    fontWeight: '600'
                  }}
                >
                  {name}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div style={{
          background: '#f0fdf4',
          padding: '20px',
          borderRadius: '12px',
          border: '2px solid #86efac'
        }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '15px', color: '#065f46' }}>
            Distribution Statistics
          </h3>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
            <div style={{ background: 'white', padding: '12px', borderRadius: '8px' }}>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Mean</div>
              <div style={{ fontSize: '20px', fontWeight: '700', color: '#065f46' }}>
                {stats.mean.toFixed(2)}
              </div>
            </div>

            <div style={{ background: 'white', padding: '12px', borderRadius: '8px' }}>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Median</div>
              <div style={{ fontSize: '20px', fontWeight: '700', color: '#065f46' }}>
                {stats.median.toFixed(2)}
              </div>
            </div>

            <div style={{ background: 'white', padding: '12px', borderRadius: '8px' }}>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Std Dev</div>
              <div style={{ fontSize: '20px', fontWeight: '700', color: '#065f46' }}>
                {stats.std.toFixed(2)}
              </div>
            </div>

            <div style={{ background: 'white', padding: '12px', borderRadius: '8px' }}>
              <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Range</div>
              <div style={{ fontSize: '20px', fontWeight: '700', color: '#065f46' }}>
                {stats.min.toFixed(1)} - {stats.max.toFixed(1)}
              </div>
            </div>
          </div>

          <div style={{ 
            marginTop: '15px',
            padding: '12px',
            background: 'white',
            borderRadius: '8px'
          }}>
            <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '6px' }}>Skewness</div>
            <div style={{ fontSize: '18px', fontWeight: '700', color: '#065f46', marginBottom: '6px' }}>
              {stats.skewness.toFixed(3)}
            </div>
            <div style={{ fontSize: '12px', color: '#4b5563', lineHeight: '1.5' }}>
              {Math.abs(stats.skewness) < 0.5 ? '✓ Roughly symmetric' : 
               stats.skewness > 0 ? '→ Right-skewed (tail on right)' : 
               '← Left-skewed (tail on left)'}
            </div>
          </div>

          <div style={{ 
            marginTop: '15px',
            padding: '12px',
            background: 'white',
            borderRadius: '8px'
          }}>
            <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>Sample Size</div>
            <div style={{ fontSize: '18px', fontWeight: '700', color: '#065f46' }}>
              {stats.count} patients
            </div>
          </div>
        </div>

        <div style={{
          background: '#f9fafb',
          padding: '20px',
          borderRadius: '12px',
          border: '2px solid #e5e7eb'
        }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '15px', color: '#1f2937' }}>
            Patient Risk Groups
          </h3>

          {['Low Risk', 'Medium Risk', 'High Risk'].map((name, idx) => {
            const clusterData = filteredData.filter(p => p.cluster === idx);
            const clusterValues = clusterData.map(p => p.features[selectedFeature]);
            const clusterMean = clusterValues.length > 0 ? clusterValues.reduce((a, b) => a + b, 0) / clusterValues.length : 0;
            
            return (
              <div 
                key={idx}
                style={{ 
                  marginBottom: '15px',
                  padding: '12px',
                  background: 'white',
                  borderRadius: '8px',
                  border: `2px solid ${['#10b981', '#f59e0b', '#ef4444'][idx]}20`,
                  opacity: highlightCluster === null || highlightCluster === idx ? 1 : 0.4,
                  transition: 'opacity 0.2s'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                  <div style={{ 
                    width: '16px', 
                    height: '16px', 
                    borderRadius: '4px', 
                    background: ['#10b981', '#f59e0b', '#ef4444'][idx]
                  }} />
                  <span style={{ fontSize: '14px', fontWeight: '600', color: '#374151' }}>
                    {name}
                  </span>
                </div>
                <div style={{ fontSize: '13px', color: '#6b7280', lineHeight: '1.6' }}>
                  <div>Count: <strong>{clusterData.length}</strong> patients</div>
                  <div>Mean {features[selectedFeature].label}: <strong>{clusterMean.toFixed(2)}</strong> {features[selectedFeature].unit}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div style={{ 
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        <div style={{
          background: '#fafafa',
          padding: '30px',
          borderRadius: '12px',
          border: '2px solid #e5e7eb'
        }}>
          <h3 style={{ fontSize: '18px', fontWeight: '700', marginBottom: '20px', color: '#1f2937', textAlign: 'center' }}>
            {features[selectedFeature].label} Distribution - {features[selectedFeature].desc}
          </h3>

          <svg width="1100" height="400" style={{ display: 'block', margin: '0 auto' }}>
            {[0, 0.25, 0.5, 0.75, 1].map(fraction => (
              <g key={fraction}>
                <line
                  x1="60"
                  y1={350 - fraction * 300}
                  x2="1060"
                  y2={350 - fraction * 300}
                  stroke="#e5e7eb"
                  strokeWidth="1"
                />
                <text
                  x="50"
                  y={350 - fraction * 300 + 5}
                  textAnchor="end"
                  fontSize="12"
                  fill="#6b7280"
                >
                  {Math.round(fraction * maxCount)}
                </text>
              </g>
            ))}

            <line x1="60" y1="350" x2="1060" y2="350" stroke="#374151" strokeWidth="2" />
            <line x1="60" y1="50" x2="60" y2="350" stroke="#374151" strokeWidth="2" />

            {bins.map((bin, idx) => {
              const barWidth = 1000 / binCount;
              const x = 60 + idx * barWidth;
              const isHovered = hoveredBin === idx;

              let cumulativeHeight = 0;
              const clusterHeights = bin.clusterCounts.map(count => {
                const h = (count / maxCount) * 300;
                const result = { start: cumulativeHeight, height: h };
                cumulativeHeight += h;
                return result;
              });

              return (
                <g key={idx}>
                  {highlightCluster === null ? (
                    <>
                      {clusterHeights.map((ch, clusterIdx) => (
                        <rect
                          key={clusterIdx}
                          x={x + 1}
                          y={350 - ch.start - ch.height}
                          width={barWidth - 2}
                          height={ch.height}
                          fill={['#10b981', '#f59e0b', '#ef4444'][clusterIdx]}
                          opacity={isHovered ? 0.9 : 0.7}
                          style={{ transition: 'opacity 0.2s' }}
                        />
                      ))}
                    </>
                  ) : (
                    <rect
                      x={x + 1}
                      y={350 - (bin.clusterCounts[highlightCluster] / maxCount) * 300}
                      width={barWidth - 2}
                      height={(bin.clusterCounts[highlightCluster] / maxCount) * 300}
                      fill={['#10b981', '#f59e0b', '#ef4444'][highlightCluster]}
                      opacity={isHovered ? 0.9 : 0.7}
                      style={{ transition: 'opacity 0.2s' }}
                    />
                  )}
                  
                  <rect
                    x={x}
                    y={50}
                    width={barWidth}
                    height={300}
                    fill="transparent"
                    style={{ cursor: 'pointer' }}
                    onMouseEnter={() => setHoveredBin(idx)}
                    onMouseLeave={() => setHoveredBin(null)}
                  />
                </g>
              );
            })}

            {showStats && (
              <>
                <line
                  x1={60 + ((stats.mean - features[selectedFeature].min) / (features[selectedFeature].max - features[selectedFeature].min)) * 1000}
                  y1="50"
                  x2={60 + ((stats.mean - features[selectedFeature].min) / (features[selectedFeature].max - features[selectedFeature].min)) * 1000}
                  y2="350"
                  stroke="#3b82f6"
                  strokeWidth="2"
                  strokeDasharray="5,5"
                />
                <text
                  x={60 + ((stats.mean - features[selectedFeature].min) / (features[selectedFeature].max - features[selectedFeature].min)) * 1000}
                  y="40"
                  textAnchor="middle"
                  fontSize="12"
                  fontWeight="600"
                  fill="#3b82f6"
                >
                  Mean: {stats.mean.toFixed(2)}
                </text>

                <line
                  x1={60 + ((stats.median - features[selectedFeature].min) / (features[selectedFeature].max - features[selectedFeature].min)) * 1000}
                  y1="50"
                  x2={60 + ((stats.median - features[selectedFeature].min) / (features[selectedFeature].max - features[selectedFeature].min)) * 1000}
                  y2="350"
                  stroke="#8b5cf6"
                  strokeWidth="2"
                  strokeDasharray="10,5"
                />
                <text
                  x={60 + ((stats.median - features[selectedFeature].min) / (features[selectedFeature].max - features[selectedFeature].min)) * 1000}
                  y="25"
                  textAnchor="middle"
                  fontSize="12"
                  fontWeight="600"
                  fill="#8b5cf6"
                >
                  Median: {stats.median.toFixed(2)}
                </text>
              </>
            )}

            {[0, 0.25, 0.5, 0.75, 1].map(fraction => {
              const value = features[selectedFeature].min + fraction * (features[selectedFeature].max - features[selectedFeature].min);
              return (
                <text
                  key={fraction}
                  x={60 + fraction * 1000}
                  y="370"
                  textAnchor="middle"
                  fontSize="12"
                  fill="#374151"
                >
                  {value.toFixed(1)}
                </text>
              );
            })}

            <text x="560" y="395" textAnchor="middle" fontSize="14" fontWeight="600" fill="#1f2937">
              {features[selectedFeature].label} ({features[selectedFeature].unit})
            </text>
            <text x="25" y="200" textAnchor="middle" fontSize="14" fontWeight="600" fill="#1f2937" transform="rotate(-90, 25, 200)">
              Frequency
            </text>
          </svg>

          {hoveredBin !== null && (
            <div style={{
              marginTop: '20px',
              padding: '15px',
              background: 'white',
              borderRadius: '8px',
              border: '2px solid #8b5cf6',
              textAlign: 'center'
            }}>
              <div style={{ fontSize: '14px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
                Range: {bins[hoveredBin].start.toFixed(2)} - {bins[hoveredBin].end.toFixed(2)} {features[selectedFeature].unit}
              </div>
              <div style={{ fontSize: '13px', color: '#4b5563' }}>
                Total: <strong>{bins[hoveredBin].count}</strong> patients
                {highlightCluster === null && (
                  <span style={{ marginLeft: '20px' }}>
                    Low Risk: <strong style={{ color: '#10b981' }}>{bins[hoveredBin].clusterCounts[0]}</strong> | 
                    Medium Risk: <strong style={{ color: '#f59e0b' }}> {bins[hoveredBin].clusterCounts[1]}</strong> | 
                    High Risk: <strong style={{ color: '#ef4444' }}> {bins[hoveredBin].clusterCounts[2]}</strong>
                  </span>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      <div style={{
        maxWidth: '1200px',
        margin: '30px auto 0',
        padding: '20px',
        background: '#fef3c7',
        borderRadius: '12px',
        border: '2px solid #fbbf24'
      }}>
        <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '12px', color: '#92400e' }}>
          💡 Understanding Feature Distributions
        </h3>
        <ul style={{ fontSize: '14px', color: '#78350f', lineHeight: '1.7', margin: 0, paddingLeft: '20px' }}>
          <li><strong>Skewness:</strong> Positive = longer tail on right (outliers above mean). Negative = longer tail on left.</li>
          <li><strong>Mean vs Median:</strong> If mean &gt; median, distribution is right-skewed. If mean &lt; median, left-skewed.</li>
          <li><strong>Outliers:</strong> Toggle to see how extreme values affect the distribution shape.</li>
          <li><strong>Bins:</strong> Fewer bins show overall pattern, more bins reveal fine details but may look noisy.</li>
          <li><strong>Clusters:</strong> See how different risk groups contribute to the overall distribution!</li>
        </ul>
      </div>
    </div>
  );
};

export default FeatureDistributionExplorer;