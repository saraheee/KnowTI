import { useState, useEffect, useRef, useCallback, useMemo } from "react";

export default function App() {
  const [isPlaying, setIsPlaying] = useState(true);
  const [selectedStrip, setSelectedStrip] = useState(null);
  const [hoveredStrip, setHoveredStrip] = useState(null);
  const [time, setTime] = useState(0);
  const [speed, setSpeed] = useState(1);
  const animFrameRef = useRef(null);
  const lastTimeRef = useRef(null);
  const timeRef = useRef(0);
  const speedRef = useRef(1);

  const animate = useCallback((timestamp) => {
    if (lastTimeRef.current === null) lastTimeRef.current = timestamp;
    const delta = (timestamp - lastTimeRef.current) / 1000;
    lastTimeRef.current = timestamp;
    timeRef.current += delta * speedRef.current;
    setTime(timeRef.current);
    animFrameRef.current = requestAnimationFrame(animate);
  }, []);

  useEffect(() => {
    if (isPlaying) {
      lastTimeRef.current = null;
      animFrameRef.current = requestAnimationFrame(animate);
    } else {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    }
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isPlaying, animate]);

  const handleReset = useCallback(() => {
    timeRef.current = 0;
    setTime(0);
    lastTimeRef.current = null;
    setSelectedStrip(null);
  }, []);

  const handleSpeedChange = useCallback((val) => {
    speedRef.current = val;
    setSpeed(val);
  }, []);

  const generateNormalPath = useCallback((width, height, t) => {
    const points = [];
    const cycles = 3;
    const cycleWidth = width / cycles;
    const baseline = height * 0.6;
    const offset = (t * 80) % cycleWidth;

    for (let i = 0; i < width + cycleWidth; i += 2) {
      const xInCycle = ((i + offset) % cycleWidth) / cycleWidth;
      let y = baseline;

      if (xInCycle > 0.05 && xInCycle < 0.18) {
        const px = (xInCycle - 0.115) / 0.065;
        y = baseline - height * 0.08 * Math.exp(-px * px * 8);
      } else if (xInCycle >= 0.18 && xInCycle < 0.28) {
        y = baseline;
      } else if (xInCycle >= 0.28 && xInCycle < 0.42) {
        if (xInCycle < 0.31) {
          y = baseline + height * 0.04;
        } else if (xInCycle < 0.38) {
          y = baseline - height * 0.38 * Math.exp(-Math.pow((xInCycle - 0.345) / 0.022, 2));
        } else {
          y = baseline + height * 0.06 * Math.exp(-Math.pow((xInCycle - 0.41) / 0.015, 2));
        }
      } else if (xInCycle >= 0.42 && xInCycle < 0.52) {
        y = baseline;
      } else if (xInCycle >= 0.52 && xInCycle < 0.72) {
        const tx = (xInCycle - 0.62) / 0.1;
        y = baseline - height * 0.12 * Math.exp(-tx * tx * 5);
      }

      const x = i - offset;
      if (x >= 0 && x <= width) {
        points.push(`${x},${y.toFixed(2)}`);
      }
    }
    return points.join(" ");
  }, []);

  const generateAFPath = useCallback((width, height, t) => {
    const points = [];
    const baseline = height * 0.6;

    // Chaotic fibrillatory baseline: many overlapping frequencies at different phases
    const fibBaseline = (x, t) => {
      const f1 = Math.sin(x * 0.09  + t * 7.3  + 0.4) * 0.38;
      const f2 = Math.sin(x * 0.14  + t * 11.7 + 1.1) * 0.28;
      const f3 = Math.sin(x * 0.22  + t * 5.1  + 2.3) * 0.20;
      const f4 = Math.sin(x * 0.07  + t * 14.9 + 0.8) * 0.14;
      const f5 = Math.sin(x * 0.31  + t * 8.6  + 3.7) * 0.10;
      const f6 = Math.sin(x * 0.055 + t * 19.2 + 1.6) * 0.08;
      const drift = Math.sin(x * 0.018 + t * 2.1) * 0.18;
      return (f1 + f2 + f3 + f4 + f5 + f6 + drift) * height * 0.065;
    };

    // QRS beats: wildly uneven spacing, varying heights, some aberrant (wide) beats
    const beats = [
      { pos: 0.12, amp: 0.36, wide: false },
      { pos: 0.27, amp: 0.28, wide: false },
      { pos: 0.51, amp: 0.41, wide: false },
      { pos: 0.63, amp: 0.22, wide: true  },
      { pos: 0.82, amp: 0.38, wide: false },
      { pos: 1.04, amp: 0.19, wide: false },
      { pos: 1.11, amp: 0.32, wide: false },
      { pos: 1.35, amp: 0.43, wide: false },
      { pos: 1.55, amp: 0.25, wide: true  },
      { pos: 1.68, amp: 0.36, wide: false },
      { pos: 1.79, amp: 0.30, wide: false },
      { pos: 1.89, amp: 0.17, wide: false },
      { pos: 2.14, amp: 0.40, wide: false },
      { pos: 2.38, amp: 0.33, wide: false },
      { pos: 2.54, amp: 0.27, wide: true  },
    ];

    const period = 2.6;

    for (let i = 0; i < width; i += 2) {
      const xNorm  = i / width;
      const scroll = (t * 0.65) % period;
      const xPhase = (xNorm + scroll) % period;

      let qrs = 0;
      for (const beat of beats) {
        const dist = xPhase - beat.pos;
        const hw = beat.wide ? 0.055 : 0.032;
        if (Math.abs(dist) < hw * 2.2) {
          if (dist > -hw * 0.35 && dist < hw * 0.35) {
            qrs = -height * beat.amp * Math.exp(-Math.pow(dist / (hw * 0.28), 2));
          } else if (dist >= hw * 0.35 && dist < hw * 1.4) {
            const sAmp = beat.wide ? 0.055 : 0.038;
            qrs = height * sAmp * Math.exp(-Math.pow((dist - hw * 0.7) / (hw * 0.4), 2));
          } else if (dist < -hw * 0.35 && dist > -hw * 1.4) {
            qrs = height * 0.025;
          } else if (beat.wide && dist >= hw * 1.4 && dist < hw * 2.2) {
            qrs = height * 0.03 * Math.exp(-Math.pow((dist - hw * 1.7) / (hw * 0.5), 2));
          }
          break;
        }
      }

      const fib = fibBaseline(i, t);
      const y   = baseline + fib + qrs;
      points.push(`${i},${y.toFixed(2)}`);
    }
    return points.join(" ");
  }, []);


  const normalPath = useMemo(() => generateNormalPath(520, 140, time), [generateNormalPath, time]);
  const afPath = useMemo(() => generateAFPath(520, 140, time), [generateAFPath, time]);

  const activeStrip = selectedStrip || hoveredStrip;

  const overlayInfo = {
    normal: {
      title: "Normal Sinus Rhythm",
      color: "#22c55e",
      points: [
        { label: "P Wave", desc: "Atrial contraction — regular, consistent before each QRS" },
        { label: "QRS Complex", desc: "Ventricular contraction — strong, uniform, predictable" },
        { label: "Rate", desc: "60–100 bpm, metronomically regular intervals" },
        { label: "SA Node", desc: "Pacemaker fires in sequence — orderly top-to-bottom conduction" },
      ],
    },
    af: {
      title: "Atrial Fibrillation",
      color: "#ef4444",
      points: [
        { label: "No P Waves", desc: "Chaotic atrial signals replace organised contraction entirely" },
        { label: "Irregular QRS", desc: "Ventricular response is unpredictable — no two intervals equal" },
        { label: "Rate", desc: "Atria fire 350–600 times/min; ventricles respond irregularly" },
        { label: "Stroke Risk", desc: "Blood pools in atria → clots form → 5× stroke risk vs normal" },
      ],
    },
  };

  const stripConfig = [
    {
      key: "normal",
      label: "Normal Sinus Rhythm",
      sublabel: "Regular · Coordinated",
      color: "#22c55e",
      bgColor: "#f0fdf4",
      borderColor: "#86efac",
      activeTextColor: "#15803d",
    },
    {
      key: "af",
      label: "Atrial Fibrillation",
      sublabel: "Irregular · Chaotic",
      color: "#ef4444",
      bgColor: "#fff1f2",
      borderColor: "#fca5a5",
      activeTextColor: "#b91c1c",
    },
  ];

  const comparisonRows = [
    { aspect: "P waves",      normal: "Present, regular before each QRS",   af: "Absent — replaced by fibrillatory baseline" },
    { aspect: "Rhythm",       normal: "Regular and predictable",              af: "Irregularly irregular" },
    { aspect: "Atrial rate",  normal: "60–100 bpm",                          af: "350–600 impulses/min" },
    { aspect: "QRS",          normal: "Uniform, narrow",                      af: "Variable spacing and interval" },
    { aspect: "Stroke risk",  normal: "Baseline",                             af: "5× higher" },
    { aspect: "Treatment",    normal: "None required",                        af: "Rate/rhythm control + anticoagulation" },
  ];

  return (
    <div style={{
      width: "100%", minHeight: "100vh",
      background: "#ffffff",
      display: "flex", flexDirection: "column",
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
    }}>
      <style>{`
        @keyframes pulseGlow {
          0%, 100% { box-shadow: 0 0 0 0 rgba(34,197,94,0); }
          50%       { box-shadow: 0 0 0 8px rgba(34,197,94,0.15); }
        }
        @keyframes pulseGlowRed {
          0%, 100% { box-shadow: 0 0 0 0 rgba(239,68,68,0); }
          50%       { box-shadow: 0 0 0 8px rgba(239,68,68,0.18); }
        }
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes heartbeat {
          0%, 100% { transform: scale(1); }
          14%      { transform: scale(1.15); }
          28%      { transform: scale(1); }
          42%      { transform: scale(1.08); }
          56%      { transform: scale(1); }
        }
        @keyframes heartbeatAF {
          0%   { transform: scale(1); }
          8%   { transform: scale(1.18); }
          16%  { transform: scale(0.97); }
          27%  { transform: scale(1.1); }
          38%  { transform: scale(1); }
          49%  { transform: scale(1.14); }
          58%  { transform: scale(0.98); }
          71%  { transform: scale(1.07); }
          83%  { transform: scale(1); }
          91%  { transform: scale(1.12); }
          100% { transform: scale(1); }
        }
        @keyframes stripReveal {
          from { opacity: 0; transform: scale(0.97); }
          to   { opacity: 1; transform: scale(1); }
        }
        @keyframes dotPulse {
          0%, 100% { opacity: 1; }
          50%      { opacity: 0.3; }
        }
        .strip-card {
          flex: 1;
          border-radius: 16px;
          border: 2px solid;
          cursor: pointer;
          transition: all 0.2s ease;
          overflow: hidden;
          position: relative;
        }
        .strip-card:hover { transform: translateY(-1px); }
        .ctrl-btn {
          display: flex; align-items: center; gap: 6px;
          padding: 8px 16px; border-radius: 8px;
          border: 1px solid #e5e7eb;
          font-size: 13px; font-weight: 600;
          cursor: pointer; transition: all 0.15s ease;
        }
        .comp-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .comp-table th {
          font-size: 12px; font-weight: 600; color: #6b7280;
          padding: 10px 14px; text-align: left;
          border-bottom: 1px solid #f3f4f6;
          background: #fafafa;
        }
        .comp-table td {
          padding: 10px 14px;
          border-bottom: 1px solid #f9fafb;
          vertical-align: top;
        }
        .comp-table tr:last-child td { border-bottom: none; }
      `}</style>

      {/* ── Header ── */}
      <div style={{ padding: "36px 48px 0", display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "6px" }}>
            <div style={{
              width: "8px", height: "8px", borderRadius: "50%", background: "#ef4444",
              animation: isPlaying ? "dotPulse 1.2s ease-in-out infinite" : "none",
            }} />
            <span style={{ fontSize: "11px", fontWeight: "600", letterSpacing: "0.12em", textTransform: "uppercase", color: "#9ca3af" }}>
              {isPlaying ? "Live" : "Paused"}
            </span>
          </div>
          <h1 style={{ margin: 0, fontSize: "26px", fontWeight: "700", color: "#111827", letterSpacing: "-0.02em" }}>
            Atrial Fibrillation
          </h1>
          <p style={{ margin: "4px 0 0", fontSize: "14px", color: "#6b7280" }}>
            Heart Rhythm Visualiser — click a strip to explore
          </p>
        </div>

        <div style={{ display: "flex", gap: "8px", alignItems: "center", paddingTop: "8px" }}>
          {/* Speed slider */}
          <div style={{
            display: "flex", alignItems: "center", gap: "10px",
            padding: "6px 14px", borderRadius: "8px",
            border: "1px solid #e5e7eb", background: "#ffffff",
          }}>
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none" stroke="#6b7280" strokeWidth="1.5" strokeLinecap="round">
              <circle cx="6.5" cy="6.5" r="5.5"/>
              <polyline points="6.5,3.5 6.5,6.5 8.5,7.5"/>
            </svg>
            <input
              type="range"
              min="0.25"
              max="3"
              step="0.25"
              value={speed}
              onChange={e => handleSpeedChange(parseFloat(e.target.value))}
              style={{ width: "80px", accentColor: "#111827", cursor: "pointer" }}
            />
            <span style={{ fontSize: "12px", fontWeight: "600", color: "#374151", minWidth: "32px" }}>
              {speed.toFixed(2)}×
            </span>
          </div>
          <button
            className="ctrl-btn"
            onClick={() => setIsPlaying(p => !p)}
            style={{ background: isPlaying ? "#111827" : "#ffffff", color: isPlaying ? "#ffffff" : "#374151" }}
          >
            {isPlaying ? (
              <>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
                  <rect x="2" y="1" width="3" height="10" rx="1"/>
                  <rect x="7" y="1" width="3" height="10" rx="1"/>
                </svg>
                Pause
              </>
            ) : (
              <>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
                  <path d="M2 1l9 5-9 5V1z"/>
                </svg>
                Play
              </>
            )}
          </button>
          <button
            className="ctrl-btn"
            onClick={handleReset}
            style={{ background: "#ffffff", color: "#374151" }}
          >
            <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
              <path d="M10 6A4 4 0 1 1 6 2V0L9 3 6 6V4a2 2 0 1 0 2 2h2z"/>
            </svg>
            Reset
          </button>
        </div>
      </div>

      {/* ── Stat bar ── */}
      <div style={{
        margin: "24px 48px 0", padding: "14px 20px",
        background: "#fafafa", borderRadius: "10px", border: "1px solid #f3f4f6",
        display: "flex", gap: "0", alignItems: "center",
      }}>
        {[
          { stat: "Most common", label: "cardiac arrhythmia worldwide" },
          { stat: "1 in 3",      label: "adults have lifetime AF risk" },
          { stat: "20%",         label: "of ischaemic strokes caused by AF" },
          { stat: "5×",          label: "higher stroke risk vs normal rhythm" },
        ].map((item, i) => (
          <div key={i} style={{ display: "flex", alignItems: "baseline", gap: "8px", flex: 1 }}>
            <span style={{ fontSize: "15px", fontWeight: "700", color: "#111827" }}>{item.stat}</span>
            <span style={{ fontSize: "12px", color: "#9ca3af" }}>{item.label}</span>
            {i < 3 && <div style={{ width: "1px", height: "16px", background: "#e5e7eb", marginLeft: "auto" }} />}
          </div>
        ))}
      </div>

      {/* ── ECG strips ── */}
      <div style={{ display: "flex", gap: "20px", padding: "24px 48px 0" }}>
        {stripConfig.map(({ key, label, sublabel, color, bgColor, borderColor, activeTextColor }) => {
          const isSelected = selectedStrip === key;
          const isHovered = hoveredStrip === key;
          const isActive = isSelected || isHovered;

          return (
            <div
              key={key}
              className="strip-card"
              onClick={() => setSelectedStrip(s => s === key ? null : key)}
              onMouseEnter={() => setHoveredStrip(key)}
              onMouseLeave={() => setHoveredStrip(null)}
              style={{
                borderColor: isActive ? color : borderColor,
                background: isActive ? bgColor : "#fafafa",
                animation: isPlaying && isActive
                  ? (key === "normal" ? "pulseGlow 2s ease-in-out infinite" : "pulseGlowRed 1.5s ease-in-out infinite")
                  : "none",
              }}
            >
              {/* Strip header */}
              <div style={{ padding: "20px 24px 0", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "2px" }}>
                    <div style={{
                      fontSize: "22px", lineHeight: 1,
                      animation: isPlaying
                        ? (key === "normal" ? "heartbeat 1.4s ease-in-out infinite" : "heartbeatAF 1.1s ease-in-out infinite")
                        : "none",
                    }}>
                      {key === "normal" ? "💚" : "❤️"}
                    </div>
                    <span style={{ fontSize: "16px", fontWeight: "700", color: "#111827" }}>{label}</span>
                  </div>
                  <span style={{ fontSize: "12px", color: isActive ? activeTextColor : "#9ca3af", fontWeight: "600", letterSpacing: "0.05em" }}>
                    {sublabel}
                  </span>
                </div>
                <div style={{
                  padding: "4px 10px", borderRadius: "20px",
                  background: isActive ? color : "#e5e7eb",
                  color: isActive ? "#ffffff" : "#9ca3af",
                  fontSize: "11px", fontWeight: "600",
                  transition: "all 0.2s ease",
                }}>
                  {isSelected ? "Selected" : "Click to explore"}
                </div>
              </div>

              {/* ECG canvas */}
              <div style={{ padding: "16px 16px 8px", position: "relative" }}>
                <svg width="100%" viewBox="0 0 520 140" style={{ display: "block", overflow: "visible" }} preserveAspectRatio="xMidYMid meet">
                  {/* Grid lines */}
                  {Array.from({ length: 14 }, (_, i) => (
                    <line key={`v${i}`} x1={i * 40} y1={0} x2={i * 40} y2={140}
                      stroke={isActive ? color : "#d1d5db"} strokeWidth="0.5" opacity="0.3" />
                  ))}
                  {Array.from({ length: 5 }, (_, i) => (
                    <line key={`h${i}`} x1={0} y1={i * 35} x2={520} y2={i * 35}
                      stroke={isActive ? color : "#d1d5db"} strokeWidth="0.5" opacity="0.3" />
                  ))}

                  {/* Isoelectric baseline */}
                  <line x1={0} y1={84} x2={520} y2={84}
                    stroke={isActive ? color : "#9ca3af"} strokeWidth="0.5" opacity="0.4" strokeDasharray="4,4" />

                  {/* ECG trace */}
                  <polyline
                    points={key === "normal" ? normalPath : afPath}
                    fill="none"
                    stroke={isActive ? color : "#6b7280"}
                    strokeWidth={isActive ? "2.5" : "2"}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    style={{ transition: "stroke 0.2s, stroke-width 0.2s" }}
                  />

                  {/* Edge fade overlays */}
                  <defs>
                    <linearGradient id={`fadeLeft${key}`} x1="0" x2="1" y1="0" y2="0">
                      <stop offset="0%"  stopColor={isActive ? bgColor : "#fafafa"} stopOpacity="1" />
                      <stop offset="8%"  stopColor={isActive ? bgColor : "#fafafa"} stopOpacity="0" />
                    </linearGradient>
                    <linearGradient id={`fadeRight${key}`} x1="0" x2="1" y1="0" y2="0">
                      <stop offset="92%"  stopColor={isActive ? bgColor : "#fafafa"} stopOpacity="0" />
                      <stop offset="100%" stopColor={isActive ? bgColor : "#fafafa"} stopOpacity="1" />
                    </linearGradient>
                  </defs>
                  <rect x="0" y="0" width="520" height="140" fill={`url(#fadeLeft${key})`} />
                  <rect x="0" y="0" width="520" height="140" fill={`url(#fadeRight${key})`} />

                  {/* Annotation labels — normal */}
                  {isSelected && key === "normal" && (
                    <g style={{ animation: "fadeSlideIn 0.3s ease" }}>
                      <text x="88"  y="20" fontSize="9" fill={color} fontWeight="600" textAnchor="middle">P wave</text>
                      <line x1="88"  y1="24" x2="88"  y2="48" stroke={color} strokeWidth="1" strokeDasharray="2,2" opacity="0.6" />
                      <text x="195" y="12" fontSize="9" fill={color} fontWeight="600" textAnchor="middle">QRS</text>
                      <line x1="195" y1="16" x2="195" y2="26" stroke={color} strokeWidth="1" strokeDasharray="2,2" opacity="0.6" />
                      <text x="282" y="30" fontSize="9" fill={color} fontWeight="600" textAnchor="middle">T wave</text>
                      <line x1="282" y1="34" x2="282" y2="52" stroke={color} strokeWidth="1" strokeDasharray="2,2" opacity="0.6" />
                    </g>
                  )}

                  {/* Annotation labels — AF */}
                  {isSelected && key === "af" && (
                    <g style={{ animation: "fadeSlideIn 0.3s ease" }}>
                      <text x="90"  y="20" fontSize="9" fill={color} fontWeight="600" textAnchor="middle">Fibrillatory baseline</text>
                      <line x1="90"  y1="24" x2="90"  y2="68" stroke={color} strokeWidth="1" strokeDasharray="2,2" opacity="0.6" />
                      <text x="350" y="16" fontSize="9" fill={color} fontWeight="600" textAnchor="middle">No P waves</text>
                      <text x="350" y="26" fontSize="8"  fill={color} fontWeight="400" textAnchor="middle" opacity="0.8">irregular intervals</text>
                    </g>
                  )}
                </svg>
              </div>

              {/* Expanded detail cards */}
              {isSelected && (
                <div style={{ padding: "0 20px 20px", animation: "stripReveal 0.25s ease" }}>
                  <div style={{
                    borderTop: `1px solid ${borderColor}`, paddingTop: "16px",
                    display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px",
                  }}>
                    {overlayInfo[key].points.map((point, i) => (
                      <div key={i} style={{
                        background: "#ffffff", border: `1px solid ${borderColor}`,
                        borderRadius: "10px", padding: "12px 14px",
                      }}>
                        <div style={{ fontSize: "11px", fontWeight: "700", color, marginBottom: "4px", letterSpacing: "0.03em" }}>
                          {point.label}
                        </div>
                        <div style={{ fontSize: "12px", color: "#6b7280", lineHeight: "1.4" }}>
                          {point.desc}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Hover hint */}
              {!isSelected && isHovered && (
                <div style={{ padding: "8px 24px 16px", animation: "fadeSlideIn 0.15s ease" }}>
                  <p style={{ margin: 0, fontSize: "12px", color, fontWeight: "500", textAlign: "center" }}>
                    Click to reveal details →
                  </p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* ── Comparison panel ── */}
      <div style={{ margin: "24px 48px 40px", borderRadius: "14px", background: "#f8fafc", border: "1px solid #e2e8f0", overflow: "hidden" }}>
        <div style={{ padding: "18px 24px 14px", borderBottom: "1px solid #e2e8f0", display: "flex", alignItems: "center", gap: "10px" }}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="#6b7280" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <rect x="1" y="1" width="14" height="14" rx="2"/>
            <line x1="1" y1="5" x2="15" y2="5"/>
            <line x1="6" y1="5" x2="6" y2="15"/>
          </svg>
          <span style={{ fontSize: "14px", fontWeight: "700", color: "#111827" }}>Side-by-side comparison</span>
        </div>
        <table className="comp-table">
          <thead>
            <tr>
              <th style={{ width: "22%" }}>Feature</th>
              <th><span style={{ color: "#22c55e" }}>●</span> Normal sinus rhythm</th>
              <th><span style={{ color: "#ef4444" }}>●</span> Atrial fibrillation</th>
            </tr>
          </thead>
          <tbody>
            {comparisonRows.map(({ aspect, normal, af }, i) => (
              <tr key={i} style={{ background: i % 2 === 0 ? "#ffffff" : "#fafafa" }}>
                <td style={{ fontWeight: "600", color: "#374151", fontSize: "12px" }}>{aspect}</td>
                <td style={{ color: "#374151" }}>{normal}</td>
                <td style={{ color: "#b91c1c" }}>{af}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
