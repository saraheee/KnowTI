import React, { useState, useRef, useCallback } from 'react';

const STROKE_TYPES = [
  { id: 'af-stroke-1', type: 'af-related', label: 'AF-Related Stroke 1' },
  { id: 'af-stroke-2', type: 'af-related', label: 'AF-Related Stroke 2' },
  { id: 'af-stroke-3', type: 'af-related', label: 'AF-Related Stroke 3' },
  { id: 'af-stroke-4', type: 'af-related', label: 'AF-Related Stroke 4' },
  { id: 'other-ischemic-1', type: 'other-ischemic', label: 'Other Ischemic 1' },
  { id: 'other-ischemic-2', type: 'other-ischemic', label: 'Other Ischemic 2' },
  { id: 'other-ischemic-3', type: 'other-ischemic', label: 'Other Ischemic 3' },
  { id: 'other-ischemic-4', type: 'other-ischemic', label: 'Other Ischemic 4' },
  { id: 'other-ischemic-5', type: 'other-ischemic', label: 'Other Ischemic 5' },
  { id: 'other-ischemic-6', type: 'other-ischemic', label: 'Other Ischemic 6' },
  { id: 'other-ischemic-7', type: 'other-ischemic', label: 'Other Ischemic 7' },
  { id: 'other-ischemic-8', type: 'other-ischemic', label: 'Other Ischemic 8' },
  { id: 'other-ischemic-9', type: 'other-ischemic', label: 'Other Ischemic 9' },
  { id: 'other-ischemic-10', type: 'other-ischemic', label: 'Other Ischemic 10' },
  { id: 'other-ischemic-11', type: 'other-ischemic', label: 'Other Ischemic 11' },
  { id: 'other-ischemic-12', type: 'other-ischemic', label: 'Other Ischemic 12' },
  { id: 'hemorrhagic-1', type: 'hemorrhagic', label: 'Hemorrhagic Stroke 1' },
  { id: 'hemorrhagic-2', type: 'hemorrhagic', label: 'Hemorrhagic Stroke 2' },
  { id: 'hemorrhagic-3', type: 'hemorrhagic', label: 'Hemorrhagic Stroke 3' },
  { id: 'hemorrhagic-4', type: 'hemorrhagic', label: 'Hemorrhagic Stroke 4' }
];

export default function App() {
  const [placements, setPlacements] = useState({});
  const [draggedItem, setDraggedItem] = useState(null);
  const [dragOverTarget, setDragOverTarget] = useState(null);
  const [feedback, setFeedback] = useState(null);
  const [showProportions, setShowProportions] = useState(false);
  const [hoveredInfo, setHoveredInfo] = useState(null);
  const dragRef = useRef(null);

  const handleDragStart = useCallback((e, item) => {
    setDraggedItem(item);
    e.dataTransfer.effectAllowed = 'move';
  }, []);

  const handleDragOver = useCallback((e, targetType) => {
    e.preventDefault();
    setDragOverTarget(targetType);
  }, []);

  const handleDragLeave = useCallback(() => {
    setDragOverTarget(null);
  }, []);

  const handleDrop = useCallback((e, targetType) => {
    e.preventDefault();
    setDragOverTarget(null);
    
    if (!draggedItem) return;

    const isCorrect = draggedItem.type === targetType;
    
    if (isCorrect) {
      setPlacements(prev => ({
        ...prev,
        [draggedItem.id]: targetType
      }));
      
      let explanation = '';
      if (targetType === 'af-related') {
        explanation = 'Correct! AF-related strokes are caused by blood clots formed in the atria due to atrial fibrillation. These embolic strokes represent exactly 20% of all ischemic strokes.';
      } else if (targetType === 'other-ischemic') {
        explanation = 'Correct! This represents other causes of ischemic stroke like atherothrombosis, small vessel disease, or other cardioembolic sources. Together they make up 80% of ischemic strokes.';
      } else if (targetType === 'hemorrhagic') {
        explanation = 'Correct! Hemorrhagic strokes are caused by bleeding in the brain and represent about 15% of all strokes.';
      }
      
      setFeedback({ type: 'success', message: explanation });
    } else {
      let hint = '';
      if (draggedItem.type === 'af-related' && targetType !== 'af-related') {
        hint = 'This piece represents an AF-related stroke. It should go in the specific AF section, which forms exactly 1/5 (20%) of the ischemic stroke area.';
      } else if (draggedItem.type === 'other-ischemic' && targetType !== 'other-ischemic') {
        hint = 'This piece represents other ischemic stroke causes (non-AF). It belongs in the larger ischemic section that represents the remaining 80%.';
      } else if (draggedItem.type === 'hemorrhagic' && targetType !== 'hemorrhagic') {
        hint = 'This piece represents a hemorrhagic stroke caused by bleeding. It belongs in the hemorrhagic section, not the ischemic areas.';
      }
      
      setFeedback({ type: 'error', message: hint });
    }
    
    setDraggedItem(null);
    setTimeout(() => setFeedback(null), 4000);
  }, [draggedItem]);

  const handleReset = useCallback(() => {
    setPlacements({});
    setFeedback(null);
    setDraggedItem(null);
    setDragOverTarget(null);
  }, []);

  const getPlacedItems = useCallback((targetType) => {
    return Object.entries(placements)
      .filter(([_, type]) => type === targetType)
      .map(([id]) => STROKE_TYPES.find(item => item.id === id));
  }, [placements]);

  const getAvailableItems = useCallback(() => {
    const placedIds = Object.keys(placements);
    return STROKE_TYPES.filter(item => !placedIds.includes(item.id));
  }, [placements]);

  const afPlaced = getPlacedItems('af-related').length;
  const otherIschemicPlaced = getPlacedItems('other-ischemic').length;
  const totalIschemic = afPlaced + otherIschemicPlaced;
  const afPercentage = totalIschemic > 0 ? Math.round((afPlaced / totalIschemic) * 100) : 0;

  return (
    <div style={{ 
      width: '100%', 
      height: '100vh', 
      backgroundColor: '#ffffff',
      display: 'flex',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      {/* Left Panel - Draggable Items */}
      <div style={{ 
        width: '300px', 
        padding: '20px', 
        borderRight: '2px solid #e0e0e0',
        overflowY: 'auto'
      }}>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          marginBottom: '20px'
        }}>
          <h3 style={{ margin: 0, color: '#333' }}>Stroke Pieces</h3>
          <button
            onClick={handleReset}
            style={{
              padding: '8px 16px',
              backgroundColor: '#f0f0f0',
              border: '1px solid #ccc',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Reset
          </button>
        </div>
        
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {getAvailableItems().map(item => (
            <div
              key={item.id}
              draggable
              onDragStart={(e) => handleDragStart(e, item)}
              style={{
                padding: '12px',
                backgroundColor: item.type === 'af-related' ? '#fff3cd' : 
                               item.type === 'other-ischemic' ? '#d1ecf1' : '#f8d7da',
                border: `2px solid ${item.type === 'af-related' ? '#ffc107' : 
                                   item.type === 'other-ischemic' ? '#17a2b8' : '#dc3545'}`,
                borderRadius: '8px',
                cursor: 'grab',
                fontSize: '14px',
                fontWeight: '500',
                textAlign: 'center',
                userSelect: 'none'
              }}
            >
              {item.type === 'af-related' ? '🫀 AF Stroke' :
               item.type === 'other-ischemic' ? '🧠 Other Ischemic' : '🩸 Hemorrhagic'}
            </div>
          ))}
        </div>

        <div style={{ marginTop: '30px', padding: '15px', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
          <button
            onClick={() => setShowProportions(!showProportions)}
            style={{
              width: '100%',
              padding: '10px',
              backgroundColor: showProportions ? '#007bff' : '#6c757d',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
              marginBottom: '10px'
            }}
          >
            {showProportions ? 'Hide' : 'Show'} Proportions
          </button>
          
          {showProportions && (
            <div style={{ fontSize: '14px', color: '#495057' }}>
              <div><strong>Current Status:</strong></div>
              <div>AF Strokes: {afPlaced}/4</div>
              <div>Other Ischemic: {otherIschemicPlaced}/12</div>
              <div>Total Ischemic: {totalIschemic}/16</div>
              <div style={{ 
                marginTop: '8px', 
                fontWeight: 'bold',
                color: afPercentage === 20 ? '#28a745' : '#dc3545'
              }}>
                AF Percentage: {afPercentage}%
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div style={{ 
        flex: 1, 
        padding: '40px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'
      }}>
        <h1 style={{ 
          marginBottom: '10px', 
          color: '#333',
          textAlign: 'center'
        }}>
          Stroke Type Distribution
        </h1>
        <p style={{ 
          marginBottom: '40px', 
          color: '#666',
          textAlign: 'center',
          maxWidth: '600px'
        }}>
          Drag stroke pieces into the correct sections. AF-related strokes should form exactly 20% (1/5) of the ischemic stroke area.
        </p>

        {/* Brain Diagram */}
        <div style={{ 
          position: 'relative',
          width: '600px',
          height: '400px',
          margin: '0 auto'
        }}>
          {/* Hemorrhagic Section */}
          <div
            onDragOver={(e) => handleDragOver(e, 'hemorrhagic')}
            onDragLeave={handleDragLeave}
            onDrop={(e) => handleDrop(e, 'hemorrhagic')}
            onMouseEnter={() => setHoveredInfo('hemorrhagic')}
            onMouseLeave={() => setHoveredInfo(null)}
            style={{
              position: 'absolute',
              top: '20px',
              left: '20px',
              width: '160px',
              height: '120px',
              backgroundColor: dragOverTarget === 'hemorrhagic' ? '#f5c6cb' : '#f8d7da',
              border: `3px ${dragOverTarget === 'hemorrhagic' ? 'solid' : 'dashed'} #dc3545`,
              borderRadius: '12px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'flex-start',
              padding: '10px',
              boxSizing: 'border-box'
            }}
          >
            <div style={{ fontWeight: 'bold', fontSize: '12px', marginBottom: '8px', color: '#721c24' }}>
              Hemorrhagic Strokes
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px', width: '100%' }}>
              {getPlacedItems('hemorrhagic').map((item, index) => (
                <div key={item.id} style={{
                  backgroundColor: '#dc3545',
                  borderRadius: '4px',
                  height: '20px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '10px',
                  color: 'white'
                }}>
                  🩸
                </div>
              ))}
            </div>
            {hoveredInfo === 'hemorrhagic' && (
              <div style={{
                position: 'absolute',
                top: '-40px',
                left: '0',
                backgroundColor: '#333',
                color: 'white',
                padding: '8px',
                borderRadius: '4px',
                fontSize: '12px',
                zIndex: 10,
                whiteSpace: 'nowrap'
              }}>
                ~15% of all strokes
              </div>
            )}
          </div>

          {/* Large Ischemic Section */}
          <div style={{
            position: 'absolute',
            top: '20px',
            right: '20px',
            width: '400px',
            height: '360px',
            backgroundColor: '#d1ecf1',
            border: '3px solid #17a2b8',
            borderRadius: '20px',
            padding: '20px',
            boxSizing: 'border-box'
          }}>
            <div style={{ 
              textAlign: 'center', 
              fontWeight: 'bold', 
              marginBottom: '20px',
              color: '#0c5460'
            }}>
              Ischemic Strokes (~85% of all strokes)
            </div>

            {/* AF-Related Section */}
            <div
              onDragOver={(e) => handleDragOver(e, 'af-related')}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, 'af-related')}
              onMouseEnter={() => setHoveredInfo('af-related')}
              onMouseLeave={() => setHoveredInfo(null)}
              style={{
                width: '100%',
                height: '60px',
                backgroundColor: dragOverTarget === 'af-related' ? '#fff3cd' : '#ffeaa7',
                border: `3px ${dragOverTarget === 'af-related' ? 'solid' : 'dashed'} #ffc107`,
                borderRadius: '8px',
                marginBottom: '15px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '10px',
                boxSizing: 'border-box',
                position: 'relative'
              }}
            >
              <div style={{ fontWeight: 'bold', fontSize: '14px', color: '#856404' }}>
                AF-Related (20%)
              </div>
              <div style={{ display: 'flex', gap: '4px' }}>
                {getPlacedItems('af-related').map((item, index) => (
                  <div key={item.id} style={{
                    backgroundColor: '#ffc107',
                    borderRadius: '4px',
                    width: '24px',
                    height: '24px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '12px'
                  }}>
                    🫀
                  </div>
                ))}
              </div>
              {hoveredInfo === 'af-related' && (
                <div style={{
                  position: 'absolute',
                  top: '-40px',
                  left: '0',
                  backgroundColor: '#333',
                  color: 'white',
                  padding: '8px',
                  borderRadius: '4px',
                  fontSize: '12px',
                  zIndex: 10,
                  whiteSpace: 'nowrap'
                }}>
                  Caused by atrial fibrillation
                </div>
              )}
            </div>

            {/* Other Ischemic Section */}
            <div
              onDragOver={(e) => handleDragOver(e, 'other-ischemic')}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, 'other-ischemic')}
              onMouseEnter={() => setHoveredInfo('other-ischemic')}
              onMouseLeave={() => setHoveredInfo(null)}
              style={{
                width: '100%',
                height: '200px',
                backgroundColor: dragOverTarget === 'other-ischemic' ? '#bee5eb' : '#d1ecf1',
                border: `3px ${dragOverTarget === 'other-ischemic' ? 'solid' : 'dashed'} #17a2b8`,
                borderRadius: '8px',
                display: 'flex',
                flexDirection: 'column',
                padding: '10px',
                boxSizing: 'border-box',
                position: 'relative'
              }}
            >
              <div style={{ fontWeight: 'bold', fontSize: '14px', marginBottom: '10px', color: '#0c5460' }}>
                Other Ischemic Causes (80%)
              </div>
              <div style={{ 
                display: 'grid', 
                gridTemplateColumns: 'repeat(6, 1fr)', 
                gap: '6px',
                flex: 1
              }}>
                {getPlacedItems('other-ischemic').map((item, index) => (
                  <div key={item.id} style={{
                    backgroundColor: '#17a2b8',
                    borderRadius: '4px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '12px',
                    color: 'white'
                  }}>
                    🧠
                  </div>
                ))}
              </div>
              {hoveredInfo === 'other-ischemic' && (
                <div style={{
                  position: 'absolute',
                  top: '-40px',
                  left: '0',
                  backgroundColor: '#333',
                  color: 'white',
                  padding: '8px',
                  borderRadius: '4px',
                  fontSize: '12px',
                  zIndex: 10,
                  whiteSpace: 'nowrap'
                }}>
                  Atherothrombosis, small vessel disease, other causes
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Feedback Message */}
        {feedback && (
          <div style={{
            position: 'fixed',
            bottom: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            maxWidth: '500px',
            padding: '15px 20px',
            backgroundColor: feedback.type === 'success' ? '#d4edda' : '#f8d7da',
            border: `1px solid ${feedback.type === 'success' ? '#c3e6cb' : '#f5c6cb'}`,
            borderRadius: '8px',
            color: feedback.type === 'success' ? '#155724' : '#721c24',
            fontSize: '14px',
            zIndex: 1000,
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
          }}>
            {feedback.message}
          </div>
        )}

        {/* Completion Message */}
        {Object.keys(placements).length === STROKE_TYPES.length && afPercentage === 20 && (
          <div style={{
            marginTop: '30px',
            padding: '20px',
            backgroundColor: '#d4edda',
            border: '1px solid #c3e6cb',
            borderRadius: '8px',
            color: '#155724',
            textAlign: 'center',
            maxWidth: '600px'
          }}>
            <h3 style={{ margin: '0 0 10px 0' }}>🎉 Excellent!</h3>
            <p style={{ margin: 0 }}>
              You've correctly assembled the stroke distribution! AF-related strokes represent exactly 20% of ischemic strokes, 
              which is a crucial statistic for understanding stroke epidemiology and prevention strategies.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}