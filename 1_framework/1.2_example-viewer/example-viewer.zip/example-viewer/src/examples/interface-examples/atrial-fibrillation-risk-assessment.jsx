import { useState, useEffect, useRef, useCallback } from 'react';

export default function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [currentAge, setCurrentAge] = useState(18);
  const [afCases, setAfCases] = useState(0);
  const [showLifetimeView, setShowLifetimeView] = useState(false);
  const [hoveredPerson, setHoveredPerson] = useState(null);
  const intervalRef = useRef(null);
  const startTimeRef = useRef(null);

  const totalPopulation = 300;
  const maxAge = 85;
  const targetAfCases = Math.floor(totalPopulation / 3);

  const getAfRiskAtAge = (age) => {
    if (age < 50) return 0.001;
    if (age < 60) return 0.005;
    if (age < 70) return 0.015;
    if (age < 80) return 0.025;
    return 0.03;
  };

  const generatePopulation = () => {
    const population = [];
    for (let i = 0; i < totalPopulation; i++) {
      population.push({
        id: i,
        hasAF: false,
        afOnsetAge: null,
        row: Math.floor(i / 20),
        col: i % 20
      });
    }
    return population;
  };

  const [population, setPopulation] = useState(generatePopulation);

  const updatePopulation = useCallback((age) => {
    setPopulation(prev => {
      const newPop = [...prev];
      const riskRate = getAfRiskAtAge(age);
      
      newPop.forEach(person => {
        if (!person.hasAF && Math.random() < riskRate * speed * 0.1) {
          person.hasAF = true;
          person.afOnsetAge = age;
        }
      });
      
      return newPop;
    });
  }, [speed]);

  useEffect(() => {
    if (isPlaying && currentAge < maxAge) {
      startTimeRef.current = Date.now();
      intervalRef.current = setInterval(() => {
        setCurrentAge(prev => {
          const newAge = Math.min(prev + 0.5, maxAge);
          updatePopulation(newAge);
          return newAge;
        });
      }, 200 / speed);
    } else {
      clearInterval(intervalRef.current);
      if (currentAge >= maxAge) {
        setIsPlaying(false);
      }
    }

    return () => clearInterval(intervalRef.current);
  }, [isPlaying, currentAge, speed, updatePopulation]);

  useEffect(() => {
    const currentAfCases = population.filter(p => p.hasAF).length;
    setAfCases(currentAfCases);
  }, [population]);

  const handleReset = () => {
    setIsPlaying(false);
    setCurrentAge(18);
    setAfCases(0);
    setPopulation(generatePopulation());
    clearInterval(intervalRef.current);
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const getPersonColor = (person) => {
    if (person.hasAF) return '#e74c3c';
    return showLifetimeView ? '#95a5a6' : '#3498db';
  };

  const getPersonOpacity = (person) => {
    if (showLifetimeView && person.hasAF) return 1;
    if (showLifetimeView && !person.hasAF) return 0.3;
    return 1;
  };

  const riskPercentage = ((afCases / totalPopulation) * 100).toFixed(1);
  const progressPercentage = ((currentAge - 18) / (maxAge - 18)) * 100;

  return (
    <div style={{
      width: '100%',
      height: '100vh',
      backgroundColor: '#ffffff',
      display: 'flex',
      flexDirection: 'column',
      padding: '20px',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '30px'
      }}>
        <h1 style={{
          margin: 0,
          fontSize: '24px',
          fontWeight: '600',
          color: '#2c3e50'
        }}>
          Atrial Fibrillation: Lifetime Risk
        </h1>

        {/* Controls */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '15px',
          background: '#f8f9fa',
          padding: '8px 16px',
          borderRadius: '8px',
          border: '1px solid #e9ecef'
        }}>
          <label style={{ fontSize: '14px', color: '#495057' }}>Speed</label>
          <input
            type="range"
            min="0.5"
            max="3"
            step="0.1"
            value={speed}
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            style={{ width: '80px' }}
          />
          <span style={{ fontSize: '12px', color: '#6c757d', minWidth: '30px' }}>
            {speed}×
          </span>

          <button
            onClick={handlePlayPause}
            style={{
              background: isPlaying ? '#e74c3c' : '#27ae60',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              padding: '6px 12px',
              cursor: 'pointer',
              fontSize: '14px'
            }}
          >
            {isPlaying ? '⏸' : '▶'}
          </button>

          <button
            onClick={handleReset}
            style={{
              background: '#6c757d',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              padding: '6px 12px',
              cursor: 'pointer',
              fontSize: '12px'
            }}
          >
            Reset
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', gap: '40px' }}>
        {/* Population Grid */}
        <div style={{ flex: 1 }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(20, 1fr)',
            gap: '3px',
            maxWidth: '600px',
            aspectRatio: '4/3'
          }}>
            {population.map((person) => (
              <div
                key={person.id}
                onMouseEnter={() => setHoveredPerson(person)}
                onMouseLeave={() => setHoveredPerson(null)}
                style={{
                  width: '100%',
                  aspectRatio: '1',
                  backgroundColor: getPersonColor(person),
                  borderRadius: '50%',
                  opacity: getPersonOpacity(person),
                  transition: 'all 0.3s ease',
                  transform: hoveredPerson?.id === person.id ? 'scale(1.5)' : 'scale(1)',
                  cursor: 'pointer',
                  position: 'relative',
                  zIndex: hoveredPerson?.id === person.id ? 10 : 1
                }}
              />
            ))}
          </div>

          {/* Toggle View */}
          <div style={{ marginTop: '20px' }}>
            <button
              onClick={() => setShowLifetimeView(!showLifetimeView)}
              style={{
                background: showLifetimeView ? '#e74c3c' : '#3498db',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                padding: '8px 16px',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              {showLifetimeView ? 'Show Current Age View' : 'Show Lifetime Risk View'}
            </button>
          </div>
        </div>

        {/* Stats Panel */}
        <div style={{
          width: '300px',
          background: '#f8f9fa',
          borderRadius: '12px',
          padding: '24px',
          height: 'fit-content'
        }}>
          <div style={{ marginBottom: '24px' }}>
            <h3 style={{
              margin: '0 0 12px 0',
              fontSize: '18px',
              color: '#2c3e50'
            }}>
              Population Age: {Math.floor(currentAge)} years
            </h3>
            <div style={{
              width: '100%',
              height: '8px',
              background: '#e9ecef',
              borderRadius: '4px',
              overflow: 'hidden'
            }}>
              <div style={{
                width: `${progressPercentage}%`,
                height: '100%',
                background: `linear-gradient(90deg, #3498db 0%, #e74c3c ${progressPercentage}%)`,
                transition: 'width 0.2s ease'
              }} />
            </div>
          </div>

          <div style={{
            display: 'grid',
            gap: '16px'
          }}>
            <div>
              <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#e74c3c' }}>
                {afCases}
              </div>
              <div style={{ fontSize: '14px', color: '#6c757d' }}>
                AF Cases
              </div>
            </div>

            <div>
              <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#27ae60' }}>
                {riskPercentage}%
              </div>
              <div style={{ fontSize: '14px', color: '#6c757d' }}>
                Current Risk
              </div>
            </div>

            <div>
              <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#f39c12' }}>
                Target: {targetAfCases}
              </div>
              <div style={{ fontSize: '14px', color: '#6c757d' }}>
                1-in-3 Lifetime Risk
              </div>
            </div>

            {currentAge >= maxAge && (
              <div style={{
                background: afCases >= targetAfCases * 0.9 ? '#d4edda' : '#f8d7da',
                padding: '12px',
                borderRadius: '8px',
                border: afCases >= targetAfCases * 0.9 ? '1px solid #c3e6cb' : '1px solid #f5c6cb',
                marginTop: '12px'
              }}>
                <div style={{
                  fontSize: '14px',
                  color: afCases >= targetAfCases * 0.9 ? '#155724' : '#721c24',
                  fontWeight: '500'
                }}>
                  {afCases >= targetAfCases * 0.9 
                    ? '✓ Reached ~1-in-3 lifetime risk' 
                    : 'Result may vary - try running again for different outcome'}
                </div>
              </div>
            )}
          </div>

          {hoveredPerson && (
            <div style={{
              marginTop: '20px',
              padding: '12px',
              background: 'white',
              borderRadius: '8px',
              border: '1px solid #e9ecef'
            }}>
              <div style={{ fontSize: '14px', fontWeight: '500' }}>
                Person {hoveredPerson.id + 1}
              </div>
              <div style={{ fontSize: '12px', color: '#6c757d', marginTop: '4px' }}>
                {hoveredPerson.hasAF 
                  ? `Developed AF at age ${Math.floor(hoveredPerson.afOnsetAge)}`
                  : 'No AF currently'
                }
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Legend */}
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        gap: '24px',
        marginTop: '20px',
        fontSize: '14px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{
            width: '12px',
            height: '12px',
            borderRadius: '50%',
            background: '#3498db'
          }} />
          <span>Healthy</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <div style={{
            width: '12px',
            height: '12px',
            borderRadius: '50%',
            background: '#e74c3c'
          }} />
          <span>Atrial Fibrillation</span>
        </div>
      </div>
    </div>
  );
}