import React, { useState } from 'react';

export default function App() {
  const [addedStudies, setAddedStudies] = useState([]);
  const [hoveredStudy, setHoveredStudy] = useState(null);
  const [hoveredMeter, setHoveredMeter] = useState(false);
  const [showComparison, setShowComparison] = useState(false);

  const studies = [
    {
      id: 1,
      name: "Pilot Study",
      description: "Initial small-scale study to test feasibility and safety",
      participants: "20-50 participants",
      confidence: 25,
      color: "#FFE4B5"
    },
    {
      id: 2,
      name: "Phase II Trial",
      description: "Larger study to assess efficacy and optimize protocol",
      participants: "100-300 participants",
      confidence: 25,
      color: "#DDA0DD"
    },
    {
      id: 3,
      name: "Multi-center RCT",
      description: "Randomized controlled trial across multiple sites",
      participants: "500-1000 participants",
      confidence: 25,
      color: "#98FB98"
    },
    {
      id: 4,
      name: "Real-world Evidence",
      description: "Post-market surveillance and effectiveness study",
      participants: "1000+ participants",
      confidence: 25,
      color: "#87CEEB"
    }
  ];

  const totalConfidence = addedStudies.reduce((sum, studyId) => {
    const study = studies.find(s => s.id === studyId);
    return sum + (study ? study.confidence : 0);
  }, 0);

  const addStudy = (studyId) => {
    if (!addedStudies.includes(studyId)) {
      setAddedStudies([...addedStudies, studyId]);
    }
  };

  const resetStudies = () => {
    setAddedStudies([]);
  };

  const getConfidenceColor = (confidence) => {
    if (confidence < 25) return '#ff4444';
    if (confidence < 50) return '#ff8844';
    if (confidence < 75) return '#ffdd44';
    return '#44dd44';
  };

  const getConfidenceLabel = (confidence) => {
    if (confidence === 0) return 'No Evidence';
    if (confidence < 50) return 'Insufficient Evidence';
    if (confidence < 75) return 'Moderate Evidence';
    if (confidence < 100) return 'Strong Evidence';
    return 'Robust Evidence';
  };

  return (
    <div style={{
      width: '100%',
      height: '100vh',
      backgroundColor: '#ffffff',
      padding: '40px',
      fontFamily: 'Arial, sans-serif',
      display: 'flex',
      flexDirection: 'column',
      gap: '40px'
    }}>
      {/* Header */}
      <div style={{ textAlign: 'center' }}>
        <h1 style={{ 
          fontSize: '32px', 
          fontWeight: 'bold', 
          color: '#2c3e50',
          margin: '0 0 10px 0'
        }}>
          Clinical Validation Confidence
        </h1>
        <p style={{ 
          fontSize: '16px', 
          color: '#7f8c8d',
          margin: 0
        }}>
          Click studies below to build validation confidence
        </p>
      </div>

      {/* Toggle Comparison */}
      <div style={{ textAlign: 'center' }}>
        <button
          onClick={() => setShowComparison(!showComparison)}
          style={{
            padding: '12px 24px',
            fontSize: '16px',
            backgroundColor: showComparison ? '#3498db' : '#ecf0f1',
            color: showComparison ? '#ffffff' : '#2c3e50',
            border: '2px solid #3498db',
            borderRadius: '8px',
            cursor: 'pointer',
            fontWeight: 'bold'
          }}
        >
          {showComparison ? 'Hide Comparison' : 'Compare: Single vs Multi-Study Validation'}
        </button>
      </div>

      {/* Main Content */}
      <div style={{ 
        display: 'flex', 
        gap: '40px', 
        flex: 1,
        justifyContent: 'center',
        alignItems: 'flex-start'
      }}>
        
        {/* Studies Section */}
        <div style={{ flex: 1, maxWidth: '500px' }}>
          <h2 style={{ 
            fontSize: '24px', 
            color: '#2c3e50', 
            marginBottom: '20px',
            textAlign: 'center'
          }}>
            Clinical Studies
          </h2>
          
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: '1fr 1fr',
            gap: '20px'
          }}>
            {studies.map((study) => (
              <div
                key={study.id}
                onClick={() => addStudy(study.id)}
                onMouseEnter={() => setHoveredStudy(study.id)}
                onMouseLeave={() => setHoveredStudy(null)}
                style={{
                  padding: '20px',
                  backgroundColor: addedStudies.includes(study.id) ? study.color : '#f8f9fa',
                  border: `3px solid ${addedStudies.includes(study.id) ? '#2c3e50' : '#e9ecef'}`,
                  borderRadius: '12px',
                  cursor: addedStudies.includes(study.id) ? 'default' : 'pointer',
                  textAlign: 'center',
                  position: 'relative',
                  transition: 'all 0.3s ease',
                  opacity: addedStudies.includes(study.id) ? 1 : 0.7,
                  transform: hoveredStudy === study.id ? 'translateY(-2px)' : 'translateY(0)'
                }}
              >
                <div style={{
                  fontSize: '18px',
                  fontWeight: 'bold',
                  color: '#2c3e50',
                  marginBottom: '8px'
                }}>
                  {study.name}
                </div>
                
                {addedStudies.includes(study.id) && (
                  <div style={{
                    fontSize: '24px',
                    color: '#27ae60'
                  }}>
                    ✓
                  </div>
                )}

                {hoveredStudy === study.id && (
                  <div style={{
                    position: 'absolute',
                    top: '0',
                    left: '0',
                    transform: 'translate(-10px, -10px)',
                    backgroundColor: '#2c3e50',
                    color: '#ffffff',
                    padding: '12px',
                    borderRadius: '8px',
                    fontSize: '14px',
                    width: '250px',
                    zIndex: 10
                  }}>
                    <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>
                      {study.description}
                    </div>
                    <div>{study.participants}</div>
                    <div>Adds {study.confidence}% confidence</div>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div style={{ textAlign: 'center', marginTop: '20px' }}>
            <button
              onClick={resetStudies}
              style={{
                padding: '10px 20px',
                fontSize: '14px',
                backgroundColor: '#e74c3c',
                color: '#ffffff',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer'
              }}
            >
              Reset All
            </button>
          </div>
        </div>

        {/* Confidence Meter */}
        <div style={{ flex: 1, maxWidth: '400px' }}>
          <h2 style={{ 
            fontSize: '24px', 
            color: '#2c3e50', 
            marginBottom: '20px',
            textAlign: 'center'
          }}>
            Validation Confidence
          </h2>

          <div 
            style={{ 
              position: 'relative',
              marginBottom: '20px'
            }}
            onMouseEnter={() => setHoveredMeter(true)}
            onMouseLeave={() => setHoveredMeter(false)}
          >
            {/* Meter Background */}
            <div style={{
              width: '100%',
              height: '60px',
              backgroundColor: '#ecf0f1',
              borderRadius: '30px',
              border: '3px solid #bdc3c7',
              overflow: 'hidden',
              position: 'relative'
            }}>
              {/* Confidence Fill */}
              <div style={{
                width: `${totalConfidence}%`,
                height: '100%',
                backgroundColor: getConfidenceColor(totalConfidence),
                transition: 'all 0.5s ease',
                borderRadius: '27px'
              }} />

              {/* Percentage Text */}
              <div style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                fontSize: '24px',
                fontWeight: 'bold',
                color: totalConfidence > 50 ? '#ffffff' : '#2c3e50'
              }}>
                {totalConfidence}%
              </div>
            </div>

            {/* Confidence Label */}
            <div style={{
              textAlign: 'center',
              marginTop: '12px',
              fontSize: '18px',
              fontWeight: 'bold',
              color: getConfidenceColor(totalConfidence)
            }}>
              {getConfidenceLabel(totalConfidence)}
            </div>

            {hoveredMeter && (
              <div style={{
                position: 'absolute',
                top: '0',
                left: '0',
                transform: 'translate(-10px, -10px)',
                backgroundColor: '#2c3e50',
                color: '#ffffff',
                padding: '12px',
                borderRadius: '8px',
                fontSize: '14px',
                width: '300px',
                textAlign: 'center'
              }}>
                Regulatory approval typically requires 75-100% confidence from multiple study types
              </div>
            )}
          </div>

          {/* Study Progress */}
          <div style={{ marginTop: '30px' }}>
            <div style={{
              fontSize: '16px',
              color: '#7f8c8d',
              marginBottom: '10px',
              textAlign: 'center'
            }}>
              Studies Completed: {addedStudies.length}/4
            </div>
            
            <div style={{
              display: 'flex',
              gap: '8px',
              justifyContent: 'center'
            }}>
              {[1, 2, 3, 4].map(i => (
                <div
                  key={i}
                  style={{
                    width: '20px',
                    height: '20px',
                    borderRadius: '50%',
                    backgroundColor: addedStudies.length >= i ? '#27ae60' : '#ecf0f1',
                    border: '2px solid #bdc3c7'
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Comparison View */}
      {showComparison && (
        <div style={{
          backgroundColor: '#f8f9fa',
          padding: '30px',
          borderRadius: '12px',
          border: '2px solid #e9ecef'
        }}>
          <h3 style={{
            fontSize: '20px',
            color: '#2c3e50',
            marginBottom: '20px',
            textAlign: 'center'
          }}>
            Single Study vs. Multi-Study Validation
          </h3>
          
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '30px'
          }}>
            <div style={{
              padding: '20px',
              backgroundColor: '#ffe6e6',
              borderRadius: '8px',
              border: '2px solid #ff4444'
            }}>
              <h4 style={{ color: '#c0392b', fontSize: '18px', marginBottom: '15px' }}>
                Single Study Approach
              </h4>
              <ul style={{ color: '#2c3e50', fontSize: '14px', lineHeight: '1.6' }}>
                <li>Limited sample size and scope</li>
                <li>Potential for bias and confounding</li>
                <li>Single-site variability</li>
                <li>Insufficient for regulatory approval</li>
                <li>Risk of false positives/negatives</li>
              </ul>
            </div>
            
            <div style={{
              padding: '20px',
              backgroundColor: '#e6ffe6',
              borderRadius: '8px',
              border: '2px solid #44dd44'
            }}>
              <h4 style={{ color: '#27ae60', fontSize: '18px', marginBottom: '15px' }}>
                Four-Study Validation
              </h4>
              <ul style={{ color: '#2c3e50', fontSize: '14px', lineHeight: '1.6' }}>
                <li>Progressive evidence building</li>
                <li>Multiple populations and settings</li>
                <li>Reproducible results</li>
                <li>Meets regulatory standards</li>
                <li>Robust statistical power</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}