import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

const CellEvolution = () => {
  const [stage, setStage] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const stages = [
    { title: "Protocell", description: "Prokaryotic host cell without organelles" },
    { title: "Bacterial Uptake", description: "Aerobic bacteria are absorbed" },
    { title: "Mitochondria", description: "Bacteria evolve into mitochondria" },
    { title: "Eukaryotic Cell", description: "Absorption of cyanobacteria → chloroplasts" }
  ];

  useEffect(() => {
    let interval;
    if (isPlaying) {
      interval = setInterval(() => {
        setStage(prev => (prev + 1) % stages.length);
      }, 2500);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const CellComponent = ({ stage }) => {
    const cellSize = 400;
    const centerX = cellSize / 2;
    const centerY = cellSize / 2;

    return (
      <svg width={cellSize} height={cellSize} className="bg-white">
        {/* Cell Membrane */}
        <circle
          cx={centerX}
          cy={centerY}
          r={160}
          fill="rgba(59, 130, 246, 0.08)"
          stroke="#3b82f6"
          strokeWidth="2"
        />
        
        {/* Nucleus */}
        <circle
          cx={centerX}
          cy={centerY - 30}
          r={30}
          fill="#8b5cf6"
          opacity="0.8"
        />
        <text x={centerX} y={centerY - 25} textAnchor="middle" className="text-xs fill-white font-medium">
          Nucleus
        </text>

        {/* Free Bacteria (Stage 1) */}
        {stage === 1 && (
          <>
            <circle cx={120} cy={120} r={15} fill="#ef4444" opacity="0.9" />
            <circle cx={280} cy={140} r={15} fill="#ef4444" opacity="0.9" />
            <circle cx={140} cy={280} r={15} fill="#ef4444" opacity="0.9" />
            <text x={120} y={125} textAnchor="middle" className="text-xs fill-white font-medium">
              Bac
            </text>
            <text x={280} y={145} textAnchor="middle" className="text-xs fill-white font-medium">
              Bac
            </text>
          </>
        )}

        {/* Mitochondria (Stage 2+) */}
        {stage >= 2 && (
          <>
            <ellipse
              cx={centerX - 60}
              cy={centerY + 40}
              rx="20"
              ry="12"
              fill="#ef4444"
              opacity="0.9"
            />
            <ellipse
              cx={centerX + 70}
              cy={centerY + 30}
              rx="20"
              ry="12"
              fill="#ef4444"
              opacity="0.9"
            />
            <text x={centerX - 60} y={centerY + 45} textAnchor="middle" className="text-xs fill-white font-bold">
              Mito
            </text>
            <text x={centerX + 70} y={centerY + 35} textAnchor="middle" className="text-xs fill-white font-bold">
              Mito
            </text>
          </>
        )}

        {/* Free Cyanobacteria (Stage 3) */}
        {stage === 3 && (
          <>
            <circle cx={100} cy={100} r={18} fill="#10b981" opacity="0.9" />
            <circle cx={300} cy={120} r={18} fill="#10b981" opacity="0.9" />
            <text x={100} y={105} textAnchor="middle" className="text-xs fill-white font-medium">
              Cyano
            </text>
            <text x={300} y={125} textAnchor="middle" className="text-xs fill-white font-medium">
              Cyano
            </text>
          </>
        )}

        {/* Chloroplasts (Stage 3+) */}
        {stage >= 3 && (
          <>
            <ellipse
              cx={centerX - 80}
              cy={centerY - 60}
              rx="22"
              ry="15"
              fill="#10b981"
              opacity="0.9"
            />
            <ellipse
              cx={centerX + 60}
              cy={centerY - 70}
              rx="22"
              ry="15"
              fill="#10b981"
              opacity="0.9"
            />
            <text x={centerX - 80} y={centerY - 55} textAnchor="middle" className="text-xs fill-white font-bold">
              Chloro
            </text>
            <text x={centerX + 60} y={centerY - 65} textAnchor="middle" className="text-xs fill-white font-bold">
              Chloro
            </text>
          </>
        )}

        {/* Uptake Arrows */}
        {stage === 1 && (
          <>
            <path d="M 135 135 L 155 155" stroke="#666" strokeWidth="2" markerEnd="url(#arrowhead)" />
            <path d="M 265 155 L 245 175" stroke="#666" strokeWidth="2" markerEnd="url(#arrowhead)" />
          </>
        )}
        {stage === 3 && (
          <>
            <path d="M 118 118 L 138 138" stroke="#666" strokeWidth="2" markerEnd="url(#arrowhead)" />
            <path d="M 282 138 L 262 158" stroke="#666" strokeWidth="2" markerEnd="url(#arrowhead)" />
          </>
        )}

        <defs>
          <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
            <polygon points="0 0, 10 3.5, 0 7" fill="#666" />
          </marker>
        </defs>
      </svg>
    );
  };

  return (
    <div className="max-w-5xl mx-auto p-6 bg-white">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Evolution of the Cell</h1>
        <p className="text-gray-600">Endosymbiotic Theory</p>
      </div>

      <div className="grid grid-cols-2 gap-8">
        {/* Cell Visualization */}
        <div>
          <div className="bg-gray-50 p-4 rounded-lg border-2 border-gray-200">
            <CellComponent stage={stage} />
          </div>

          <div className="flex justify-center space-x-4 mt-4">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              {isPlaying ? <Pause size={20} /> : <Play size={20} />}
              <span>{isPlaying ? 'Pause' : 'Play'}</span>
            </button>
            <button
              onClick={() => { setStage(0); setIsPlaying(false); }}
              className="flex items-center space-x-2 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
            >
              <RotateCcw size={20} />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Stage Navigation */}
        <div className="space-y-3">
          <h3 className="text-lg font-semibold mb-4 text-gray-800">Evolutionary Stages</h3>
          
          {stages.map((stageInfo, index) => (
            <div
              key={index}
              className={`p-3 rounded-lg cursor-pointer transition-all ${
                index === stage 
                  ? 'bg-blue-100 border-l-4 border-blue-500 shadow-sm' 
                  : 'bg-gray-50 hover:bg-gray-100'
              }`}
              onClick={() => setStage(index)}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-white text-sm font-semibold ${
                  index === stage ? 'bg-blue-500' : 'bg-gray-400'
                }`}>
                  {index + 1}
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-gray-800 text-sm">{stageInfo.title}</div>
                  <div className="text-xs text-gray-600 mt-1">{stageInfo.description}</div>
                </div>
              </div>
            </div>
          ))}

          {/* Legend */}
          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
            <h4 className="font-semibold mb-2 text-gray-800 text-sm">Organelles</h4>
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-2 bg-red-500 rounded"></div>
                <span className="text-xs">Mitochondria (Mito)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-2 bg-green-500 rounded"></div>
                <span className="text-xs">Chloroplasts (Chloro)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                <span className="text-xs">Nucleus</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CellEvolution;
