import React, { useState } from 'react';
import { Info, Zap, Shield, Home, Cpu, Package } from 'lucide-react';

const EukaryoteCellExplorer = () => {
  const [selectedOrganelle, setSelectedOrganelle] = useState(null);
  const [cellType, setCellType] = useState('eukaryote');

  const organelles = {
    nucleus: {
      name: 'Nucleus',
      description: 'Control center of the cell containing DNA',
      color: '#8B5CF6',
      icon: <Cpu className="w-4 h-4" />,
      position: { x: 50, y: 50 }
    },
    mitochondria: {
      name: 'Mitochondrion',
      description: 'Powerhouse of the cell – ATP production',
      color: '#EF4444',
      icon: <Zap className="w-4 h-4" />,
      position: { x: 25, y: 70 }
    },
    er: {
      name: 'Endoplasmic Reticulum',
      description: 'Protein and lipid synthesis',
      color: '#10B981',
      icon: <Package className="w-4 h-4" />,
      position: { x: 75, y: 30 }
    },
    golgi: {
      name: 'Golgi Apparatus',
      description: 'Packaging and transport of proteins',
      color: '#F59E0B',
      icon: <Package className="w-4 h-4" />,
      position: { x: 75, y: 70 }
    },
    membrane: {
      name: 'Cell Membrane',
      description: 'Protects the cell and regulates exchange with the environment',
      color: '#6366F1',
      icon: <Shield className="w-4 h-4" />,
      position: { x: 10, y: 10 }
    }
  };

  const prokaryoteFeatures = {
    nucleoid: {
      name: 'Nucleoid',
      description: 'DNA region without a membrane',
      color: '#8B5CF6',
      position: { x: 45, y: 45 }
    },
    membrane: {
      name: 'Cell Membrane',
      description: 'Outer boundary',
      color: '#6366F1',
      position: { x: 10, y: 10 }
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl">
      <div className="mb-6 text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">Cell Types Comparison</h1>
        
        <div className="flex justify-center gap-4 mb-6">
          <button
            onClick={() => setCellType('eukaryote')}
            className={`px-6 py-3 rounded-lg font-semibold transition-all ${
              cellType === 'eukaryote' 
                ? 'bg-purple-600 text-white shadow-lg' 
                : 'bg-white text-purple-600 border-2 border-purple-600 hover:bg-purple-50'
            }`}
          >
            <Home className="w-5 h-5 inline mr-2" />
            Eukaryotic Cell
          </button>
          <button
            onClick={() => setCellType('prokaryote')}
            className={`px-6 py-3 rounded-lg font-semibold transition-all ${
              cellType === 'prokaryote' 
                ? 'bg-green-600 text-white shadow-lg' 
                : 'bg-white text-green-600 border-2 border-green-600 hover:bg-green-50'
            }`}
          >
            <Shield className="w-5 h-5 inline mr-2" />
            Prokaryotic Cell
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Cell Visualization */}
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <h2 className="text-xl font-bold mb-4 text-center">
            {cellType === 'eukaryote' ? 'Eukaryotic Cell' : 'Prokaryotic Cell'}
          </h2>
          
          <div className="relative w-80 h-80 mx-auto bg-transparent overflow-visible">
            {cellType === 'eukaryote' ? (
              <>
                {/* Cell membrane - outer clickable ring */}
                <div 
                  className="absolute inset-0 border-8 border-blue-400 rounded-full bg-gradient-to-br from-cyan-50 to-blue-100 cursor-pointer hover:border-blue-500 transition-colors opacity-90"
                  onClick={() => setSelectedOrganelle('membrane')}
                  title="Click for cell membrane info"
                >
                  
                  {/* Cell interior */}
                  <div className="absolute inset-8 rounded-full bg-gradient-to-br from-cyan-25 to-blue-75">
                  
                    {/* Nucleus - more realistic shape */}
                    <div 
                      className="absolute w-20 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full border-3 border-purple-800 cursor-pointer transform hover:scale-105 transition-all shadow-xl z-20"
                      style={{ 
                        left: `${organelles.nucleus.position.x}%`, 
                        top: `${organelles.nucleus.position.y}%`,
                        transform: 'translate(-50%, -50%)',
                        boxShadow: 'inset 0 2px 4px rgba(0,0,0,0.3), 0 4px 8px rgba(0,0,0,0.2)'
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedOrganelle('nucleus');
                      }}
                    >
                      <div className="w-full h-full flex items-center justify-center text-white relative">
                        <Cpu className="w-6 h-6" />
                        {/* Nucleolus */}
                        <div className="absolute top-1 right-1 w-2 h-2 bg-purple-900 rounded-full"></div>
                      </div>
                      <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 text-xs font-bold text-purple-700 bg-white px-2 py-1 rounded shadow whitespace-nowrap">
                        Nucleus
                      </div>
                    </div>

                    {/* Mitochondria - bean-shaped */}
                    <div 
                      className="absolute w-14 h-8 bg-gradient-to-r from-red-400 to-red-600 cursor-pointer transform hover:scale-110 transition-all shadow-lg z-10"
                      style={{ 
                        left: `${organelles.mitochondria.position.x}%`, 
                        top: `${organelles.mitochondria.position.y}%`,
                        transform: 'translate(-50%, -50%) rotate(-20deg)',
                        borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%',
                        boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.3), 0 2px 6px rgba(0,0,0,0.2)'
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedOrganelle('mitochondria');
                      }}
                    >
                      <div className="w-full h-full flex items-center justify-center text-white relative">
                        <Zap className="w-4 h-4" />
                        {/* Cristae (inner structures) */}
                        <div className="absolute inset-1 border border-red-300 rounded-full opacity-50"></div>
                      </div>
                      <div className="absolute -bottom-8 left-1/2 text-xs font-bold text-red-700 bg-white px-2 py-1 rounded shadow whitespace-nowrap" style={{ transform: 'translate(-50%, 0) rotate(20deg)' }}>
                        Mitochondrion
                      </div>
                    </div>

                    {/* Second mitochondrion */}
                    <div 
                      className="absolute w-12 h-6 bg-gradient-to-r from-red-400 to-red-600 cursor-pointer transform hover:scale-110 transition-all shadow-lg z-10"
                      style={{ 
                        left: '30%', 
                        top: '25%',
                        transform: 'translate(-50%, -50%) rotate(45deg)',
                        borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%',
                        boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.3), 0 2px 6px rgba(0,0,0,0.2)'
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedOrganelle('mitochondria');
                      }}
                    >
                      <div className="w-full h-full flex items-center justify-center text-white">
                        <Zap className="w-3 h-3" />
                      </div>
                    </div>

                    {/* ER - folded structure */}
                    <div 
                      className="absolute w-16 h-10 bg-gradient-to-br from-green-400 to-green-600 cursor-pointer transform hover:scale-105 transition-all shadow-lg z-10"
                      style={{ 
                        left: `${organelles.er.position.x}%`, 
                        top: `${organelles.er.position.y}%`,
                        transform: 'translate(-50%, -50%)',
                        borderRadius: '8px 20px 8px 20px',
                        boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.2), 0 2px 4px rgba(0,0,0,0.1)'
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedOrganelle('er');
                      }}
                    >
                      <div className="w-full h-full flex items-center justify-center text-white">
                        <Package className="w-4 h-4" />
                      </div>
                      {/* Ribosomes */}
                      <div className="absolute -top-1 left-1 w-1.5 h-1.5 bg-green-800 rounded-full"></div>
                      <div className="absolute -bottom-1 right-2 w-1.5 h-1.5 bg-green-800 rounded-full"></div>
                      <div className="absolute top-1 -right-1 w-1.5 h-1.5 bg-green-800 rounded-full"></div>
                      <div className="absolute -bottom-8 left-1/2 text-xs font-bold text-green-700 bg-white px-2 py-1 rounded shadow whitespace-nowrap">
                        ER
                      </div>
                    </div>

                    {/* Golgi - stacked structure */}
                    <div 
                      className="absolute w-12 h-14 cursor-pointer transform hover:scale-105 transition-all z-10"
                      style={{ 
                        left: `${organelles.golgi.position.x}%`, 
                        top: `${organelles.golgi.position.y}%`,
                        transform: 'translate(-50%, -50%)'
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedOrganelle('golgi');
                      }}
                    >
                      {/* Stacked cisternae */}
                      <div className="absolute w-full h-2.5 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-lg shadow-md" style={{top: '0%'}}></div>
                      <div className="absolute w-full h-2.5 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-lg shadow-md" style={{top: '30%'}}></div>
                      <div className="absolute w-full h-2.5 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-lg shadow-md" style={{top: '60%'}}></div>
                      <div className="w-full h-full flex items-center justify-center text-white">
                        <Package className="w-3 h-3 relative z-10" />
                      </div>
                      <div className="absolute -bottom-8 left-1/2 text-xs font-bold text-yellow-700 bg-white px-2 py-1 rounded shadow whitespace-nowrap">
                        Golgi Apparatus
                      </div>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* Prokaryotic Cell - simpler structure */}
                <div 
                  className="absolute inset-0 border-8 border-green-400 rounded-full bg-gradient-to-br from-green-50 to-green-100 cursor-pointer hover:border-green-500 transition-colors opacity-90"
                  onClick={() => setSelectedOrganelle('prokaryote_membrane')}
                  title="Click for cell membrane info"
                >
                  
                  <div className="absolute inset-8 rounded-full bg-gradient-to-br from-green-25 to-green-75">
                    {/* Nucleoid - no membrane, irregular shape */}
                    <div 
                      className="absolute w-16 h-12 bg-gradient-to-br from-purple-300 to-purple-500 cursor-pointer transform hover:scale-105 transition-all shadow-md border-2 border-dashed border-purple-600 z-10"
                      style={{ 
                        left: `${prokaryoteFeatures.nucleoid.position.x}%`, 
                        top: `${prokaryoteFeatures.nucleoid.position.y}%`,
                        transform: 'translate(-50%, -50%)',
                        borderRadius: '60% 40% 30% 70% / 60% 30% 70% 40%',
                        opacity: '0.8'
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedOrganelle('nucleoid');
                      }}
                    >
                      <div className="w-full h-full flex items-center justify-center text-white">
                        <Cpu className="w-4 h-4" />
                      </div>
                      <div className="absolute -bottom-8 left-1/2 text-xs font-bold text-purple-700 bg-white px-2 py-1 rounded shadow whitespace-nowrap">
                        Nucleoid (DNA)
                      </div>
                      {/* Indicating DNA strands */}
                      <div className="absolute inset-1 border border-purple-200 opacity-60" style={{borderRadius: '50% 40% 30% 60% / 50% 30% 60% 40%'}}></div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Info panel */}
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Info className="w-6 h-6 mr-2 text-blue-600" />
            {selectedOrganelle ? 'Organelle Info' : 'Key Features'}
          </h2>
          
          {selectedOrganelle ? (
            <div className="space-y-4">
              {cellType === 'eukaryote' && organelles[selectedOrganelle] && (
                <>
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center text-white"
                      style={{ backgroundColor: organelles[selectedOrganelle].color }}
                    >
                      {organelles[selectedOrganelle].icon}
                    </div>
                    <h3 className="text-lg font-semibold">{organelles[selectedOrganelle].name}</h3>
                  </div>
                  <p className="text-gray-700">{organelles[selectedOrganelle].description}</p>
                </>
              )}
              
              {cellType === 'prokaryote' && selectedOrganelle === 'nucleoid' && (
                <>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-400 flex items-center justify-center text-white">
                      <Cpu className="w-4 h-4" />
                    </div>
                    <h3 className="text-lg font-semibold">Nucleoid</h3>
                  </div>
                  <p className="text-gray-700">DNA region without surrounding membrane – main difference to eukaryotes!</p>
                </>
              )}
              
              {cellType === 'prokaryote' && selectedOrganelle === 'prokaryote_membrane' && (
                <>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-green-400 flex items-center justify-center text-white">
                      <Shield className="w-4 h-4" />
                    </div>
                    <h3 className="text-lg font-semibold">Cell Membrane</h3>
                  </div>
                  <p className="text-gray-700">Outer boundary of the prokaryotic cell – often reinforced with a cell wall</p>
                </>
              )}
              
              <button 
                onClick={() => setSelectedOrganelle(null)}
                className="mt-4 px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Back to Overview
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {cellType === 'eukaryote' ? (
                <>
                  <div className="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-500">
                    <h3 className="font-semibold text-purple-800 mb-2">🧬 Nucleus Present</h3>
                    <p className="text-sm text-purple-700">DNA enclosed by nuclear membrane</p>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
                    <h3 className="font-semibold text-blue-800 mb-2">🏭 Membrane-bound Organelles</h3>
                    <p className="text-sm text-blue-700">Mitochondria, ER, Golgi apparatus</p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg border-l-4 border-green-500">
                    <h3 className="font-semibold text-green-800 mb-2">🔬 Complex Structure</h3>
                    <p className="text-sm text-green-700">Specialized compartments for different functions</p>
                  </div>
                </>
              ) : (
                <>
                  <div className="bg-red-50 p-4 rounded-lg border-l-4 border-red-500">
                    <h3 className="font-semibold text-red-800 mb-2">❌ No True Nucleus</h3>
                    <p className="text-sm text-red-700">DNA free in cytoplasm (nucleoid)</p>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-lg border-l-4 border-orange-500">
                    <h3 className="font-semibold text-orange-800 mb-2">🚫 No Organelles</h3>
                    <p className="text-sm text-orange-700">No membrane-bound structures</p>
                  </div>
                  <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-500">
                    <h3 className="font-semibold text-yellow-800 mb-2">⚡ Simple Structure</h3>
                    <p className="text-sm text-yellow-700">Bacteria and Archaea</p>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="mt-6 text-center text-sm text-gray-600">
        💡 Click on the structures in the cell to learn more!
      </div>
    </div>
  );
};

export default EukaryoteCellExplorer;
