import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, ChevronRight } from 'lucide-react';

const GeneRegulationDemo = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [selectedCell, setSelectedCell] = useState(null);

  // Cell differentiation paths
  const cellTypes = [
    { id: 'stem', name: 'Stem Cell', color: '#8B5CF6', genes: ['Oct4', 'Sox2', 'Nanog'] },
    { id: 'neural', name: 'Neuron', color: '#3B82F6', genes: ['NeuroD', 'Pax6', 'Ngn2'] },
    { id: 'muscle', name: 'Muscle Cell', color: '#EF4444', genes: ['MyoD', 'Myf5', 'MRF4'] },
    { id: 'liver', name: 'Liver Cell', color: '#10B981', genes: ['HNF4α', 'C/EBPα', 'FOXA2'] }
  ];

  const regulationSteps = [
    { title: 'Chromatin Structure', description: 'DNA packaging regulates gene accessibility' },
    { title: 'Transcription Factors', description: 'Proteins bind to promoter regions' },
    { title: 'Epigenetic Modification', description: 'Methylation and acetylation' },
    { title: 'Gene Expression', description: 'Activation of specific gene programs' }
  ];

  useEffect(() => {
    if (isAnimating) {
      const timer = setTimeout(() => {
        setActiveStep((prev) => (prev + 1) % regulationSteps.length);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [activeStep, isAnimating]);

  const ChromatinStructure = ({ isActive }) => (
    <div className={`transition-all duration-1000 ${isActive ? 'scale-110 opacity-100' : 'opacity-60'}`}>
      <div className="relative">
        {/* DNA Helix */}
        <svg width="200" height="80" className="mx-auto">
          <path
            d="M20 40 Q60 20 100 40 T180 40"
            stroke="#4338CA"
            strokeWidth="4"
            fill="none"
            className={isActive ? 'animate-pulse' : ''}
          />
          <path
            d="M20 40 Q60 60 100 40 T180 40"
            stroke="#7C3AED"
            strokeWidth="4"
            fill="none"
            className={isActive ? 'animate-pulse' : ''}
          />
        </svg>
        {/* Histones */}
        <div className="flex justify-center space-x-4 mt-2">
          {[1, 2, 3].map(i => (
            <div
              key={i}
              className={`w-6 h-6 rounded-full bg-amber-400 transition-all duration-500 ${
                isActive ? 'animate-bounce' : ''
              }`}
              style={{ animationDelay: `${i * 200}ms` }}
            />
          ))}
        </div>
      </div>
      <p className="text-center text-sm mt-2 text-gray-600">Chromatin</p>
    </div>
  );

  const TranscriptionFactor = ({ isActive }) => (
    <div className={`transition-all duration-1000 ${isActive ? 'scale-110 opacity-100' : 'opacity-60'}`}>
      <div className="relative flex flex-col items-center">
        {/* Promoter */}
        <div className="w-24 h-4 bg-gray-300 rounded mb-4">
          <div className="w-6 h-4 bg-blue-500 rounded-l"></div>
        </div>
        {/* Transcription Factor */}
        <div className={`w-8 h-8 bg-red-500 rounded-full transition-all duration-1000 ${
          isActive ? 'transform -translate-y-4' : ''
        }`}>
          <div className="w-full h-full rounded-full border-2 border-white flex items-center justify-center">
            <div className="w-2 h-2 bg-white rounded-full"></div>
          </div>
        </div>
      </div>
      <p className="text-center text-sm mt-2 text-gray-600">Transcription Factor</p>
    </div>
  );

  const EpigeneticModification = ({ isActive }) => (
    <div className={`transition-all duration-1000 ${isActive ? 'scale-110 opacity-100' : 'opacity-60'}`}>
      <div className="relative">
        <svg width="120" height="80" className="mx-auto">
          {/* DNA Strand */}
          <line x1="20" y1="40" x2="100" y2="40" stroke="#4338CA" strokeWidth="6" />
          {/* Methyl groups */}
          {[30, 50, 70, 90].map((x, i) => (
            <circle
              key={i}
              cx={x}
              cy="25"
              r="4"
              fill="#F59E0B"
              className={isActive ? 'animate-ping' : ''}
              style={{ animationDelay: `${i * 300}ms` }}
            />
          ))}
          {/* Acetyl groups */}
          {[35, 55, 75].map((x, i) => (
            <rect
              key={i}
              x={x-2}
              y="50"
              width="4"
              height="4"
              fill="#10B981"
              className={isActive ? 'animate-pulse' : ''}
              style={{ animationDelay: `${i * 400}ms` }}
            />
          ))}
        </svg>
      </div>
      <p className="text-center text-sm mt-2 text-gray-600">Epigenetics</p>
    </div>
  );

  const GeneExpression = ({ isActive }) => (
    <div className={`transition-all duration-1000 ${isActive ? 'scale-110 opacity-100' : 'opacity-60'}`}>
      <div className="relative flex flex-col items-center">
        {/* Gene */}
        <div className="w-16 h-4 bg-blue-600 rounded mb-2"></div>
        {/* mRNA */}
        {isActive && (
          <div className="animate-pulse">
            {[1, 2, 3].map(i => (
              <div
                key={i}
                className="w-2 h-8 bg-green-500 rounded mx-1 inline-block animate-bounce"
                style={{ animationDelay: `${i * 200}ms` }}
              />
            ))}
          </div>
        )}
        {/* Protein */}
        <div className={`mt-2 w-12 h-6 bg-purple-500 rounded-full transition-all duration-1000 ${
          isActive ? 'animate-pulse' : ''
        }`}></div>
      </div>
      <p className="text-center text-sm mt-2 text-gray-600">Gene Expression</p>
    </div>
  );

  const CellDifferentiation = () => (
    <div className="mt-8 p-6 bg-gray-50 rounded-xl">
      <h3 className="text-lg font-semibold mb-4 text-center">Cell Differentiation</h3>
      <div className="flex justify-center items-center space-x-4">
        {/* Stem Cell */}
        <div
          className={`w-16 h-16 rounded-full cursor-pointer transition-all duration-300 ${
            selectedCell === 'stem' ? 'ring-4 ring-purple-300 scale-110' : ''
          }`}
          style={{ backgroundColor: cellTypes[0].color }}
          onClick={() => setSelectedCell(selectedCell === 'stem' ? null : 'stem')}
        >
          <div className="w-full h-full rounded-full border-4 border-white flex items-center justify-center">
            <div className="w-4 h-4 bg-white rounded-full"></div>
          </div>
        </div>

        {/* Arrows to differentiated cells */}
        <div className="flex flex-col space-y-8">
          {cellTypes.slice(1).map((cell) => (
            <div key={cell.id} className="flex items-center space-x-2">
              <ChevronRight className="w-4 h-4 text-gray-400" />
              <div
                className={`w-12 h-12 rounded-full cursor-pointer transition-all duration-300 ${
                  selectedCell === cell.id ? 'ring-4 ring-opacity-50 scale-110' : ''
                }`}
                style={{ 
                  backgroundColor: cell.color,
                  ringColor: cell.color + '80'
                }}
                onClick={() => setSelectedCell(selectedCell === cell.id ? null : cell.id)}
              >
                <div className="w-full h-full rounded-full border-3 border-white"></div>
              </div>
              <span className="text-sm font-medium">{cell.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Gene expression for selected cell */}
      {selectedCell && (
        <div className="mt-6 p-4 bg-white rounded-lg border-2 border-gray-200">
          <h4 className="font-semibold mb-2">
            Active genes in {cellTypes.find(c => c.id === selectedCell)?.name}:
          </h4>
          <div className="flex space-x-2">
            {cellTypes.find(c => c.id === selectedCell)?.genes.map((gene, index) => (
              <div
                key={gene}
                className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm animate-pulse"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                {gene}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto p-6 bg-white">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          Gene Regulation in Eukaryotes
        </h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Interactive visualization of the molecular mechanisms that control cell differentiation and development
        </p>
      </div>

      {/* Control Buttons */}
      <div className="flex justify-center space-x-4 mb-8">
        <button
          onClick={() => setIsAnimating(!isAnimating)}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          {isAnimating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          <span>{isAnimating ? 'Pause' : 'Start'}</span>
        </button>
        <button
          onClick={() => {
            setActiveStep(0);
            setIsAnimating(false);
          }}
          className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Reset</span>
        </button>
      </div>

      {/* Regulation Mechanisms */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="text-center">
          <ChromatinStructure isActive={activeStep === 0} />
        </div>
        <div className="text-center">
          <TranscriptionFactor isActive={activeStep === 1} />
        </div>
        <div className="text-center">
          <EpigeneticModification isActive={activeStep === 2} />
        </div>
        <div className="text-center">
          <GeneExpression isActive={activeStep === 3} />
        </div>
      </div>

      {/* Step Display */}
      <div className="flex justify-center mb-8">
        <div className="bg-gray-100 rounded-lg p-4 max-w-md text-center">
          <h3 className="font-semibold text-lg mb-2">
            {regulationSteps[activeStep].title}
          </h3>
          <p className="text-gray-600">
            {regulationSteps[activeStep].description}
          </p>
        </div>
      </div>

      {/* Step Navigation */}
      <div className="flex justify-center space-x-2 mb-8">
        {regulationSteps.map((_, index) => (
          <button
            key={index}
            onClick={() => setActiveStep(index)}
            className={`w-3 h-3 rounded-full transition-colors ${
              activeStep === index ? 'bg-blue-600' : 'bg-gray-300'
            }`}
          />
        ))}
      </div>

      {/* Cell Differentiation */}
      <CellDifferentiation />

      {/* Additional Information */}
      <div className="mt-8 p-6 bg-blue-50 rounded-xl">
        <h3 className="text-lg font-semibold mb-3">Core Concepts:</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <strong>Gene Regulation:</strong> Control of gene expression through various molecular mechanisms
          </div>
          <div>
            <strong>Cell Differentiation:</strong> Process by which cells develop specialized functions
          </div>
          <div>
            <strong>Epigenetics:</strong> Heritable changes without altering DNA sequence
          </div>
          <div>
            <strong>Transcription Factors:</strong> Proteins that regulate gene expression
          </div>
        </div>
      </div>
    </div>
  );
};

export default GeneRegulationDemo;
