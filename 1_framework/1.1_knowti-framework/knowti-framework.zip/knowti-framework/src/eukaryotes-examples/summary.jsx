import { useState } from "react";
import { 
  CircleDot, 
  Zap, 
  Dna, 
  Microscope, 
  Factory, 
  Cpu, 
  TreePine, 
  Leaf, 
  Settings, 
  FileText, 
  Cog, 
  Target, 
  Users, 
  RotateCcw,
  Layers,
  Network,
  Atom,
  Building,
  Gauge
} from "lucide-react";

export default function EukaryoticCellDiagram() {
  const [activeCategory, setActiveCategory] = useState(1);
  const [hoveredKeyword, setHoveredKeyword] = useState(null);
  const [highlightedKeyword, setHighlightedKeyword] = useState(null);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });
  
  const getKeywordIcon = (keywordName) => {
    const iconMap = {
      "Eukaryotes": <Microscope size={16} />,
      "Nucleus": <CircleDot size={16} />,
      "Humans, Animals, Plants, Fungi, Algae": <Users size={16} />,
      "Prokaryotes": <Atom size={16} />,
      "Organelles & Compartmentalization": <Building size={16} />,
      "LECA (Last Eukaryotic Common Ancestor)": <TreePine size={16} />,
      "Mitochondria": <Zap size={16} />,
      "Endosymbiotic Theory": <Network size={16} />,
      "Archaea": <Microscope size={16} />,
      "Animal Cell, Plant Cell": <Layers size={16} />,
      "Diameter of Eucytes": <Gauge size={16} />,
      "Compartmentalization": <Building size={16} />,
      "Ribosomes": <Factory size={16} />,
      "Endoplasmic Reticulum & Cytoplasm": <Cpu size={16} />,
      "Golgi Apparatus": <Settings size={16} />,
      "Plastids": <Leaf size={16} />,
      "Chloroplasts": <Leaf size={16} />,
      "Gene Regulation": <Cog size={16} />,
      "Transcription": <FileText size={16} />,
      "Translation": <Factory size={16} />,
      "RNA Processing": <Settings size={16} />,
      "Environmental Adaptation": <Target size={16} />,
      "Gene Activation": <Cog size={16} />,
      "Cell Type Development": <Users size={16} />,
      "Reminder: Nucleus & RNA Processing": <RotateCcw size={16} />
    };
    return iconMap[keywordName] || <CircleDot size={16} />;
  };
  
  const categories = [
    {
      id: 1,
      title: "Fundamentals",
      description: "Introduction to eukaryotes and distinction from prokaryotes",
      color: "#4299e1",
      keywords: [
        { name: "Eukaryotes", description: "Organisms with membrane-bound nucleus and organelles", timecode: "00:00:00–00:00:10" },
        { name: "Nucleus", description: "Central control center containing DNA", timecode: "00:00:10–00:00:16" },
        { name: "Humans, Animals, Plants, Fungi, Algae", description: "Diverse examples of eukaryotic organisms", timecode: "00:00:16–00:00:22" },
        { name: "Prokaryotes", description: "Simple cells lacking membrane-bound nucleus", timecode: "00:00:22–00:00:26" },
        { name: "Organelles & Compartmentalization", description: "Specialized structures creating distinct cellular regions", timecode: "00:00:41–00:00:47" }
      ]
    },
    {
      id: 2,
      title: "Evolutionary Origin",
      description: "Evolution and emergence of complex eukaryotic cells",
      color: "#48bb78",
      keywords: [
        { name: "LECA (Last Eukaryotic Common Ancestor)", description: "Common ancestor of all modern eukaryotes", timecode: "00:01:06–00:01:12" },
        { name: "Mitochondria", description: "Powerhouses evolved from ancient bacteria", timecode: "00:01:12–00:01:18" },
        { name: "Endosymbiotic Theory", description: "Theory explaining organelle evolution through bacterial engulfment", timecode: "00:01:18–00:01:22" },
        { name: "Archaea", description: "Ancient microbes potentially involved in eukaryotic evolution", timecode: "00:01:28–00:01:33" },
        { name: "Animal Cell, Plant Cell", description: "Two major evolutionary branches of eukaryotes", timecode: "00:01:51–00:01:57" },
        { name: "Diameter of Eucytes", description: "Typically 10–30 micrometers, up to 100 μm", timecode: "00:01:57–00:02:02" }
      ]
    },
    {
      id: 3,
      title: "Cellular Architecture",
      description: "Structural organization and key organelles",
      color: "#ed8936",
      keywords: [
        { name: "Compartmentalization", description: "Organized division of cellular functions into distinct spaces", timecode: "00:02:08–00:02:14" },
        { name: "Organelles", description: "Membrane-bound structures with specialized functions", timecode: "00:02:19–00:02:25" },
        { name: "Nucleus", description: "Command center housing chromosomal DNA", timecode: "00:02:42–00:02:47" },
        { name: "Ribosomes", description: "Molecular machines for protein synthesis", timecode: "00:02:53–00:02:59" },
        { name: "Endoplasmic Reticulum & Cytoplasm", description: "Protein factory network and gel-like cellular medium", timecode: "00:02:59–00:03:05" }
      ]
    },
    {
      id: 4,
      title: "Cellular Functions",
      description: "Metabolic processes and energy production systems",
      color: "#9f7aea",
      keywords: [
        { name: "Golgi Apparatus", description: "Cellular post office for protein modification and shipping", timecode: "00:03:05–00:03:10" },
        { name: "Mitochondria", description: "Cellular power plants producing ATP energy", timecode: "00:03:10–00:03:16" },
        { name: "Plastids", description: "Plant-specific organelles including chloroplasts", timecode: "00:03:16–00:03:25" },
        { name: "Chloroplasts", description: "Solar panels converting sunlight to chemical energy", timecode: "00:03:25–00:03:33" },
        { name: "Gene Regulation", description: "Sophisticated control of gene expression", timecode: "00:03:33–00:03:39" },
        { name: "Transcription", description: "DNA information copied to messenger RNA", timecode: "00:03:52–00:03:57" }
      ]
    },
    {
      id: 5,
      title: "Gene Expression Control",
      description: "Complex regulatory mechanisms and cellular differentiation",
      color: "#f56565",
      keywords: [
        { name: "Translation", description: "RNA instructions converted to functional proteins", timecode: "00:04:04–00:04:09" },
        { name: "RNA Processing", description: "mRNA modification and quality control", timecode: "00:04:16–00:04:23" },
        { name: "Environmental Adaptation", description: "Dynamic response to changing conditions", timecode: "00:04:36–00:04:45" },
        { name: "Gene Activation", description: "Precise control of which genes are active", timecode: "00:04:56–00:05:02" },
        { name: "Cell Type Development", description: "Specialization into muscle, nerve, and other cell types", timecode: "00:05:02–00:05:06" },
        { name: "Reminder: Nucleus & RNA Processing", description: "Key distinguishing features of eukaryotic cells", timecode: "00:05:11–00:05:18" }
      ]
    }
  ];

  const category = categories.find(c => c.id === activeCategory);

  const handleMouseEnter = (keyword, event) => {
    const rect = event.target.getBoundingClientRect();
    setTooltipPosition({
      x: rect.left + rect.width / 2,
      y: rect.top - 10
    });
    setHoveredKeyword(keyword);
    setHighlightedKeyword(keyword.name);
  };

  const handleMouseLeave = () => {
    setHoveredKeyword(null);
    setHighlightedKeyword(null);
  };

  return (
    <div className="w-full h-screen max-h-screen p-4 bg-gray-50" style={{ width: '1200px', height: '700px', maxWidth: '1200px', maxHeight: '700px' }}>
      <div className="flex justify-center mb-4">
        <div className="flex space-x-2 overflow-x-auto p-2">
          {categories.map(cat => (
            <button
              key={cat.id}
              className="px-4 py-2 rounded-full font-medium transition-colors duration-200 whitespace-nowrap"
              style={{ 
                backgroundColor: activeCategory === cat.id ? cat.color : "white",
                color: activeCategory === cat.id ? "white" : cat.color,
                borderWidth: 2,
                borderColor: cat.color
              }}
              onClick={() => setActiveCategory(cat.id)}
            >
              {cat.title}
            </button>
          ))}
        </div>
      </div>
      
      <div className="flex" style={{ height: 'calc(100% - 80px)' }}>
        <div className="w-1/2 p-4 bg-white rounded-lg shadow mr-4 overflow-y-auto">
          <div className="text-xl font-bold" style={{ color: category.color }}>{category.title}</div>
          <div className="text-gray-700 mb-4">{category.description}</div>
          <div className="grid grid-cols-1 gap-2">
            {category.keywords.map((keyword, index) => (
              <div 
                key={index}
                className="p-3 rounded cursor-pointer transition-colors duration-200 border relative"
                style={{ 
                  borderColor: category.color, 
                  backgroundColor: highlightedKeyword === keyword.name ? `${category.color}40` : `${category.color}20`
                }}
                onMouseEnter={(e) => handleMouseEnter(keyword, e)}
                onMouseLeave={handleMouseLeave}
              >
                <div className="flex items-center gap-2 font-semibold">
                  {getKeywordIcon(keyword.name)}
                  {keyword.name}
                </div>
                <div className="text-xs text-gray-500 mt-1">{keyword.timecode}</div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="w-1/2 p-4 bg-white rounded-lg shadow overflow-y-auto">
          <div className="text-xl font-bold mb-4">Eukaryotic Cell</div>
          <div className="flex justify-center">
            <svg width="400" height="400" viewBox="0 0 320 320">
              {/* Cell membrane */}
              <ellipse cx="160" cy="160" rx="150" ry="140" fill="#f7fafc" stroke="#2d3748" strokeWidth="2" />
              <text x="177" y="50" fontSize="10" fill="#2d3748">Cell Membrane</text>
              
              {/* Nucleus */}
              <circle 
                cx="160" 
                cy="160" 
                r="50" 
                fill={activeCategory === 1 || (activeCategory === 3 && (highlightedKeyword === "Nucleus" || hoveredKeyword?.name === "Nucleus")) ? "#4299e1" : "#edf2f7"} 
                stroke="#2d3748" 
                strokeWidth="2" 
                opacity={activeCategory === 1 || (activeCategory === 3 && (highlightedKeyword === "Nucleus" || hoveredKeyword?.name === "Nucleus")) ? 0.7 : 1}
                onMouseEnter={(e) => {
                  if (activeCategory === 1 || activeCategory === 3) {
                    const keyword = category.keywords.find(k => k.name === "Nucleus");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: (activeCategory === 1 || activeCategory === 3) ? 'pointer' : 'default' }}
              />
              {/* Nuclear pores */}
              <circle cx="170" cy="150" r="3" fill="#4299e1" opacity={0.7} />
              <circle cx="150" cy="170" r="3" fill="#4299e1" opacity={0.7} />
              <circle cx="140" cy="140" r="3" fill="#4299e1" opacity={0.7} />
              <circle cx="180" cy="180" r="3" fill="#4299e1" opacity={0.7} />
              {/* Nucleolus */}
              <circle cx="165" cy="155" r="12" fill="#63b3ed" opacity={0.6} />
              <text x="160" y="160" textAnchor="middle" dominantBaseline="middle" fontSize="10" fontWeight="bold">Nucleus</text>
              
              {/* Mitochondria */}
              <ellipse 
                cx="240" 
                cy="120" 
                rx="30" 
                ry="15" 
                fill={(activeCategory === 2 && (highlightedKeyword === "Mitochondria" || hoveredKeyword?.name === "Mitochondria")) || (activeCategory === 4 && (highlightedKeyword === "Mitochondria" || hoveredKeyword?.name === "Mitochondria")) ? "#48bb78" : "#edf2f7"} 
                stroke="#2d3748" 
                strokeWidth="2" 
                opacity={(activeCategory === 2 && (highlightedKeyword === "Mitochondria" || hoveredKeyword?.name === "Mitochondria")) || (activeCategory === 4 && (highlightedKeyword === "Mitochondria" || hoveredKeyword?.name === "Mitochondria")) ? 0.7 : 1}
                onMouseEnter={(e) => {
                  if (activeCategory === 2 || activeCategory === 4) {
                    const keyword = category.keywords.find(k => k.name === "Mitochondria");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: (activeCategory === 2 || activeCategory === 4) ? 'pointer' : 'default' }}
              />
              <path d="M210 120 Q 240 105, 270 120 Q 240 135, 210 120" fill="none" stroke="#2d3748" strokeWidth="1" />
              <text x="240" y="120" textAnchor="middle" dominantBaseline="middle" fontSize="8">Mitochondria</text>
              
              {/* Endoplasmic reticulum */}
              <path 
                d="M90 100 Q 70 90, 50 100 Q 30 110, 50 120 Q 70 130, 90 120 Q 110 110, 90 100" 
                fill={(activeCategory === 3 && (highlightedKeyword === "Endoplasmic Reticulum & Cytoplasm" || hoveredKeyword?.name === "Endoplasmic Reticulum & Cytoplasm")) ? "#ed8936" : "#edf2f7"} 
                stroke="#2d3748" 
                strokeWidth="2" 
                opacity={(activeCategory === 3 && (highlightedKeyword === "Endoplasmic Reticulum & Cytoplasm" || hoveredKeyword?.name === "Endoplasmic Reticulum & Cytoplasm")) ? 0.7 : 1}
                onMouseEnter={(e) => {
                  if (activeCategory === 3) {
                    const keyword = category.keywords.find(k => k.name === "Endoplasmic Reticulum & Cytoplasm");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
              />
              <circle 
                cx="60" 
                cy="105" 
                r="3" 
                fill={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? "#9f7aea" : "#9f7aea"} 
                opacity={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? 1 : 0.5}
                onMouseEnter={(e) => {
                  if (activeCategory === 3) {
                    const keyword = category.keywords.find(k => k.name === "Ribosomes");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
              />
              <circle 
                cx="70" 
                cy="115" 
                r="3" 
                fill={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? "#9f7aea" : "#9f7aea"} 
                opacity={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? 1 : 0.5}
                onMouseEnter={(e) => {
                  if (activeCategory === 3) {
                    const keyword = category.keywords.find(k => k.name === "Ribosomes");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
              />
              <text x="70" y="107" textAnchor="middle" dominantBaseline="middle" fontSize="8">ER</text>
              
              {/* Golgi apparatus */}
              <path 
                d="M80 210 C 90 205, 110 205, 120 210 M80 220 C 90 215, 110 215, 120 220 M80 230 C 90 225, 110 225, 120 230" 
                fill="none" 
                stroke={(activeCategory === 4 && (highlightedKeyword === "Golgi Apparatus" || hoveredKeyword?.name === "Golgi Apparatus")) ? "#9f7aea" : "#2d3748"} 
                strokeWidth={(activeCategory === 4 && (highlightedKeyword === "Golgi Apparatus" || hoveredKeyword?.name === "Golgi Apparatus")) ? 3 : 2}
                onMouseEnter={(e) => {
                  if (activeCategory === 4) {
                    const keyword = category.keywords.find(k => k.name === "Golgi Apparatus");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: activeCategory === 4 ? 'pointer' : 'default' }}
              />
              <text x="100" y="240" textAnchor="middle" dominantBaseline="middle" fontSize="8">Golgi</text>
              
              {/* Chloroplast (in plant cells) */}
              <ellipse 
                cx="220" 
                cy="220" 
                rx="25" 
                ry="15" 
                fill={(activeCategory === 4 && (highlightedKeyword === "Chloroplasts" || hoveredKeyword?.name === "Chloroplasts" || highlightedKeyword === "Plastids" || hoveredKeyword?.name === "Plastids")) ? "#48bb78" : "#c6f6d5"} 
                stroke="#2d3748" 
                strokeWidth="2" 
                opacity={(activeCategory === 4 && (highlightedKeyword === "Chloroplasts" || hoveredKeyword?.name === "Chloroplasts" || highlightedKeyword === "Plastids" || hoveredKeyword?.name === "Plastids")) ? 0.9 : 0.6}
                onMouseEnter={(e) => {
                  if (activeCategory === 4) {
                    const keyword = category.keywords.find(k => k.name === "Chloroplasts" || k.name === "Plastids");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: activeCategory === 4 ? 'pointer' : 'default' }}
              />
              <ellipse cx="220" cy="220" rx="15" ry="8" fill="#9ae6b4" stroke="#2d3748" strokeWidth="1" opacity={0.8} />
              <text x="220" y="220" textAnchor="middle" dominantBaseline="middle" fontSize="8">Chloroplast</text>
              
              {/* Ribosomes */}
              <circle 
                cx="130" 
                cy="90" 
                r="4" 
                fill={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? "#9f7aea" : "#9f7aea"} 
                opacity={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? 1 : 0.5}
                onMouseEnter={(e) => {
                  if (activeCategory === 3) {
                    const keyword = category.keywords.find(k => k.name === "Ribosomes");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
              />
              <circle 
                cx="120" 
                cy="100" 
                r="4" 
                fill={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? "#9f7aea" : "#9f7aea"} 
                opacity={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? 1 : 0.5}
                onMouseEnter={(e) => {
                  if (activeCategory === 3) {
                    const keyword = category.keywords.find(k => k.name === "Ribosomes");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
              />
              <circle 
                cx="230" 
                cy="180" 
                r="4" 
                fill={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? "#9f7aea" : "#9f7aea"} 
                opacity={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? 1 : 0.5}
                onMouseEnter={(e) => {
                  if (activeCategory === 3) {
                    const keyword = category.keywords.find(k => k.name === "Ribosomes");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
              />
              <circle 
                cx="90" 
                cy="180" 
                r="4" 
                fill={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? "#9f7aea" : "#9f7aea"} 
                opacity={(activeCategory === 3 && (highlightedKeyword === "Ribosomes" || hoveredKeyword?.name === "Ribosomes")) ? 1 : 0.5}
                onMouseEnter={(e) => {
                  if (activeCategory === 3) {
                    const keyword = category.keywords.find(k => k.name === "Ribosomes");
                    if (keyword) {
                      handleMouseEnter(keyword, e);
                    }
                  }
                }}
                onMouseLeave={handleMouseLeave}
                style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
              />
              
              {/* Additional organelles for more detail */}
              
              {/* Vacuole (plant cell feature) */}
              <ellipse 
                cx="160" 
                cy="255" 
                rx="20" 
                ry="25" 
                fill="#e6fffa" 
                stroke="#2d3748" 
                strokeWidth="1" 
                opacity={0.7}
              />
              <text x="160" y="255" textAnchor="middle" dominantBaseline="middle" fontSize="8">Vacuole</text>
              
              {/* Lysosomes */}
              <circle cx="250" cy="190" r="8" fill="#fbb6ce" stroke="#2d3748" strokeWidth="1" opacity={0.8} />
              <circle cx="260" cy="200" r="6" fill="#fbb6ce" stroke="#2d3748" strokeWidth="1" opacity={0.8} />
              <text x="255" y="212" fontSize="8" fill="#2d3748">Lysosomes</text>
              
              {/* Cytoskeleton representation */}
              <path d="M50 160 Q 80 140, 110 160 Q 140 180, 160 160 Q 180 140, 210 160 Q 240 180, 270 160" 
                    fill="none" stroke="#a0aec0" strokeWidth="1" strokeDasharray="2,2" opacity={0.5} />
              <path d="M160 50 Q 140 80, 160 110 Q 180 140, 160 160 Q 140 180, 160 210 Q 180 240, 160 270" 
                    fill="none" stroke="#a0aec0" strokeWidth="1" strokeDasharray="2,2" opacity={0.5} />
              
              {/* Cell compartments */}
              <text x="120" y="60" textAnchor="middle" dominantBaseline="middle" fontSize="12" fontWeight="bold" fill="#2d3748">Cytoplasm</text>
              
              {/* Regulation visualization */}
              {activeCategory === 5 && (
                <>
                  <path d="M160 110 L160 90 L180 90" fill="none" stroke="#f56565" strokeWidth="2" strokeDasharray={highlightedKeyword === "Transcription" || hoveredKeyword?.name === "Transcription" || highlightedKeyword === "RNA Processing" || hoveredKeyword?.name === "RNA Processing" ? "0" : "3"} />
                  <text x="170" y="85" fontSize="8" fill="#f56565">{highlightedKeyword === "Transcription" || hoveredKeyword?.name === "Transcription" ? "DNA→mRNA" : "Transcription"}</text>
                  
                  <path d="M180 90 L200 90 L200 110" fill="none" stroke="#f56565" strokeWidth="2" strokeDasharray={highlightedKeyword === "RNA Processing" || hoveredKeyword?.name === "RNA Processing" ? "0" : "3"} />
                  <text x="205" y="100" fontSize="8" fill="#f56565">{highlightedKeyword === "RNA Processing" || hoveredKeyword?.name === "RNA Processing" ? "RNA-Modification" : "Processing"}</text>
                  
                  <path d="M200 110 L200 130 L180 130" fill="none" stroke="#f56565" strokeWidth="2" strokeDasharray={highlightedKeyword === "Translation" || hoveredKeyword?.name === "Translation" ? "0" : "3"} />
                  <text x="190" y="140" fontSize="8" fill="#f56565">{highlightedKeyword === "Translation" || hoveredKeyword?.name === "Translation" ? "mRNA→Protein" : "Translation"}</text>
                  
                  <path d="M140 90 L120 90 L120 130 L140 130" fill="none" stroke="#f56565" strokeWidth="2" strokeDasharray={highlightedKeyword === "Gene Activation" || hoveredKeyword?.name === "Gene Activation" || highlightedKeyword === "Cell Type Development" || hoveredKeyword?.name === "Cell Type Development" ? "0" : "3"} />
                  <text x="95" y="85" fontSize="8" fill="#f56565">{highlightedKeyword === "Gene Activation" || hoveredKeyword?.name === "Gene Activation" || highlightedKeyword === "Cell Type Development" || hoveredKeyword?.name === "Cell Type Development" ? "Gene Control" : "Regulation"}</text>
                </>
              )}
              
              {/* Category highlighting */}
              {activeCategory === 1 && (
                <rect x="20" y="20" width="280" height="280" fill="none" stroke="#4299e1" strokeWidth="4" strokeDasharray="5,5" rx="20" ry="20" />
              )}
              {activeCategory === 2 && (
                <path d="M160 160 L240 120 M160 160 L220 220" stroke="#48bb78" strokeWidth="2" strokeDasharray="5,5" />
              )}
              {activeCategory === 3 && (
                <>
                  <circle cx="160" cy="160" r="55" fill="none" stroke="#ed8936" strokeWidth="2" strokeDasharray="5,5" />
                  <path d="M160 160 L90 110 M160 160 L230 180" stroke="#ed8936" strokeWidth="2" strokeDasharray="5,5" />
                </>
              )}
            </svg>
          </div>
        </div>
      </div>
      
      {/* Modern White Tooltip */}
      {hoveredKeyword && (
        <div 
          className="fixed z-50 bg-white rounded-lg shadow-xl border border-gray-200 p-4 max-w-xs pointer-events-none transform -translate-x-1/2 -translate-y-full transition-all duration-200 ease-out"
          style={{ 
            left: tooltipPosition.x,
            top: tooltipPosition.y - 10, // 10px distance to keyword
            boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
          }}
        >
          {/* Small downward arrow */}
          <div 
            className="absolute left-1/2 transform -translate-x-1/2 top-full w-0 h-0"
            style={{
              borderLeft: '6px solid transparent',
              borderRight: '6px solid transparent',
              borderTop: '6px solid white',
              filter: 'drop-shadow(0 2px 2px rgba(0, 0, 0, 0.1))'
            }}
          />
          
          {/* Tooltip Content */}
          <div className="text-sm text-gray-800 font-medium leading-relaxed">
            {hoveredKeyword.description}
          </div>
        </div>
      )}
    </div>
  );
};