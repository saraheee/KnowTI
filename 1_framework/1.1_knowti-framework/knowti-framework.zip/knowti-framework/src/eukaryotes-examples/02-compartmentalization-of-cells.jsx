import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

const CellCompartmentSimulator = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [showCompartments, setShowCompartments] = useState(true);
  const [particles, setParticles] = useState([]);

  // Organelle definitions
  const organelles = [
    { 
      id: 'Nucleus', 
      x: 200, y: 150, 
      width: 120, height: 100, 
      color: '#3B82F6',
      reaction: 'DNA → RNA',
      particleColor: '#60A5FA'
    },
    { 
      id: 'Mitochondrion', 
      x: 50, y: 80, 
      width: 100, height: 80, 
      color: '#10B981',
      reaction: 'Glucose → ATP',
      particleColor: '#34D399'
    },
    { 
      id: 'Endoplasmic\nReticulum', 
      x: 350, y: 100, 
      width: 120, height: 90, 
      color: '#F59E0B',
      reaction: 'Protein synthesis',
      particleColor: '#FBBF24'
    },
    { 
      id: 'Ribosome', 
      x: 80, y: 220, 
      width: 110, height: 80, 
      color: '#8B5CF6',
      reaction: 'mRNA → Protein',
      particleColor: '#A78BFA'
    },
    { 
      id: 'Golgi Apparatus', 
      x: 320, y: 250, 
      width: 130, height: 90, 
      color: '#EF4444',
      reaction: 'Protein modification',
      particleColor: '#F87171'
    }
  ];

  // Generate particles
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      const newParticles = organelles.map(organelle => ({
        id: Math.random(),
        organelleId: organelle.id,
        x: organelle.x + Math.random() * organelle.width,
        y: organelle.y + Math.random() * organelle.height,
        color: organelle.particleColor,
        life: 100,
        vx: showCompartments ? (Math.random() - 0.5) * 2 : (Math.random() - 0.5) * 8,
        vy: showCompartments ? (Math.random() - 0.5) * 2 : (Math.random() - 0.5) * 8
      }));

      setParticles(prev => [...prev, ...newParticles].slice(-50));
    }, 200);

    return () => clearInterval(interval);
  }, [isRunning, showCompartments]);

  // Animate particles
  useEffect(() => {
    if (!isRunning) return;

    const animationInterval = setInterval(() => {
      setParticles(prev => prev.map(particle => {
        let newX = particle.x + particle.vx;
        let newY = particle.y + particle.vy;
        
        if (showCompartments) {
          // Keep particles inside compartments
          const organelle = organelles.find(o => o.id === particle.organelleId);
          if (organelle) {
            if (newX < organelle.x || newX > organelle.x + organelle.width) {
              particle.vx *= -1;
              newX = particle.x + particle.vx;
            }
            if (newY < organelle.y || newY > organelle.y + organelle.height) {
              particle.vy *= -1;
              newY = particle.y + particle.vy;
            }
          }
        } else {
          // Bounce particles off cell wall
          if (newX < 20 || newX > 480) particle.vx *= -1;
          if (newY < 20 || newY > 380) particle.vy *= -1;
        }

        return {
          ...particle,
          x: newX,
          y: newY,
          life: particle.life - 1
        };
      }).filter(p => p.life > 0));
    }, 50);

    return () => clearInterval(animationInterval);
  }, [isRunning, showCompartments]);

  const resetSimulation = () => {
    setIsRunning(false);
    setParticles([]);
  };

  return (
    <div className="flex flex-col items-center p-8 bg-white min-h-screen">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-2 text-center">
          Cell Compartmentalization
        </h1>
        <p className="text-gray-600 text-center">
          {showCompartments 
            ? "Separated compartments allow simultaneous processes" 
            : "Without compartments, all reactions mix chaotically"}
        </p>
      </div>

      {/* Control panel */}
      <div className="flex gap-4 mb-6">
        <button
          onClick={() => setIsRunning(!isRunning)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
        >
          {isRunning ? <Pause size={20} /> : <Play size={20} />}
          {isRunning ? 'Pause' : 'Start'}
        </button>
        
        <button
          onClick={resetSimulation}
          className="flex items-center gap-2 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
        >
          <RotateCcw size={20} />
          Reset
        </button>
        
        <button
          onClick={() => setShowCompartments(!showCompartments)}
          className={`px-4 py-2 rounded-lg transition-colors ${
            showCompartments 
              ? 'bg-green-500 text-white hover:bg-green-600' 
              : 'bg-red-500 text-white hover:bg-red-600'
          }`}
        >
          {showCompartments ? 'Compartments ON' : 'Compartments OFF'}
        </button>
      </div>

      {/* Cell visualization */}
      <div className="relative">
        <svg width="500" height="400" className="border-2 border-gray-300 rounded-xl bg-gray-50">
          {/* Cell wall */}
          <rect 
            x="10" y="10" 
            width="480" height="380" 
            fill="none" 
            stroke="#6B7280" 
            strokeWidth="3" 
            rx="20"
          />
          
          {/* Organelles */}
          {organelles.map(organelle => (
            <g key={organelle.id}>
              {/* Organelle background */}
              <rect
                x={organelle.x}
                y={organelle.y}
                width={organelle.width}
                height={organelle.height}
                fill={showCompartments ? `${organelle.color}20` : 'transparent'}
                stroke={showCompartments ? organelle.color : 'transparent'}
                strokeWidth="2"
                rx="8"
              />
              
              {/* Organelle label (only when compartments visible) */}
              {showCompartments && (
                <>
                  {organelle.id.includes('\n') ? (
                    <>
                      <text
                        x={organelle.x + organelle.width/2}
                        y={organelle.y + organelle.height/2 - 18}
                        textAnchor="middle"
                        className="text-xs font-semibold fill-gray-700"
                      >
                        {organelle.id.split('\n')[0]}
                      </text>
                      <text
                        x={organelle.x + organelle.width/2}
                        y={organelle.y + organelle.height/2 - 2}
                        textAnchor="middle"
                        className="text-xs font-semibold fill-gray-700"
                      >
                        {organelle.id.split('\n')[1]}
                      </text>
                    </>
                  ) : (
                    <text
                      x={organelle.x + organelle.width/2}
                      y={organelle.y + organelle.height/2 - 10}
                      textAnchor="middle"
                      className="text-xs font-semibold fill-gray-700"
                    >
                      {organelle.id}
                    </text>
                  )}
                </>
              )}
              
              {/* Reaction label */}
              {showCompartments && (
                <text
                  x={organelle.x + organelle.width/2}
                  y={organelle.y + organelle.height/2 + 12}
                  textAnchor="middle"
                  className="text-xs fill-gray-600"
                >
                  {organelle.reaction}
                </text>
              )}
            </g>
          ))}
          
          {/* Particles */}
          {particles.map(particle => (
            <circle
              key={particle.id}
              cx={particle.x}
              cy={particle.y}
              r="4"
              fill={particle.color}
              opacity={particle.life / 100}
            />
          ))}
        </svg>
      </div>

      {/* Status indicator */}
      <div className="mt-6 text-center">
        <div className={`inline-flex items-center px-4 py-2 rounded-full ${
          showCompartments 
            ? 'bg-green-100 text-green-800' 
            : 'bg-red-100 text-red-800'
        }`}>
          <div className={`w-3 h-3 rounded-full mr-2 ${
            showCompartments ? 'bg-green-500' : 'bg-red-500'
          }`}></div>
          {showCompartments 
            ? 'Simultaneous reactions in separate compartments' 
            : 'Chaotic mixing of all reactions'}
        </div>
      </div>

      {/* Legend */}
      <div className="mt-6 grid grid-cols-3 gap-4 text-xs">
        {organelles.slice(0, 3).map(organelle => (
          <div key={organelle.id} className="flex items-center">
            <div 
              className="w-4 h-4 rounded mr-2" 
              style={{ backgroundColor: organelle.particleColor }}
            ></div>
            <span className="text-gray-700">{organelle.reaction}</span>
          </div>
        ))}
      </div>
      <div className="mt-2 grid grid-cols-2 gap-4 text-xs">
        {organelles.slice(3).map(organelle => (
          <div key={organelle.id} className="flex items-center">
            <div 
              className="w-4 h-4 rounded mr-2" 
              style={{ backgroundColor: organelle.particleColor }}
            ></div>
            <span className="text-gray-700">{organelle.reaction}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CellCompartmentSimulator;
