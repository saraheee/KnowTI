import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, ChevronRight } from 'lucide-react';

const EukaryoticTranscription = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const steps = [
    { 
      id: 'start', 
      label: 'Start – DNA in nucleus ready for transcription',
      description: 'The nucleus contains DNA separated from the cytoplasm'
    },
    { 
      id: 'polymerase', 
      label: 'RNA polymerase binds to promoter',
      description: 'The enzyme recognizes special DNA start sequences'
    },
    { 
      id: 'unwinding', 
      label: 'DNA double helix unwinds',
      description: 'RNA polymerase opens the double helix to access information'
    },
    { 
      id: 'synthesis', 
      label: 'mRNA is synthesized',
      description: 'RNA polymerase builds complementary mRNA from the DNA template'
    },
    { 
      id: 'complete', 
      label: 'mRNA exits nucleus through nuclear pores',
      description: 'Mature mRNA is transported into the cytoplasm to the ribosomes'
    }
  ];

  useEffect(() => {
    let interval;
    if (isPlaying && currentStep < steps.length - 1) {
      interval = setInterval(() => {
        setCurrentStep(prev => prev + 1);
      }, 2000);
    } else if (currentStep >= steps.length - 1) {
      setIsPlaying(false);
    }
    return () => clearInterval(interval);
  }, [isPlaying, currentStep, steps.length]);

  const reset = () => {
    setCurrentStep(0);
    setIsPlaying(false);
  };

  const togglePlay = () => {
    if (currentStep >= steps.length - 1) {
      reset();
    }
    setIsPlaying(!isPlaying);
  };

  const DNAStrand = ({ isUnwound }) => (
    <g>
      <path
        d={isUnwound ? "M 80 90 Q 200 70 320 90" : "M 80 90 Q 200 80 320 90"}
        stroke="#4F46E5"
        strokeWidth="4"
        fill="none"
      />
      <path
        d={isUnwound ? "M 80 110 Q 200 130 320 110" : "M 80 110 Q 200 120 320 110"}
        stroke="#7C3AED"
        strokeWidth="4"
        fill="none"
      />
      
      {/* DNA bases */}
      {[100, 130, 160, 190, 220, 250, 280].map((x, i) => (
        <g key={i}>
          <circle cx={x} cy={isUnwound ? 90 : 95} r="3" fill="#4F46E5" />
          <circle cx={x} cy={isUnwound ? 110 : 105} r="3" fill="#7C3AED" />
        </g>
      ))}
      
      {/* DNA label */}
      <text x="70" y="85" textAnchor="middle" fill="#4F46E5" fontSize="12" fontWeight="bold">
        DNA
      </text>
      <text x="70" y="97" textAnchor="middle" fill="#4F46E5" fontSize="9">
        Double strand
      </text>
    </g>
  );

  const RNAPolymerase = ({ x, visible }) => (
    <g 
      className={`transition-all duration-1000 ${visible ? 'opacity-100' : 'opacity-0'}`}
      transform={`translate(${x}, 0)`}
    >
      <ellipse cx="200" cy="100" rx="25" ry="15" fill="#EF4444" />
      <text x="200" y="105" textAnchor="middle" fill="white" fontSize="10" fontWeight="bold">
        RNA-Pol
      </text>
    </g>
  );

  const mRNA = ({ progress, exiting }) => {
    const length = progress * 120;
    return (
      <g className={`transition-all duration-1000 ${exiting ? 'opacity-50' : 'opacity-100'}`}>
        <path
          d={`M 200 120 L ${200 + length} 120`}
          stroke="#10B981"
          strokeWidth="3"
          fill="none"
          strokeDasharray="5,5"
        />
        {progress > 0.3 && (
          <text x={200 + length/2} y="135" textAnchor="middle" fill="#10B981" fontSize="12" fontWeight="bold">
            mRNA
          </text>
        )}
      </g>
    );
  };

  const NuclearMembrane = () => (
    <g>
      <ellipse cx="250" cy="100" rx="200" ry="80" fill="none" stroke="#6B7280" strokeWidth="3" strokeDasharray="10,5" />
      <text x="250" y="160" textAnchor="middle" fill="#6B7280" fontSize="18" fontWeight="bold">
        Nucleus
      </text>
      
      {/* Nuclear pores */}
      {[150, 350].map((x, i) => (
        <g key={i}>
          <circle cx={x} cy="100" r="8" fill="none" stroke="#6B7280" strokeWidth="2" />
          <text x={x} y="105" textAnchor="middle" fill="#6B7280" fontSize="8">
            P
          </text>
        </g>
      ))}
    </g>
  );

  const getPolymerasePosition = () => {
    if (currentStep === 0) return -50;
    if (currentStep === 1) return -20;
    if (currentStep >= 2) return Math.min(currentStep * 20, 100);
    return 0;
  };

  const getmRNAProgress = () => {
    if (currentStep < 3) return 0;
    if (currentStep === 3) return 0.6;
    return 1;
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6 bg-white">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">
          Transcription in Eukaryotes
        </h2>
        
        {/* Controls */}
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={togglePlay}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            {isPlaying ? <Pause size={20} /> : <Play size={20} />}
            {isPlaying ? 'Pause' : 'Start'}
          </button>
          
          <button
            onClick={reset}
            className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            <RotateCcw size={20} />
            Reset
          </button>
        </div>

        {/* Progress indicator */}
        <div className="flex items-center gap-2 mb-6">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center">
              <div
                className={`w-3 h-3 rounded-full transition-colors ${
                  index <= currentStep ? 'bg-blue-600' : 'bg-gray-300'
                }`}
              />
              {index < steps.length - 1 && (
                <ChevronRight size={16} className="text-gray-400 mx-1" />
              )}
            </div>
          ))}
        </div>

        {/* Current step */}
        <div className="bg-blue-50 p-4 rounded-lg mb-6">
          <h3 className="font-semibold text-blue-800 mb-1">
            Step {currentStep + 1}: {steps[currentStep].label}
          </h3>
          <p className="text-sm text-blue-600">{steps[currentStep].description}</p>
        </div>
      </div>

      {/* Main visualization */}
      <div className="bg-gray-50 rounded-lg p-8">
        <svg width="500" height="200" viewBox="0 0 500 200" className="w-full h-auto">
          {/* Nucleus */}
          <NuclearMembrane />
          
          {/* DNA */}
          <DNAStrand isUnwound={currentStep >= 2} />
          
          {/* RNA Polymerase */}
          <RNAPolymerase 
            x={getPolymerasePosition()} 
            visible={currentStep >= 1} 
          />
          
          {/* mRNA */}
          <mRNA 
            progress={getmRNAProgress()} 
            exiting={currentStep >= 4}
          />
        </svg>
      </div>

      {/* Legend */}
      <div className="mt-6 bg-white border border-gray-200 rounded-lg p-4">
        <h4 className="font-semibold text-gray-800 mb-3">Legend</h4>
        <div className="flex flex-wrap gap-6">
          <div className="flex items-center gap-2">
            <div className="w-6 h-1 bg-blue-600 rounded"></div>
            <span className="text-sm text-gray-700">DNA double strand</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-1 bg-green-600 rounded" style={{backgroundImage: 'repeating-linear-gradient(90deg, #10B981 0, #10B981 3px, transparent 3px, transparent 6px)'}}></div>
            <span className="text-sm text-gray-700">mRNA</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-3 bg-red-500 rounded-full"></div>
            <span className="text-sm text-gray-700">RNA polymerase</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 border-2 border-gray-500 rounded-full"></div>
            <span className="text-sm text-gray-700">Nuclear pore (P)</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EukaryoticTranscription;
