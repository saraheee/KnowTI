import React, { useState } from 'react';
import { TreePine, Bug, Microscope, User } from 'lucide-react';

const OrganismGroups = () => {
  const [selectedGroup, setSelectedGroup] = useState(null);

  const organismGroups = {
    animals: {
      name: 'Animals',
      icon: Bug,
      color: 'bg-green-50 hover:bg-green-100 border-green-200',
      examples: ['Mammals', 'Birds', 'Insects', 'Fish', 'Reptiles', 'Amphibians'],
      description: 'Multicellular organisms with specialized tissues'
    },
    plants: {
      name: 'Plants',
      icon: TreePine,
      color: 'bg-emerald-50 hover:bg-emerald-100 border-emerald-200',
      examples: ['Flowering plants', 'Ferns', 'Mosses', 'Conifers', 'Grasses', 'Algae'],
      description: 'Photosynthetic organisms with a cell wall'
    },
    fungi: {
      name: 'Fungi',
      icon: Microscope,
      color: 'bg-orange-50 hover:bg-orange-100 border-orange-200',
      examples: ['Yeasts', 'Molds', 'Mushrooms', 'Lichens', 'Rust fungi', 'Mildew'],
      description: 'Heterotrophic organisms with a chitin cell wall'
    },
    humans: {
      name: 'Humans',
      icon: User,
      color: 'bg-blue-50 hover:bg-blue-100 border-blue-200',
      examples: ['Homo sapiens', 'Nervous system', 'Immune system', 'Digestive system', 'Respiration', 'Circulation'],
      description: 'Complex multicellular organisms with highly developed systems'
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-8 bg-white">
      {/* Header */}
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-800 mb-3">Eukaryotic Organism Groups</h1>
        <p className="text-gray-600">Click on a group to learn more</p>
      </div>

      {/* Organism Groups Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-10">
        {Object.entries(organismGroups).map(([key, group]) => {
          const IconComponent = group.icon;
          return (
            <button
              key={key}
              onClick={() => setSelectedGroup(selectedGroup === key ? null : key)}
              className={`p-8 border-2 rounded-2xl transition-all duration-300 transform ${group.color} ${
                selectedGroup === key ? 'ring-4 ring-blue-200 scale-105 shadow-lg' : 'hover:scale-102 shadow-md'
              }`}
            >
              <IconComponent className="w-16 h-16 mx-auto mb-4 text-gray-700" />
              <div className="text-lg font-semibold text-gray-800">{group.name}</div>
            </button>
          );
        })}
      </div>

      {/* Group Details */}
      {selectedGroup && (
        <div className="bg-gray-50 rounded-2xl p-8 transition-all duration-500 shadow-inner border">
          <div className="flex items-center gap-4 mb-6">
            {React.createElement(organismGroups[selectedGroup].icon, { 
              className: "w-10 h-10 text-gray-700" 
            })}
            <h2 className="text-2xl font-bold text-gray-800">
              {organismGroups[selectedGroup].name}
            </h2>
          </div>
          
          <p className="text-lg text-gray-600 mb-6 leading-relaxed">
            {organismGroups[selectedGroup].description}
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {organismGroups[selectedGroup].examples.map((example, index) => (
              <div
                key={index}
                className="bg-white p-4 rounded-xl text-center font-medium text-gray-700 shadow-sm border hover:shadow-md transition-shadow duration-200"
              >
                {example}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Interactive Hint */}
      {!selectedGroup && (
        <div className="text-center mt-8">
          <div className="inline-flex items-center gap-2 text-gray-500 text-sm">
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
            Select an organism group
          </div>
        </div>
      )}
    </div>
  );
};

export default OrganismGroups;
