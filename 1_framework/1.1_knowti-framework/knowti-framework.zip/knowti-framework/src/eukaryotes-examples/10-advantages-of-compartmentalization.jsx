import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Zap, Cpu, TrendingUp } from 'lucide-react';

const CellCompartmentalization = () => {
  const [activeDemo, setActiveDemo] = useState(0);
  
  // Demo 1: Simultaneous processes
  const [processesRunning, setProcessesRunning] = useState(false);
  const [processProgress, setProcessProgress] = useState({
    mitochondria: 0,
    ribosome: 0,
    golgi: 0
  });

  // Demo 2: Specialization
  const [selectedOrganelle, setSelectedOrganelle] = useState(null);

  // Demo 3: Efficiency
  const [efficiencyMode, setEfficiencyMode] = useState('compartmentalized');
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    let interval;
    if (processesRunning) {
      interval = setInterval(() => {
        setProcessProgress(prev => ({
          mitochondria: (prev.mitochondria + 2) % 100,
          ribosome: (prev.ribosome + 1.5) % 100,
          golgi: (prev.golgi + 1) % 100
        }));
      }, 100);
    }
    return () => clearInterval(interval);
  }, [processesRunning]);

  useEffect(() => {
    if (activeDemo === 2) {
      const newParticles = Array.from({ length: 20 }, (_, i) => ({
        id: i,
        x: Math.random() * 400,
        y: Math.random() * 300,
        vx: (Math.random() - 0.5) * 4,
        vy: (Math.random() - 0.5) * 4,
        type: ['protein', 'lipid', 'glucose'][Math.floor(Math.random() * 3)]
      }));
      setParticles(newParticles);
    }
  }, [activeDemo, efficiencyMode]);

  useEffect(() => {
    if (activeDemo === 2) {
      const interval = setInterval(() => {
        setParticles(prev => prev.map(particle => {
          let newX = particle.x + particle.vx;
          let newY = particle.y + particle.vy;
          let newVx = particle.vx;
          let newVy = particle.vy;

          if (efficiencyMode === 'compartmentalized') {
            // Particles are attracted to specific organelles
            const targets = {
              protein: { x: 100, y: 100 },
              lipid: { x: 300, y: 100 },
              glucose: { x: 200, y: 200 }
            };
            const target = targets[particle.type];
            const dx = target.x - newX;
            const dy = target.y - newY;
            newVx += dx * 0.01;
            newVy += dy * 0.01;
          }

          if (newX < 0 || newX > 400) newVx *= -1;
          if (newY < 0 || newY > 300) newVy *= -1;
          newX = Math.max(0, Math.min(400, newX));
          newY = Math.max(0, Math.min(300, newY));

          return { ...particle, x: newX, y: newY, vx: newVx, vy: newVy };
        }));
      }, 50);
      return () => clearInterval(interval);
    }
  }, [activeDemo, efficiencyMode]);

  const organelles = [
    { 
      name: 'Mitochondrion', 
      function: 'ATP Synthesis', 
      color: '#ff6b6b',
      specialty: 'Energy production through cellular respiration'
    },
    { 
      name: 'Ribosome', 
      function: 'Protein Synthesis', 
      color: '#4ecdc4',
      specialty: 'Translation of mRNA into proteins'
    },
    { 
      name: 'Golgi Apparatus', 
      function: 'Protein Modification', 
      color: '#45b7d1',
      specialty: 'Packaging and shipping of proteins'
    },
    { 
      name: 'ER', 
      function: 'Protein Folding', 
      color: '#96ceb4',
      specialty: 'Synthesis of membrane proteins'
    }
  ];

  const demos = [
    {
      title: 'Simultaneous Processes',
      icon: <Zap className="w-5 h-5" />,
      description: 'Different organelles operate simultaneously'
    },
    {
      title: 'Specialization',
      icon: <Cpu className="w-5 h-5" />,
      description: 'Each organelle has a specific function'
    },
    {
      title: 'Efficiency Increase',
      icon: <TrendingUp className="w-5 h-5" />,
      description: 'Compartments vs. chaotic mixing'
    }
  ];

  return (
    <div className="p-6 bg-white min-h-screen">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-8 text-center">
          Advantages of Compartmentalization
        </h1>
        
        {/* Navigation */}
        <div className="flex justify-center mb-8">
          <div className="flex bg-gray-100 rounded-lg p-1">
            {demos.map((demo, index) => (
              <button
                key={index}
                onClick={() => setActiveDemo(index)}
                className={`flex items-center gap-2 px-4 py-2 rounded-md transition-all ${
                  activeDemo === index 
                    ? 'bg-white text-blue-600 shadow-sm' 
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                {demo.icon}
                <span className="font-medium">{demo.title}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Demo Content */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          
          {/* Demo 1: Simultaneous Processes */}
          {activeDemo === 0 && (
            <div className="text-center">
              <h2 className="text-2xl font-semibold mb-4 text-gray-800">
                Simultaneous Metabolic Processes
              </h2>
              <p className="text-gray-600 mb-8">
                Different organelles can work at the same time without interfering with each other
              </p>
              
              <div className="flex justify-center mb-6">
                <button
                  onClick={() => setProcessesRunning(!processesRunning)}
                  className="flex items-center gap-2 bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
                >
                  {processesRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  {processesRunning ? 'Pause' : 'Start'}
                </button>
              </div>

              <div className="grid grid-cols-3 gap-8 max-w-4xl mx-auto">
                {organelles.slice(0, 3).map((organelle, index) => (
                  <div key={index} className="text-center">
                    <div 
                      className="w-32 h-32 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-lg relative overflow-hidden"
                      style={{ backgroundColor: organelle.color }}
                    >
                      <div 
                        className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-20 transition-all duration-300"
                        style={{ 
                          height: `${Object.values(processProgress)[index]}%` 
                        }}
                      />
                      <span className="relative z-10">{organelle.name}</span>
                    </div>
                    <p className="font-medium text-gray-800">{organelle.function}</p>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                      <div 
                        className="h-2 rounded-full transition-all duration-300"
                        style={{ 
                          backgroundColor: organelle.color,
                          width: `${Object.values(processProgress)[index]}%` 
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Demo 2: Specialization */}
          {activeDemo === 1 && (
            <div>
              <h2 className="text-2xl font-semibold mb-4 text-center text-gray-800">
                Organelle Specialization
              </h2>
              <p className="text-gray-600 mb-8 text-center">
                Click on an organelle to discover its specialized function
              </p>

              <div className="grid grid-cols-2 gap-6 max-w-4xl mx-auto">
                {organelles.map((organelle, index) => (
                  <div
                    key={index}
                    onClick={() => setSelectedOrganelle(selectedOrganelle === index ? null : index)}
                    className={`p-6 rounded-lg border-2 cursor-pointer transition-all transform hover:scale-105 ${
                      selectedOrganelle === index 
                        ? 'border-blue-500 bg-blue-50' 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center gap-4 mb-4">
                      <div 
                        className="w-16 h-16 rounded-full flex items-center justify-center text-white font-bold"
                        style={{ backgroundColor: organelle.color }}
                      >
                        {organelle.name.slice(0, 2)}
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-800">{organelle.name}</h3>
                        <p className="text-gray-600">{organelle.function}</p>
                      </div>
                    </div>
                    
                    {selectedOrganelle === index && (
                      <div className="mt-4 p-4 bg-white rounded-lg border border-gray-200">
                        <p className="text-gray-700">{organelle.specialty}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Demo 3: Efficiency */}
          {activeDemo === 2 && (
            <div>
              <h2 className="text-2xl font-semibold mb-4 text-center text-gray-800">
                Efficiency Increase through Compartments
              </h2>
              <p className="text-gray-600 mb-6 text-center">
                Compare organized vs. chaotic cellular processes
              </p>

              <div className="flex justify-center gap-4 mb-6">
                <button
                  onClick={() => setEfficiencyMode('compartmentalized')}
                  className={`px-6 py-2 rounded-lg transition-colors ${
                    efficiencyMode === 'compartmentalized' 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Compartmentalized
                </button>
                <button
                  onClick={() => setEfficiencyMode('chaotic')}
                  className={`px-6 py-2 rounded-lg transition-colors ${
                    efficiencyMode === 'chaotic' 
                      ? 'bg-red-500 text-white' 
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Chaotic
                </button>
              </div>

              <div className="relative w-full max-w-2xl mx-auto">
                <svg width="450" height="350" className="border border-gray-200 rounded-lg">
                  {/* Compartments (only visible in compartmentalized mode) */}
                  {efficiencyMode === 'compartmentalized' && (
                    <>
                      <circle cx="100" cy="100" r="40" fill="#ff6b6b" fillOpacity="0.2" stroke="#ff6b6b" strokeWidth="2" />
                      <circle cx="300" cy="100" r="40" fill="#4ecdc4" fillOpacity="0.2" stroke="#4ecdc4" strokeWidth="2" />
                      <circle cx="200" cy="200" r="40" fill="#45b7d1" fillOpacity="0.2" stroke="#45b7d1" strokeWidth="2" />
                      <text x="100" y="60" textAnchor="middle" className="text-xs font-medium">Protein</text>
                      <text x="300" y="60" textAnchor="middle" className="text-xs font-medium">Lipid</text>
                      <text x="200" y="160" textAnchor="middle" className="text-xs font-medium">Glucose</text>
                    </>
                  )}
                  
                  {/* Particles */}
                  {particles.map(particle => (
                    <circle
                      key={particle.id}
                      cx={particle.x}
                      cy={particle.y}
                      r="4"
                      fill={
                        particle.type === 'protein' ? '#ff6b6b' :
                        particle.type === 'lipid' ? '#4ecdc4' : '#45b7d1'
                      }
                      className="transition-all duration-100"
                    />
                  ))}
                </svg>

                <div className="mt-4 text-center">
                  <p className="text-sm text-gray-600">
                    {efficiencyMode === 'compartmentalized' 
                      ? 'Molecules move purposefully to their specialized organelles' 
                      : 'Molecules move randomly and inefficiently throughout the cell'
                    }
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CellCompartmentalization;
