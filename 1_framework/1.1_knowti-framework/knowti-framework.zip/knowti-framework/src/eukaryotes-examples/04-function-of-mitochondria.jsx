import React, { useState, useEffect } from 'react';
import { Zap, Battery, Flame, Play, Pause, RotateCcw } from 'lucide-react';

const MitochondriaVisualization = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [atpCount, setAtpCount] = useState(0);
  const [selectedComponent, setSelectedComponent] = useState(null);
  const [animationStep, setAnimationStep] = useState(0);

  useEffect(() => {
    let interval;
    if (isRunning) {
      interval = setInterval(() => {
        setAnimationStep(prev => (prev + 1) % 4);
        setAtpCount(prev => prev + 1);
      }, 1500);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  const reset = () => {
    setIsRunning(false);
    setAtpCount(0);
    setAnimationStep(0);
    setSelectedComponent(null);
  };

  const components = {
    outer: {
      title: "Outer Membrane",
      description: "Protective barrier of the mitochondria"
    },
    inner: {
      title: "Inner Membrane",
      description: "Site of ATP synthesis"
    },
    cristae: {
      title: "Cristae",
      description: "Increase surface area for more energy production"
    },
    matrix: {
      title: "Matrix",
      description: "Center of cellular metabolism"
    }
  };

  const FloatingMolecule = ({ type, delay, x, y }) => (
    <div 
      className={`absolute w-3 h-3 rounded-full transition-all duration-1000 ${
        type === 'glucose' ? 'bg-orange-400' : 
        type === 'oxygen' ? 'bg-blue-400' : 
        'bg-green-400'
      } ${isRunning ? 'animate-pulse' : ''}`}
      style={{
        left: `${x}px`,
        top: `${y}px`,
        transform: isRunning ? `translate(${Math.sin(Date.now() / 1000 + delay) * 20}px, ${Math.cos(Date.now() / 1000 + delay) * 15}px)` : 'none'
      }}
    />
  );

  return (
    <div className="w-full max-w-6xl mx-auto p-8 bg-white">
      <div className="text-center mb-4">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">Mitochondria: Powerhouse of the Cell</h1>
      </div>

      <div className="relative bg-gray-50 rounded-2xl p-6">
        {/* Control buttons top left */}
        <div className="absolute top-4 left-4 z-10 flex gap-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className="flex items-center gap-1 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
          >
            {isRunning ? <Pause size={16} /> : <Play size={16} />}
            {isRunning ? 'Pause' : 'Start'}
          </button>
          
          <button
            onClick={reset}
            className="flex items-center gap-1 px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm"
          >
            <RotateCcw size={16} />
            Reset
          </button>
        </div>

        {/* ATP counter top center */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-10">
          <div className="bg-green-600 text-white px-6 py-3 rounded-full shadow-lg">
            <div className="flex items-center gap-2">
              <Zap className="text-white animate-pulse" size={24} />
              <span className="text-xl font-bold">ATP: {atpCount}</span>
              <Zap className="text-white animate-pulse" size={24} />
            </div>
          </div>
        </div>

        <svg viewBox="0 0 600 400" className="w-full h-auto">
          {/* Outer Membrane */}
          <ellipse
            cx="300" cy="200" rx="280" ry="180"
            fill="none"
            stroke={selectedComponent === 'outer' ? '#3b82f6' : '#6b7280'}
            strokeWidth={selectedComponent === 'outer' ? 4 : 2}
            className="cursor-pointer transition-all"
            onClick={() => setSelectedComponent(selectedComponent === 'outer' ? null : 'outer')}
          />
          
          {/* Inner Membrane */}
          <ellipse
            cx="300" cy="200" rx="240" ry="140"
            fill="rgba(59, 130, 246, 0.1)"
            stroke={selectedComponent === 'inner' ? '#3b82f6' : '#4b5563'}
            strokeWidth={selectedComponent === 'inner' ? 4 : 2}
            className="cursor-pointer transition-all"
            onClick={() => setSelectedComponent(selectedComponent === 'inner' ? null : 'inner')}
          />
          
          {/* Cristae */}
          {[...Array(8)].map((_, i) => (
            <path
              key={i}
              d={`M ${120 + i * 60} 200 Q ${140 + i * 60} ${180 + (i % 2) * 40} ${160 + i * 60} 200`}
              fill="none"
              stroke={selectedComponent === 'cristae' ? '#3b82f6' : '#059669'}
              strokeWidth={selectedComponent === 'cristae' ? 3 : 2}
              className="cursor-pointer transition-all"
              onClick={() => setSelectedComponent(selectedComponent === 'cristae' ? null : 'cristae')}
            />
          ))}
          
          {/* Matrix */}
          <circle
            cx="300" cy="200" r="80"
            fill={selectedComponent === 'matrix' ? 'rgba(59, 130, 246, 0.2)' : 'rgba(16, 185, 129, 0.2)'}
            stroke={selectedComponent === 'matrix' ? '#3b82f6' : '#10b981'}
            strokeWidth={selectedComponent === 'matrix' ? 3 : 2}
            className="cursor-pointer transition-all"
            onClick={() => setSelectedComponent(selectedComponent === 'matrix' ? null : 'matrix')}
          />
          
          {/* ATP Synthase Complexes */}
          {[...Array(6)].map((_, i) => (
            <g key={i}>
              <circle
                cx={200 + i * 40}
                cy={120 + (i % 2) * 20}
                r="8"
                fill="#f59e0b"
                className={isRunning ? 'animate-spin' : ''}
              />
              <circle
                cx={200 + i * 40}
                cy={120 + (i % 2) * 20}
                r="4"
                fill="#d97706"
              />
            </g>
          ))}
          
          {/* Floating Molecules */}
          {isRunning && (
            <>
              <FloatingMolecule type="glucose" delay={0} x={50} y={100} />
              <FloatingMolecule type="oxygen" delay={1} x={80} y={300} />
              <FloatingMolecule type="glucose" delay={2} x={500} y={150} />
              <FloatingMolecule type="oxygen" delay={3} x={520} y={250} />
            </>
          )}
          
          {/* ATP Molecules */}
          {[...Array(Math.min(atpCount, 12))].map((_, i) => (
            <g key={i}>
              <circle
                cx={300 + (i % 4 - 2) * 30}
                cy={300 + Math.floor(i / 4) * 25}
                r="6"
                fill="#10b981"
                className="animate-pulse"
              />
              <text
                x={300 + (i % 4 - 2) * 30}
                y={305 + Math.floor(i / 4) * 25}
                textAnchor="middle"
                className="text-xs fill-black font-bold"
              >
                ATP
              </text>
            </g>
          ))}
        </svg>
      </div>

      {/* Component Info */}
      {selectedComponent && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
          <h3 className="text-lg font-bold text-blue-900 mb-1">
            {components[selectedComponent].title}
          </h3>
          <p className="text-blue-800 text-sm">
            {components[selectedComponent].description}
          </p>
        </div>
      )}
    </div>
  );
};

export default MitochondriaVisualization;
