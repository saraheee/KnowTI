import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Shield } from 'lucide-react';

const MRNAProtectionSimulator = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [time, setTime] = useState(0);
  const [unprotectedHealth, setUnprotectedHealth] = useState(100);
  const [protectedHealth, setProtectedHealth] = useState(100);
  const [unprotectedProteins, setUnprotectedProteins] = useState(0);
  const [protectedProteins, setProtectedProteins] = useState(0);
  const [nucleases, setNucleases] = useState([]);

  // Nuclease positions and movement
  useEffect(() => {
    if (isRunning) {
      const interval = setInterval(() => {
        setTime(t => t + 1);
        
        // Unprotected mRNA degrades faster
        setUnprotectedHealth(h => Math.max(0, h - 2.5));
        
        // Protected mRNA degrades very slowly
        setProtectedHealth(h => Math.max(0, h - 0.3));
        
        // Protein production (only if mRNA is healthy)
        setUnprotectedProteins(p => unprotectedHealth > 20 ? p + 0.5 : p);
        setProtectedProteins(p => protectedHealth > 20 ? p + 2 : p);
        
        // Update nucleases
        setNucleases(prev => 
          prev.map(n => ({
            ...n,
            x: n.x + n.speed,
            opacity: n.x > 300 ? 0 : 1
          })).filter(n => n.x < 400)
        );
        
        // Add new nucleases randomly
        if (Math.random() < 0.3) {
          setNucleases(prev => [...prev, {
            id: Date.now(),
            x: -20,
            y: Math.random() * 100 + 50,
            speed: Math.random() * 2 + 1,
            opacity: 1,
            target: Math.random() < 0.5 ? 'unprotected' : 'protected'
          }]);
        }
      }, 100);
      
      return () => clearInterval(interval);
    }
  }, [isRunning, unprotectedHealth, protectedHealth]);

  const reset = () => {
    setIsRunning(false);
    setTime(0);
    setUnprotectedHealth(100);
    setProtectedHealth(100);
    setUnprotectedProteins(0);
    setProtectedProteins(0);
    setNucleases([]);
  };

  const MRNAStrand = ({ health, protected: isProtected }) => {
    const segments = 20;
    const segmentHealth = health / 100;
    
    return (
      <div className="relative">
        {/* mRNA backbone */}
        <div className="flex items-center space-x-1">
          {isProtected && (
            <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xs font-bold">C</span>
            </div>
          )}
          
          {Array.from({ length: segments }).map((_, i) => {
            const segmentIndex = i / segments;
            const isHealthy = segmentIndex < segmentHealth;
            
            return (
              <div
                key={i}
                className={`w-3 h-2 rounded-sm transition-all duration-300 ${
                  isHealthy 
                    ? (isProtected ? 'bg-green-500' : 'bg-orange-400')
                    : 'bg-gray-300'
                }`}
              />
            );
          })}
          
          {isProtected && (
            <div className="flex space-x-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="w-2 h-2 bg-purple-500 rounded-full" />
              ))}
            </div>
          )}
        </div>
        
        {/* Ribosome animation */}
        {health > 20 && (
          <div 
            className={`absolute top-4 w-6 h-4 bg-teal-600 rounded transition-all duration-1000 ${
              isProtected ? 'animate-pulse' : ''
            }`}
            style={{
              left: `${Math.min((time * (isProtected ? 2 : 0.5)) % 300, 250)}px`,
              animation: isProtected ? 'none' : 'pulse 2s infinite'
            }}
          >
            <div className="w-full h-full bg-teal-700 rounded-t"></div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-6 bg-white">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">mRNA Protection Mechanism</h2>
        <p className="text-gray-600">Comparison: Unprotected vs. Processed mRNA</p>
      </div>

      {/* Controls */}
      <div className="flex justify-center items-center space-x-4 mb-8">
        <button
          onClick={() => setIsRunning(!isRunning)}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          {isRunning ? <Pause size={20} /> : <Play size={20} />}
          <span>{isRunning ? 'Pause' : 'Start'}</span>
        </button>
        
        <button
          onClick={reset}
          className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
        >
          <RotateCcw size={20} />
          <span>Reset</span>
        </button>
        
        <div className="text-sm text-gray-600">
          Time: {(time / 10).toFixed(1)}s
        </div>
      </div>

      {/* Main comparison */}
      <div className="grid grid-cols-2 gap-8 mb-8">
        {/* Unprotected mRNA */}
        <div className="bg-red-50 p-6 rounded-lg border-2 border-red-200">
          <div className="flex items-center space-x-2 mb-4">
            <div className="w-4 h-4 bg-red-500 rounded"></div>
            <h3 className="font-semibold text-red-800">Unprotected mRNA</h3>
          </div>
          
          <div className="mb-6">
            <MRNAStrand health={unprotectedHealth} protected={false} />
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Stability:</span>
              <div className="w-24 h-2 bg-gray-200 rounded">
                <div 
                  className="h-full bg-red-500 rounded transition-all duration-300"
                  style={{ width: `${unprotectedHealth}%` }}
                ></div>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm">Proteins:</span>
              <span className="font-bold text-red-600">{Math.floor(unprotectedProteins)}</span>
            </div>
          </div>
        </div>

        {/* Protected mRNA */}
        <div className="bg-green-50 p-6 rounded-lg border-2 border-green-200">
          <div className="flex items-center space-x-2 mb-4">
            <Shield className="w-4 h-4 text-green-600" />
            <h3 className="font-semibold text-green-800">Processed mRNA</h3>
          </div>
          
          <div className="mb-6">
            <MRNAStrand health={protectedHealth} protected={true} />
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Stability:</span>
              <div className="w-24 h-2 bg-gray-200 rounded">
                <div 
                  className="h-full bg-green-500 rounded transition-all duration-300"
                  style={{ width: `${protectedHealth}%` }}
                ></div>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-sm">Proteins:</span>
              <span className="font-bold text-green-600">{Math.floor(protectedProteins)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Nucleases animation */}
      <div className="relative h-32 bg-gray-50 rounded-lg mb-6 overflow-hidden">
        <div className="absolute top-2 left-2 text-xs text-gray-600">Exonucleases</div>
        {nucleases.map(nuclease => (
          <div
            key={nuclease.id}
            className={`absolute w-4 h-4 rounded-full transition-all duration-100 ${
              nuclease.target === 'unprotected' ? 'bg-red-400' : 'bg-orange-400'
            }`}
            style={{
              left: `${nuclease.x}px`,
              top: `${nuclease.y}px`,
              opacity: nuclease.target === 'protected' && nuclease.x > 200 ? 0.3 : nuclease.opacity
            }}
          >
            <div className="w-2 h-2 bg-white rounded-full mx-auto mt-1"></div>
          </div>
        ))}
        
        <div className="absolute bottom-2 left-4 text-xs text-gray-500">
          Attack on unprotected ends
        </div>
      </div>

      {/* Legend */}
      <div className="grid grid-cols-2 gap-6 text-sm">
        <div className="space-y-2">
          <h4 className="font-semibold text-red-800">Without RNA processing:</h4>
          <ul className="space-y-1 text-gray-700">
            <li>• Rapid degradation by exonucleases</li>
            <li>• Inefficient ribosome binding</li>
            <li>• Low protein production</li>
          </ul>
        </div>
        
        <div className="space-y-2">
          <h4 className="font-semibold text-green-800">With RNA processing:</h4>
          <ul className="space-y-1 text-gray-700">
            <li>• 5′ cap protects from degradation</li>
            <li>• Improved translation</li>
            <li>• Poly-A tail increases stability</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default MRNAProtectionSimulator;
