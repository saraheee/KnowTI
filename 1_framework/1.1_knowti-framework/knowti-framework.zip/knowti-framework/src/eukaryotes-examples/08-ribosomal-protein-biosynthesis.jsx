import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

const RibosomeProteinSynthesis = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [step, setStep] = useState(0);
  const [ribosomeType, setRibosomeType] = useState('free'); // 'free' or 'er'

  const steps = [
    { name: 'mRNA binds', progress: 0 },
    { name: 'Ribosome attaches', progress: 25 },
    { name: 'tRNA brings amino acid', progress: 50 },
    { name: 'Peptide chain grows', progress: 75 },
    { name: 'Protein complete', progress: 100 }
  ];

  useEffect(() => {
    let interval;
    if (isPlaying) {
      interval = setInterval(() => {
        setStep(prev => prev < steps.length - 1 ? prev + 1 : 0);
      }, 2000);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const reset = () => {
    setIsPlaying(false);
    setStep(0);
  };

  const mRNASequence = "AUG-UUC-AAG-UGA";
  const aminoAcids = ["Met", "Phe", "Lys", "Stop"];

  return (
    <div className="w-full max-w-4xl mx-auto p-6 bg-white">
      {/* Header Controls */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-800">Protein Biosynthesis</h1>
        <div className="flex gap-4">
          <button
            onClick={() => setRibosomeType(ribosomeType === 'free' ? 'er' : 'free')}
            className="px-4 py-2 bg-blue-100 text-blue-800 rounded-lg hover:bg-blue-200 transition-colors"
          >
            {ribosomeType === 'free' ? 'Free Ribosomes' : 'ER Ribosomes'}
          </button>
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
          >
            {isPlaying ? <Pause size={16} /> : <Play size={16} />}
            {isPlaying ? 'Pause' : 'Start'}
          </button>
          <button
            onClick={reset}
            className="flex items-center gap-2 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
          >
            <RotateCcw size={16} />
            Reset
          </button>
        </div>
      </div>

      {/* Main Visualization */}
      <div className="relative bg-gray-50 rounded-2xl p-8 mb-6" style={{ height: '400px' }}>
        {/* ER Membrane (if ER type selected) */}
        {ribosomeType === 'er' && (
          <>
            <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-purple-200 to-purple-100 rounded-b-2xl">
              <div className="absolute top-3 left-4 text-sm text-purple-700 font-medium">
                Endoplasmic Reticulum (ER)
              </div>
            </div>
            {/* Ribosomes attached to ER */}
            <div className="absolute bottom-20 left-12">
              <div className="w-8 h-6 bg-orange-400 rounded-t-full"></div>
              <div className="w-6 h-4 bg-orange-300 rounded-b mx-1"></div>
            </div>
            <div className="absolute bottom-20 left-28">
              <div className="w-8 h-6 bg-orange-400 rounded-t-full"></div>
              <div className="w-6 h-4 bg-orange-300 rounded-b mx-1"></div>
            </div>
            <div className="absolute bottom-20 right-20">
              <div className="w-8 h-6 bg-orange-400 rounded-t-full"></div>
              <div className="w-6 h-4 bg-orange-300 rounded-b mx-1"></div>
            </div>
          </>
        )}

        {/* mRNA */}
        <div className="absolute top-20 left-8 right-8">
          <div className="flex items-center mb-2">
            <span className="text-sm font-medium text-gray-600">mRNA (Messenger RNA)</span>
          </div>
          <div className="flex">
            {mRNASequence.split('-').map((codon, i) => (
              <div 
                key={i}
                className={`px-3 py-2 mx-1 rounded text-sm font-mono ${
                  step >= 1 && i <= Math.floor(step * 0.8) ? 'bg-blue-500 text-white' : 'bg-blue-100 text-blue-800'
                }`}
              >
                {codon}
              </div>
            ))}
          </div>
          <div className="text-xs text-gray-500 mt-1">Codons (3 bases each code for 1 amino acid)</div>
        </div>

        {/* Ribosome */}
        <div 
          className={`absolute transition-all duration-1000 ${
            ribosomeType === 'er' ? 'bottom-24' : 'bottom-8'
          }`}
          style={{ 
            left: `${20 + step * 15}%`,
            opacity: step >= 1 ? 1 : 0.3
          }}
        >
          <div className="relative">
            {/* Ribosome Label */}
            <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 text-sm font-medium text-orange-600">
              Ribosome
            </div>
            
            {/* Large Subunit */}
            <div className="w-24 h-16 bg-orange-400 rounded-t-full flex items-center justify-center">
            </div>
            {/* Small Subunit */}
            <div className="w-20 h-12 bg-orange-300 rounded-b-lg mx-2 flex items-center justify-center">
            </div>
            
            {/* tRNA inside ribosome */}
            {step >= 2 && (
              <div className="absolute top-6 left-6 w-8 h-8 bg-green-500 rounded transform rotate-45">
                <div className="absolute -top-1 -left-1 w-2 h-2 bg-red-500 rounded-full"></div>
              </div>
            )}
          </div>
        </div>

        {/* Growing Protein Chain */}
        {step >= 3 && (
          <div 
            className="absolute transition-all duration-1000"
            style={{ 
              left: `${35 + step * 15}%`,
              bottom: ribosomeType === 'er' ? '88px' : '64px'
            }}
          >
            <div className="flex">
              {aminoAcids.slice(0, Math.min(step - 2, 3)).map((aa, i) => (
                <div 
                  key={i}
                  className="w-6 h-6 bg-red-400 rounded-full mx-1 flex items-center justify-center text-xs text-white font-bold"
                  style={{ animationDelay: `${i * 0.5}s` }}
                >
                  {aa}
                </div>
              ))}
            </div>
            <div className="text-xs text-center mt-1 text-gray-600">Protein</div>
          </div>
        )}

        {/* Free tRNA */}
        {step >= 2 && (
          <div className="absolute top-32 right-12">
            <div className="w-6 h-6 bg-green-400 rounded transform rotate-12">
              <div className="absolute -top-1 -left-1 w-2 h-2 bg-red-400 rounded-full"></div>
            </div>
            <div className="text-xs text-center mt-1 text-gray-600">tRNA (Transfer RNA)</div>
          </div>
        )}

        {/* Location Label */}
        <div className="absolute top-4 right-4 px-4 py-2 bg-white rounded-lg shadow-md border-2 border-gray-200">
          <span className="text-lg font-semibold text-gray-800">
            {ribosomeType === 'free' ? 'Cytoplasm' : 'Rough ER'}
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-gray-600">Progress</span>
          <span className="text-sm text-gray-500">{steps[step]?.name}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-green-500 h-2 rounded-full transition-all duration-1000"
            style={{ width: `${steps[step]?.progress || 0}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default RibosomeProteinSynthesis;
