import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, CheckCircle, XCircle } from 'lucide-react';

const ClusterQualityDemo = () => {
  const [isAnimating, setIsAnimating] = useState(false);
  const [quality, setQuality] = useState('good'); // 'good' or 'poor'
  const [progress, setProgress] = useState(100);
  const [speed, setSpeed] = useState(1);
  const [hoveredPoint, setHoveredPoint] = useState(null);
  const [selectedPoint, setSelectedPoint] = useState(null);
  const [showNeighbors, setShowNeighbors] = useState(false);

  // Generate data for both good and poor quality projections
  const generateData = () => {
    const points = [];
    const colors = ['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6'];
    
    // Good quality projection: clear separation
    const goodCenters = [
      { x: 20, y: 20 },
      { x: 80, y: 20 },
      { x: 50, y: 50 },
      { x: 20, y: 80 },
      { x: 80, y: 80 }
    ];
    
    // Poor quality projection: overlapping clusters
    const poorCenters = [
      { x: 45, y: 45 },
      { x: 55, y: 45 },
      { x: 50, y: 50 },
      { x: 45, y: 55 },
      { x: 55, y: 55 }
    ];
    
    for (let clusterIdx = 0; clusterIdx < 5; clusterIdx++) {
      for (let i = 0; i < 18; i++) {
        const angle = Math.random() * Math.PI * 2;
        const radius = Math.random() * 4 + 2;
        
        const goodX = goodCenters[clusterIdx].x + Math.cos(angle) * radius;
        const goodY = goodCenters[clusterIdx].y + Math.sin(angle) * radius;
        
        const poorX = poorCenters[clusterIdx].x + Math.cos(angle) * radius * 2;
        const poorY = poorCenters[clusterIdx].y + Math.sin(angle) * radius * 2;
        
        // Generate high-dimensional coordinates
        const hdCoords = Array(10).fill(0).map((_, dim) => 
          clusterIdx * 20 + (Math.random() - 0.5) * 10
        );
        
        points.push({
          id: `p-${clusterIdx}-${i}`,
          cluster: clusterIdx,
          color: colors[clusterIdx],
          goodX,
          goodY,
          poorX,
          poorY,
          hdCoords
        });
      }
    }
    
    return points;
  };

  const [data] = useState(generateData());

  const getCurrentPosition = (point) => {
    const t = progress / 100;
    if (quality === 'good') {
      return {
        x: point.poorX + (point.goodX - point.poorX) * t,
        y: point.poorY + (point.goodY - point.poorY) * t
      };
    } else {
      return {
        x: point.goodX + (point.poorX - point.goodX) * t,
        y: point.goodY + (point.poorY - point.goodY) * t
      };
    }
  };

  // Calculate high-dimensional distance between two points
  const getHDDistance = (p1, p2) => {
    return Math.sqrt(
      p1.hdCoords.reduce((sum, coord, idx) => 
        sum + Math.pow(coord - p2.hdCoords[idx], 2), 0
      )
    );
  };

  // Calculate 2D distance between two points
  const get2DDistance = (p1, p2) => {
    const pos1 = getCurrentPosition(p1);
    const pos2 = getCurrentPosition(p2);
    return Math.sqrt(
      Math.pow(pos1.x - pos2.x, 2) + Math.pow(pos1.y - pos2.y, 2)
    );
  };

  // Find nearest neighbors in high-dimensional space
  const findHDNeighbors = (point, k = 5) => {
    const distances = data
      .filter(p => p.id !== point.id)
      .map(p => ({ point: p, distance: getHDDistance(point, p) }))
      .sort((a, b) => a.distance - b.distance);
    return distances.slice(0, k).map(d => d.point);
  };

  // Find nearest neighbors in 2D space
  const find2DNeighbors = (point, k = 5) => {
    const distances = data
      .filter(p => p.id !== point.id)
      .map(p => ({ point: p, distance: get2DDistance(point, p) }))
      .sort((a, b) => a.distance - b.distance);
    return distances.slice(0, k).map(d => d.point);
  };

  // Calculate metrics
  const calculateMetrics = () => {
    // 1. Silhouette Score approximation
    let silhouetteSum = 0;
    data.forEach(point => {
      const pos = getCurrentPosition(point);
      const sameCluster = data.filter(p => p.cluster === point.cluster && p.id !== point.id);
      const otherClusters = data.filter(p => p.cluster !== point.cluster);
      
      const avgIntraClusterDist = sameCluster.reduce((sum, p) => {
        const pPos = getCurrentPosition(p);
        return sum + Math.sqrt(Math.pow(pos.x - pPos.x, 2) + Math.pow(pos.y - pPos.y, 2));
      }, 0) / sameCluster.length;
      
      const avgInterClusterDist = otherClusters.reduce((sum, p) => {
        const pPos = getCurrentPosition(p);
        return sum + Math.sqrt(Math.pow(pos.x - pPos.x, 2) + Math.pow(pos.y - pPos.y, 2));
      }, 0) / otherClusters.length;
      
      const s = (avgInterClusterDist - avgIntraClusterDist) / Math.max(avgIntraClusterDist, avgInterClusterDist);
      silhouetteSum += s;
    });
    const silhouetteScore = (silhouetteSum / data.length + 1) * 50; // Normalize to 0-100
    
    // 2. Neighbor Preservation (for selected point)
    let neighborPreservation = 100;
    if (selectedPoint) {
      const point = data.find(p => p.id === selectedPoint);
      const hdNeighbors = findHDNeighbors(point, 5);
      const twoDNeighbors = find2DNeighbors(point, 5);
      const preserved = hdNeighbors.filter(hn => 
        twoDNeighbors.some(tn => tn.id === hn.id)
      ).length;
      neighborPreservation = (preserved / 5) * 100;
    }
    
    // 3. Cluster Compactness
    const clusterVariances = [];
    for (let c = 0; c < 5; c++) {
      const clusterPoints = data.filter(p => p.cluster === c);
      const positions = clusterPoints.map(p => getCurrentPosition(p));
      const centerX = positions.reduce((sum, p) => sum + p.x, 0) / positions.length;
      const centerY = positions.reduce((sum, p) => sum + p.y, 0) / positions.length;
      const variance = positions.reduce((sum, p) => 
        sum + Math.pow(p.x - centerX, 2) + Math.pow(p.y - centerY, 2), 0
      ) / positions.length;
      clusterVariances.push(variance);
    }
    const avgVariance = clusterVariances.reduce((a, b) => a + b, 0) / 5;
    const compactness = Math.max(0, 100 - avgVariance * 0.5);
    
    return {
      silhouetteScore: Math.max(0, Math.min(100, silhouetteScore)),
      neighborPreservation,
      compactness: Math.max(0, Math.min(100, compactness))
    };
  };

  const metrics = calculateMetrics();

  useEffect(() => {
    if (isAnimating && progress < 100) {
      const timer = setTimeout(() => {
        setProgress(prev => Math.min(prev + speed * 2, 100));
      }, 50);
      return () => clearTimeout(timer);
    } else if (progress >= 100) {
      setIsAnimating(false);
    }
  }, [isAnimating, progress, speed]);

  const handleToggle = () => {
    setQuality(prev => prev === 'good' ? 'poor' : 'good');
    setProgress(0);
    setShowNeighbors(false);
  };

  const handleReset = () => {
    setProgress(0);
    setIsAnimating(false);
  };

  const handlePlayPause = () => {
    if (progress >= 100) setProgress(0);
    setIsAnimating(!isAnimating);
  };

  const handlePointClick = (pointId) => {
    setSelectedPoint(pointId);
    setShowNeighbors(true);
  };

  const getScoreColor = (score) => {
    if (score >= 70) return '#10b981';
    if (score >= 40) return '#f59e0b';
    return '#ef4444';
  };

  const getScoreLabel = (score) => {
    if (score >= 70) return 'Excellent';
    if (score >= 40) return 'Moderate';
    return 'Poor';
  };

  return (
    <div style={{ 
      width: '100%', 
      minHeight: '100vh', 
      background: 'white',
      padding: '20px',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      <div style={{ textAlign: 'center', marginBottom: '30px' }}>
        <h1 style={{ 
          fontSize: '28px', 
          fontWeight: '700', 
          color: '#1f2937',
          marginBottom: '8px'
        }}>
          Cluster Quality Demonstrator
        </h1>
        <p style={{ fontSize: '16px', color: '#6b7280' }}>
          Compare good vs poor dimensionality reduction quality
        </p>
      </div>

      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        gap: '15px',
        marginBottom: '30px',
        flexWrap: 'wrap'
      }}>
        <button
          onClick={handlePlayPause}
          style={{
            padding: '12px 24px',
            background: isAnimating ? '#ef4444' : '#10b981',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '15px',
            fontWeight: '600',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
          }}
        >
          {isAnimating ? <Pause size={18} /> : <Play size={18} />}
          {isAnimating ? 'Pause' : 'Animate'}
        </button>

        <button
          onClick={handleToggle}
          style={{
            padding: '12px 24px',
            background: quality === 'good' ? '#10b981' : '#ef4444',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '15px',
            fontWeight: '600',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
          }}
        >
          {quality === 'good' ? <CheckCircle size={18} /> : <XCircle size={18} />}
          Switch to {quality === 'good' ? 'Poor' : 'Good'} Quality
        </button>

        <button
          onClick={handleReset}
          style={{
            padding: '12px 24px',
            background: '#6b7280',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            fontSize: '15px',
            fontWeight: '600',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
          }}
        >
          <RotateCcw size={18} />
          Reset
        </button>
      </div>

      <div style={{ 
        maxWidth: '400px', 
        margin: '0 auto 30px',
        padding: '15px',
        background: '#f9fafb',
        borderRadius: '8px'
      }}>
        <label style={{ 
          display: 'block', 
          marginBottom: '8px',
          fontSize: '14px',
          fontWeight: '600',
          color: '#374151'
        }}>
          Animation Speed: {speed}x
        </label>
        <input
          type="range"
          min="0.5"
          max="3"
          step="0.5"
          value={speed}
          onChange={(e) => setSpeed(parseFloat(e.target.value))}
          style={{ width: '100%' }}
        />
      </div>

      {/* Quality Metrics Dashboard */}
      <div style={{
        maxWidth: '1200px',
        margin: '0 auto 30px',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '20px'
      }}>
        <div style={{
          background: 'white',
          border: `3px solid ${getScoreColor(metrics.silhouetteScore)}`,
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ 
            fontSize: '14px', 
            fontWeight: '600',
            color: '#6b7280',
            marginBottom: '8px'
          }}>
            Silhouette Score
          </div>
          <div style={{ 
            fontSize: '36px', 
            fontWeight: '700',
            color: getScoreColor(metrics.silhouetteScore),
            marginBottom: '8px'
          }}>
            {metrics.silhouetteScore.toFixed(0)}%
          </div>
          <div style={{
            fontSize: '13px',
            color: '#6b7280',
            marginBottom: '12px'
          }}>
            {getScoreLabel(metrics.silhouetteScore)} - Cluster separation quality
          </div>
          <div style={{ 
            background: '#f3f4f6',
            borderRadius: '999px',
            height: '8px',
            overflow: 'hidden'
          }}>
            <div style={{
              background: getScoreColor(metrics.silhouetteScore),
              height: '100%',
              width: `${metrics.silhouetteScore}%`,
              transition: 'width 0.3s ease'
            }} />
          </div>
        </div>

        <div style={{
          background: 'white',
          border: `3px solid ${getScoreColor(metrics.neighborPreservation)}`,
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ 
            fontSize: '14px', 
            fontWeight: '600',
            color: '#6b7280',
            marginBottom: '8px'
          }}>
            Neighbor Preservation
          </div>
          <div style={{ 
            fontSize: '36px', 
            fontWeight: '700',
            color: getScoreColor(metrics.neighborPreservation),
            marginBottom: '8px'
          }}>
            {metrics.neighborPreservation.toFixed(0)}%
          </div>
          <div style={{
            fontSize: '13px',
            color: '#6b7280',
            marginBottom: '12px'
          }}>
            {getScoreLabel(metrics.neighborPreservation)} - {selectedPoint ? 'For selected point' : 'Click a point to measure'}
          </div>
          <div style={{ 
            background: '#f3f4f6',
            borderRadius: '999px',
            height: '8px',
            overflow: 'hidden'
          }}>
            <div style={{
              background: getScoreColor(metrics.neighborPreservation),
              height: '100%',
              width: `${metrics.neighborPreservation}%`,
              transition: 'width 0.3s ease'
            }} />
          </div>
        </div>

        <div style={{
          background: 'white',
          border: `3px solid ${getScoreColor(metrics.compactness)}`,
          borderRadius: '12px',
          padding: '20px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ 
            fontSize: '14px', 
            fontWeight: '600',
            color: '#6b7280',
            marginBottom: '8px'
          }}>
            Cluster Compactness
          </div>
          <div style={{ 
            fontSize: '36px', 
            fontWeight: '700',
            color: getScoreColor(metrics.compactness),
            marginBottom: '8px'
          }}>
            {metrics.compactness.toFixed(0)}%
          </div>
          <div style={{
            fontSize: '13px',
            color: '#6b7280',
            marginBottom: '12px'
          }}>
            {getScoreLabel(metrics.compactness)} - How tight clusters are
          </div>
          <div style={{ 
            background: '#f3f4f6',
            borderRadius: '999px',
            height: '8px',
            overflow: 'hidden'
          }}>
            <div style={{
              background: getScoreColor(metrics.compactness),
              height: '100%',
              width: `${metrics.compactness}%`,
              transition: 'width 0.3s ease'
            }} />
          </div>
        </div>
      </div>

      <div style={{ 
        display: 'flex', 
        justifyContent: 'center',
        gap: '30px',
        flexWrap: 'wrap',
        alignItems: 'flex-start'
      }}>
        {/* Visualization */}
        <div style={{ position: 'relative' }}>
          <svg 
            width="550" 
            height="550" 
            style={{ 
              border: '2px solid #e5e7eb',
              borderRadius: '12px',
              background: '#fafafa'
            }}
          >
            {[0, 25, 50, 75, 100].map(val => (
              <React.Fragment key={val}>
                <line
                  x1={val * 5.5}
                  y1="0"
                  x2={val * 5.5}
                  y2="550"
                  stroke="#f0f0f0"
                  strokeWidth="1"
                />
                <line
                  x1="0"
                  y1={val * 5.5}
                  x2="550"
                  y2={val * 5.5}
                  stroke="#f0f0f0"
                  strokeWidth="1"
                />
              </React.Fragment>
            ))}

            {/* Show neighbor connections */}
            {showNeighbors && selectedPoint && (() => {
              const point = data.find(p => p.id === selectedPoint);
              const hdNeighbors = findHDNeighbors(point, 5);
              const twoDNeighbors = find2DNeighbors(point, 5);
              const pos = getCurrentPosition(point);
              
              return (
                <>
                  {/* HD neighbors (should be preserved) - green lines */}
                  {hdNeighbors.map(neighbor => {
                    const nPos = getCurrentPosition(neighbor);
                    const isAlso2DNeighbor = twoDNeighbors.some(tn => tn.id === neighbor.id);
                    return (
                      <line
                        key={`hd-${neighbor.id}`}
                        x1={pos.x * 5.5}
                        y1={pos.y * 5.5}
                        x2={nPos.x * 5.5}
                        y2={nPos.y * 5.5}
                        stroke={isAlso2DNeighbor ? '#10b981' : '#ef4444'}
                        strokeWidth="2"
                        opacity="0.6"
                        strokeDasharray={isAlso2DNeighbor ? '0' : '5,5'}
                      />
                    );
                  })}
                </>
              );
            })()}

            {/* Data points */}
            {data.map(point => {
              const pos = getCurrentPosition(point);
              const t = progress / 100;
              const isHovered = hoveredPoint === point.id;
              const isSelected = selectedPoint === point.id;
              const isHDNeighbor = selectedPoint && showNeighbors && 
                findHDNeighbors(data.find(p => p.id === selectedPoint), 5).some(n => n.id === point.id);
              
              return (
                <circle
                  key={point.id}
                  cx={pos.x * 5.5}
                  cy={pos.y * 5.5}
                  r={isSelected ? 12 : isHovered || isHDNeighbor ? 9 : 6}
                  fill={point.color}
                  opacity={t * 0.85 + (isHovered || isSelected ? 0.15 : 0)}
                  stroke={isSelected ? '#1f2937' : 'white'}
                  strokeWidth={isSelected ? 3 : 2}
                  style={{ 
                    cursor: 'pointer',
                    transition: 'all 0.2s ease'
                  }}
                  onMouseEnter={() => setHoveredPoint(point.id)}
                  onMouseLeave={() => setHoveredPoint(null)}
                  onClick={() => handlePointClick(point.id)}
                />
              );
            })}

            <text x="275" y="30" textAnchor="middle" fontSize="20" fontWeight="bold" fill="#1f2937">
              {quality === 'good' ? '✓ Good Quality Projection' : '✗ Poor Quality Projection'}
            </text>
          </svg>
        </div>

        {/* Info Panel */}
        <div style={{ maxWidth: '340px' }}>
          <div style={{
            background: quality === 'good' ? '#f0fdf4' : '#fee2e2',
            padding: '20px',
            borderRadius: '12px',
            border: `3px solid ${quality === 'good' ? '#86efac' : '#fca5a5'}`,
            marginBottom: '20px'
          }}>
            <h3 style={{ 
              fontSize: '18px', 
              fontWeight: '700',
              marginBottom: '12px',
              color: quality === 'good' ? '#065f46' : '#991b1b'
            }}>
              {quality === 'good' ? '✓ Good Dimensionality Reduction' : '✗ Poor Dimensionality Reduction'}
            </h3>
            <p style={{ 
              fontSize: '14px', 
              color: '#374151',
              lineHeight: '1.6',
              margin: 0
            }}>
              {quality === 'good' 
                ? 'Clusters are well-separated and distinct. Points close in high-dimensional space remain close in 2D. Local neighborhoods are preserved, making patterns easy to identify.'
                : 'Clusters overlap significantly. Points that are far apart in high-dimensional space appear close in 2D. Local structure is destroyed, making the visualization misleading.'}
            </p>
          </div>

          <div style={{
            background: '#f9fafb',
            padding: '20px',
            borderRadius: '12px',
            marginBottom: '20px',
            border: '2px solid #e5e7eb'
          }}>
            <h3 style={{ 
              fontSize: '16px', 
              fontWeight: '700',
              marginBottom: '15px',
              color: '#1f2937'
            }}>
              Clusters
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6'].map((color, idx) => (
                <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div style={{ 
                    width: '20px', 
                    height: '20px', 
                    borderRadius: '50%', 
                    background: color,
                    border: '2px solid white',
                    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                  }} />
                  <span style={{ fontSize: '14px', color: '#374151' }}>
                    Cluster {idx + 1} (18 points)
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div style={{
            background: '#eff6ff',
            padding: '20px',
            borderRadius: '12px',
            border: '2px solid #93c5fd',
            marginBottom: '20px'
          }}>
            <h3 style={{ 
              fontSize: '16px', 
              fontWeight: '700',
              marginBottom: '12px',
              color: '#1e40af'
            }}>
              📊 Understanding Metrics
            </h3>
            <div style={{ fontSize: '13px', color: '#1e40af', lineHeight: '1.7' }}>
              <div style={{ marginBottom: '10px' }}>
                <strong>Silhouette Score:</strong> Measures cluster separation vs compactness. Higher is better.
              </div>
              <div style={{ marginBottom: '10px' }}>
                <strong>Neighbor Preservation:</strong> % of high-D neighbors that remain neighbors in 2D.
              </div>
              <div>
                <strong>Compactness:</strong> How tightly grouped points within clusters are.
              </div>
            </div>
          </div>

          <div style={{
            background: '#fef3c7',
            padding: '15px',
            borderRadius: '8px',
            border: '2px solid #fbbf24'
          }}>
            <p style={{ 
              fontSize: '13px', 
              color: '#92400e',
              margin: 0,
              lineHeight: '1.5'
            }}>
              💡 <strong>Try this:</strong> Click any point to see its nearest neighbors in high-D space. Green lines show preserved neighbors, red dashed lines show broken neighborhoods!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClusterQualityDemo;