import React, { useState, useMemo } from 'react';
import { X } from 'lucide-react';

const PETTBRHistogram = () => {
  // Generate realistic PET TBR data for right side (orange)
  const generateRightData = () => {
    const data = [];
    for (let i = 0; i < 1925; i++) {
      const rand = Math.random();
      let value;
      if (rand < 0.7) {
        value = Math.random() * 2 + Math.random() * 0.5;
      } else if (rand < 0.95) {
        value = Math.random() * 8 + 2;
      } else {
        value = Math.random() * 80 + 10;
      }
      data.push(value);
    }
    return data;
  };

  // Generate different data for left side (green/teal)
  const generateLeftData = () => {
    const data = [];
    for (let i = 0; i < 1500; i++) {
      const rand = Math.random();
      let value;
      if (rand < 0.8) {
        value = Math.random() * 1.5 + Math.random() * 0.3;
      } else if (rand < 0.96) {
        value = Math.random() * 6 + 1.5;
      } else {
        value = Math.random() * 25 + 7;
      }
      data.push(value);
    }
    return data;
  };

  const [rightData] = useState(generateRightData());
  const [leftData] = useState(generateLeftData());
  const [hoveredSide, setHoveredSide] = useState(null);
  const [hoveredBin, setHoveredBin] = useState(null);
  const [selectedBar, setSelectedBar] = useState(null);

  // Calculate statistics for each dataset
  const calculateStats = (data) => {
    const sorted = [...data].sort((a, b) => a - b);
    const mean = data.reduce((a, b) => a + b, 0) / data.length;
    const median = sorted[Math.floor(sorted.length / 2)];
    const min = sorted[0];
    const max = sorted[sorted.length - 1];
    return { mean, median, min, max };
  };

  const leftStats = useMemo(() => calculateStats(leftData), [leftData]);
  const rightStats = useMemo(() => calculateStats(rightData), [rightData]);

  // Create histogram bins for right side
  const rightHistogram = useMemo(() => {
    const binWidth = 5;
    const maxValue = Math.max(...rightData);
    const binCount = Math.ceil(maxValue / binWidth);
    
    const bins = Array.from({ length: binCount }, (_, i) => ({
      start: i * binWidth,
      end: (i + 1) * binWidth,
      count: 0,
      values: []
    }));

    rightData.forEach(value => {
      const binIndex = Math.min(Math.floor(value / binWidth), binCount - 1);
      bins[binIndex].count++;
      bins[binIndex].values.push(value);
    });

    return bins.map((bin, i) => ({
      label: bin.start,
      rangeEnd: bin.end,
      count: bin.count,
      values: bin.values,
      percentage: (bin.count / rightData.length * 100).toFixed(1),
      mean: bin.values.length > 0 ? (bin.values.reduce((a, b) => a + b, 0) / bin.values.length).toFixed(2) : 0,
      index: i
    }));
  }, [rightData]);

  // Create histogram bins for left side
  const leftHistogram = useMemo(() => {
    const binWidth = 5;
    const maxValue = Math.max(...leftData);
    const binCount = Math.ceil(maxValue / binWidth);
    
    const bins = Array.from({ length: binCount }, (_, i) => ({
      start: i * binWidth,
      end: (i + 1) * binWidth,
      count: 0,
      values: []
    }));

    leftData.forEach(value => {
      const binIndex = Math.min(Math.floor(value / binWidth), binCount - 1);
      bins[binIndex].count++;
      bins[binIndex].values.push(value);
    });

    return bins.map((bin, i) => ({
      label: bin.start,
      rangeEnd: bin.end,
      count: bin.count,
      values: bin.values,
      percentage: (bin.count / leftData.length * 100).toFixed(1),
      mean: bin.values.length > 0 ? (bin.values.reduce((a, b) => a + b, 0) / bin.values.length).toFixed(2) : 0,
      index: i
    }));
  }, [leftData]);

  const maxCount = Math.max(
    Math.max(...rightHistogram.map(d => d.count)),
    Math.max(...leftHistogram.map(d => d.count))
  );

  const maxBins = Math.max(rightHistogram.length, leftHistogram.length);
  const barHeight = 40;

  const handleBarClick = (side, bar) => {
    setSelectedBar({ side, bar });
  };

  return (
    <div className="w-full h-full bg-white p-8 overflow-auto">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-xl font-semibold text-gray-800 mb-1">
            PET TBR 2mm BSO 1 nephr area
          </h1>
          <p className="text-gray-600 text-sm">
            Left: n = {leftData.length} | Right: n = {rightData.length}
          </p>
        </div>

        {/* Chart */}
        <div className="bg-white rounded-lg mb-8 relative">
          <svg width="100%" height={maxBins * barHeight + 60} className="overflow-visible">
            {/* Y-axis labels */}
            <g transform="translate(0, 30)">
              {Array.from({ length: maxBins }).map((_, i) => (
                <text
                  key={i}
                  x="50%"
                  y={i * barHeight + barHeight / 2}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  className="text-base fill-gray-700 font-semibold"
                >
                  {i * 5}
                </text>
              ))}
            </g>

            {/* Center line */}
            <line
              x1="50%"
              y1="20"
              x2="50%"
              y2={maxBins * barHeight + 40}
              stroke="#d1d5db"
              strokeWidth="2"
            />

            {/* Left bars (Teal/Green) - Mirrored */}
            <g transform="translate(0, 30)">
              {leftHistogram.map((bar, i) => {
                const barWidthPercent = (bar.count / maxCount) * 45;
                const isHovered = hoveredSide === 'left' && hoveredBin === i;
                const isOtherHovered = hoveredSide === 'right' || (hoveredSide === 'left' && hoveredBin !== i);
                
                return (
                  <g key={`left-${i}`}>
                    <rect
                      x={`calc(50% - ${barWidthPercent}%)`}
                      y={i * barHeight + 2}
                      width={`${barWidthPercent}%`}
                      height={barHeight - 4}
                      fill="#4db8a8"
                      opacity={isOtherHovered && !isHovered ? 0.3 : 1}
                      className="cursor-pointer transition-opacity duration-200"
                      onMouseEnter={() => {
                        setHoveredSide('left');
                        setHoveredBin(i);
                      }}
                      onMouseLeave={() => {
                        setHoveredSide(null);
                        setHoveredBin(null);
                      }}
                      onClick={() => handleBarClick('left', bar)}
                    />
                    {isHovered && (
                      <g>
                        <rect
                          x={`calc(50% - ${barWidthPercent}% - 85)`}
                          y={i * barHeight + 5}
                          width="75"
                          height="30"
                          fill="white"
                          stroke="#4db8a8"
                          strokeWidth="2"
                          rx="6"
                        />
                        <text
                          x={`calc(50% - ${barWidthPercent}% - 47.5)`}
                          y={i * barHeight + 23}
                          textAnchor="middle"
                          className="text-sm fill-gray-800 font-bold"
                        >
                          {bar.count}
                        </text>
                      </g>
                    )}
                  </g>
                );
              })}
            </g>

            {/* Right bars (Orange) */}
            <g transform="translate(0, 30)">
              {rightHistogram.map((bar, i) => {
                const barWidthPercent = (bar.count / maxCount) * 45;
                const isHovered = hoveredSide === 'right' && hoveredBin === i;
                const isOtherHovered = hoveredSide === 'left' || (hoveredSide === 'right' && hoveredBin !== i);
                
                return (
                  <g key={`right-${i}`}>
                    <rect
                      x="50%"
                      y={i * barHeight + 2}
                      width={`${barWidthPercent}%`}
                      height={barHeight - 4}
                      fill="#f59e42"
                      opacity={isOtherHovered && !isHovered ? 0.3 : 1}
                      className="cursor-pointer transition-opacity duration-200"
                      onMouseEnter={() => {
                        setHoveredSide('right');
                        setHoveredBin(i);
                      }}
                      onMouseLeave={() => {
                        setHoveredSide(null);
                        setHoveredBin(null);
                      }}
                      onClick={() => handleBarClick('right', bar)}
                    />
                    {isHovered && (
                      <g>
                        <rect
                          x={`calc(50% + ${barWidthPercent}% + 10)`}
                          y={i * barHeight + 5}
                          width="75"
                          height="30"
                          fill="white"
                          stroke="#f59e42"
                          strokeWidth="2"
                          rx="6"
                        />
                        <text
                          x={`calc(50% + ${barWidthPercent}% + 47.5)`}
                          y={i * barHeight + 23}
                          textAnchor="middle"
                          className="text-sm fill-gray-800 font-bold"
                        >
                          {bar.count}
                        </text>
                      </g>
                    )}
                  </g>
                );
              })}
            </g>

            {/* X-axis labels - LARGER */}
            <g transform={`translate(0, ${maxBins * barHeight + 45})`}>
              <text x="10%" textAnchor="middle" className="text-base fill-gray-700 font-semibold">
                {maxCount}
              </text>
              <text x="25%" textAnchor="middle" className="text-base fill-gray-600">
                {Math.round(maxCount * 0.75)}
              </text>
              <text x="40%" textAnchor="middle" className="text-base fill-gray-600">
                {Math.round(maxCount * 0.5)}
              </text>
              <text x="50%" textAnchor="middle" className="text-lg fill-gray-800 font-bold">
                0
              </text>
              <text x="60%" textAnchor="middle" className="text-base fill-gray-600">
                {Math.round(maxCount * 0.5)}
              </text>
              <text x="75%" textAnchor="middle" className="text-base fill-gray-600">
                {Math.round(maxCount * 0.75)}
              </text>
              <text x="90%" textAnchor="middle" className="text-base fill-gray-700 font-semibold">
                {maxCount}
              </text>
            </g>
            
            {/* X-axis label */}
            <text 
              x="50%" 
              y={maxBins * barHeight + 80} 
              textAnchor="middle" 
              className="text-sm fill-gray-600 font-medium"
            >
              Frequency (Count)
            </text>
          </svg>
        </div>

        {/* Legend */}
        <div className="flex justify-center gap-8 mb-8">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-teal-500 rounded"></div>
            <span className="text-sm text-gray-700 font-medium">Left Distribution</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-orange-500 rounded"></div>
            <span className="text-sm text-gray-700 font-medium">Right Distribution</span>
          </div>
        </div>

        {/* Detailed Information Panel - Click */}
        {selectedBar && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={() => setSelectedBar(null)}>
            <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full mx-4" onClick={(e) => e.stopPropagation()}>
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-1">
                    Range {selectedBar.bar.label}-{selectedBar.bar.rangeEnd}
                  </h3>
                  <p className={`text-sm font-medium ${selectedBar.side === 'left' ? 'text-teal-600' : 'text-orange-600'}`}>
                    {selectedBar.side === 'left' ? 'Left' : 'Right'} Distribution
                  </p>
                </div>
                <button 
                  onClick={() => setSelectedBar(null)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="text-sm font-semibold text-gray-600 mb-3">Bin Statistics</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-700">Count:</span>
                      <span className="font-semibold text-gray-900">{selectedBar.bar.count} patients</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Percentage:</span>
                      <span className="font-semibold text-gray-900">{selectedBar.bar.percentage}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Mean in bin:</span>
                      <span className="font-semibold text-gray-900">{selectedBar.bar.mean}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Range:</span>
                      <span className="font-semibold text-gray-900">{selectedBar.bar.label} - {selectedBar.bar.rangeEnd}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 rounded-lg p-4">
                  <h4 className="text-sm font-semibold text-blue-900 mb-2">Dataset Overview</h4>
                  <div className="space-y-2 text-sm">
                    {selectedBar.side === 'left' ? (
                      <>
                        <div className="flex justify-between">
                          <span className="text-blue-800">Total samples:</span>
                          <span className="font-semibold text-blue-900">{leftData.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-blue-800">Mean:</span>
                          <span className="font-semibold text-blue-900">{leftStats.mean.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-blue-800">Median:</span>
                          <span className="font-semibold text-blue-900">{leftStats.median.toFixed(2)}</span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex justify-between">
                          <span className="text-blue-800">Total samples:</span>
                          <span className="font-semibold text-blue-900">{rightData.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-blue-800">Mean:</span>
                          <span className="font-semibold text-blue-900">{rightStats.mean.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-blue-800">Median:</span>
                          <span className="font-semibold text-blue-900">{rightStats.median.toFixed(2)}</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                <div className="bg-purple-50 rounded-lg p-4">
                  <h4 className="text-sm font-semibold text-purple-900 mb-2">💡 Insight</h4>
                  <p className="text-sm text-purple-800">
                    This bin contains <strong>{selectedBar.bar.percentage}%</strong> of all {selectedBar.side} distribution data points.
                    {parseFloat(selectedBar.bar.percentage) > 10 && " This is a highly concentrated range!"}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Learning Insights - Clean white background */}
        <div className="bg-white rounded-xl shadow-lg border-2 border-gray-200 p-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <span className="text-2xl">📊</span> Key Insights
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-800 mb-2">✓ Butterfly Chart Design</h4>
              <p className="text-sm text-gray-700">
                This mirror histogram allows direct comparison between two distributions, sharing a common axis at the center.
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-800 mb-2">✓ Compare Distributions</h4>
              <p className="text-sm text-gray-700">
                Notice how the left (teal) and right (orange) distributions have different shapes and concentrations.
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-800 mb-2">✓ Interactive Exploration</h4>
              <p className="text-sm text-gray-700">
                <strong>Hover</strong> over any bar to see the exact count. <strong>Click</strong> any bar for detailed information panel.
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-800 mb-2">✓ Pattern Recognition</h4>
              <p className="text-sm text-gray-700">
                Both sides show right-skewed distributions typical of medical imaging data, with most values at lower ranges.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PETTBRHistogram;