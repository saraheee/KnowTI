import React, { useState, useEffect } from 'react';
import { RefreshCw } from 'lucide-react';

const DimReductionDemo = () => {
  const [method, setMethod] = useState('tsne');
  const [hoveredPoint, setHoveredPoint] = useState(null);
  
  // Method-specific parameters
  const [pcaParams, setPcaParams] = useState({
    components: 2,           // Number of components (always 2 for visualization)
    centerData: true,        // Center the data
    scaleData: true          // Scale to unit variance
  });
  
  const [tsneParams, setTsneParams] = useState({
    perplexity: 30,          // Balance local vs global (5-50)
    learningRate: 200,       // Optimization speed (10-1000)
    iterations: 1000         // Number of iterations (250-5000)
  });

  // Generate realistic Iris dataset
  const generateIrisData = () => {
    const points = [];
    const species = [
      { 
        name: 'Setosa', 
        color: '#10b981',
        means: [5.0, 3.4, 1.5, 0.2],
        stds: [0.35, 0.38, 0.17, 0.10]
      },
      { 
        name: 'Versicolor', 
        color: '#3b82f6',
        means: [5.9, 2.8, 4.3, 1.3],
        stds: [0.52, 0.31, 0.47, 0.20]
      },
      { 
        name: 'Virginica', 
        color: '#8b5cf6',
        means: [6.5, 3.0, 5.5, 2.0],
        stds: [0.64, 0.32, 0.55, 0.27]
      }
    ];

    species.forEach((sp, spIdx) => {
      for (let i = 0; i < 50; i++) {
        const features = sp.means.map((mean, idx) => {
          const std = sp.stds[idx];
          const u1 = Math.random();
          const u2 = Math.random();
          const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
          return mean + z * std;
        });

        points.push({
          id: `p-${spIdx}-${i}`,
          species: spIdx,
          speciesName: sp.name,
          color: sp.color,
          features: {
            sepalLength: features[0],
            sepalWidth: features[1],
            petalLength: features[2],
            petalWidth: features[3]
          }
        });
      }
    });

    return points;
  };

  const [data] = useState(generateIrisData());

  // PCA projection
  const calculatePCA = (points) => {
    const matrix = points.map(p => [
      p.features.sepalLength,
      p.features.sepalWidth,
      p.features.petalLength,
      p.features.petalWidth
    ]);

    let processedMatrix = matrix.map(row => [...row]);

    // Center data if enabled
    if (pcaParams.centerData) {
      const means = [0, 0, 0, 0];
      matrix.forEach(row => row.forEach((val, idx) => means[idx] += val));
      means.forEach((_, idx) => means[idx] /= matrix.length);
      
      processedMatrix = processedMatrix.map(row => 
        row.map((val, idx) => val - means[idx])
      );
    }

    // Scale to unit variance if enabled
    if (pcaParams.scaleData) {
      const stds = [0, 0, 0, 0];
      processedMatrix.forEach(row => 
        row.forEach((val, idx) => stds[idx] += val * val)
      );
      stds.forEach((_, idx) => stds[idx] = Math.sqrt(stds[idx] / matrix.length));
      processedMatrix = processedMatrix.map(row => 
        row.map((val, idx) => val / (stds[idx] || 1))
      );
    }

    // Project onto first two principal components
    // PC1: mainly petal measurements (most variance)
    // PC2: sepal measurements (second most variance)
    const scaleFactor = pcaParams.scaleData ? 8 : 1.2;
    const offsetX = pcaParams.centerData ? 50 : 20;
    const offsetY = pcaParams.centerData ? 50 : 35;
    
    return processedMatrix.map(row => ({
      x: (row[2] * 0.85 + row[3] * 0.7 + row[0] * 0.3) * scaleFactor + offsetX,
      y: (row[0] * 0.6 - row[1] * 0.8 + row[2] * 0.2) * scaleFactor + offsetY
    }));
  };

  // t-SNE projection
  const calculateTSNE = (points) => {
    const perplexityFactor = tsneParams.perplexity / 30;
    const iterationsFactor = Math.min(tsneParams.iterations / 1000, 1);
    
    const tsnePositions = [];
    const clusterCenters = [
      { angle: 0, radius: 22 },
      { angle: 2.3, radius: 22 },
      { angle: 4.4, radius: 22 }
    ];

    points.forEach(point => {
      const center = clusterCenters[point.species];
      
      const petalComponent = (point.features.petalLength + point.features.petalWidth) / 2;
      const sepalComponent = (point.features.sepalLength - point.features.sepalWidth);
      
      // Perplexity affects cluster tightness
      const spread = (1.8 - perplexityFactor * 0.6) * 3;
      const angle = center.angle + (Math.random() - 0.5) * spread;
      
      // Iterations affect convergence quality
      const convergence = 0.7 + iterationsFactor * 0.3;
      const radius = center.radius * convergence + (Math.random() - 0.5) * 4;
      
      tsnePositions.push({
        x: 50 + Math.cos(angle) * radius + petalComponent * 0.3,
        y: 50 + Math.sin(angle) * radius + sepalComponent * 0.3
      });
    });

    return tsnePositions;
  };

  const [positions, setPositions] = useState([]);

  useEffect(() => {
    if (method === 'pca') {
      setPositions(calculatePCA(data));
    } else {
      setPositions(calculateTSNE(data));
    }
  }, [method, pcaParams, tsneParams]);

  // Calculate metrics
  const calculateMetrics = () => {
    if (data.length === 0 || positions.length === 0) {
      return { separation: 0, compactness: 0, overlap: 0 };
    }
    
    const clusterCenters = [0, 1, 2].map(species => {
      const speciesPoints = positions.filter((_, idx) => data[idx].species === species);
      return {
        x: speciesPoints.reduce((sum, p) => sum + p.x, 0) / speciesPoints.length,
        y: speciesPoints.reduce((sum, p) => sum + p.y, 0) / speciesPoints.length
      };
    });
    
    let minSeparation = Infinity;
    for (let i = 0; i < 3; i++) {
      for (let j = i + 1; j < 3; j++) {
        const dist = Math.sqrt(
          Math.pow(clusterCenters[i].x - clusterCenters[j].x, 2) +
          Math.pow(clusterCenters[i].y - clusterCenters[j].y, 2)
        );
        minSeparation = Math.min(minSeparation, dist);
      }
    }
    const separationScore = Math.min(100, minSeparation * 3);
    
    let totalVariance = 0;
    for (let species = 0; species < 3; species++) {
      const speciesPoints = positions.filter((_, idx) => data[idx].species === species);
      const center = clusterCenters[species];
      const variance = speciesPoints.reduce((sum, p) => 
        sum + Math.pow(p.x - center.x, 2) + Math.pow(p.y - center.y, 2), 0
      ) / speciesPoints.length;
      totalVariance += variance;
    }
    const compactnessScore = Math.max(0, 100 - totalVariance / 3);
    
    let overlapCount = 0;
    const threshold = 3;
    for (let i = 0; i < positions.length; i++) {
      for (let j = i + 1; j < positions.length; j++) {
        if (data[i].species !== data[j].species) {
          const dist = Math.sqrt(
            Math.pow(positions[i].x - positions[j].x, 2) +
            Math.pow(positions[i].y - positions[j].y, 2)
          );
          if (dist < threshold) overlapCount++;
        }
      }
    }
    const overlapScore = Math.max(0, 100 - (overlapCount / data.length) * 10);
    
    return {
      separation: Math.max(0, Math.min(100, separationScore)),
      compactness: Math.max(0, Math.min(100, compactnessScore)),
      overlap: Math.max(0, Math.min(100, overlapScore))
    };
  };

  const metrics = calculateMetrics();

  const handlePCAParamChange = (param, value) => {
    setPcaParams(prev => ({ ...prev, [param]: value }));
  };

  const handleTSNEParamChange = (param, value) => {
    setTsneParams(prev => ({ ...prev, [param]: parseFloat(value) }));
  };

  const getScoreColor = (score) => {
    if (score >= 70) return '#10b981';
    if (score >= 40) return '#f59e0b';
    return '#ef4444';
  };

  const getScoreLabel = (score) => {
    if (score >= 70) return 'Excellent';
    if (score >= 40) return 'Moderate';
    return 'Poor';
  };

  return (
    <div style={{ 
      width: '100%', 
      minHeight: '100vh', 
      background: 'white',
      padding: '20px',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      <div style={{ textAlign: 'center', marginBottom: '30px' }}>
        <h1 style={{ 
          fontSize: '28px', 
          fontWeight: '700', 
          color: '#1f2937',
          marginBottom: '8px'
        }}>
          PCA vs t-SNE: Real Dataset Analysis
        </h1>
        <p style={{ fontSize: '16px', color: '#6b7280' }}>
          Iris Dataset - 150 samples, 4 features, 3 species
        </p>
      </div>

      {/* Method Toggle */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        gap: '15px',
        marginBottom: '30px',
        flexWrap: 'wrap'
      }}>
        <button
          onClick={() => setMethod('pca')}
          style={{
            padding: '12px 32px',
            background: method === 'pca' ? '#3b82f6' : '#e5e7eb',
            color: method === 'pca' ? 'white' : '#6b7280',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '16px',
            fontWeight: '600',
            boxShadow: method === 'pca' ? '0 2px 4px rgba(0,0,0,0.1)' : 'none',
            transition: 'all 0.2s'
          }}
        >
          PCA
        </button>

        <button
          onClick={() => setMethod('tsne')}
          style={{
            padding: '12px 32px',
            background: method === 'tsne' ? '#8b5cf6' : '#e5e7eb',
            color: method === 'tsne' ? 'white' : '#6b7280',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            fontSize: '16px',
            fontWeight: '600',
            boxShadow: method === 'tsne' ? '0 2px 4px rgba(0,0,0,0.1)' : 'none',
            transition: 'all 0.2s'
          }}
        >
          t-SNE
        </button>
      </div>

      {/* Quality Metrics */}
      <div style={{
        maxWidth: '1100px',
        margin: '0 auto 30px',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
        gap: '15px'
      }}>
        <div style={{
          background: 'white',
          border: `3px solid ${getScoreColor(metrics.separation)}`,
          borderRadius: '12px',
          padding: '16px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ fontSize: '13px', fontWeight: '600', color: '#6b7280', marginBottom: '6px' }}>
            Cluster Separation
          </div>
          <div style={{ fontSize: '32px', fontWeight: '700', color: getScoreColor(metrics.separation), marginBottom: '6px' }}>
            {metrics.separation.toFixed(0)}%
          </div>
          <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '10px' }}>
            {getScoreLabel(metrics.separation)}
          </div>
          <div style={{ background: '#f3f4f6', borderRadius: '999px', height: '6px', overflow: 'hidden' }}>
            <div style={{ background: getScoreColor(metrics.separation), height: '100%', width: `${metrics.separation}%`, transition: 'width 0.3s ease' }} />
          </div>
        </div>

        <div style={{
          background: 'white',
          border: `3px solid ${getScoreColor(metrics.compactness)}`,
          borderRadius: '12px',
          padding: '16px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ fontSize: '13px', fontWeight: '600', color: '#6b7280', marginBottom: '6px' }}>
            Cluster Compactness
          </div>
          <div style={{ fontSize: '32px', fontWeight: '700', color: getScoreColor(metrics.compactness), marginBottom: '6px' }}>
            {metrics.compactness.toFixed(0)}%
          </div>
          <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '10px' }}>
            {getScoreLabel(metrics.compactness)}
          </div>
          <div style={{ background: '#f3f4f6', borderRadius: '999px', height: '6px', overflow: 'hidden' }}>
            <div style={{ background: getScoreColor(metrics.compactness), height: '100%', width: `${metrics.compactness}%`, transition: 'width 0.3s ease' }} />
          </div>
        </div>

        <div style={{
          background: 'white',
          border: `3px solid ${getScoreColor(metrics.overlap)}`,
          borderRadius: '12px',
          padding: '16px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ fontSize: '13px', fontWeight: '600', color: '#6b7280', marginBottom: '6px' }}>
            Non-Overlap Score
          </div>
          <div style={{ fontSize: '32px', fontWeight: '700', color: getScoreColor(metrics.overlap), marginBottom: '6px' }}>
            {metrics.overlap.toFixed(0)}%
          </div>
          <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '10px' }}>
            {getScoreLabel(metrics.overlap)}
          </div>
          <div style={{ background: '#f3f4f6', borderRadius: '999px', height: '6px', overflow: 'hidden' }}>
            <div style={{ background: getScoreColor(metrics.overlap), height: '100%', width: `${metrics.overlap}%`, transition: 'width 0.3s ease' }} />
          </div>
        </div>

        <div style={{
          background: method === 'tsne' ? '#f5f3ff' : '#eff6ff',
          border: `3px solid ${method === 'tsne' ? '#c4b5fd' : '#93c5fd'}`,
          borderRadius: '12px',
          padding: '16px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ fontSize: '13px', fontWeight: '600', color: '#6b7280', marginBottom: '6px' }}>
            Current Method
          </div>
          <div style={{ fontSize: '24px', fontWeight: '700', color: method === 'tsne' ? '#7c3aed' : '#2563eb', marginBottom: '6px' }}>
            {method === 'tsne' ? 't-SNE' : 'PCA'}
          </div>
          <div style={{ fontSize: '12px', color: '#4b5563' }}>
            {method === 'tsne' ? 'Non-linear, local structure' : 'Linear, global variance'}
          </div>
        </div>
      </div>

      <div style={{ 
        display: 'flex', 
        justifyContent: 'center',
        gap: '30px',
        flexWrap: 'wrap',
        alignItems: 'flex-start'
      }}>
        {/* Parameter Controls */}
        <div style={{ width: '320px' }}>
          {method === 'pca' ? (
            <div style={{
              background: '#eff6ff',
              padding: '20px',
              borderRadius: '12px',
              marginBottom: '20px',
              border: '2px solid #93c5fd'
            }}>
              <h3 style={{ fontSize: '18px', fontWeight: '700', marginBottom: '8px', color: '#1e40af' }}>
                PCA Parameters
              </h3>
              <p style={{ fontSize: '13px', color: '#1e40af', marginBottom: '20px', lineHeight: '1.5' }}>
                Principal Component Analysis settings
              </p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div>
                  <label style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '10px',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    cursor: 'pointer'
                  }}>
                    <input
                      type="checkbox"
                      checked={pcaParams.centerData}
                      onChange={(e) => handlePCAParamChange('centerData', e.target.checked)}
                      style={{ width: '18px', height: '18px', cursor: 'pointer' }}
                    />
                    Center Data (subtract mean)
                  </label>
                  <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '6px', marginLeft: '28px' }}>
                    Remove the mean from each feature
                  </div>
                </div>

                <div>
                  <label style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '10px',
                    fontSize: '14px',
                    fontWeight: '600',
                    color: '#374151',
                    cursor: 'pointer'
                  }}>
                    <input
                      type="checkbox"
                      checked={pcaParams.scaleData}
                      onChange={(e) => handlePCAParamChange('scaleData', e.target.checked)}
                      style={{ width: '18px', height: '18px', cursor: 'pointer' }}
                    />
                    Scale Data (unit variance)
                  </label>
                  <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '6px', marginLeft: '28px' }}>
                    Normalize features to same scale
                  </div>
                </div>
              </div>

              <div style={{
                marginTop: '20px',
                padding: '15px',
                background: '#dbeafe',
                borderRadius: '8px'
              }}>
                <div style={{ fontSize: '13px', color: '#1e40af', lineHeight: '1.6' }}>
                  <strong>💡 Tip:</strong> Scaling is important when features have different units or ranges. Try toggling to see the effect!
                </div>
              </div>
            </div>
          ) : (
            <div style={{
              background: '#f5f3ff',
              padding: '20px',
              borderRadius: '12px',
              marginBottom: '20px',
              border: '2px solid #c4b5fd'
            }}>
              <h3 style={{ fontSize: '18px', fontWeight: '700', marginBottom: '8px', color: '#6b21a8' }}>
                t-SNE Parameters
              </h3>
              <p style={{ fontSize: '13px', color: '#6b21a8', marginBottom: '20px', lineHeight: '1.5' }}>
                t-Distributed Stochastic Neighbor Embedding settings
              </p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <label style={{ fontSize: '14px', fontWeight: '600', color: '#374151' }}>
                      Perplexity
                    </label>
                    <span style={{ fontSize: '14px', fontWeight: '700', color: '#8b5cf6', background: 'white', padding: '4px 12px', borderRadius: '6px' }}>
                      {tsneParams.perplexity.toFixed(0)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="50"
                    step="5"
                    value={tsneParams.perplexity}
                    onChange={(e) => handleTSNEParamChange('perplexity', e.target.value)}
                    style={{ width: '100%', accentColor: '#8b5cf6' }}
                  />
                  <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>
                    Balance between local and global structure (typically 5-50)
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <label style={{ fontSize: '14px', fontWeight: '600', color: '#374151' }}>
                      Learning Rate
                    </label>
                    <span style={{ fontSize: '14px', fontWeight: '700', color: '#8b5cf6', background: 'white', padding: '4px 12px', borderRadius: '6px' }}>
                      {tsneParams.learningRate.toFixed(0)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="1000"
                    step="50"
                    value={tsneParams.learningRate}
                    onChange={(e) => handleTSNEParamChange('learningRate', e.target.value)}
                    style={{ width: '100%', accentColor: '#8b5cf6' }}
                  />
                  <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>
                    Step size for optimization (10-1000, usually 100-500)
                  </div>
                </div>

                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <label style={{ fontSize: '14px', fontWeight: '600', color: '#374151' }}>
                      Iterations
                    </label>
                    <span style={{ fontSize: '14px', fontWeight: '700', color: '#8b5cf6', background: 'white', padding: '4px 12px', borderRadius: '6px' }}>
                      {tsneParams.iterations.toFixed(0)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="250"
                    max="5000"
                    step="250"
                    value={tsneParams.iterations}
                    onChange={(e) => handleTSNEParamChange('iterations', e.target.value)}
                    style={{ width: '100%', accentColor: '#8b5cf6' }}
                  />
                  <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>
                    Number of optimization steps (more = better convergence)
                  </div>
                </div>
              </div>

              <div style={{
                marginTop: '20px',
                padding: '15px',
                background: '#ede9fe',
                borderRadius: '8px'
              }}>
                <div style={{ fontSize: '13px', color: '#6b21a8', lineHeight: '1.6' }}>
                  <strong>💡 Tip:</strong> Lower perplexity (5-15) emphasizes local structure. Higher (30-50) focuses on global structure. Try different values!
                </div>
              </div>
            </div>
          )}

          <div style={{
            background: '#f9fafb',
            padding: '20px',
            borderRadius: '12px',
            marginBottom: '20px',
            border: '2px solid #e5e7eb'
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '700', marginBottom: '15px', color: '#1f2937' }}>
              Iris Species
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {[
                { name: 'Setosa', color: '#10b981' },
                { name: 'Versicolor', color: '#3b82f6' },
                { name: 'Virginica', color: '#8b5cf6' }
              ].map((species, idx) => (
                <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div style={{ 
                    width: '20px', 
                    height: '20px', 
                    borderRadius: '50%', 
                    background: species.color,
                    border: '2px solid white',
                    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                  }} />
                  <span style={{ fontSize: '14px', color: '#374151' }}>
                    {species.name} (50 samples)
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div style={{
            background: '#fef3c7',
            padding: '15px',
            borderRadius: '8px',
            border: '2px solid #fbbf24'
          }}>
            <p style={{ fontSize: '13px', color: '#92400e', margin: 0, lineHeight: '1.5' }}>
              💡 <strong>Compare methods:</strong> Switch between PCA and t-SNE to see how each method handles the same data differently!
            </p>
          </div>
        </div>

        {/* Visualization */}
        <div style={{ position: 'relative' }}>
          <svg 
            width="550" 
            height="550" 
            style={{ 
              border: '2px solid #e5e7eb',
              borderRadius: '12px',
              background: '#fafafa'
            }}
          >
            {[0, 25, 50, 75, 100].map(val => (
              <React.Fragment key={val}>
                <line x1={val * 5.5} y1="0" x2={val * 5.5} y2="550" stroke="#f0f0f0" strokeWidth="1" />
                <line x1="0" y1={val * 5.5} x2="550" y2={val * 5.5} stroke="#f0f0f0" strokeWidth="1" />
              </React.Fragment>
            ))}

            {data.map((point, idx) => {
              const pos = positions[idx] || { x: 50, y: 50 };
              const isHovered = hoveredPoint === point.id;
              
              return (
                <circle
                  key={point.id}
                  cx={pos.x * 5.5}
                  cy={pos.y * 5.5}
                  r={isHovered ? 8 : 5}
                  fill={point.color}
                  opacity={isHovered ? 1 : 0.85}
                  stroke="white"
                  strokeWidth="2"
                  style={{ cursor: 'pointer', transition: 'all 0.2s ease' }}
                  onMouseEnter={() => setHoveredPoint(point.id)}
                  onMouseLeave={() => setHoveredPoint(null)}
                />
              );
            })}

            <text x="275" y="30" textAnchor="middle" fontSize="20" fontWeight="bold" fill="#1f2937">
              {method === 'tsne' ? 't-SNE Projection' : 'PCA Projection'}
            </text>

            <text x="275" y="530" textAnchor="middle" fontSize="14" fill="#6b7280">
              Component 1
            </text>
            <text x="30" y="275" textAnchor="middle" fontSize="14" fill="#6b7280" transform="rotate(-90, 30, 275)">
              Component 2
            </text>
          </svg>

          {hoveredPoint && (
            <div style={{
              position: 'absolute',
              top: '60px',
              right: '-260px',
              background: 'white',
              padding: '16px',
              borderRadius: '8px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
              border: '2px solid #e5e7eb',
              minWidth: '240px',
              zIndex: 10
            }}>
              {data.find(p => p.id === hoveredPoint) && (() => {
                const point = data.find(p => p.id === hoveredPoint);
                return (
                  <>
                    <h4 style={{ 
                      margin: '0 0 12px 0', 
                      fontSize: '15px', 
                      fontWeight: '700',
                      color: point.color
                    }}>
                      Iris {point.speciesName}
                    </h4>
                    <div style={{ fontSize: '13px', color: '#4b5563', lineHeight: '1.8' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                        <span>Sepal Length:</span>
                        <strong>{point.features.sepalLength.toFixed(1)} cm</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                        <span>Sepal Width:</span>
                        <strong>{point.features.sepalWidth.toFixed(1)} cm</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                        <span>Petal Length:</span>
                        <strong>{point.features.petalLength.toFixed(1)} cm</strong>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>Petal Width:</span>
                        <strong>{point.features.petalWidth.toFixed(1)} cm</strong>
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>
          )}
        </div>
      </div>

      {/* Educational Info */}
      <div style={{
        maxWidth: '900px',
        margin: '30px auto 0',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))',
        gap: '20px'
      }}>
        <div style={{
          background: method === 'tsne' ? '#f5f3ff' : '#eff6ff',
          padding: '20px',
          borderRadius: '12px',
          border: `2px solid ${method === 'tsne' ? '#c4b5fd' : '#93c5fd'}`
        }}>
          <h3 style={{ 
            fontSize: '16px', 
            fontWeight: '700',
            marginBottom: '12px',
            color: method === 'tsne' ? '#6b21a8' : '#1e40af'
          }}>
            {method === 'tsne' ? '🔮 t-SNE Characteristics' : '📐 PCA Characteristics'}
          </h3>
          <ul style={{ 
            fontSize: '14px', 
            color: '#374151',
            lineHeight: '1.7',
            margin: 0,
            paddingLeft: '20px'
          }}>
            {method === 'tsne' ? (
              <>
                <li><strong>Non-linear:</strong> Can capture complex manifold structures</li>
                <li><strong>Local focus:</strong> Preserves neighborhood relationships</li>
                <li><strong>Better separation:</strong> Creates distinct visual clusters</li>
                <li><strong>Stochastic:</strong> Different runs give slightly different results</li>
                <li><strong>Slower:</strong> Iterative optimization process</li>
                <li><strong>Best for:</strong> Visualization and exploration</li>
              </>
            ) : (
              <>
                <li><strong>Linear:</strong> Projects data along principal axes</li>
                <li><strong>Global focus:</strong> Maximizes overall variance</li>
                <li><strong>Interpretable:</strong> Components have clear meaning</li>
                <li><strong>Deterministic:</strong> Same input always gives same output</li>
                <li><strong>Faster:</strong> Direct eigenvalue decomposition</li>
                <li><strong>Best for:</strong> Feature reduction and preprocessing</li>
              </>
            )}
          </ul>
        </div>

        <div style={{
          background: '#fff7ed',
          padding: '20px',
          borderRadius: '12px',
          border: '2px solid #fdba74'
        }}>
          <h3 style={{ 
            fontSize: '16px', 
            fontWeight: '700',
            marginBottom: '12px',
            color: '#9a3412'
          }}>
            📊 When to Use Each Method
          </h3>
          <div style={{ 
            fontSize: '14px', 
            color: '#7c2d12',
            lineHeight: '1.7'
          }}>
            <div style={{ marginBottom: '12px' }}>
              <strong style={{ color: '#2563eb' }}>Use PCA when:</strong>
              <ul style={{ margin: '4px 0 0 0', paddingLeft: '20px' }}>
                <li>You need speed and reproducibility</li>
                <li>Linear relationships are important</li>
                <li>You want interpretable components</li>
              </ul>
            </div>
            <div>
              <strong style={{ color: '#7c3aed' }}>Use t-SNE when:</strong>
              <ul style={{ margin: '4px 0 0 0', paddingLeft: '20px' }}>
                <li>Visualization is the primary goal</li>
                <li>Local structure matters more</li>
                <li>You have complex, non-linear data</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Dataset Description */}
      <div style={{
        maxWidth: '900px',
        margin: '20px auto 0',
        padding: '20px',
        background: '#f0fdf4',
        borderRadius: '12px',
        border: '2px solid #86efac'
      }}>
        <h3 style={{ 
          fontSize: '16px', 
          fontWeight: '700',
          marginBottom: '12px',
          color: '#065f46'
        }}>
          📚 About the Iris Dataset
        </h3>
        <p style={{ 
          fontSize: '14px', 
          color: '#064e3b',
          lineHeight: '1.6',
          margin: 0
        }}>
          The Iris dataset is a classic in machine learning, introduced by Ronald Fisher in 1936. 
          It contains measurements of 150 iris flowers from three species (50 samples each). 
          Each sample has 4 features: sepal length, sepal width, petal length, and petal width (all in cm). 
          <strong> Setosa</strong> is easily separable, while <strong>Versicolor</strong> and <strong>Virginica</strong> 
          have some overlap. This makes it perfect for demonstrating dimensionality reduction techniques!
        </p>
      </div>
    </div>
  );
};

export default DimReductionDemo;