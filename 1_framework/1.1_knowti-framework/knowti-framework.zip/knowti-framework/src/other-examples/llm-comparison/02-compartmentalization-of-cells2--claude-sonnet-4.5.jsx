import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

const CellCompartmentalization = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [compartmentsOn, setCompartmentsOn] = useState(true);
  const [particles, setParticles] = useState([]);
  const [frameCount, setFrameCount] = useState(0);
  const animationRef = useRef(null);
  const particleIdCounter = useRef(0);

  // Organelle definitions
  const organelles = [
    {
      id: 'nucleus',
      name: 'Zellkern',
      color: '#3B82F6',
      lightColor: '#93C5FD',
      x: 250,
      y: 200,
      width: 120,
      height: 100,
      rx: 50,
      reaction: 'DNA → RNA',
      description: 'Transkription'
    },
    {
      id: 'mitochondrion',
      name: 'Mitochondrium',
      color: '#10B981',
      lightColor: '#6EE7B7',
      x: 100,
      y: 100,
      width: 100,
      height: 70,
      rx: 35,
      reaction: 'Glucose → ATP',
      description: 'Energieproduktion'
    },
    {
      id: 'er',
      name: 'Endoplasmatisches Retikulum',
      color: '#F97316',
      lightColor: '#FDBA74',
      x: 350,
      y: 280,
      width: 110,
      height: 80,
      rx: 40,
      reaction: 'Proteinsynthese',
      description: 'Protein-Herstellung'
    },
    {
      id: 'ribosome',
      name: 'Ribosom',
      color: '#A855F7',
      lightColor: '#D8B4FE',
      x: 80,
      y: 280,
      width: 70,
      height: 70,
      rx: 35,
      reaction: 'mRNA → Protein',
      description: 'Translation'
    },
    {
      id: 'golgi',
      name: 'Golgi-Apparat',
      color: '#EF4444',
      lightColor: '#FCA5A5',
      x: 360,
      y: 100,
      width: 100,
      height: 80,
      rx: 40,
      reaction: 'Proteinmodifikation',
      description: 'Protein-Verarbeitung'
    }
  ];

  // Cell boundary
  const cellBoundary = {
    x: 20,
    y: 20,
    width: 460,
    height: 360,
    rx: 30
  };

  // Check if point is inside organelle
  const isInsideOrganelle = (x, y, organelle) => {
    return (
      x >= organelle.x &&
      x <= organelle.x + organelle.width &&
      y >= organelle.y &&
      y <= organelle.y + organelle.height
    );
  };

  // Check if point is inside cell
  const isInsideCell = (x, y) => {
    return (
      x >= cellBoundary.x &&
      x <= cellBoundary.x + cellBoundary.width &&
      y >= cellBoundary.y &&
      y <= cellBoundary.y + cellBoundary.height
    );
  };

  // Particle generation effect
  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setParticles(prev => {
        // Limit total particles
        if (prev.length >= 50) return prev;

        const newParticles = organelles.map(organelle => ({
          id: particleIdCounter.current++,
          organelleId: organelle.id,
          x: organelle.x + Math.random() * organelle.width,
          y: organelle.y + Math.random() * organelle.height,
          vx: (Math.random() - 0.5) * 3,
          vy: (Math.random() - 0.5) * 3,
          color: organelle.color,
          lightColor: organelle.lightColor,
          lifetime: 0,
          maxLifetime: 100
        }));

        return [...prev, ...newParticles];
      });
    }, 200);

    return () => clearInterval(interval);
  }, [isPlaying]);

  // Animation loop
  useEffect(() => {
    if (!isPlaying) return;

    const animate = () => {
      setFrameCount(f => f + 1);
      
      setParticles(prev => {
        return prev
          .map(particle => {
            let newX = particle.x + particle.vx;
            let newY = particle.y + particle.vy;
            let newVx = particle.vx;
            let newVy = particle.vy;

            if (compartmentsOn) {
              // Bounce within organelle boundaries
              const organelle = organelles.find(o => o.id === particle.organelleId);
              
              if (organelle) {
                // Check horizontal boundaries
                if (newX <= organelle.x || newX >= organelle.x + organelle.width) {
                  newVx = -newVx;
                  newX = particle.x + newVx;
                }
                
                // Check vertical boundaries
                if (newY <= organelle.y || newY >= organelle.y + organelle.height) {
                  newVy = -newVy;
                  newY = particle.y + newVy;
                }
              }
            } else {
              // Bounce within cell boundaries
              if (newX <= cellBoundary.x || newX >= cellBoundary.x + cellBoundary.width) {
                newVx = -newVx;
                newX = particle.x + newVx;
              }
              
              if (newY <= cellBoundary.y || newY >= cellBoundary.y + cellBoundary.height) {
                newVy = -newVy;
                newY = particle.y + newVy;
              }
            }

            return {
              ...particle,
              x: newX,
              y: newY,
              vx: newVx,
              vy: newVy,
              lifetime: particle.lifetime + 1
            };
          })
          .filter(particle => particle.lifetime < particle.maxLifetime);
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, compartmentsOn]);

  const handleReset = () => {
    setParticles([]);
    setIsPlaying(false);
    setFrameCount(0);
    particleIdCounter.current = 0;
  };

  const toggleCompartments = () => {
    setCompartmentsOn(prev => !prev);
    setParticles([]); // Clear particles when toggling
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-3 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Zellkompartimentierung Simulation
          </h1>
          <p className="text-gray-600 text-lg">
            Entdecke, wie Organellen getrennte Reaktionsräume ermöglichen
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Simulation */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-4 h-4 rounded-full ${compartmentsOn ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></div>
                  <span className="font-semibold text-gray-700">
                    {compartmentsOn ? 'Kompartimentiert' : 'Chaotisch'}
                  </span>
                </div>
                <div className="text-sm text-gray-500">
                  Partikel: {particles.length}/50
                </div>
              </div>

              {/* SVG Cell */}
              <div className="bg-gray-50 rounded-xl">
                <svg width="500" height="400" className="w-full h-auto">
                  {/* Cell Wall */}
                  <rect
                    {...cellBoundary}
                    fill="rgba(229, 231, 235, 0.3)"
                    stroke="#6B7280"
                    strokeWidth="3"
                    strokeDasharray="5,5"
                  />
                  
                  {/* Organelles */}
                  {organelles.map(organelle => (
                    <g key={organelle.id}>
                      <rect
                        x={organelle.x}
                        y={organelle.y}
                        width={organelle.width}
                        height={organelle.height}
                        rx={organelle.rx}
                        fill={compartmentsOn ? `${organelle.color}20` : 'transparent'}
                        stroke={organelle.color}
                        strokeWidth={compartmentsOn ? "2" : "1"}
                        strokeDasharray={compartmentsOn ? "0" : "3,3"}
                        className="transition-all duration-300"
                      />
                      <text
                        x={organelle.x + organelle.width / 2}
                        y={organelle.y + organelle.height / 2}
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="text-xs font-bold pointer-events-none"
                        fill={organelle.color}
                      >
                        {organelle.name}
                      </text>
                      <text
                        x={organelle.x + organelle.width / 2}
                        y={organelle.y + organelle.height / 2 + 15}
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="text-xs pointer-events-none"
                        fill={organelle.color}
                        opacity="0.7"
                      >
                        {organelle.reaction}
                      </text>
                    </g>
                  ))}
                  
                  {/* Particles */}
                  {particles.map(particle => {
                    const opacity = 1 - (particle.lifetime / particle.maxLifetime);
                    return (
                      <circle
                        key={particle.id}
                        cx={particle.x}
                        cy={particle.y}
                        r="4"
                        fill={particle.color}
                        opacity={opacity}
                        className="transition-opacity"
                      >
                        <animate
                          attributeName="r"
                          values="4;5;4"
                          dur="1s"
                          repeatCount="indefinite"
                        />
                      </circle>
                    );
                  })}
                </svg>
              </div>

              {/* Controls */}
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className={`flex-1 px-6 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all transform hover:scale-105 ${
                    isPlaying
                      ? 'bg-gradient-to-r from-red-500 to-red-600 text-white shadow-lg'
                      : 'bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg'
                  }`}
                >
                  {isPlaying ? (
                    <>
                      <Pause size={20} />
                      Pause
                    </>
                  ) : (
                    <>
                      <Play size={20} />
                      Start
                    </>
                  )}
                </button>
                <button
                  onClick={handleReset}
                  className="px-6 py-3 bg-gray-600 text-white rounded-xl font-semibold flex items-center gap-2 hover:bg-gray-700 transition-colors transform hover:scale-105 shadow-lg"
                >
                  <RotateCcw size={20} />
                  Reset
                </button>
                <button
                  onClick={toggleCompartments}
                  className={`flex-1 px-6 py-3 rounded-xl font-semibold transition-all transform hover:scale-105 shadow-lg ${
                    compartmentsOn
                      ? 'bg-gradient-to-r from-green-500 to-emerald-600 text-white'
                      : 'bg-gradient-to-r from-red-500 to-orange-600 text-white'
                  }`}
                >
                  {compartmentsOn ? 'Kompartimente EIN' : 'Kompartimente AUS'}
                </button>
              </div>
            </div>
          </div>

          {/* Information Panel */}
          <div className="lg:col-span-1 space-y-6">
            {/* Status */}
            <div className={`rounded-2xl shadow-2xl p-6 text-white ${
              compartmentsOn
                ? 'bg-gradient-to-br from-green-500 to-emerald-600'
                : 'bg-gradient-to-br from-red-500 to-orange-600'
            }`}>
              <h3 className="text-xl font-bold mb-3">
                {compartmentsOn ? '✅ Organisiert' : '⚠️ Chaos'}
              </h3>
              <p className="text-sm leading-relaxed opacity-90">
                {compartmentsOn
                  ? 'Jedes Organell führt seine spezifische Reaktion in einem geschützten Raum durch. Die Partikel bleiben in ihren Kompartimenten und ermöglichen gleichzeitige, spezialisierte Prozesse.'
                  : 'Ohne Kompartimente vermischen sich alle Partikel chaotisch in der Zelle. Verschiedene Reaktionen stören sich gegenseitig, und die Effizienz der Zelle bricht zusammen.'}
              </p>
            </div>

            {/* Legend */}
            <div className="bg-white rounded-2xl shadow-2xl p-6">
              <h3 className="text-xl font-bold mb-4 text-gray-800 flex items-center gap-2">
                🎨 Partikel-Legende
              </h3>
              <div className="space-y-3">
                {organelles.map(organelle => (
                  <div key={organelle.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors">
                    <div
                      className="w-6 h-6 rounded-full"
                      style={{ backgroundColor: organelle.color }}
                    ></div>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-gray-700">
                        {organelle.reaction}
                      </p>
                      <p className="text-xs text-gray-500">
                        {organelle.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Educational Info */}
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl shadow-xl p-6 border-2 border-blue-200">
              <h3 className="text-lg font-bold mb-3 text-gray-800">
                💡 Warum Kompartimentierung?
              </h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Ermöglicht gleichzeitige, unterschiedliche Reaktionen</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Optimale Bedingungen für jede Reaktion</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Verhindert störende Wechselwirkungen</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold">•</span>
                  <span>Erhöht die Effizienz der Zelle</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Info */}
        <div className="mt-6 bg-white rounded-2xl shadow-xl p-6">
          <h3 className="text-xl font-bold mb-3 text-gray-800">
            🔬 Wie funktioniert diese Simulation?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-700">
            <div>
              <h4 className="font-semibold text-blue-600 mb-2">Mit Kompartimenten:</h4>
              <p className="leading-relaxed">
                Jedes Organell erzeugt kontinuierlich Partikel, die innerhalb seiner Grenzen bleiben. 
                Dies simuliert, wie echte Zellen spezialisierte Reaktionen in isolierten Räumen durchführen, 
                was gleichzeitige und effiziente biochemische Prozesse ermöglicht.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-red-600 mb-2">Ohne Kompartimente:</h4>
              <p className="leading-relaxed">
                Alle Partikel bewegen sich frei durch die gesamte Zelle. Dies zeigt, was passieren würde, 
                wenn es keine Organellen gäbe: Chaos, ineffiziente Reaktionen und gegenseitige Störungen. 
                Die Zelle könnte nicht überleben!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CellCompartmentalization;