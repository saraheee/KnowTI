import React, { useState, useEffect, useRef, useCallback } from 'react';

// --- VISUALIZATION CONSTANTS ---
const CELL_SIZE = 400; // Canvas drawing size
const NUCLEUS_RADIUS = CELL_SIZE * 0.2;
const CELL_RADIUS = CELL_SIZE * 0.45;
const PARTICLE_COUNT = 80;
const SPEED_FACTOR = 0.8;
const COLORS = {
    CYTOPLASM: '#9AE6B4', // Light Green
    NUCLEUS: '#63B3ED',    // Bright Blue
    PARTICLE: '#F6AD55',  // Orange (Ribosomes/Proteins)
    MEMBRANE: '#4A5568',  // Dark Gray
    DNA: '#E37222'        // Deep Orange for Prokaryote DNA
};
const CENTER = CELL_SIZE / 2;
const CANVAS_INFO_WIDTH = CELL_SIZE + 300; // Expanded width to fit info panel

// New Organelle Structure with Descriptions and simple diagram coordinates
const ORGANELLES = {
    NUCLEUS: {
        r: NUCLEUS_RADIUS, x: CENTER, y: CENTER, color: COLORS.NUCLEUS,
        name: 'Nucleus',
        function: 'The cell\'s control center, containing the **DNA** (genetic material). It manages cell growth and reproduction.',
        diagram: (ctx, x, y) => {
            ctx.strokeStyle = COLORS.NUCLEUS;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(x, y, 40, 0, Math.PI * 2);
            ctx.stroke();
            ctx.fillStyle = COLORS.DNA;
            ctx.font = 'bold 10px Inter';
            ctx.fillText('DNA', x - 10, y + 3);
        },
        // [x, y, width, height] for simple bounding box check
        bounds: [CENTER - NUCLEUS_RADIUS, CENTER - NUCLEUS_RADIUS, NUCLEUS_RADIUS * 2, NUCLEUS_RADIUS * 2] 
    },
    MITOCHONDRION: {
        x: CENTER + CELL_RADIUS * 0.25, y: CENTER - CELL_RADIUS * 0.35, w: 40, h: 20, color: '#FF7F50',
        name: 'Mitochondrion',
        function: 'The **powerhouse** of the cell. It performs cellular respiration to generate **ATP** (energy).',
        diagram: (ctx, x, y) => {
            ctx.strokeStyle = '#FF7F50';
            ctx.fillStyle = '#FF7F5055';
            ctx.beginPath();
            ctx.ellipse(x, y, 40, 20, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
            ctx.beginPath(); // Inner membrane folds
            ctx.moveTo(x - 30, y + 5);
            ctx.lineTo(x - 10, y + 5);
            ctx.lineTo(x, y - 5);
            ctx.lineTo(x + 10, y - 5);
            ctx.lineTo(x + 30, y);
            ctx.stroke();
        },
        bounds: [CENTER + CELL_RADIUS * 0.25 - 20, CENTER - CELL_RADIUS * 0.35 - 10, 40, 20]
    },
    ER: {
        x: CENTER - CELL_RADIUS * 0.2, y: CENTER, w: 100, h: 60, color: '#8A2BE2',
        name: 'Endoplasmic Reticulum (ER)',
        function: 'A network that makes and transports proteins (Rough ER) and fats (Smooth ER).',
        diagram: (ctx, x, y) => {
            ctx.strokeStyle = '#8A2BE2';
            ctx.lineWidth = 2;
            for (let i = -1; i <= 1; i++) {
                ctx.beginPath();
                ctx.moveTo(x - 40, y + i * 15);
                ctx.bezierCurveTo(x - 10, y + i * 15 - 5, x + 10, y + i * 15 + 5, x + 40, y + i * 15);
                ctx.stroke();
            }
        },
        bounds: [CENTER - CELL_RADIUS * 0.2 - 50, CENTER - 30, 100, 60]
    },
    GOLGI: {
        x: CENTER + CELL_RADIUS * 0.4, y: CENTER + CELL_RADIUS * 0.3, w: 50, h: 40, color: '#FFD700',
        name: 'Golgi Apparatus',
        function: 'The cell\'s **post office**. It modifies, sorts, and packages proteins and lipids from the ER.',
        diagram: (ctx, x, y) => {
            ctx.strokeStyle = '#FFD700';
            ctx.lineWidth = 2;
            for (let i = -1; i <= 1; i++) {
                ctx.beginPath();
                ctx.moveTo(x - 20, y + i * 10);
                ctx.bezierCurveTo(x - 5, y + i * 10 - 5, x + 5, y + i * 10 + 5, x + 20, y + i * 10);
                ctx.stroke();
            }
            ctx.fillStyle = '#000000';
            ctx.beginPath(); // Vesicle
            ctx.arc(x + 25, y + 15, 3, 0, Math.PI * 2);
            ctx.fill();
        },
        bounds: [CENTER + CELL_RADIUS * 0.4 - 25, CENTER + CELL_RADIUS * 0.3 - 20, 50, 40]
    }
};

const allOrganelles = Object.keys(ORGANELLES);

// --- UTILITY FUNCTIONS ---

// Function to generate initial particle state
const createParticle = () => ({
    x: CENTER + (Math.random() - 0.5) * CELL_RADIUS * 2,
    y: CENTER + (Math.random() - 0.5) * CELL_RADIUS * 2,
    vx: (Math.random() - 0.5) * SPEED_FACTOR,
    vy: (Math.random() - 0.5) * SPEED_FACTOR,
    color: COLORS.PARTICLE
});

const getDistance = (p1, p2) => Math.sqrt((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2);

// --- MAIN REACT COMPONENT ---
const App = () => {
    const canvasRef = useRef(null);
    const animationRef = useRef(null);
    // isEukaryote: true = Eukaryote Explorer, false = Prokaryote Comparison
    const [isEukaryote, setIsEukaryote] = useState(true);
    const [isPlaying, setIsPlaying] = useState(true);
    const [particles, setParticles] = useState(() => Array.from({ length: PARTICLE_COUNT }, createParticle));
    const [hoveredOrganelle, setHoveredOrganelle] = useState(null);
    const [clickedOrganelle, setClickedOrganelle] = useState(null);

    // Reset particles to initial positions and velocities
    const resetParticles = useCallback(() => {
        setParticles(Array.from({ length: PARTICLE_COUNT }, createParticle));
    }, []);

    // Toggle between Eukaryote and Prokaryote states
    const toggleState = useCallback(() => {
        setIsEukaryote(prev => !prev);
        setClickedOrganelle(null); // Clear info box on state switch
        resetParticles();
    }, [resetParticles]);

    // Event Handlers for Mouse Interaction
    const handleMouseMove = useCallback((e) => {
        const canvas = canvasRef.current;
        if (!canvas || !isEukaryote) { // Only active in Eukaryote Explorer Mode
            setHoveredOrganelle(null);
            return;
        }

        const rect = canvas.getBoundingClientRect();
        // Mouse coordinates relative to the canvas size
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;
        const mouseX = (e.clientX - rect.left) * scaleX;
        const mouseY = (e.clientY - rect.top) * scaleY;

        let newHovered = null;

        allOrganelles.forEach(key => {
            const org = ORGANELLES[key];
            if (key === 'NUCLEUS') {
                // Check distance from nucleus center
                const dist = getDistance({ x: mouseX, y: mouseY }, { x: CENTER, y: CENTER });
                if (dist < NUCLEUS_RADIUS) {
                    newHovered = key;
                }
            } else if (
                mouseX > org.bounds[0] && 
                mouseX < org.bounds[0] + org.bounds[2] &&
                mouseY > org.bounds[1] && 
                mouseY < org.bounds[1] + org.bounds[3]
            ) {
                newHovered = key;
            }
        });

        setHoveredOrganelle(newHovered);
    }, [isEukaryote]);

    const handleClick = useCallback(() => {
        if (isEukaryote) {
            // Clicking locks the current hovered organelle's info box
            setClickedOrganelle(hoveredOrganelle);
        }
    }, [isEukaryote, hoveredOrganelle]);

    // Attach event listeners
    useEffect(() => {
        const canvas = canvasRef.current;
        if (canvas) {
            // Set up event listeners on the canvas
            canvas.addEventListener('mousemove', handleMouseMove);
            canvas.addEventListener('click', handleClick);
        }
        return () => {
            if (canvas) {
                // Cleanup listeners
                canvas.removeEventListener('mousemove', handleMouseMove);
                canvas.removeEventListener('click', handleClick);
            }
        };
    }, [handleMouseMove, handleClick]);


    // Draw Organelle Specific Information Box
    const drawOrganelleInfo = useCallback((ctx) => {
        const currentOrganelleKey = clickedOrganelle || hoveredOrganelle;
        if (!currentOrganelleKey) return;

        const org = ORGANELLES[currentOrganelleKey];
        const infoX = CELL_SIZE + 20;
        const infoY = CENTER - 100;
        const boxWidth = 250;
        const boxHeight = 200;

        // Draw Info Box Background
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = '#4A5568';
        ctx.lineWidth = 2;
        ctx.fillRect(infoX, infoY, boxWidth, boxHeight);
        ctx.strokeRect(infoX, infoY, boxWidth, boxHeight);

        // Draw Title
        ctx.fillStyle = '#2D3748';
        ctx.font = 'bold 16px Inter, sans-serif';
        ctx.fillText(org.name, infoX + 10, infoY + 25);

        // Draw Function Description
        ctx.font = '12px Inter, sans-serif';
        ctx.fillStyle = '#4A5568';
        const description = org.function.split(' ');
        let line = '';
        let y = infoY + 45;
        const maxLineWidth = boxWidth - 20;

        // Simple text wrapping 
        description.forEach(word => {
            const testLine = line + word + ' ';
            // If the test line is too long, draw the current line and start a new one
            if (ctx.measureText(testLine).width > maxLineWidth && line !== '') {
                ctx.fillText(line, infoX + 10, y);
                line = word + ' ';
                y += 15;
            } else {
                line = testLine;
            }
        });
        ctx.fillText(line, infoX + 10, y);

        // Draw Simple Diagram
        ctx.save();
        ctx.translate(infoX + boxWidth / 2, infoY + boxHeight - 60);
        org.diagram(ctx, 0, 0); 
        ctx.restore();

        // Hover/Click Indicator
        ctx.fillStyle = clickedOrganelle ? '#DC2626' : '#10B981';
        ctx.font = 'bold 10px Inter, sans-serif';
        ctx.fillText(clickedOrganelle ? 'INFO LOCKED' : 'HOVERING', infoX + boxWidth - 75, infoY + 15);

    }, [hoveredOrganelle, clickedOrganelle]);


    // Draw the cell structure (Eukaryote or Prokaryote)
    const drawCell = useCallback((ctx) => {
        const cx = CENTER;
        const cy = CENTER;

        // 1. Draw Cell Membrane/Wall
        ctx.beginPath();
        ctx.arc(cx, cy, CELL_RADIUS, 0, Math.PI * 2, false);
        ctx.fillStyle = COLORS.CYTOPLASM + '33'; // Cytoplasm background
        ctx.fill();
        ctx.lineWidth = 4;
        ctx.strokeStyle = COLORS.MEMBRANE;
        ctx.stroke();

        // Highlight Hovered Organelle (Applies in Eukaryote Mode)
        if (isEukaryote && hoveredOrganelle) {
            ctx.fillStyle = 'rgba(255, 255, 0, 0.3)';
            if (hoveredOrganelle === 'NUCLEUS') {
                ctx.beginPath();
                ctx.arc(CENTER, CENTER, NUCLEUS_RADIUS, 0, Math.PI * 2);
                ctx.fill();
            } else {
                const org = ORGANELLES[hoveredOrganelle];
                // Use the simplified bounding box for the hover highlight
                ctx.fillRect(org.bounds[0], org.bounds[1], org.bounds[2], org.bounds[3]);
            }
        }

        if (isEukaryote) {
            // Eukaryotic State: EXPLORER MODE (Detailed)
            const n = ORGANELLES.NUCLEUS;
            const m = ORGANELLES.MITOCHONDRION;
            const er = ORGANELLES.ER;
            const g = ORGANELLES.GOLGI;

            // NUCLEUS
            ctx.beginPath();
            ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2, false);
            ctx.fillStyle = n.color + '44';
            ctx.fill();
            ctx.lineWidth = 3;
            ctx.strokeStyle = n.color;
            ctx.stroke();
            // DNA Placeholder
            ctx.fillStyle = COLORS.DNA;
            ctx.font = 'bold 10px Inter';
            ctx.fillText('DNA', n.x - 10, n.y + 3);

            // MITOCHONDRION (Oval)
            ctx.beginPath();
            ctx.ellipse(m.x, m.y, m.w / 2, m.h / 2, 0, 0, Math.PI * 2);
            ctx.fillStyle = m.color + '55';
            ctx.fill();
            ctx.strokeStyle = m.color;
            ctx.lineWidth = 2;
            ctx.stroke();

            // ER (Wavy lines near nucleus)
            ctx.strokeStyle = er.color;
            ctx.lineWidth = 3;
            for (let i = -1; i <= 1; i++) {
                ctx.beginPath();
                ctx.moveTo(er.x - er.w / 2, er.y + i * 15);
                ctx.bezierCurveTo(er.x - 20, er.y + i * 15 - 10, er.x + 20, er.y + i * 15 + 10, er.x + er.w / 2, er.y + i * 15);
                ctx.stroke();
            }

            // GOLGI (Stack of curved sacs)
            ctx.strokeStyle = g.color;
            ctx.lineWidth = 3;
            for (let i = -1; i <= 1; i++) {
                ctx.beginPath();
                ctx.moveTo(g.x - g.w / 2, g.y + i * 10);
                ctx.bezierCurveTo(g.x - 10, g.y + i * 10 - 5, g.x + 10, g.y + i * 10 + 5, g.x + g.w / 2, g.y + i * 10);
                ctx.stroke();
            }

            // Labels for Eukaryote Explorer
            ctx.fillStyle = '#1A202C';
            ctx.font = 'bold 12px Inter, sans-serif';
            ctx.fillText('Nucleus', n.x - 25, n.y - n.r - 5);
            ctx.fillText('Mito', m.x - 15, m.y - m.h / 2 - 5);
            ctx.fillText('ER', er.x + er.w / 2 + 5, er.y + 5);
            ctx.fillText('Golgi', g.x + g.w / 2 + 5, g.y + 5);


        } else {
            // Prokaryotic State: COMPARISON MODE (Simple)
            const cx = CENTER;
            const cy = CENTER;

            // Draw Nucleoid Area
            ctx.beginPath();
            ctx.ellipse(cx, cy, NUCLEUS_RADIUS * 1.5, NUCLEUS_RADIUS * 1.2, 0, 0, Math.PI * 2);
            ctx.fillStyle = COLORS.DNA + '33';
            ctx.fill();

            // Draw DNA Strand
            ctx.beginPath();
            ctx.strokeStyle = COLORS.DNA;
            ctx.lineWidth = 2;
            ctx.arc(cx + 10, cy + 10, NUCLEUS_RADIUS * 0.8, 0, Math.PI * 1.5, false);
            ctx.stroke();

            // Labels for Prokaryote Comparison
            ctx.fillStyle = '#1A202C';
            ctx.font = 'bold 14px Inter, sans-serif';
            ctx.fillText('NUCLEOID', cx - 35, cy - NUCLEUS_RADIUS * 1.5 - 15);
            ctx.font = '12px Inter, sans-serif';
            ctx.fillText('Chaos & Merged', cx - 50, cy + CELL_RADIUS - 10);
        }

    }, [isEukaryote, hoveredOrganelle]);

    // Update and draw particles (mRNA/Ribosomes)
    const drawParticles = useCallback((ctx) => {
        const newParticles = particles.map(p => {
            let { x, y, vx, vy } = p;

            // Update position
            x += vx;
            y += vy;

            // Boundary Check
            const distFromCenter = getDistance({ x, y }, { x: CENTER, y: CENTER });
            if (distFromCenter > CELL_RADIUS) {
                const angle = Math.atan2(y - CENTER, x - CENTER);
                const normalX = Math.cos(angle);
                const normalY = Math.sin(angle);
                const dotProduct = vx * normalX + vy * normalY;
                vx = vx - 2 * dotProduct * normalX;
                vy = vy - 2 * dotProduct * normalY;
                x = CENTER + normalX * (CELL_RADIUS - 1);
                y = CENTER + normalY * (CELL_RADIUS - 1);
            }

            // State Specific Logic
            if (isEukaryote) {
                // Eukaryotic Logic: Compartmentalization/Organelle avoidance
                const distFromNucleus = getDistance({ x, y }, { x: CENTER, y: CENTER });

                if (distFromNucleus < NUCLEUS_RADIUS) {
                    p.color = COLORS.NUCLEUS; // Particle is mRNA in nucleus
                    // 'Export' logic: (mRNA leaving nucleus)
                    if (distFromNucleus > NUCLEUS_RADIUS - 5 && Math.random() < 0.02) {
                         vx = -vx * 3;
                         vy = -vy * 3;
                         p.color = COLORS.PARTICLE; // Particle is now a ribosome/protein
                    }
                } else {
                    p.color = COLORS.PARTICLE; // Particle is a ribosome/protein in cytoplasm
                }
                vx += (Math.random() - 0.5) * 0.05;
                vy += (Math.random() - 0.5) * 0.05;

            } else {
                // Prokaryotic Logic: Chaos
                p.color = COLORS.PARTICLE;
                vx += (Math.random() - 0.5) * 0.2;
                vy += (Math.random() - 0.5) * 0.2;
            }

            // Clamp velocity
            const speed = Math.sqrt(vx * vx + vy * vy);
            const clampSpeed = SPEED_FACTOR * (isEukaryote ? 1 : 2); 
            if (speed > clampSpeed) {
                vx = (vx / speed) * clampSpeed;
                vy = (vy / speed) * clampSpeed;
            } else if (speed < SPEED_FACTOR * 0.5) {
                vx = (vx / speed) * SPEED_FACTOR * 0.5;
                vy = (vy / speed) * SPEED_FACTOR * 0.5;
            }

            return { ...p, x, y, vx, vy };
        });

        setParticles(newParticles);

        // Draw the particles
        newParticles.forEach(p => {
            ctx.beginPath();
            ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.fill();
        });

    }, [isEukaryote, particles]);

    // Animation Loop
    const animate = useCallback(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        // Clear the expanded canvas
        ctx.clearRect(0, 0, CANVAS_INFO_WIDTH, CELL_SIZE); 

        drawCell(ctx);
        drawParticles(ctx);
        drawOrganelleInfo(ctx); 

        if (isPlaying) {
            animationRef.current = requestAnimationFrame(animate);
        }
    }, [drawCell, drawParticles, drawOrganelleInfo, isPlaying]);

    // Start/Stop/Cleanup Animation
    useEffect(() => {
        if (isPlaying) {
            animationRef.current = requestAnimationFrame(animate);
        } else {
            cancelAnimationFrame(animationRef.current);
        }
        return () => cancelAnimationFrame(animationRef.current);
    }, [isPlaying, animate]);


    const statusText = isEukaryote ? "EUKARYOTE EXPLORATION MODE (Hover or Click on an organelle)" : "PROKARYOTE COMPARISON MODE (Unorganized)";
    const statusColor = isEukaryote ? "text-blue-600 border-blue-600" : "text-orange-600 border-orange-600";

    return (
        <div className="p-4 sm:p-8 flex flex-col items-center min-h-screen bg-gray-50 font-sans">
            <script src="https://cdn.tailwindcss.com"></script>
            <style>{`
                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
                body { font-family: 'Inter', sans-serif; }
                .cell-container {
                    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
                    background: white;
                }
            `}</style>

            <header className="text-center mb-6">
                <h1 className="text-3xl font-bold text-gray-800">Eukaryotic Cell Explorer</h1>
                <p className="text-gray-600">Hover over the parts of the cell to learn more! Click to lock the information.</p>
            </header>

            <div className={`p-4 mb-8 border-2 rounded-lg font-semibold transition-colors duration-500 ${statusColor}`}>
                {statusText}
            </div>

            <div className="flex justify-center">
                <div className="cell-container rounded-lg overflow-hidden shadow-xl mb-8">
                    <canvas
                        ref={canvasRef}
                        width={CANVAS_INFO_WIDTH}
                        height={CELL_SIZE}
                        className="block cursor-pointer"
                    />
                </div>
            </div>


            {/* Controls Section */}
            <div className="flex flex-wrap justify-center gap-4 w-full max-w-lg">
                <button
                    onClick={() => { toggleState(); }}
                    className="px-6 py-3 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition duration-300 transform hover:scale-105"
                >
                    {isEukaryote ? 'Switch to Prokaryote Comparison' : 'Switch to Eukaryote Explorer'}
                </button>

                <button
                    onClick={() => setIsPlaying(prev => !prev)}
                    className="px-6 py-3 bg-green-500 text-white font-semibold rounded-lg shadow-md hover:bg-green-600 transition duration-300 transform hover:scale-105"
                >
                    {isPlaying ? 'Pause Animation' : 'Play Animation'}
                </button>

                <button
                    onClick={resetParticles}
                    className="px-6 py-3 bg-gray-500 text-white font-semibold rounded-lg shadow-md hover:bg-gray-600 transition duration-300 transform hover:scale-105"
                >
                    Reset Particles
                </button>
            </div>

            {/* Key Concepts Explanation */}
            <div className="mt-8 text-sm text-gray-700 max-w-2xl text-center p-4 bg-white rounded-xl shadow-lg">
                <p className="font-bold mb-2">Particle Representation:</p>
                <p>The animated particles represent the cell's small machinery, primarily **Ribosomes** (orange, in the cytoplasm) and precursor molecules like **mRNA** (blue, in the nucleus).</p>
                <p className={`mt-2 ${clickedOrganelle ? 'text-red-500 font-semibold' : 'text-gray-400'}`}>
                    Clicking locks the info box. Click anywhere else on an organelle to select a new one!
                </p>
            </div>
        </div>
    );
};

export default App;