import React, { useState, useRef, useEffect } from 'react';
import './EukaryoticCell.css';

const EukaryoticCellVisualization = () => {
  const [isAnimating, setIsAnimating] = useState(true);
  const [showEukaryotic, setShowEukaryotic] = useState(true);
  const [hoverInfo, setHoverInfo] = useState(null);
  const [activeInfo, setActiveInfo] = useState(null);
  const animationRef = useRef(null);

  const cellStructures = {
    eukaryotic: [
      { 
        id: 'nucleus', 
        name: 'Nucleus', 
        color: '#ff6b6b', 
        x: 50, y: 50, 
        size: 25, 
        shortText: 'Large red circle in center with double membrane',
        description: 'Control center containing DNA - directs all cellular activities. The defining feature of eukaryotic cells, showing organized genetic material enclosed in a nuclear membrane.',
        detailedInfo: 'The nucleus is the most prominent organelle in eukaryotic cells. It contains the cell\'s chromosomes and is the site of DNA replication and transcription. Surrounded by a double membrane called the nuclear envelope.'
      },
      { 
        id: 'mitochondria', 
        name: 'Mitochondria', 
        color: '#4ecdc4', 
        x: 25, y: 30, 
        size: 8, 
        shortText: 'Teal-colored oval structures',
        description: 'Powerhouse of the cell - produces ATP energy through cellular respiration. Energy production organelles that have their own DNA.',
        detailedInfo: 'Mitochondria are often called the powerhouses of the cell. They generate most of the cell\'s supply of ATP through cellular respiration. They have their own DNA and can replicate independently.'
      },
      { 
        id: 'er', 
        name: 'Endoplasmic Reticulum', 
        color: '#45b7d1', 
        x: 70, y: 30, 
        size: 12, 
        shortText: 'Blue network-like structure',
        description: 'Protein synthesis and transport - rough ER has ribosomes, smooth ER makes lipids. Internal transport system for molecules.',
        detailedInfo: 'The ER is a network of membranous tubules and sacs. Rough ER is studded with ribosomes and involved in protein synthesis. Smooth ER synthesizes lipids, detoxifies drugs, and stores calcium ions.'
      },
      { 
        id: 'golgi', 
        name: 'Golgi Apparatus', 
        color: '#96ceb4', 
        x: 30, y: 70, 
        size: 10, 
        shortText: 'Green stacked sac structure',
        description: 'Protein modification and packaging - processes and ships cellular products. Cellular "post office" that modifies and packages proteins.',
        detailedInfo: 'The Golgi apparatus modifies, sorts, and packages proteins and lipids for transport to their final destinations. It consists of flattened membranous sacs called cisternae.'
      },
      { 
        id: 'lysosomes', 
        name: 'Lysosomes', 
        color: '#feca57', 
        x: 75, y: 75, 
        size: 6, 
        shortText: 'Small yellow circles',
        description: 'Cellular digestion - contains enzymes to break down waste and foreign materials. Recycling centers that digest cellular debris.',
        detailedInfo: 'Lysosomes contain digestive enzymes that break down macromolecules, old cell parts, and microorganisms. They maintain an acidic internal environment for optimal enzyme function.'
      },
      { 
        id: 'ribosomes', 
        name: 'Ribosomes', 
        color: '#ff9ff3', 
        x: 40, y: 60, 
        size: 3, 
        shortText: 'Tiny pink dots scattered in cytoplasm',
        description: 'Protein synthesis - read RNA to build proteins. Protein factories, some free-floating, some attached to ER.',
        detailedInfo: 'Ribosomes are molecular machines that synthesize proteins. They read messenger RNA and assemble amino acids into protein chains. Found free in cytoplasm or attached to rough ER.'
      }
    ],
    prokaryotic: [
      { 
        id: 'nucleoid', 
        name: 'Nucleoid', 
        color: '#ff6b6b', 
        x: 50, y: 50, 
        size: 20, 
        shortText: 'Red region without clear membrane boundary',
        description: 'Free-floating DNA region - genetic material not enclosed in nucleus. The key difference - DNA floats freely without nuclear membrane.',
        detailedInfo: 'The nucleoid is an irregularly-shaped region within the prokaryotic cell that contains most of the genetic material. Unlike the eukaryotic nucleus, it is not surrounded by a membrane.'
      },
      { 
        id: 'ribosomes', 
        name: 'Ribosomes', 
        color: '#ff9ff3', 
        x: 60, y: 40, 
        size: 3, 
        shortText: 'Pink dots scattered throughout',
        description: 'Protein synthesis - smaller than eukaryotic ribosomes. Simpler protein synthesis machinery.',
        detailedInfo: 'Prokaryotic ribosomes are smaller (70S) than eukaryotic ribosomes (80S). They perform the same function of protein synthesis but are structurally different, which is why some antibiotics target bacterial ribosomes specifically.'
      },
      { 
        id: 'cellWall', 
        name: 'Cell Wall', 
        color: '#54a0ff', 
        x: 50, y: 50, 
        size: 45, 
        shortText: 'Outer blue boundary layer',
        description: 'Protective outer layer - provides structural support and protection. Rigid outer structure for protection.',
        detailedInfo: 'The cell wall is a rigid layer outside the plasma membrane that provides structural support and protection. In bacteria, it is typically made of peptidoglycan, which distinguishes them from eukaryotic cells.'
      }
    ]
  };

  const animateParticles = () => {
    if (!isAnimating || !animationRef.current) return;

    const canvas = animationRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw cell membrane
    ctx.strokeStyle = '#2c3e50';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height / 2, 180, 0, 2 * Math.PI);
    ctx.stroke();

    const structures = showEukaryotic ? cellStructures.eukaryotic : cellStructures.prokaryotic;
    
    // Draw organelles
    structures.forEach(organelle => {
      ctx.fillStyle = organelle.color;
      ctx.beginPath();
      ctx.arc(
        organelle.x * canvas.width / 100,
        organelle.y * canvas.height / 100,
        organelle.size,
        0,
        2 * Math.PI
      );
      ctx.fill();
      
      // Add organelle membrane for nucleus in eukaryotic
      if (showEukaryotic && organelle.id === 'nucleus') {
        ctx.strokeStyle = '#2c3e50';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
    });

    // Animate particles
    const time = Date.now() * 0.001;
    const particleCount = showEukaryotic ? 50 : 30;

    for (let i = 0; i < particleCount; i++) {
      const angle = (i / particleCount) * Math.PI * 2 + time * 0.5;
      const radius = showEukaryotic ? 60 + Math.sin(time + i) * 20 : 80 + Math.sin(time + i) * 40;
      
      const x = canvas.width / 2 + Math.cos(angle) * radius;
      const y = canvas.height / 2 + Math.sin(angle) * radius;

      ctx.fillStyle = showEukaryotic ? '#3498db' : '#e74c3c';
      ctx.beginPath();
      ctx.arc(x, y, 2, 0, 2 * Math.PI);
      ctx.fill();
    }

    requestAnimationFrame(animateParticles);
  };

  useEffect(() => {
    animateParticles();
  }, [isAnimating, showEukaryotic]);

  const handleCanvasClick = (event) => {
    const canvas = animationRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / canvas.width) * 100;
    const y = ((event.clientY - rect.top) / canvas.height) * 100;

    const structures = showEukaryotic ? cellStructures.eukaryotic : cellStructures.prokaryotic;
    
    const clickedOrganelle = structures.find(organelle => {
      const distance = Math.sqrt(
        Math.pow(x - organelle.x, 2) + Math.pow(y - organelle.y, 2)
      );
      return distance < organelle.size;
    });

    setActiveInfo(clickedOrganelle || null);
    setHoverInfo(null);
  };

  const handleCanvasHover = (event) => {
    const canvas = animationRef.current;
    const rect = canvas.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / canvas.width) * 100;
    const y = ((event.clientY - rect.top) / canvas.height) * 100;

    const structures = showEukaryotic ? cellStructures.eukaryotic : cellStructures.prokaryotic;
    
    const hoveredOrganelle = structures.find(organelle => {
      const distance = Math.sqrt(
        Math.pow(x - organelle.x, 2) + Math.pow(y - organelle.y, 2)
      );
      return distance < organelle.size;
    });

    setHoverInfo(hoveredOrganelle || null);
  };

  const resetSimulation = () => {
    setIsAnimating(true);
    setShowEukaryotic(true);
    setHoverInfo(null);
    setActiveInfo(null);
  };

  const closeActiveInfo = () => {
    setActiveInfo(null);
  };

  return (
    <div className="cell-visualization">
      <div className="controls">
        <button 
          className={`control-btn ${isAnimating ? 'active' : ''}`}
          onClick={() => setIsAnimating(!isAnimating)}
        >
          {isAnimating ? '⏸️ Pause' : '▶️ Play'}
        </button>
        
        <button 
          className={`control-btn toggle ${showEukaryotic ? 'eukaryotic' : 'prokaryotic'}`}
          onClick={() => setShowEukaryotic(!showEukaryotic)}
        >
          {showEukaryotic ? '🦠 Prokaryotic' : '🧬 Eukaryotic'}
        </button>
        
        <button 
          className="control-btn reset"
          onClick={resetSimulation}
        >
          🔄 Reset
        </button>
      </div>

      <div className="visualization-area">
        <canvas
          ref={animationRef}
          width={600}
          height={400}
          onClick={handleCanvasClick}
          onMouseMove={handleCanvasHover}
          onMouseLeave={() => setHoverInfo(null)}
          className="cell-canvas"
        />
        
        <div className="status-indicator">
          <div className={`status ${showEukaryotic ? 'eukaryotic' : 'prokaryotic'}`}>
            {showEukaryotic ? '🧬 Eukaryotic Cell' : '🦠 Prokaryotic Cell'}
          </div>
          <div className="description">
            {showEukaryotic 
              ? 'Organized structure with membrane-bound nucleus and organelles'
              : 'Simple structure without membrane-bound nucleus'}
          </div>
        </div>

        {hoverInfo && (
          <div 
            className="info-panel hover-panel"
            style={{
              left: `${hoverInfo.x}%`,
              top: `${hoverInfo.y - 10}%`
            }}
          >
            <h4>{hoverInfo.name}</h4>
            <p><strong>Visual:</strong> {hoverInfo.shortText}</p>
            <p>{hoverInfo.description}</p>
          </div>
        )}

        {activeInfo && (
          <div className="info-panel active-panel">
            <button className="close-btn" onClick={closeActiveInfo}>×</button>
            <h3>{activeInfo.name}</h3>
            <div className="info-section">
              <h4>Visual Structure:</h4>
              <p>{activeInfo.shortText}</p>
            </div>
            <div className="info-section">
              <h4>Description:</h4>
              <p>{activeInfo.description}</p>
            </div>
            <div className="info-section">
              <h4>Detailed Information:</h4>
              <p>{activeInfo.detailedInfo}</p>
            </div>
            <div className="particle-info">
              <h4>What's Shown:</h4>
              <p>
                {showEukaryotic 
                  ? '🔵 Blue particles show organized molecular movement following structured pathways, demonstrating efficient, directed transport in compartmentalized cell'
                  : '🔴 Red particles show random, chaotic molecular movement, demonstrating less efficient diffusion-based transport in simple cell'
                }
              </p>
            </div>
          </div>
        )}
      </div>

      <div className="key-features">
        <div className="feature">
          <div className="color-dot eukaryotic"></div>
          <span>Membrane-bound nucleus</span>
        </div>
        <div className="feature">
          <div className="color-dot organelle"></div>
          <span>Specialized organelles</span>
        </div>
        <div className="feature">
          <div className="color-dot particle-eukaryotic"></div>
          <span>Organized transport</span>
        </div>
        <div className="feature">
          <div className="color-dot particle-prokaryotic"></div>
          <span>Random diffusion</span>
        </div>
      </div>

      <div className="learning-objectives">
        <h3>Learning Objectives Demonstrated:</h3>
        <ul>
          <li>✅ <strong>Nucleus as central feature</strong> - Clear visual distinction of nuclear membrane</li>
          <li>✅ <strong>Eukaryotic cell structure</strong> - Multiple organized organelles with specific functions</li>
          <li>✅ <strong>Distinction from prokaryotes</strong> - Immediate visual comparison showing organizational differences</li>
        </ul>
      </div>
    </div>
  );
};

export default EukaryoticCellVisualization;