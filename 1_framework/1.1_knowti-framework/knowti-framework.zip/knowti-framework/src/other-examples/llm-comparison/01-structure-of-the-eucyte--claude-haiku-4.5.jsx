import React, { useState } from 'react';
import { Play, Pause } from 'lucide-react';

export default function CompartmentalizationExamples() {
  const [activeExample, setActiveExample] = useState(0);

  const examples = [
    {
      title: "1. Isolated Reaction Spaces",
      component: <IsolatedSpaces />
    },
    {
      title: "2. Simultaneous Different Reactions",
      component: <SimultaneousReactions />
    },
    {
      title: "3. Metabolic Pipeline",
      component: <MetabolicPipeline />
    },
    {
      title: "4. Organelle Task Assignment",
      component: <OrganelleTask />
    },
    {
      title: "5. Molecular Transport & Specialization",
      component: <MolecularTransport />
    }
  ];

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#fff', padding: '40px 20px' }}>
      <div style={{ maxWidth: '900px', margin: '0 auto' }}>
        <div style={{ marginBottom: '30px' }}>
          <h1 style={{ fontSize: '28px', fontWeight: '600', marginBottom: '20px', color: '#222' }}>
            Cellular Compartmentalization
          </h1>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            {examples.map((ex, i) => (
              <button
                key={i}
                onClick={() => setActiveExample(i)}
                style={{
                  padding: '10px 16px',
                  border: 'none',
                  borderRadius: '6px',
                  fontSize: '13px',
                  fontWeight: activeExample === i ? '600' : '500',
                  cursor: 'pointer',
                  backgroundColor: activeExample === i ? '#2563eb' : '#e5e7eb',
                  color: activeExample === i ? '#fff' : '#374151',
                  transition: 'all 0.2s'
                }}
              >
                {i + 1}
              </button>
            ))}
          </div>
        </div>

        <div style={{
          backgroundColor: '#fff',
          border: '1px solid #e5e7eb',
          borderRadius: '12px',
          padding: '40px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '30px', color: '#374151' }}>
            {examples[activeExample].title}
          </h2>
          {examples[activeExample].component}
        </div>
      </div>
    </div>
  );
}

// Example 1: Isolated Reaction Spaces
function IsolatedSpaces() {
  const compartments = [
    { name: 'Mitochondria', color: '#f87171', reaction: 'ATP\nProduction', molecules: 12 },
    { name: 'Golgi', color: '#fbbf24', reaction: 'Protein\nPackaging', molecules: 8 },
    { name: 'Lysosome', color: '#a78bfa', reaction: 'Digestion', molecules: 15 },
    { name: 'Ribosome', color: '#34d399', reaction: 'Protein\nSynthesis', molecules: 10 }
  ];

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: '20px'
    }}>
      {compartments.map((comp, i) => (
        <div
          key={i}
          style={{
            padding: '20px',
            backgroundColor: comp.color,
            opacity: 0.15,
            borderRadius: '12px',
            border: `2px solid ${comp.color}`,
            textAlign: 'center'
          }}
        >
          <div style={{
            width: '60px',
            height: '60px',
            backgroundColor: comp.color,
            borderRadius: '50%',
            margin: '0 auto 12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#fff'
          }}>
            ●
          </div>
          <div style={{ fontSize: '13px', fontWeight: '600', color: '#1f2937', marginBottom: '8px' }}>
            {comp.name}
          </div>
          <div style={{ fontSize: '11px', color: '#4b5563', whiteSpace: 'pre', marginBottom: '8px' }}>
            {comp.reaction}
          </div>
          <div style={{ fontSize: '12px', color: comp.color, fontWeight: '600' }}>
            {comp.molecules} molecules
          </div>
        </div>
      ))}
    </div>
  );
}

// Example 2: Simultaneous Different Reactions
function SimultaneousReactions() {
  const [running, setRunning] = useState(true);
  const [time, setTime] = useState(0);

  React.useEffect(() => {
    if (!running) return;
    const timer = setInterval(() => setTime(t => (t + 1) % 100), 100);
    return () => clearInterval(timer);
  }, [running]);

  const reactions = [
    { name: 'Glycolysis', color: '#ef4444', progress: (time * 1.2) % 100 },
    { name: 'Beta-oxidation', color: '#f97316', progress: (time * 0.8) % 100 },
    { name: 'Citric Acid Cycle', color: '#eab308', progress: (time * 0.9) % 100 },
    { name: 'Photosynthesis', color: '#22c55e', progress: (time * 1.1) % 100 }
  ];

  return (
    <div>
      <div style={{ marginBottom: '20px' }}>
        <button
          onClick={() => setRunning(!running)}
          style={{
            padding: '8px 16px',
            backgroundColor: '#2563eb',
            color: '#fff',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontSize: '13px',
            fontWeight: '600',
            display: 'flex',
            alignItems: 'center',
            gap: '6px'
          }}
        >
          {running ? <Pause size={16} /> : <Play size={16} />}
          {running ? 'Pause' : 'Play'}
        </button>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        {reactions.map((rx, i) => (
          <div key={i}>
            <div style={{ fontSize: '12px', fontWeight: '600', color: '#374151', marginBottom: '8px' }}>
              {rx.name}
            </div>
            <div style={{
              height: '24px',
              backgroundColor: '#f3f4f6',
              borderRadius: '12px',
              overflow: 'hidden',
              position: 'relative'
            }}>
              <div
                style={{
                  height: '100%',
                  width: `${rx.progress}%`,
                  backgroundColor: rx.color,
                  transition: 'width 0.1s linear',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'flex-end',
                  paddingRight: '8px',
                  fontSize: '10px',
                  fontWeight: '600',
                  color: '#fff'
                }}
              >
                {Math.round(rx.progress)}%
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Example 3: Metabolic Pipeline
function MetabolicPipeline() {
  const stages = [
    { label: 'Input', color: '#3b82f6', value: 'Glucose' },
    { label: 'Stage 1', color: '#8b5cf6', value: 'Glycolysis' },
    { label: 'Stage 2', color: '#ec4899', value: 'Acetyl-CoA' },
    { label: 'Stage 3', color: '#f97316', value: 'Citric Cycle' },
    { label: 'Output', color: '#22c55e', value: 'ATP (Energy)' }
  ];

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '16px', overflowX: 'auto', padding: '20px 0' }}>
      {stages.map((stage, i) => (
        <React.Fragment key={i}>
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            minWidth: '90px'
          }}>
            <div style={{
              width: '70px',
              height: '70px',
              backgroundColor: stage.color,
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#fff',
              fontWeight: 'bold',
              marginBottom: '8px',
              fontSize: '24px'
            }}>
              ⬤
            </div>
            <div style={{ fontSize: '11px', fontWeight: '600', color: '#6b7280', textAlign: 'center' }}>
              {stage.label}
            </div>
            <div style={{ fontSize: '11px', color: stage.color, fontWeight: '600', marginTop: '4px' }}>
              {stage.value}
            </div>
          </div>
          {i < stages.length - 1 && (
            <div style={{ fontSize: '20px', color: '#d1d5db', marginBottom: '10px' }}>→</div>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

// Example 4: Organelle Task Assignment
function OrganelleTask() {
  const organelles = [
    { name: 'Nucleus', task: 'Gene\nRegulation', icon: '◆', color: '#1f2937' },
    { name: 'ER', task: 'Protein\nSynthesis', icon: '∿', color: '#7c3aed' },
    { name: 'Golgi', task: 'Sorting &\nShipping', icon: '⬜', color: '#06b6d4' },
    { name: 'Mitochondria', task: 'Energy\nProduction', icon: '❤', color: '#dc2626' }
  ];

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(2, 1fr)',
      gap: '24px'
    }}>
      {organelles.map((org, i) => (
        <div key={i} style={{
          padding: '24px',
          backgroundColor: '#f9fafb',
          borderRadius: '12px',
          border: '2px solid #e5e7eb',
          textAlign: 'center'
        }}>
          <div style={{
            fontSize: '48px',
            marginBottom: '12px',
            color: org.color
          }}>
            {org.icon}
          </div>
          <div style={{ fontSize: '14px', fontWeight: '700', color: '#1f2937', marginBottom: '8px' }}>
            {org.name}
          </div>
          <div style={{ fontSize: '12px', color: '#6b7280', whiteSpace: 'pre', lineHeight: '1.5' }}>
            {org.task}
          </div>
        </div>
      ))}
    </div>
  );
}

// Example 5: Molecular Transport & Specialization
function MolecularTransport() {
  const [positions, setPositions] = useState([0, 25, 50, 75]);

  React.useEffect(() => {
    const timer = setInterval(() => {
      setPositions(prev => prev.map(p => (p + 3) % 100));
    }, 50);
    return () => clearInterval(timer);
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '30px' }}>
      {['Protein Transport', 'Vesicle Movement', 'Ion Channel Flow', 'Enzyme Diffusion'].map((name, idx) => (
        <div key={idx}>
          <div style={{ fontSize: '12px', fontWeight: '600', color: '#374151', marginBottom: '12px' }}>
            {name}
          </div>
          <div style={{
            height: '40px',
            backgroundColor: '#f3f4f6',
            borderRadius: '20px',
            position: 'relative',
            overflow: 'hidden',
            border: '1px solid #e5e7eb'
          }}>
            <div style={{
              position: 'absolute',
              left: `${positions[idx]}%`,
              top: '50%',
              transform: 'translate(-50%, -50%)',
              width: '24px',
              height: '24px',
              backgroundColor: ['#3b82f6', '#8b5cf6', '#ec4899', '#f97316'][idx],
              borderRadius: '50%',
              boxShadow: `0 0 12px ${['#3b82f6', '#8b5cf6', '#ec4899', '#f97316'][idx]}99`
            }} />
          </div>
        </div>
      ))}
    </div>
  );
}