import React, { useState } from "react";

// Organelles data for eukaryotic cell
const ORGANELLES = [
  {
    name: "Nucleus",
    color: "#2563EB",
    cx: 130,
    cy: 130,
    rx: 43,
    ry: 43,
    desc: "Contains the cell's genetic material and acts as the control center.",
    visual: (
      <svg width="55" height="55">
        <ellipse cx="27" cy="27" rx="24" ry="24" fill="#2563EB" opacity={0.9}/>
        <ellipse cx="27" cy="27" rx="12" ry="12" fill="#fff" opacity={0.8}/>
        <ellipse cx="27" cy="27" rx="5" ry="5" fill="#6366F1" />
      </svg>
    ),
  },
  {
    name: "Mitochondrion",
    color: "#F59E42",
    cx: 250,
    cy: 85,
    rx: 38,
    ry: 21,
    desc: "Produces the cell's energy (ATP) through respiration.",
    visual: (
      <svg width="70" height="40">
        <ellipse cx="35" cy="20" rx="30" ry="15" fill="#F59E42" opacity={0.9}/>
        <path d="M10 20 Q 30 30 60 10" stroke="#fff" strokeWidth={2} fill="none"/>
      </svg>
    ),
  },
  {
    name: "Endoplasmic Reticulum",
    color: "#06B6D4",
    cx: 250,
    cy: 200,
    rx: 34,
    ry: 14,
    desc: "Synthesizes proteins and lipids.",
    visual: (
      <svg width="64" height="32">
        <ellipse cx="32" cy="16" rx="28" ry="10" fill="#06B6D4" opacity={0.85}/>
        <rect x="8" y="10" width="48" height="4" fill="#fff" opacity={0.4}/>
        <rect x="10" y="18" width="44" height="4" fill="#fff" opacity={0.3}/>
      </svg>
    ),
  },
  {
    name: "Golgi Apparatus",
    color: "#F472B6",
    cx: 85,
    cy: 210,
    rx: 22,
    ry: 13,
    desc: "Packages and distributes proteins and lipids.",
    visual: (
      <svg width="46" height="32">
        <ellipse cx="23" cy="16" rx="20" ry="10" fill="#F472B6" opacity={0.85}/>
        <ellipse cx="23" cy="20" rx="16" ry="6" fill="#fff" opacity={0.2}/>
      </svg>
    ),
  },
  {
    name: "Lysosome",
    color: "#FBBF24",
    cx: 290,
    cy: 150,
    rx: 12,
    ry: 12,
    desc: "Breaks down waste and cellular debris.",
    visual: (
      <svg width="28" height="28">
        <ellipse cx="14" cy="14" rx="11" ry="11" fill="#FBBF24" opacity={0.85}/>
        <ellipse cx="14" cy="18" rx="5" ry="3" fill="#fff" opacity={0.2}/>
      </svg>
    ),
  },
  {
    name: "Cytoplasm",
    color: "#A7F3D0",
    cx: 180,
    cy: 150,
    rx: 135,
    ry: 95,
    desc: "Fluid that fills the cell and surrounds organelles.",
    visual: (
      <svg width="80" height="28">
        <ellipse cx="40" cy="14" rx="38" ry="12" fill="#A7F3D0" opacity={0.6}/>
      </svg>
    ),
  },
];

export default function EukaryoticCellStatic() {
  const [selected, setSelected] = useState(null);

  // Z-index for cell outline and cytoplasm (background)
  const cytoplasm = ORGANELLES.find(org => org.name === "Cytoplasm");
  const nonCytoplasmic = ORGANELLES.filter(org => org.name !== "Cytoplasm");

  return (
    <div
      style={{
        background: "#fff",
        padding: 32,
        borderRadius: 22,
        boxShadow: "0 4px 18px #ececec",
        fontFamily: "'Inter', Arial, sans-serif",
        maxWidth: 440,
        margin: "24px auto",
      }}
    >
      <h2 style={{ fontWeight: 700, fontSize: 22, marginBottom: 8 }}>
        Structure of the Eukaryotic Cell
      </h2>
      <div style={{
        fontSize: 16, color: "#3B82F6", fontWeight: 600, margin: "0 0 12px 0"
      }}>
        ● Eukaryotic Cell
      </div>
      <div style={{ position: "relative", width: 370, height: 280, margin: "0 auto" }}>
        <svg width={370} height={280} style={{ position: "absolute", zIndex: 1 }}>
          {/* Cytoplasm outline */}
          <ellipse
            cx={cytoplasm.cx}
            cy={cytoplasm.cy}
            rx={cytoplasm.rx}
            ry={cytoplasm.ry}
            fill={cytoplasm.color}
            opacity={0.45}
            stroke="#34D399"
            strokeWidth={3.5}
          />
        </svg>
        {/* Organelles */}
        {nonCytoplasmic.map((org, i) => (
          <div key={org.name} style={{
            position: "absolute",
            left: org.cx - org.rx,
            top: org.cy - org.ry,
            width: org.rx * 2,
            height: org.ry * 2 + 38,
            cursor: "pointer",
            textAlign: "center",
            zIndex: 2,
          }}>
            <svg
              width={org.rx * 2}
              height={org.ry * 2}
              style={{ display: "block" }}
              onClick={() => setSelected(org)}
              tabIndex={0}
              aria-label={org.name}
            >
              <ellipse
                cx={org.rx}
                cy={org.ry}
                rx={org.rx}
                ry={org.ry}
                fill={org.color}
                opacity={0.93}
                stroke="#fff"
                strokeWidth="2"
              />
              {/* Special visual features for special organelles, e.g., nucleus inner */}
              {org.name === "Nucleus" ? (
                <>
                  <ellipse cx={org.rx} cy={org.ry} rx={org.rx * 0.55} ry={org.ry * 0.55} fill="#fff" opacity={0.6}/>
                  <ellipse cx={org.rx} cy={org.ry} rx={org.rx * 0.24} ry={org.ry * 0.24} fill="#6366F1"/>
                </>
              ) : null}
            </svg>
            <div style={{
              fontSize: 13,
              fontWeight: 600,
              color: "#444",
              marginTop: 4,
            }}>
              {org.name}
            </div>
          </div>
        ))}
      </div>
      {/* Organelles info card, appears when organelle is clicked */}
      {selected && (
        <div style={{
          margin: "20px auto 0 auto",
          padding: "20px 18px 10px 18px",
          background: "#F1F5F9",
          borderRadius: 14,
          maxWidth: 340,
          color: "#222",
          boxShadow: "0 2px 6px #d3e2f6",
          textAlign: "left",
          position: "relative"
        }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 18, marginBottom: 7
          }}>
            {selected.visual}
            <span style={{
              fontWeight: 700, fontSize: 18, color: "#374151"
            }}>{selected.name}</span>
          </div>
          <div style={{ fontSize: 15 }}>
            {selected.desc}
          </div>
          <button onClick={() => setSelected(null)} style={{
            position: "absolute", top: 5, right: 8, fontSize: 16, color: "#888",
            background: "none", border: "none", cursor: "pointer", fontWeight: 600,
          }}>
            ✕
          </button>
        </div>
      )}
      <div style={{ fontSize: 13, color: "#aaa", marginTop: 12 }}>
        Click any organelle for details.
      </div>
    </div>
  );
}
