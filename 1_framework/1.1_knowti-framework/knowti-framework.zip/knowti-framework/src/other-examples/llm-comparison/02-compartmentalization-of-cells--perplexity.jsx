import React, { useState, useRef, useEffect } from "react";

const REACTION_TYPES = [
  { color: "#3B82F6", label: "Reaction A" }, // Blue
  { color: "#10B981", label: "Reaction B" }, // Green
  { color: "#F59E42", label: "Reaction C" }, // Orange
];

const COMPARTMENTS = [
  { name: "Compartment 1", x: 40, y: 60, w: 110, h: 230 },
  { name: "Compartment 2", x: 170, y: 60, w: 110, h: 230 },
  { name: "Compartment 3", x: 300, y: 60, w: 110, h: 230 },
];

// Generate random initial positions for the particles.
const randomParticle = (compIdx, typeIdx, compartmentalized) => {
  const comp = COMPARTMENTS[compIdx];
  if (compartmentalized) {
    // Within compartment bounds
    return {
      x: comp.x + 10 + Math.random() * (comp.w - 20),
      y: comp.y + 10 + Math.random() * (comp.h - 20),
      dx: (Math.random() - 0.5) * 2,
      dy: (Math.random() - 0.5) * 2,
      type: typeIdx,
      compartment: compIdx,
    };
  } else {
    // Anywhere in cytoplasm area
    return {
      x: 35 + Math.random() * 375,
      y: 55 + Math.random() * 250,
      dx: (Math.random() - 0.5) * 2.2,
      dy: (Math.random() - 0.5) * 2.2,
      type: typeIdx,
      compartment: compIdx, // simulate "potential zone" for reset
    };
  }
};

const PARTICLES_PER_COMPARTMENT = 8;

const getInitialParticles = (compartmentalized) =>
  COMPARTMENTS.flatMap((_, compIdx) =>
    REACTION_TYPES.map((_, typeIdx) =>
      Array.from({ length: PARTICLES_PER_COMPARTMENT }, () =>
        randomParticle(compIdx, typeIdx, compartmentalized)
      )
    )
  ).flat();

export default function CompartmentalizationVisualizer() {
  const [compartmentalized, setCompartmentalized] = useState(true);
  const [particles, setParticles] = useState(() =>
    getInitialParticles(true)
  );
  const [playing, setPlaying] = useState(false);
  const rafRef = useRef();

  // Animation loop
  useEffect(() => {
    if (!playing) return;
    rafRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line
  }, [playing, compartmentalized, particles]);

  function animate() {
    setParticles((particles) =>
      particles.map((p) => moveParticle(p, compartmentalized))
    );
    rafRef.current = requestAnimationFrame(animate);
  }

  // Movement and bounds for each mode
  function moveParticle(p, compartmentalized) {
    let { x, y, dx, dy, type, compartment } = p;
    let nx = x + dx;
    let ny = y + dy;
    let minX, minY, maxX, maxY;
    if (compartmentalized) {
      // Bound within compartment
      const comp = COMPARTMENTS[compartment];
      minX = comp.x + 10;
      minY = comp.y + 10;
      maxX = comp.x + comp.w - 10;
      maxY = comp.y + comp.h - 10;
    } else {
      // Bound within overall cytoplasm zone
      minX = 35;
      minY = 55;
      maxX = 410;
      maxY = 305;
    }
    if (nx < minX || nx > maxX) dx *= -1;
    if (ny < minY || ny > maxY) dy *= -1;
    nx = Math.max(minX, Math.min(nx, maxX));
    ny = Math.max(minY, Math.min(ny, maxY));
    return { ...p, x: nx, y: ny, dx, dy };
  }

  // STATE TOGGLE: with/without compartmentalization
  const handleToggle = () => {
    setCompartmentalized((prev) => {
      const next = !prev;
      setParticles(getInitialParticles(next));
      return next;
    });
    setPlaying(false); // Pause on mode switch for clarity
  };

  const handleReset = () => {
    setParticles(getInitialParticles(compartmentalized));
    setPlaying(false);
  };

  // STATUS INDICATOR
  const STATE_LABEL = compartmentalized
    ? "Compartmentalization ON"
    : "Compartmentalization OFF";
  const STATE_DESC = compartmentalized
    ? "Simultaneous, separate reactions can occur in dedicated zones."
    : "Reactions mix and may interfere everywhere."

  return (
    <div
      style={{
        background: "#fff",
        padding: 32,
        borderRadius: 20,
        maxWidth: 470,
        boxShadow: "0 4px 18px 0 #ececec",
        fontFamily:
          "'Inter', 'Segoe UI', 'Helvetica Neue', Arial, sans-serif",
        margin: "0 auto",
      }}
    >
      <h2 style={{ fontWeight: 700, fontSize: 22, marginBottom: 8 }}>
        Compartmentalization in Cells
      </h2>
      <div
        style={{
          margin: "18px 0 20px 0",
          display: "flex",
          gap: 14,
          alignItems: "center",
        }}
      >
        <button
          onClick={() => setPlaying((p) => !p)}
          style={{
            background: "#3B82F6",
            color: "#fff",
            border: "none",
            borderRadius: 9,
            padding: "6px 16px",
            fontWeight: 600,
            fontSize: 15,
            cursor: "pointer",
            outline: "none",
            transition: "background 0.2s",
            boxShadow: playing
              ? "0 1px 5px 0 #d0e1fd"
              : "0 0px 0px 0 #fff",
          }}
        >
          {playing ? "Pause" : "Play"}
        </button>
        <button
          onClick={handleToggle}
          style={{
            background: compartmentalized ? "#10B981" : "#F59E42",
            color: "#fff",
            border: "none",
            borderRadius: 9,
            padding: "6px 20px",
            fontWeight: 600,
            fontSize: 15,
            cursor: "pointer",
            outline: "none",
          }}
        >
          {compartmentalized ? "Disable" : "Enable"} Compartmentalization
        </button>
        <button
          onClick={handleReset}
          style={{
            background: "#E5E7EB",
            color: "#444",
            border: "none",
            borderRadius: 9,
            padding: "6px 15px",
            fontWeight: 600,
            fontSize: 15,
            cursor: "pointer",
            outline: "none",
          }}
        >
          Reset
        </button>
      </div>
      {/* STATUS LABEL */}
      <div
        style={{
          fontSize: 16,
          fontWeight: 600,
          letterSpacing: 0.01,
          padding: "6px 0 8px 0",
          color: compartmentalized ? "#10B981" : "#F59E42",
        }}
      >
        ● {STATE_LABEL}
      </div>
      <div
        style={{
          fontSize: 13,
          color: "#888",
          marginBottom: 6,
          minHeight: 18,
          transition: "color 0.2s",
        }}
      >
        {STATE_DESC}
      </div>
      {/* VISUALIZATION AREA */}
      <svg
        width={450}
        height={330}
        style={{
          background: "#FAFAFA",
          borderRadius: 18,
          boxShadow: "0 1px 12px #f1f5f9",
          display: "block",
        }}
      >
        {/* Compartments */}
        {compartmentalized
          ? COMPARTMENTS.map((c, idx) => (
              <g key={c.name}>
                <rect
                  x={c.x}
                  y={c.y}
                  width={c.w}
                  height={c.h}
                  rx={22}
                  fill="#F1F5F9"
                  stroke="#CBD5E1"
                  strokeWidth={2.4}
                />
                {/* Draw subtle label */}
                <text
                  x={c.x + c.w / 2}
                  y={c.y + c.h + 20}
                  textAnchor="middle"
                  fontSize={13}
                  fill="#888"
                  fontWeight={500}
                >
                  {c.name}
                </text>
              </g>
            ))
          : (
            // Faded boundary indicating no compartments
            <rect
              x={35}
              y={55}
              width={375}
              height={250}
              rx={32}
              fill="#FEF3C7"
              stroke="#FBBF24"
              strokeWidth={3.1}
              strokeDasharray="7 6"
              opacity={0.2}
            />
          )}
        {/* Particles (animated substrates/enzymes) */}
        {particles.map((p, idx) => (
          <circle
            key={idx}
            cx={p.x}
            cy={p.y}
            r={compartmentalized ? 9.2 : 10.5}
            fill={REACTION_TYPES[p.type].color}
            opacity={compartmentalized ? 0.85 : 0.45}
            stroke="#fff"
            strokeWidth="2"
          >
            {/* Tooltip on hover */}
          </circle>
        ))}
        {/* Minimal reaction type labels as colored dots, bottom right */}
        {REACTION_TYPES.map((t, i) => (
          <g key={t.label}>
            <circle
              cx={360 + i * 28}
              cy={317}
              r={7}
              fill={t.color}
              stroke="#fff"
              strokeWidth={1.5}
            />
            <text
              x={360 + i * 28 + 12}
              y={321}
              fontSize={12}
              fill="#999"
              fontWeight={600}
              textAnchor="start"
            >
              {String.fromCharCode(65 + i)}
            </text>
          </g>
        ))}
      </svg>
      <div style={{ fontSize: 13, color: "#aaa", marginTop: 10 }}>
        Hover or click on particles for more details.
      </div>
    </div>
  );
}
