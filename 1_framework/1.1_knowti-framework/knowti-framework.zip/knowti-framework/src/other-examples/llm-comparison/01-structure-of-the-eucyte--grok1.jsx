import React, { useRef, useEffect, useState } from 'react';
import './EukaryoticCell.css';

const EukaryoticCell = () => {
  const canvasRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isEukaryotic, setIsEukaryotic] = useState(true);
  const [hoveredOrganelle, setHoveredOrganelle] = useState(null);
  const [selectedOrganelle, setSelectedOrganelle] = useState(null);
  const animationRef = useRef(null);

  // Organelle data with detailed information
  const organelles = [
    {
      name: 'Nucleus',
      x: 300,
      y: 200,
      radius: 30,
      color: '#ff4d4d',
      borderColor: '#cc0000',
      hoverInfo: 'Nucleus: Stores DNA',
      clickInfo: 'The nucleus is the control center of the eukaryotic cell, containing DNA and regulating gene expression and cell division.',
    },
    {
      name: 'Mitochondrion',
      x: 150,
      y: 100,
      radius: 15,
      color: '#4da8ff',
      borderColor: '#0033cc',
      hoverInfo: 'Mitochondrion: Energy production',
      clickInfo: 'Mitochondria are the powerhouses of the cell, generating ATP through cellular respiration.',
    },
    {
      name: 'Endoplasmic Reticulum',
      x: 400,
      y: 150,
      radius: 10,
      color: '#4dff4d',
      borderColor: '#00cc00',
      hoverInfo: 'ER: Protein synthesis',
      clickInfo: 'The endoplasmic reticulum (ER) is involved in protein synthesis and lipid metabolism. The rough ER has ribosomes, while the smooth ER does not.',
    },
    {
      name: 'Golgi Apparatus',
      x: 300,
      y: 300,
      radius: 12,
      color: '#ffcc00',
      borderColor: '#cc9900',
      hoverInfo: 'Golgi: Protein modification',
      clickInfo: 'The Golgi apparatus modifies, sorts, and packages proteins and lipids for secretion or use within the cell.',
    },
  ];

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const width = (canvas.width = 600);
    const height = (canvas.height = 400);

    // Particle class for organelles/molecules
    class Particle {
      constructor(x, y, color, radius, speedX, speedY, borderColor = null) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.radius = radius;
        this.speedX = speedX;
        this.speedY = speedY;
        this.borderColor = borderColor;
      }

      draw(ctx) {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.fill();
        if (this.borderColor) {
          ctx.strokeStyle = this.borderColor;
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      }

      update(width, height) {
        this.x += this.speedX;
        this.y += this.speedY;
        if (this.x < 0 || this.x > width) this.speedX *= -1;
        if (this.y < 0 || this.y > height) this.speedY *= -1;
      }
    }

    // Initialize particles
    let particles = [];
    const initParticles = () => {
      particles = [];
      if (isEukaryotic) {
        // Eukaryotic: structured organelles with borders
        organelles.forEach(org => {
          particles.push(
            new Particle(org.x, org.y, org.color, org.radius, 0, 0, org.borderColor)
          );
        });
      } else {
        // Prokaryotic: chaotic molecules, no borders
        for (let i = 0; i < 20; i++) {
          const x = Math.random() * width;
          const y = Math.random() * height;
          const speedX = (Math.random() - 0.5) * 2;
          const speedY = (Math.random() - 0.5) * 2;
          particles.push(new Particle(x, y, '#999999', 5, speedX, speedY));
        }
      }
    };

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);

      // Draw cell membrane
      ctx.strokeStyle = '#333333';
      ctx.lineWidth = 5;
      ctx.strokeRect(20, 20, width - 40, height - 40);

      // Draw particles
      particles.forEach(particle => {
        particle.draw(ctx);
        if (isPlaying && !isEukaryotic) {
          particle.update(width, height);
        }
      });

      // Draw labels for eukaryotic state
      if (isEukaryotic) {
        ctx.fillStyle = '#333333';
        ctx.font = '14px Arial';
        organelles.forEach(org => {
          ctx.fillText(org.name, org.x - 20, org.y - org.radius - 10);
        });

        // Draw hover info
        if (hoveredOrganelle) {
          ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
          ctx.fillRect(10, 10, 200, 30);
          ctx.fillStyle = '#ffffff';
          ctx.font = '12px Arial';
          ctx.fillText(hoveredOrganelle.hoverInfo, 15, 25);
        }
      }

      if (isPlaying) {
        animationRef.current = requestAnimationFrame(animate);
      }
    };

    // Mouse move handler for hover
    const handleMouseMove = e => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      let found = null;
      if (isEukaryotic) {
        organelles.forEach(org => {
          if (Math.hypot(x - org.x, y - org.y) < org.radius) {
            found = org;
          }
        });
      }
      setHoveredOrganelle(found);
    };

    // Mouse click handler
    const handleClick = e => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      let found = null;
      if (isEukaryotic) {
        organelles.forEach(org => {
          if (Math.hypot(x - org.x, y - org.y) < org.radius) {
            found = org;
          }
        });
      }
      setSelectedOrganelle(found);
    };

    // Add event listeners
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('click', handleClick);

    // Initialize and start animation
    initParticles();
    animate();

    // Cleanup
    return () => {
      cancelAnimationFrame(animationRef.current);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('click', handleClick);
    };
  }, [isPlaying, isEukaryotic, hoveredOrganelle]);

  // Handle play/pause
  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  // Handle state toggle
  const toggleState = () => {
    setIsEukaryotic(!isEukaryotic);
    setHoveredOrganelle(null);
    setSelectedOrganelle(null);
  };

  // Handle reset
  const resetSimulation = () => {
    setIsPlaying(true);
    setIsEukaryotic(true);
    setHoveredOrganelle(null);
    setSelectedOrganelle(null);
  };

  // Close modal
  const closeModal = () => {
    setSelectedOrganelle(null);
  };

  return (
    <div className="flex flex-col items-center p-4 bg-white">
      <h2 className="text-2xl font-bold mb-4">Eukaryotic vs Prokaryotic Cell</h2>
      <canvas ref={canvasRef} className="border border-gray-300 mb-4"></canvas>
      <div className="flex space-x-4">
        <button
          onClick={togglePlay}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          {isPlaying ? 'Pause' : 'Play'}
        </button>
        <button
          onClick={toggleState}
          className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
        >
          {isEukaryotic ? 'Show Prokaryotic' : 'Show Eukaryotic'}
        </button>
        <button
          onClick={resetSimulation}
          className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
        >
          Reset
        </button>
      </div>
      <div className="mt-2 text-lg">
        Status:{' '}
        <span className="font-bold">{isEukaryotic ? 'Eukaryotic Cell' : 'Prokaryotic Cell'}</span>
      </div>

      {/* Modal for click information */}
      {selectedOrganelle && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg max-w-md">
            <h3 className="text-xl font-bold mb-2">{selectedOrganelle.name}</h3>
            <p className="text-gray-700 mb-4">{selectedOrganelle.clickInfo}</p>
            <button
              onClick={closeModal}
              className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EukaryoticCell;