import React, { useState } from 'react';
import { TrendingUp, Brain, DollarSign, Scissors, Dog, Award, Info, Star } from 'lucide-react';

const DogBreedInfographic = () => {
  const [selectedBreed, setSelectedBreed] = useState(null);
  const [hoveredBreed, setHoveredBreed] = useState(null);
  const [sortBy, setSortBy] = useState('popularity');

  const breeds = [
    {
      id: 1,
      name: "Labrador",
      popularity: 95,
      intelligence: 85,
      cost: 60,
      grooming: 40,
      color: "#F59E0B",
      icon: "🦮"
    },
    {
      id: 2,
      name: "German Shepherd",
      popularity: 88,
      intelligence: 95,
      cost: 70,
      grooming: 65,
      color: "#8B4513",
      icon: "🐕"
    },
    {
      id: 3,
      name: "Golden Retriever",
      popularity: 92,
      intelligence: 80,
      cost: 65,
      grooming: 70,
      color: "#DAA520",
      icon: "🦮"
    },
    {
      id: 4,
      name: "French Bulldog",
      popularity: 85,
      intelligence: 55,
      cost: 85,
      grooming: 30,
      color: "#D2691E",
      icon: "🐕"
    },
    {
      id: 5,
      name: "Poodle",
      popularity: 75,
      intelligence: 98,
      cost: 75,
      grooming: 95,
      color: "#4B0082",
      icon: "🐩"
    },
    {
      id: 6,
      name: "Beagle",
      popularity: 78,
      intelligence: 60,
      cost: 50,
      grooming: 35,
      color: "#CD853F",
      icon: "🐕"
    },
    {
      id: 7,
      name: "Bulldog",
      popularity: 72,
      intelligence: 50,
      cost: 80,
      grooming: 25,
      color: "#A0522D",
      icon: "🐕"
    },
    {
      id: 8,
      name: "Border Collie",
      popularity: 65,
      intelligence: 100,
      cost: 55,
      grooming: 60,
      color: "#000000",
      icon: "🐕"
    },
    {
      id: 9,
      name: "Chihuahua",
      popularity: 68,
      intelligence: 45,
      cost: 40,
      grooming: 20,
      color: "#DEB887",
      icon: "🐕"
    },
    {
      id: 10,
      name: "Husky",
      popularity: 80,
      intelligence: 70,
      cost: 68,
      grooming: 80,
      color: "#708090",
      icon: "🐕"
    }
  ];

  const getSortedBreeds = () => {
    const sorted = [...breeds].sort((a, b) => {
      switch(sortBy) {
        case 'popularity': return b.popularity - a.popularity;
        case 'intelligence': return b.intelligence - a.intelligence;
        case 'cost': return b.cost - a.cost;
        case 'grooming': return b.grooming - a.grooming;
        default: return 0;
      }
    });
    return sorted;
  };

  const getMetricColor = (value) => {
    if (value >= 80) return '#10b981';
    if (value >= 60) return '#f59e0b';
    if (value >= 40) return '#f97316';
    return '#ef4444';
  };

  const MetricBar = ({ value, color, label, icon: Icon }) => (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-1">
          <Icon size={12} />
          <span className="font-medium">{label}</span>
        </div>
        <span className="font-bold">{value}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
        <div 
          className="h-2 rounded-full transition-all duration-1000"
          style={{ 
            width: `${value}%`,
            backgroundColor: color
          }}
        />
      </div>
    </div>
  );

  const BreedCard = ({ breed, isHovered, isSelected }) => {
    const scale = isHovered ? 1.05 : isSelected ? 1.03 : 1;
    
    return (
      <div
        onClick={() => setSelectedBreed(isSelected ? null : breed)}
        onMouseEnter={() => setHoveredBreed(breed.id)}
        onMouseLeave={() => setHoveredBreed(null)}
        className="bg-white rounded-2xl p-4 cursor-pointer transition-all shadow-lg hover:shadow-2xl"
        style={{ 
          transform: `scale(${scale})`,
          borderWidth: '3px',
          borderColor: isSelected ? breed.color : 'transparent'
        }}
      >
        <div className="text-center mb-3">
          <div className="text-5xl mb-2">{breed.icon}</div>
          <h3 className="font-bold text-gray-800">{breed.name}</h3>
        </div>

        <div className="space-y-2">
          <MetricBar 
            value={breed.popularity} 
            color={getMetricColor(breed.popularity)}
            label="Pop"
            icon={TrendingUp}
          />
          <MetricBar 
            value={breed.intelligence} 
            color={getMetricColor(breed.intelligence)}
            label="IQ"
            icon={Brain}
          />
          <MetricBar 
            value={breed.cost} 
            color={getMetricColor(breed.cost)}
            label="Cost"
            icon={DollarSign}
          />
          <MetricBar 
            value={breed.grooming} 
            color={getMetricColor(breed.grooming)}
            label="Groom"
            icon={Scissors}
          />
        </div>

        {(isHovered || isSelected) && (
          <div className="mt-3 text-center text-xs text-gray-600">
            {isSelected ? '▼ Click to close' : '▶ Click for details'}
          </div>
        )}
      </div>
    );
  };

  const ScatterPlot = ({ xMetric, yMetric }) => {
    return (
      <div className="relative w-full h-96 bg-gray-50 rounded-xl p-8">
        <div className="absolute bottom-8 left-8 right-8 h-px bg-gray-400" />
        <div className="absolute bottom-8 left-8 top-8 w-px bg-gray-400" />
        
        <div className="absolute left-2 top-1/2 transform -translate-y-1/2 -rotate-90 text-xs font-bold text-gray-600">
          {yMetric.toUpperCase()}
        </div>
        
        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-xs font-bold text-gray-600">
          {xMetric.toUpperCase()}
        </div>

        {breeds.map(breed => {
          const x = (breed[xMetric] / 100) * 100;
          const y = 100 - (breed[yMetric] / 100) * 100;
          const isHovered = hoveredBreed === breed.id;
          const isSelected = selectedBreed?.id === breed.id;

          return (
            <div
              key={breed.id}
              onMouseEnter={() => setHoveredBreed(breed.id)}
              onMouseLeave={() => setHoveredBreed(null)}
              onClick={() => setSelectedBreed(breed)}
              className="absolute cursor-pointer transition-all"
              style={{
                left: `${x}%`,
                top: `${y}%`,
                transform: `translate(-50%, -50%) scale(${isHovered || isSelected ? 1.5 : 1})`
              }}
            >
              <div 
                className="w-8 h-8 rounded-full flex items-center justify-center shadow-lg border-2 border-white"
                style={{ backgroundColor: breed.color }}
              >
                <span className="text-lg">{breed.icon}</span>
              </div>
              {isHovered && (
                <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-2 py-1 rounded text-xs whitespace-nowrap">
                  {breed.name}
                </div>
              )}
            </div>
          );
        })}

        <div className="absolute top-1/2 left-8 right-8 h-px bg-gray-300 opacity-30" />
        <div className="absolute top-8 bottom-8 left-1/2 w-px bg-gray-300 opacity-30" />
      </div>
    );
  };

  const BubbleChart = () => {
    return (
      <div className="relative w-full h-96 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-8 flex items-center justify-center flex-wrap gap-4">
        {breeds.map(breed => {
          const size = 40 + (breed.popularity * 0.8);
          const isHovered = hoveredBreed === breed.id;
          const isSelected = selectedBreed?.id === breed.id;

          return (
            <div
              key={breed.id}
              onMouseEnter={() => setHoveredBreed(breed.id)}
              onMouseLeave={() => setHoveredBreed(null)}
              onClick={() => setSelectedBreed(breed)}
              className="flex items-center justify-center cursor-pointer transition-all relative"
              style={{
                width: `${size}px`,
                height: `${size}px`,
                transform: `scale(${isHovered || isSelected ? 1.2 : 1})`
              }}
            >
              <div 
                className="w-full h-full rounded-full flex items-center justify-center shadow-xl border-4 border-white"
                style={{ 
                  backgroundColor: breed.color,
                  opacity: 0.8
                }}
              >
                <div className="text-center">
                  <div style={{ fontSize: `${size/3}px` }}>{breed.icon}</div>
                </div>
              </div>
              {isHovered && (
                <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-3 py-1 rounded-lg text-xs whitespace-nowrap z-10">
                  {breed.name}: {breed.popularity}%
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  const RadarChart = ({ breed }) => {
    const metrics = [
      { key: 'popularity', label: 'Popularity', angle: 0 },
      { key: 'intelligence', label: 'Intelligence', angle: 90 },
      { key: 'cost', label: 'Cost', angle: 180 },
      { key: 'grooming', label: 'Grooming', angle: 270 },
    ];

    const size = 200;
    const center = size / 2;
    const maxRadius = size / 2 - 40;

    const getPoint = (value, angle) => {
      const radius = (value / 100) * maxRadius;
      const rad = (angle - 90) * (Math.PI / 180);
      return {
        x: center + radius * Math.cos(rad),
        y: center + radius * Math.sin(rad)
      };
    };

    const points = metrics.map(m => getPoint(breed[m.key], m.angle));
    const pathData = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ') + ' Z';

    return (
      <div className="flex items-center justify-center">
        <svg width={size} height={size} className="overflow-visible">
          {[20, 40, 60, 80, 100].map(percent => (
            <circle
              key={percent}
              cx={center}
              cy={center}
              r={(percent / 100) * maxRadius}
              fill="none"
              stroke="#e5e7eb"
              strokeWidth="1"
            />
          ))}

          {metrics.map(m => {
            const end = getPoint(100, m.angle);
            return (
              <line
                key={m.key}
                x1={center}
                y1={center}
                x2={end.x}
                y2={end.y}
                stroke="#d1d5db"
                strokeWidth="1"
              />
            );
          })}

          <path
            d={pathData}
            fill={breed.color}
            fillOpacity="0.4"
            stroke={breed.color}
            strokeWidth="3"
          />

          {points.map((p, i) => (
            <circle
              key={i}
              cx={p.x}
              cy={p.y}
              r="5"
              fill={breed.color}
              stroke="white"
              strokeWidth="2"
            />
          ))}

          {metrics.map(m => {
            const labelPoint = getPoint(115, m.angle);
            return (
              <text
                key={m.key}
                x={labelPoint.x}
                y={labelPoint.y}
                textAnchor="middle"
                dominantBaseline="middle"
                className="text-xs font-bold fill-gray-700"
              >
                {m.label}
              </text>
            );
          })}
        </svg>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
            🐕 Dog Breed Infographic
          </h1>
          <p className="text-gray-600">Interactive visualization of breed characteristics</p>
        </div>

        <div className="bg-white rounded-2xl p-4 mb-8 shadow-lg">
          <div className="flex items-center gap-2 mb-3">
            <Info size={16} className="text-blue-600" />
            <span className="text-sm font-medium text-gray-700">Sort by:</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { key: 'popularity', icon: TrendingUp, label: 'Popularity', color: 'blue' },
              { key: 'intelligence', icon: Brain, label: 'Intelligence', color: 'purple' },
              { key: 'cost', icon: DollarSign, label: 'Cost', color: 'green' },
              { key: 'grooming', icon: Scissors, label: 'Grooming', color: 'pink' }
            ].map(metric => {
              const Icon = metric.icon;
              const isActive = sortBy === metric.key;
              const colorClasses = {
                blue: 'bg-blue-500',
                purple: 'bg-purple-500',
                green: 'bg-green-500',
                pink: 'bg-pink-500'
              };
              
              return (
                <button
                  key={metric.key}
                  onClick={() => setSortBy(metric.key)}
                  className={`flex items-center justify-center gap-2 p-3 rounded-xl font-medium transition-all ${
                    isActive 
                      ? `${colorClasses[metric.color]} text-white shadow-lg scale-105` 
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <Icon size={18} />
                  <span className="text-sm">{metric.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl p-6 shadow-lg mb-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Dog size={24} />
                Breed Comparison
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {getSortedBreeds().slice(0, 6).map(breed => (
                  <BreedCard
                    key={breed.id}
                    breed={breed}
                    isHovered={hoveredBreed === breed.id}
                    isSelected={selectedBreed?.id === breed.id}
                  />
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <TrendingUp size={24} />
                Popularity Visualization
              </h2>
              <p className="text-sm text-gray-600 mb-4">
                💡 Bubble size = popularity. Hover to see details.
              </p>
              <BubbleChart />
            </div>
          </div>

          <div className="space-y-6">
            {selectedBreed ? (
              <div 
                className="bg-white rounded-2xl p-6 shadow-lg border-4"
                style={{ borderColor: selectedBreed.color }}
              >
                <div className="text-center mb-4">
                  <div className="text-6xl mb-2">{selectedBreed.icon}</div>
                  <h2 className="text-2xl font-bold text-gray-800">{selectedBreed.name}</h2>
                </div>

                <div className="mb-4">
                  <RadarChart breed={selectedBreed} />
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <TrendingUp size={16} className="text-blue-600" />
                      <span className="text-sm font-medium">Popularity</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-gray-800">{selectedBreed.popularity}%</span>
                      <Star fill={selectedBreed.popularity > 80 ? '#f59e0b' : 'none'} className="text-yellow-500" size={16} />
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Brain size={16} className="text-purple-600" />
                      <span className="text-sm font-medium">Intelligence</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-gray-800">{selectedBreed.intelligence}%</span>
                      <Award fill={selectedBreed.intelligence > 80 ? '#8b5cf6' : 'none'} className="text-purple-500" size={16} />
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <DollarSign size={16} className="text-green-600" />
                      <span className="text-sm font-medium">Cost</span>
                    </div>
                    <span className="font-bold text-gray-800">{selectedBreed.cost}%</span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-pink-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Scissors size={16} className="text-pink-600" />
                      <span className="text-sm font-medium">Grooming</span>
                    </div>
                    <span className="font-bold text-gray-800">{selectedBreed.grooming}%</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
                <div className="text-6xl mb-4">👆</div>
                <p className="text-gray-600">Click a breed card to see detailed analysis</p>
              </div>
            )}

            <div className="bg-white rounded-2xl p-6 shadow-lg">
              <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                <Info size={18} />
                Visual Guide
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-green-500" />
                  <span className="text-gray-700">High (80-100%)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-yellow-500" />
                  <span className="text-gray-700">Medium (60-79%)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-orange-500" />
                  <span className="text-gray-700">Low (40-59%)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-red-500" />
                  <span className="text-gray-700">Very Low (less than 40%)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-6 shadow-lg mb-8">
          <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Brain size={24} />
            Intelligence vs Cost Analysis
          </h2>
          <p className="text-sm text-gray-600 mb-4">
            💡 Hover over dots to see breed names. Click to select.
          </p>
          <ScatterPlot xMetric="cost" yMetric="intelligence" />
        </div>

        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-6 shadow-lg text-white">
          <h2 className="text-2xl font-bold mb-4">📊 Visualization Insights</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-bold mb-2 flex items-center gap-2">
                <TrendingUp size={18} />
                Popularity
              </h3>
              <p className="text-sm text-blue-100">
                Bubble chart shows relative popularity through size. Larger bubbles = more popular breeds.
              </p>
            </div>
            <div>
              <h3 className="font-bold mb-2 flex items-center gap-2">
                <Brain size={18} />
                Intelligence
              </h3>
              <p className="text-sm text-purple-100">
                Scatter plot reveals: high intelligence does not always mean high cost. Border Collies = smartest but affordable!
              </p>
            </div>
            <div>
              <h3 className="font-bold mb-2 flex items-center gap-2">
                <Scissors size={18} />
                Grooming
              </h3>
              <p className="text-sm text-pink-100">
                Bar charts show: Poodles need most grooming (95%), while Chihuahuas need least (20%).
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DogBreedInfographic;