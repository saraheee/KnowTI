import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

// Import all your components here
// Replace these examples with your actual component imports
const Component1 = () => <div className="flex items-center justify-center h-full bg-blue-500 text-white text-4xl">Component 1</div>;
const Component2 = () => <div className="flex items-center justify-center h-full bg-green-500 text-white text-4xl">Component 2</div>;
const Component3 = () => <div className="flex items-center justify-center h-full bg-purple-500 text-white text-4xl">Component 3</div>;

// Array of all your components
const components = [
  { name: 'Component 1', component: Component1 },
  { name: 'Component 2', component: Component2 },
  { name: 'Component 3', component: Component3 },
];

export default function App() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % components.length);
  };

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + components.length) % components.length);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowLeft') {
      goToPrevious();
    } else if (e.key === 'ArrowRight') {
      goToNext();
    }
  };

  React.useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const CurrentComponent = components[currentIndex].component;

  return (
    <div className="fixed inset-0 bg-gray-900 flex items-center justify-center">
      {/* Main content area */}
      <div className="w-full h-full relative">
        <CurrentComponent />
        
        {/* Component name indicator */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-50 text-white px-4 py-2 rounded-full text-sm">
          {currentIndex + 1} / {components.length} - {components[currentIndex].name}
        </div>
      </div>

      {/* Left arrow */}
      <button
        onClick={goToPrevious}
        className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 hover:bg-opacity-75 text-white p-4 rounded-full transition-all"
        aria-label="Previous component"
      >
        <ChevronLeft size={32} />
      </button>

      {/* Right arrow */}
      <button
        onClick={goToNext}
        className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 hover:bg-opacity-75 text-white p-4 rounded-full transition-all"
        aria-label="Next component"
      >
        <ChevronRight size={32} />
      </button>

      {/* Navigation dots */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
        {components.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentIndex
                ? 'bg-white w-8'
                : 'bg-white bg-opacity-50 hover:bg-opacity-75'
            }`}
            aria-label={`Go to component ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}