import './App.css';
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { X, Play, Pause, Download, Square } from 'lucide-react';

import eukaryoteVideo from './eukaryotes.mp4';
import genomeVideo from './genome.mp4';

import { GENOME_COMPONENTS } from './index';
import { EUKARYOTE_COMPONENTS } from './index';

let jsonFile = '/eukaryotes-data.json';
let inputVideo = './eukaryotes.mp4';
let VIDEO_DURATION = 323;
const MIN_VIDEO_WIDTH = 400;
const MAX_VIDEO_WIDTH = 1200;
const SIDE_PADDING = 48;

////////////////////////////////////
// TODO: select video
//
const selectedVideo = 'EUKARYOTES';
//const selectedVideo = 'GENOME'; 
////////////////////////////////////


let SPECIAL_COMPONENTS = {};
loadSpecialComponents(selectedVideo);

function loadSpecialComponents(selectedVideo) {
  inputVideo = selectedVideo === 'EUKARYOTES' ? eukaryoteVideo : genomeVideo;
  VIDEO_DURATION = selectedVideo === 'EUKARYOTES' ? 326 : 263
  if (selectedVideo === 'EUKARYOTES') {
    console.log('EUKARYOTES video is selected!');
    jsonFile = 'eukaryotes-data.json';
    SPECIAL_COMPONENTS = EUKARYOTE_COMPONENTS;

  } else if (selectedVideo === 'GENOME') {
    console.log('GENOME video is selected!');
    jsonFile = 'genome-data.json';
    SPECIAL_COMPONENTS = GENOME_COMPONENTS;

  } else {
    console.log('UNKNOWN video is selected!');
  }
}

const DEFAULT_SPECIAL_CONFIG = {
  flexRatio: 4,
  height: '600px',
  scale: 0.9,
  scaleOrigin: 'top-left'
};

// Logging functionality
class UserActivityLogger {
  constructor() {
    this.logs = [];
    this.sessionStartTime = Date.now();
    this.isLogging = false;
    this.mousePosition = { x: 0, y: 0 };
    this.lastMouseUpdate = 0;
  }

  start() {
    this.isLogging = true;
    this.sessionStartTime = Date.now();
    this.log('SESSION_START', 'Application started', { timestamp: new Date().toISOString() });
  }

  stop() {
    if (this.isLogging) {
      this.log('SESSION_END', 'Application stopped', { 
        timestamp: new Date().toISOString(),
        totalDuration: Date.now() - this.sessionStartTime
      });
      this.isLogging = false;
    }
  }

  log(action, description, data = {}) {
    if (!this.isLogging) return;
    
    const logEntry = {
      timestamp: Date.now(),
      relativeTime: Date.now() - this.sessionStartTime,
      action,
      description,
      mousePosition: { ...this.mousePosition },
      ...data
    };
    
    this.logs.push(logEntry);
    console.log('LOG:', logEntry);
  }

  updateMousePosition(x, y) {
    const now = Date.now();
    if (now - this.lastMouseUpdate > 100) { // Throttle mouse updates
      this.mousePosition = { x, y };
      this.lastMouseUpdate = now;
      if (this.isLogging) {
        this.log('MOUSE_MOVE', `Mouse moved to (${x}, ${y})`, { x, y });
      }
    }
  }

  generateReport() {
    const totalDuration = Date.now() - this.sessionStartTime;
    const report = [
      '='.repeat(80),
      'USER ACTIVITY LOG REPORT',
      '='.repeat(80),
      `Session Start: ${new Date(this.sessionStartTime).toLocaleString()}`,
      `Session End: ${new Date().toLocaleString()}`,
      `Total Duration: ${(totalDuration / 1000).toFixed(2)} seconds`,
      `Total Actions: ${this.logs.length}`,
      '',
      'DETAILED ACTION LOG:',
      '-'.repeat(80),
      ''
    ];

    this.logs.forEach((log, index) => {
      report.push(`[${index + 1}] ${new Date(log.timestamp).toLocaleTimeString()}`);
      report.push(`    Time: +${(log.relativeTime / 1000).toFixed(2)}s`);
      report.push(`    Action: ${log.action}`);
      report.push(`    Description: ${log.description}`);
      report.push(`    Mouse: (${log.mousePosition.x}, ${log.mousePosition.y})`);
      
      // Add specific data based on action type
      if (log.videoTime !== undefined) {
        report.push(`    Video Time: ${log.videoTime.toFixed(2)}s`);
      }
      if (log.sliderValue !== undefined) {
        report.push(`    Slider Value: ${log.sliderValue}%`);
      }
      if (log.eventTitle) {
        report.push(`    Event: ${log.eventTitle}`);
      }
      if (log.componentName) {
        report.push(`    Component: ${log.componentName}`);
      }
      if (log.videoWidth) {
        report.push(`    Video Width: ${log.videoWidth}px`);
      }
      
      report.push('');
    });

    // Add summary statistics
    report.push('-'.repeat(80));
    report.push('SUMMARY STATISTICS:');
    report.push('-'.repeat(80));
    
    const actionCounts = {};
    this.logs.forEach(log => {
      actionCounts[log.action] = (actionCounts[log.action] || 0) + 1;
    });
    
    Object.entries(actionCounts).forEach(([action, count]) => {
      report.push(`${action}: ${count} times`);
    });

    return report.join('\n');
  }

  downloadReport() {
    const report = this.generateReport();
    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `user-activity-log-${new Date().toISOString().replace(/[:.]/g, '-')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

// Helper functions
function parseTimeToSeconds(timeString) {
  // Parse "04:16,556" format to seconds
  const parts = timeString.split(':');
  if (parts.length !== 2) return 0;
  
  const minutes = parseInt(parts[0], 10);
  const secondsParts = parts[1].split(',');
  const seconds = parseInt(secondsParts[0], 10);
  const milliseconds = secondsParts[1] ? parseInt(secondsParts[1], 10) : 0;
  
  return minutes * 60 + seconds + milliseconds / 1000;
}

function timeToPercentage(timeInSeconds) {
  return (timeInSeconds / VIDEO_DURATION) * 100;
}

function percentageToTime(percentage) {
  return (percentage / 100) * VIDEO_DURATION;
}

function getSpecialEventInfo(event) {
  if (!event) return null;
  if (event.specialComponent) {
    const componentName = event.specialComponent.component;
    const Component = SPECIAL_COMPONENTS[componentName];
    if (!Component) return null;
    return {
      Component,
      config: { ...DEFAULT_SPECIAL_CONFIG, ...event.specialComponent.config },
      props: event.specialComponent.props || {}
    };
  }
  const Component = SPECIAL_COMPONENTS[event.title];
  if (Component) {
    return {
      Component,
      config: DEFAULT_SPECIAL_CONFIG,
      props: {}
    };
  }
  return null;
}

// --- Components ---
function VideoPlayer({
  videoRef, videoWidth, isVideoPlaying, isVideoHovered,
  handleVideoClick, handleVideoMouseEnter, handleVideoMouseLeave, inputVideo
}) {
  return (
    <div
      className="bg-black rounded-lg shadow-lg overflow-hidden cursor-pointer relative mx-auto"
      style={{ width: `${videoWidth}px`, maxWidth: '100%' }}
      onClick={handleVideoClick}
      onMouseEnter={handleVideoMouseEnter}
      onMouseLeave={handleVideoMouseLeave}
    >
      <video
        ref={videoRef}
        className="w-full h-auto object-contain cursor-pointer"
        preload="metadata"
        muted={false}
        playsInline
        src={inputVideo}
        onSeeked={e => e.stopPropagation()}
      >
        Your browser does not support the video element.
      </video>
      {isVideoHovered && (
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-30 transition-all duration-200">
          <div className="bg-black bg-opacity-60 rounded-full p-4 transform transition-transform hover:scale-110">
            {isVideoPlaying ? (
              <Pause size={48} className="text-white" />
            ) : (
              <Play size={48} className="text-white ml-1" />
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function Slider({
  sliderRef, videoWidth, sliderValue,
  handleSliderChange, handleSliderMouseDown, handleSliderMouseUp, handleSliderFocus
}) {
  return (
    <div className="mx-auto" style={{ width: `${videoWidth}px`, maxWidth: '100%' }}>
      <input
        ref={sliderRef}
        type="range"
        min="0"
        max="100"
        value={sliderValue}
        onChange={handleSliderChange}
        onMouseDown={handleSliderMouseDown}
        onMouseUp={handleSliderMouseUp}
        onTouchStart={handleSliderMouseDown}
        onTouchEnd={handleSliderMouseUp}
        onFocus={handleSliderFocus}
        className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer slider"
        style={{
          background: `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${sliderValue}%, #d1d5db ${sliderValue}%, #d1d5db 100%)`
        }}
      />
    </div>
  );
}

function Timeline({
  events, videoWidth, sliderValue, currentEvent, hoveredEvent, highlightedEvent,
  handleEventClick, handleEventHover
}) {
  return (
    <div className="relative mx-auto" style={{ width: `${videoWidth}px`, maxWidth: '100%', height: "80px" }}>
      <div className="relative h-full" style={{ position: 'relative' }}>
        {events.map((event, index) => {
          const isActive = currentEvent && event.id === currentEvent.id;
          const isHovered = hoveredEvent?.id === event.id;
          const isHighlighted = highlightedEvent?.id === event.id;
          const isNearPosition = Math.abs(event.timelinePosition - sliderValue) <= 0.5;
          
          const leftPositionPixels = (event.timelinePosition / 100) * videoWidth;
          const iconRadius = 18; // half pixel size of the icon (36px / 2)
          const adjustedLeftPosition = Math.max(iconRadius, Math.min(videoWidth - iconRadius, leftPositionPixels));

          return (
            <div
              key={event.id}
              className="flex flex-col items-center cursor-pointer group absolute"
              style={{
                left: `${adjustedLeftPosition}px`,
                transform: 'translateX(-50%)',
                top: 0,
              }}
              onClick={() => handleEventClick(event)}
              onMouseEnter={() => handleEventHover(event)}
              onMouseLeave={() => handleEventHover(null)}
            >
              <div
                className={`
                  w-8 h-8 md:w-9 md:h-9 rounded-full flex items-center justify-center text-sm md:text-base mb-2 
                  transition-all duration-300 ease-out relative
                  ${isActive ? 'bg-blue-600 scale-125 shadow-lg shadow-blue-400/50 animate-glow' : 'bg-blue-400'}
                  ${isHighlighted ? 'bg-yellow-500 scale-140 shadow-xl shadow-yellow-400/60 animate-bounce' : ''}
                  ${isNearPosition && !isActive && !isHighlighted ? 'bg-blue-500 scale-110 animate-pulse' : ''}
                  hover:bg-blue-500 hover:scale-105
                `}
              >
                {(isActive || isHighlighted) && (
                  <div className={`absolute inset-0 rounded-full animate-ping opacity-30 ${
                    isHighlighted ? 'bg-yellow-500' : 'bg-blue-600'
                  }`}></div>
                )}
                <span className="relative z-10">{event.icon}</span>
              </div>
              
              {/* Title for active highlighted events */}
              {(isActive || isHighlighted) && (
                <div className={`
                  text-xs md:text-sm font-semibold text-center whitespace-nowrap 
                  transition-all duration-300 max-w-24 md:max-w-none overflow-hidden
                  ${isHighlighted ? 'text-yellow-600 scale-110 animate-pulse' : 'text-blue-800 scale-105'}
                `}>
                  <span className="hidden md:inline">{event.title}</span>
                  <span className="md:hidden">{event.title.split(' ')[0]}</span>
                </div>
              )}
              
              {/* Hover tooltip */}
              {isHovered && !isActive && !isHighlighted && (
                <div className="absolute -top-16 left-1/2 transform -translate-x-1/2 px-3 py-2 bg-gray-800 text-white text-xs rounded-lg shadow-lg z-10 animate-fadeIn whitespace-nowrap">
                  <div className="font-medium">{event.title}</div>
                  <div className="text-xs opacity-75">{event.minute}</div>
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-800"></div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function SpecialOverlay({ show, isClosing, currentEvent, currentSpecialInfo, handleCloseSpecialComponent }) {
  if (!currentSpecialInfo) return null;
  const { Component, props } = currentSpecialInfo;

  return (
    (show || isClosing) && (
      <div
        className={`fixed inset-0 bg-black transition-opacity duration-300 flex items-center justify-center z-50 p-4 ${
          show && !isClosing ? 'bg-opacity-50' : 'bg-opacity-0'
        }`}
        onClick={handleCloseSpecialComponent}
      >
        <div
          className={`bg-white bg-opacity-95 backdrop-blur-sm rounded-lg shadow-2xl relative max-w-7xl max-h-[90vh] w-full h-[90vh] overflow-hidden transition-all duration-300 transform ${
            show && !isClosing ? 'scale-100 opacity-100' : 'scale-95 opacity-0'
          }`}
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50 bg-opacity-90">
            <div className="flex items-center">
              <span className="text-2xl md:text-3xl mr-3">{currentEvent.icon}</span>
              <div>
                <h2 className="text-lg md:text-xl font-bold text-black">{currentEvent.title}</h2>
                <p className="text-xs md:text-sm text-gray-600">{currentEvent.minute}</p>
              </div>
            </div>
            <button
              onClick={handleCloseSpecialComponent}
              className="text-gray-600 hover:text-red-600 transition-colors p-2 rounded-full hover:bg-gray-200 hover:bg-opacity-50"
            >
              <X size={24} className="md:hidden" />
              <X size={28} className="hidden md:block" />
            </button>
          </div>

          {/* Content */}
          <div
            className="p-4 md:p-6 h-full overflow-auto flex items-center justify-center"
            style={{ height: 'calc(100% - 80px)' }} // Subtract header height
          >
            <div className="w-full h-full max-w-full max-h-full overflow-auto flex items-center justify-center">
              <div className="max-w-full max-h-full overflow-auto">
                <Component {...props} />
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  );
}

function LoggingControls({ logger, isLogging, onStartLogging, onStopLogging, onDownloadLog }) {
  return (
    <div className="fixed top-4 right-4 bg-white bg-opacity-90 backdrop-blur-sm rounded-lg shadow-lg p-4 z-40">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className={`w-3 h-3 rounded-full ${isLogging ? 'bg-red-500 animate-pulse' : 'bg-gray-400'}`}></div>
          <span className="text-sm font-medium">{isLogging ? 'Recording' : 'Stopped'}</span>
        </div>
        
        {!isLogging ? (
          <button
            onClick={onStartLogging}
            className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-sm transition-colors"
          >
            <Play size={16} />
            Start
          </button>
        ) : (
          <button
            onClick={onStopLogging}
            className="flex items-center gap-2 bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm transition-colors"
          >
            <Square size={16} />
            Stop
          </button>
        )}
        
        <button
          onClick={onDownloadLog}
          className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-sm transition-colors"
          title="Download Log"
        >
          <Download size={16} />
          Log
        </button>
      </div>
    </div>
  );
}

function Legend({ sliderValue, isUserInteracting, currentEvent, sliderActivated, videoWidth }) {
  return (
    <div className="text-center text-xs md:text-base text-gray-600 mt-4 px-4">
      <p className="break-words">
        Video: {VIDEO_DURATION}s | Position: {percentageToTime(sliderValue).toFixed(1)}s |
        {isUserInteracting ? ' (User control)' : ' (Auto-sync)'}
        {currentEvent && ` | Active: ${currentEvent.title} (${currentEvent.minute})`}
        {sliderActivated && ' | Slider: Active'}
        | Video: {videoWidth}px wide
      </p>
    </div>
  );
}

// --- Main App ---
export default function ZelltypenZeitleiste() {
  // --- State ---
  const [sliderValue, setSliderValue] = useState(0);
  const [currentEvent, setCurrentEvent] = useState(null);
  let [hoveredEvent, setHoveredEvent] = useState(null);
  const [showSpecialComponent, setShowSpecialComponent] = useState(false);
  const [events, setEvents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isUserInteracting, setIsUserInteracting] = useState(false);
  const [lastUpdateTime, setLastUpdateTime] = useState(0);
  const [sliderActivated, setSliderActivated] = useState(true);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [isVideoHovered, setIsVideoHovered] = useState(false);
  const [videoHeight, setVideoHeight] = useState(675);
  const [videoWidth, setVideoWidth] = useState(MAX_VIDEO_WIDTH);
  const [isClosing, setIsClosing] = useState(false);
  const [isLogging, setIsLogging] = useState(false);
  const [highlightedEvent, setHighlightedEvent] = useState(null);
  const [autoOpenTimer, setAutoOpenTimer] = useState(null);
  const [processedEvents, setProcessedEvents] = useState(new Set());

  // --- Refs ---
  const videoRef = useRef(null);
  const sliderRef = useRef(null);
  const animationFrameRef = useRef(null);
  const containerRef = useRef(null);
  const loggerRef = useRef(new UserActivityLogger());

  // Mouse tracking
  useEffect(() => {
    const handleMouseMove = (e) => {
      loggerRef.current.updateMousePosition(e.clientX, e.clientY);
    };

    document.addEventListener('mousemove', handleMouseMove);
    return () => document.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // --- Effects ---
  // Responsive video width
  useEffect(() => {
    const calculateVideoWidth = () => {
      if (!containerRef.current) return MAX_VIDEO_WIDTH;
      const containerWidth = containerRef.current.offsetWidth;
      const availableWidth = containerWidth - SIDE_PADDING;
      return Math.min(MAX_VIDEO_WIDTH, Math.max(MIN_VIDEO_WIDTH, availableWidth));
    };
    const handleResize = () => {
      const newWidth = calculateVideoWidth();
      setVideoWidth(newWidth);
      loggerRef.current.log('WINDOW_RESIZE', 'Window resized', { 
        videoWidth: newWidth,
        windowWidth: window.innerWidth,
        windowHeight: window.innerHeight
      });
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Video height
  useEffect(() => {
    const videoElement = videoRef.current;
    if (!videoElement) return;
    const handleLoadedMetadata = () => {
      const aspectRatio = videoElement.videoHeight / videoElement.videoWidth;
      const newHeight = videoWidth * aspectRatio;
      setVideoHeight(newHeight);
      loggerRef.current.log('VIDEO_METADATA_LOADED', 'Video metadata loaded', {
        videoWidth: videoElement.videoWidth,
        videoHeight: videoElement.videoHeight,
        aspectRatio,
        displayHeight: newHeight
      });
    };
    videoElement.addEventListener('loadedmetadata', handleLoadedMetadata);
    if (videoElement.readyState >= 1) handleLoadedMetadata();
    return () => videoElement.removeEventListener('loadedmetadata', handleLoadedMetadata);
  }, [videoWidth]);

  // Auto-activate slider and enable sound
  useEffect(() => {
    const timer = setTimeout(() => {
      if (sliderRef.current) {
        setIsUserInteracting(true);
        handleStartLogging();
        sliderRef.current.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
        sliderRef.current.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
        sliderRef.current.focus();
        setSliderActivated(true);
        loggerRef.current.log('SLIDER_AUTO_ACTIVATED', 'Slider automatically activated');
        setTimeout(() => setIsUserInteracting(false), 100);
      }
      if (videoRef.current) {
        videoRef.current.muted = false;
        videoRef.current.volume = 1.0;
        loggerRef.current.log('VIDEO_UNMUTED', 'Video unmuted and volume set to 100%');
      }
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  // Load timeline data and convert time format
  useEffect(() => {
    setIsLoading(true);
    fetch(jsonFile)
      .then(response => {
        if (!response.ok) throw new Error('Error loading timeline data');
        return response.json();
      })
      .then(data => {
        // Convert minute format to timeline position
        const processedEvents = data.map(event => ({
          ...event,
          timeInSeconds: parseTimeToSeconds(event.minute),
          timelinePosition: timeToPercentage(parseTimeToSeconds(event.minute))
        }));
        
        // Sort by timeline position
        const sortedEvents = processedEvents.sort((a, b) => a.timelinePosition - b.timelinePosition);
        
        setEvents(sortedEvents);
        setIsLoading(false);
      })
      .catch(err => {
        setError('Error loading timeline data. Please ensure the "timeline-data.json" file is present in the public folder.');
        setIsLoading(false);
      });
  }, []);

  // Event icon activation based on current video position
  useEffect(() => {
    if (events.length === 0 || isLoading) return;
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    
    animationFrameRef.current = requestAnimationFrame(() => {
      let bestEvent = null;
      let closestDistance = Infinity;
      
      for (let event of events) {
        const distance = Math.abs(event.timelinePosition - sliderValue);
        if (distance <= 3 && distance < closestDistance) {
          closestDistance = distance;
          bestEvent = event;
        }
      }
      
      if (!bestEvent) {
        const sortedEvents = [...events].sort((a, b) => a.timelinePosition - b.timelinePosition);
        for (let event of sortedEvents) {
          if (event.timelinePosition <= sliderValue) bestEvent = event;
          else break;
        }
      }
      
      if (bestEvent !== currentEvent) {
        setCurrentEvent(bestEvent);
        if (bestEvent) {
          loggerRef.current.log('EVENT_ACTIVATED', 'Timeline event activated', {
            eventTitle: bestEvent.title,
            eventTime: bestEvent.minute,
            eventId: bestEvent.id,
            sliderValue,
            videoTime: videoRef.current?.currentTime
          });
        }
      }
      
      // Sync video position when user interacts
      if (videoRef.current && isUserInteracting) {
        const videoTime = percentageToTime(sliderValue);
        if (Math.abs(videoRef.current.currentTime - videoTime) > 0.5) {
          videoRef.current.currentTime = videoTime;
          loggerRef.current.log('VIDEO_SEEK', 'Video seeked via slider', {
            newTime: videoTime,
            sliderValue
          });
        }
      }
    });
    
    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [sliderValue, events, isLoading, isUserInteracting, currentEvent]);

  // Video time update listener
  useEffect(() => {
    const videoElement = videoRef.current;
    if (!videoElement) return;
    let throttleTimeout = null;
    
    const updateSliderFromVideo = () => {
      if (isUserInteracting || videoElement.paused) return;
      const currentTime = videoElement.currentTime;
      const now = Date.now();
      if (now - lastUpdateTime < 100) return;
      
      const newSliderValue = Math.round(timeToPercentage(currentTime));
      if (Math.abs(newSliderValue - sliderValue) >= 1) {
        setSliderValue(Math.min(100, Math.max(0, newSliderValue)));
        setLastUpdateTime(now);
      }
    };
    
    const throttledUpdate = () => {
      if (throttleTimeout) return;
      throttleTimeout = setTimeout(() => {
        updateSliderFromVideo();
        throttleTimeout = null;
      }, 100);
    };
    
    videoElement.addEventListener('timeupdate', throttledUpdate);
    
    const handlePlay = () => {
      setIsUserInteracting(false);
      setIsVideoPlaying(true);
      loggerRef.current.log('VIDEO_PLAY', 'Video started playing', {
        videoTime: videoElement.currentTime,
        sliderValue
      });
    };
    const handlePause = () => {
      setIsUserInteracting(true);
      setIsVideoPlaying(false);
      loggerRef.current.log('VIDEO_PAUSE', 'Video paused', {
        videoTime: videoElement.currentTime,
        sliderValue
      });
    };
    const handleSeeking = () => {
      setIsUserInteracting(true);
      loggerRef.current.log('VIDEO_SEEKING', 'Video seeking started', {
        videoTime: videoElement.currentTime
      });
    };
    const handleSeeked = () => {
      loggerRef.current.log('VIDEO_SEEKED', 'Video seeking completed', {
        videoTime: videoElement.currentTime
      });
      setTimeout(() => setIsUserInteracting(false), 500);
    };
    
    videoElement.addEventListener('play', handlePlay);
    videoElement.addEventListener('pause', handlePause);
    videoElement.addEventListener('seeking', handleSeeking);
    videoElement.addEventListener('seeked', handleSeeked);
    
    return () => {
      if (throttleTimeout) clearTimeout(throttleTimeout);
      videoElement.removeEventListener('timeupdate', throttledUpdate);
      videoElement.removeEventListener('play', handlePlay);
      videoElement.removeEventListener('pause', handlePause);
      videoElement.removeEventListener('seeking', handleSeeking);
      videoElement.removeEventListener('seeked', handleSeeked);
    };
  }, [sliderValue, isUserInteracting, lastUpdateTime]);

  // Keyboard event listener for closing overlays
  useEffect(() => {
    const handleKeyDown = (event) => {
      loggerRef.current.log('KEY_PRESS', 'Key pressed', { key: event.key, code: event.code });
      if (event.key === 'Escape') {
        if (showSpecialComponent) {
          setShowSpecialComponent(false);
          loggerRef.current.log('OVERLAY_CLOSE_KEYBOARD', 'Overlay closed via Escape key');
        }
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [showSpecialComponent]);

// Process event
useEffect(() => {
  if (!currentEvent || !currentEvent.id) return;
  
  // Check whether event is already processed
  if (processedEvents.has(currentEvent.id)) return;
  
  // Check whether event has a special component
  const specialInfo = getSpecialEventInfo(currentEvent);
  if (!specialInfo) return;
  
  console.log('Auto-opening component and pausing video for:', currentEvent.title);
  
  // Mark event as processed
  setProcessedEvents(prev => new Set([...prev, currentEvent.id]));
  
  // Highlight the current example bubble on the timeline (sofort)
  setHighlightedEvent(currentEvent);
  loggerRef.current.log('EVENT_AUTO_HIGHLIGHT', 'Event automatically highlighted', {
    eventTitle: currentEvent.title,
    eventId: currentEvent.id
  });
  
  // Pause video immediately
  if (videoRef.current && !videoRef.current.paused) {
    const exactPauseTime = videoRef.current.currentTime;
    videoRef.current.pause();
    videoRef.current.currentTime = exactPauseTime - 50;
    
    loggerRef.current.log('VIDEO_AUTO_PAUSE', 'Video automatically paused for special component', {
      componentName: currentEvent.title,
      eventId: currentEvent.id,
      videoTime: exactPauseTime
    });
  }
  
  // Open component immediately
  setShowSpecialComponent(true);
  loggerRef.current.log('SPECIAL_COMPONENT_AUTO_OPEN', 'Special component automatically opened', {
    componentName: currentEvent.title,
    eventId: currentEvent.id
  });
}, [currentEvent, processedEvents]);

// Cleanup when closing the component
useEffect(() => {
  // Check whether the component is manually closed
  if (!showSpecialComponent && highlightedEvent) {
    // Remove highlight
    setHighlightedEvent(null);
    
    // Auto play of video
    if (videoRef.current && videoRef.current.paused) {
      videoRef.current.play();
      loggerRef.current.log('VIDEO_AUTO_RESUME', 'Video automatically resumed after component close', {
        videoTime: videoRef.current.currentTime
      });
    }
  }
}, [showSpecialComponent, highlightedEvent]);

  useEffect(() => {
    return () => {
      if (autoOpenTimer) {
        clearTimeout(autoOpenTimer);
      }
    };
  }, [autoOpenTimer]);

  // Handlers
  const handleSliderChange = useCallback((e) => {
    const newValue = parseInt(e.target.value);
    setIsUserInteracting(true);
    setSliderValue(newValue);
    setSliderActivated(true);
    loggerRef.current.log('SLIDER_CHANGE', 'Slider value changed', {
      oldValue: sliderValue,
      newValue,
      videoTime: videoRef.current?.currentTime
    });
    setTimeout(() => setIsUserInteracting(false), 1000);
  }, [sliderValue]);
  
  const handleSliderMouseDown = useCallback(() => {
    setIsUserInteracting(true);
    setSliderActivated(true);
    loggerRef.current.log('SLIDER_MOUSE_DOWN', 'Slider interaction started');
  }, []);
  
  const handleSliderMouseUp = useCallback(() => {
    loggerRef.current.log('SLIDER_MOUSE_UP', 'Slider interaction ended', {
      finalValue: sliderValue
    });
    setTimeout(() => setIsUserInteracting(false), 500);
  }, [sliderValue]);
  
  const handleSliderFocus = useCallback(() => {
    setSliderActivated(true);
    loggerRef.current.log('SLIDER_FOCUS', 'Slider focused');
  }, []);

  const handleEventClick = useCallback((event) => {
    if (videoRef.current && !videoRef.current.paused) videoRef.current.pause();
    setIsUserInteracting(true);
    setSliderValue(event.timelinePosition);
    setCurrentEvent(event);
    
    loggerRef.current.log('EVENT_CLICK', 'Timeline event clicked', {
      eventTitle: event.title,
      eventId: event.id,
      eventTime: event.minute,
      timelinePosition: event.timelinePosition
    });
    
    const specialInfo = getSpecialEventInfo(event);
    if (specialInfo) {
      setShowSpecialComponent(true);
      loggerRef.current.log('SPECIAL_COMPONENT_OPEN', 'Special component opened', {
        componentName: event.title,
        eventId: event.id
      });
    }    
    setTimeout(() => setIsUserInteracting(false), 1000);
  }, []);

  const handleVideoClick = useCallback(() => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
        loggerRef.current.log('VIDEO_CLICK_PLAY', 'Video clicked to play');
      } else {
        videoRef.current.pause();
        loggerRef.current.log('VIDEO_CLICK_PAUSE', 'Video clicked to pause');
      }
    }
  }, []);
  
  const handleVideoMouseEnter = useCallback(() => {
    setIsVideoHovered(true);
    loggerRef.current.log('VIDEO_HOVER_ENTER', 'Mouse entered video area');
  }, []);
  
  const handleVideoMouseLeave = useCallback(() => {
    setIsVideoHovered(false);
    loggerRef.current.log('VIDEO_HOVER_LEAVE', 'Mouse left video area');
  }, []);

  const handleCloseSpecialComponent = useCallback(() => {
    setIsClosing(true);
    loggerRef.current.log('SPECIAL_COMPONENT_CLOSE_START', 'Special component close initiated');
    setTimeout(() => {
      setShowSpecialComponent(false);
      setIsClosing(false);
      
      // Auto play video after closing component with examples
      if (videoRef.current && videoRef.current.paused) {
        videoRef.current.play();
        loggerRef.current.log('VIDEO_AUTO_RESUME', 'Video automatically resumed after component close');
      }
      
      loggerRef.current.log('SPECIAL_COMPONENT_CLOSE_END', 'Special component closed');
    }, 300);
  }, []);

  const handleStartLogging = useCallback(() => {
    setIsLogging(true);
    loggerRef.current.start();
  }, []);

  // --- Render ---
  const handleStopLogging = useCallback(() => {
    setIsLogging(false);
    loggerRef.current.stop();
  }, []);

  const handleDownloadLog = useCallback(() => {
    loggerRef.current.log('LOG_DOWNLOAD_REQUESTED', 'User requested log download');
    loggerRef.current.downloadReport();
  }, []);

  setHoveredEvent = useCallback((event) => {
    if (event) {
      loggerRef.current.log('EVENT_HOVER_ENTER', 'Mouse entered timeline event', {
        eventTitle: event.title,
        eventId: event.id
      });
    } else {
      loggerRef.current.log('EVENT_HOVER_LEAVE', 'Mouse left timeline event');
    }
  }, []);

  // Component mount/unmount logging
  useEffect(() => {
    loggerRef.current.log('COMPONENT_MOUNT', 'Application component mounted');
    return () => {
      loggerRef.current.log('COMPONENT_UNMOUNT', 'Application component unmounting');
    };
  }, []);

  // Visibility change tracking
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        loggerRef.current.log('PAGE_HIDDEN', 'Page became hidden/inactive');
      } else {
        loggerRef.current.log('PAGE_VISIBLE', 'Page became visible/active');
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  // Render
  const currentSpecialInfo = getSpecialEventInfo(currentEvent);

  if (isLoading) {
    return <div className="flex items-center justify-center h-96 text-xl">Loading data...</div>;
  }
  
  if (error) {
    return (
      <div className="flex flex-col items-center p-12 bg-gray-100 rounded-lg">
        <h1 className="text-4xl font-bold mb-10 text-red-800">Error</h1>
        <p className="text-xl text-red-600">{error}</p>
        <div className="mt-8">
          <label className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded text-lg cursor-pointer">
            Upload File
            <input type="file" accept=".json" onChange={() => {}} className="hidden" />
          </label>
        </div>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="flex flex-col items-center p-6 md:p-12 bg-gray-100 rounded-lg min-h-screen relative">
      <LoggingControls 
        logger={loggerRef.current}
        isLogging={isLogging}
        onStartLogging={handleStartLogging}
        onStopLogging={handleStopLogging}
        onDownloadLog={handleDownloadLog}
      />
      
      <h1 className="text-2xl md:text-4xl font-bold mb-6 md:mb-10 text-blue-800 text-center"></h1>
      
      <div className="w-full flex flex-col gap-6 mb-8">
        <div className="flex flex-col gap-4 min-w-0">
          <VideoPlayer
            videoRef={videoRef}
            videoWidth={videoWidth}
            isVideoPlaying={isVideoPlaying}
            isVideoHovered={isVideoHovered}
            handleVideoClick={handleVideoClick}
            handleVideoMouseEnter={handleVideoMouseEnter}
            handleVideoMouseLeave={handleVideoMouseLeave}
            inputVideo={inputVideo}
          />
          <Slider
            sliderRef={sliderRef}
            videoWidth={videoWidth}
            sliderValue={sliderValue}
            handleSliderChange={handleSliderChange}
            handleSliderMouseDown={handleSliderMouseDown}
            handleSliderMouseUp={handleSliderMouseUp}
            handleSliderFocus={handleSliderFocus}
          />
          <Timeline
            events={events}
            videoWidth={videoWidth}
            sliderValue={sliderValue}
            currentEvent={currentEvent}
            hoveredEvent={hoveredEvent}
            highlightedEvent={highlightedEvent}
            handleEventClick={handleEventClick}
            handleEventHover={setHoveredEvent}
          />
        </div>
      </div>
      
      <SpecialOverlay
        show={showSpecialComponent}
        isClosing={isClosing}
        currentEvent={currentEvent}
        currentSpecialInfo={currentSpecialInfo}
        handleCloseSpecialComponent={handleCloseSpecialComponent}
      />
      
    </div>
  );
}