import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

export default function GenomicBlueprint() {
  const [isAnimating, setIsAnimating] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  const steps = [
    'DNA double helix as foundation',
    'Genes as protein blueprints',
    'Chromosomes organize genes',
    'Genome = Complete blueprint'
  ];

  const stepDescriptions = [
    'DNA forms the molecular foundation of all genetic information',
    'Genes are specific DNA sequences containing instructions for proteins',
    'Chromosomes organize thousands of genes in compact form',
    'The genome encompasses all genes in a cell - the complete blueprint of life'
  ];

  useEffect(() => {
    let interval;
    if (isAnimating) {
      interval = setInterval(() => {
        setCurrentStep((prev) => (prev + 1) % steps.length);
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [isAnimating]);

  /* --- Komponenten --- */
  const DNAHelix = ({ animated = false }) => (
    <div className="relative">
      <svg width="120" height="80" viewBox="0 0 140 90">
        <defs>
          <linearGradient id="dnaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{stopColor:'#3B82F6', stopOpacity:1}} />
            <stop offset="100%" style={{stopColor:'#1D4ED8', stopOpacity:1}} />
          </linearGradient>
          <linearGradient id="dnaGlow" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{stopColor:'#60A5FA', stopOpacity:0.9}} />
            <stop offset="100%" style={{stopColor:'#3B82F6', stopOpacity:0.4}} />
          </linearGradient>
        </defs>
        <path 
          d="M15 25 Q35 15, 55 25 T95 25 Q115 35, 115 45 Q115 55, 95 65 T55 65 Q35 75, 15 65"
          fill="none" 
          stroke={animated ? "url(#dnaGlow)" : "url(#dnaGrad)"} 
          strokeWidth={animated ? "5" : "4"}
          className={animated ? 'animate-pulse' : ''}
        />
        <path 
          d="M15 65 Q35 75, 55 65 T95 65 Q115 55, 115 45 Q115 35, 95 25 T55 25 Q35 15, 15 25"
          fill="none" 
          stroke={animated ? "url(#dnaGlow)" : "url(#dnaGrad)"} 
          strokeWidth={animated ? "5" : "4"}
          opacity="0.8"
          className={animated ? 'animate-pulse' : ''}
        />
      </svg>
    </div>
  );

  const GeneSegment = ({ highlighted = false }) => (
    <div className={`relative p-2 rounded-lg transition-all duration-500 ${highlighted ? 'bg-green-50 shadow-lg' : 'bg-white shadow-md'}`}>
      <div className="flex space-x-1 justify-center">
        {['A','T','G','C','T','A','G','C'].map((base, i) => (
          <div 
            key={i}
            className={`w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold ${
              base==='A'? 'bg-red-100 text-red-700 border border-red-200' :
              base==='T'? 'bg-blue-100 text-blue-700 border border-blue-200' :
              base==='G'? 'bg-green-100 text-green-700 border border-green-200' :
              'bg-yellow-100 text-yellow-700 border border-yellow-200'
            } ${highlighted?'scale-110 shadow':'shadow-sm'}`}
          >
            {base}
          </div>
        ))}
      </div>
      <div className={`text-xs text-green-600 mt-1 text-center ${highlighted?'font-bold text-green-700':''}`}>
        Gene Sequence
      </div>
    </div>
  );

  const ChromosomeView = ({ active = false }) => (
    <div className={`relative transition-all duration-500 ${active?'scale-105':''}`}>
      <div className={`w-16 h-32 bg-gradient-to-b from-orange-400 via-orange-500 to-orange-600 rounded-lg shadow-lg`} />
      <div className={`text-xs text-orange-600 mt-1 text-center ${active?'font-bold text-orange-700':''}`}>
        Chromosome
      </div>
    </div>
  );

  const GenomeCircle = ({ active = false }) => (
    <div className={`relative transition-all duration-500 ${active?'scale-105':''}`}>
      <div className={`w-28 h-28 rounded-full border-4 bg-gradient-to-br from-red-50 to-red-100 flex flex-col items-center justify-center shadow-lg ${active?'border-red-400 shadow-2xl':'border-red-500'}`}>
        <div className={`text-red-600 font-bold text-sm ${active?'text-base text-red-700':''}`}>GENOME</div>
      </div>
      <div className="text-xs text-red-600 mt-1 text-center">Complete Genome</div>
    </div>
  );

  const FlowArrow = ({ direction = "right", color = "#64748B", size = "md" }) => {
    const rotations = { right:"rotate-0", down:"rotate-90", left:"rotate-180", up:"-rotate-90" };
    const sizes = { sm:"w-4 h-4", md:"w-6 h-6", lg:"w-8 h-8" };
    return (
      <div className={`${sizes[size]} ${rotations[direction]}`} style={{color}}>
        <svg viewBox="0 0 24 24" fill="currentColor">
          <path d="M13.025 1l-2.847 2.828 6.176 6.176h-16.354v3.992h16.354l-6.176 6.176 2.847 2.828 10.975-11z"/>
        </svg>
      </div>
    );
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-gray-50 to-white p-4 font-sans">
      <div className="max-w-full mx-auto h-full flex flex-col items-center">

        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Genome as Genetic Blueprint</h1>
          <p className="text-sm text-gray-600">Hierarchical Organization of Genetic Information</p>
        </div>

        {/* Controls */}
        <div className="flex justify-center mb-6 space-x-2">
          <button
            onClick={() => setIsAnimating(!isAnimating)}
            className="flex items-center space-x-1 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 shadow"
          >
            {isAnimating ? <Pause size={16}/> : <Play size={16}/>}
            <span className="text-xs">{isAnimating?'Pause':'Start'}</span>
          </button>
          <button
            onClick={() => { setCurrentStep(0); setIsAnimating(false); }}
            className="flex items-center space-x-1 px-4 py-2 border text-gray-700 rounded-md hover:bg-gray-50 shadow"
          >
            <RotateCcw size={16}/>
            <span className="text-xs">Reset</span>
          </button>
        </div>

        {/* Main Visualization */}
        <div className="flex flex-wrap items-center justify-center space-x-4 space-y-4 mb-6">
          <DNAHelix animated={currentStep===0}/>
          <FlowArrow direction="right" color="#3B82F6" size="md"/>
          <GeneSegment highlighted={currentStep===1}/>
          <FlowArrow direction="right" color="#10B981" size="md"/>
          <ChromosomeView active={currentStep===2}/>
          <FlowArrow direction="right" color="#F59E0B" size="md"/>
          <GenomeCircle active={currentStep===3}/>
        </div>

        {/* Info Panel */}
        <div className="bg-white rounded-xl shadow-lg p-4 w-full max-w-3xl text-center mb-6">
          <div className="text-sm font-bold text-gray-800 mb-2">Step {currentStep+1}: {steps[currentStep]}</div>
          <div className="text-xs text-gray-600">{stepDescriptions[currentStep]}</div>
        </div>

        {/* Statistics */}
        <div className="flex justify-center space-x-8 text-center">
          <div className="bg-white rounded-md p-2 shadow">
            <div className="text-lg font-bold text-gray-700">46</div>
            <div className="text-xs text-gray-500">Chromosomes</div>
          </div>
          <div className="bg-white rounded-md p-2 shadow">
            <div className="text-lg font-bold text-gray-700">~20,000</div>
            <div className="text-xs text-gray-500">Genes</div>
          </div>
          <div className="bg-white rounded-md p-2 shadow">
            <div className="text-lg font-bold text-gray-700">3.2B</div>
            <div className="text-xs text-gray-500">Base Pairs</div>
          </div>
        </div>
      </div>
    </div>
  );
}
