import React, { useState } from 'react';

const GenomeVisualization = () => {
  const [activeCategory, setActiveCategory] = useState(1);
  const [highlightedKeyword, setHighlightedKeyword] = useState(null);
  const [hoveredKeyword, setHoveredKeyword] = useState(null);
  const [tooltip, setTooltip] = useState({ show: false, x: 0, y: 0, content: '' });

  const categories = [
    {
      id: 1,
      title: "Fundamentals",
      description: "Basic concepts of genomes and their biological functions",
      color: "#4299e1",
      keywords: [
        { name: "Genome", description: "Totality of all genes in a cell", timecode: "00:00:29–00:00:35" },
        { name: "Genes", description: "Individual sections of genetic material", timecode: "00:00:23–00:00:29" },
        { name: "Genetic Material", description: "Carrier of genetic information", timecode: "00:00:19–00:00:23" },
        { name: "DNA/RNA", description: "Storage form of hereditary information", timecode: "00:00:35–00:00:41" },
        { name: "Chromosome", description: "Coiled DNA strand", timecode: "00:00:47–00:00:52" }
      ]
    },
    {
      id: 2,
      title: "Structure & Organization",
      description: "Organization and structural components of genetic material",
      color: "#48bb78",
      keywords: [
        { name: "Coding Regions", description: "Areas with protein information", timecode: "00:01:13–00:01:21" },
        { name: "Non-coding Regions", description: "Sections without protein information", timecode: "00:01:25–00:01:30" },
        { name: "Base Pairs", description: "Basic building blocks of DNA", timecode: "00:02:35–00:02:41" },
        { name: "DNA Sequence", description: "Order of bases", timecode: "00:02:57–00:03:02" },
        { name: "Mutation", description: "Change in base sequence", timecode: "00:03:07–00:03:14" }
      ]
    },
    {
      id: 3,
      title: "Human Genome",
      description: "Unique characteristics and properties of human genetic material",
      color: "#ed8936",
      keywords: [
        { name: "46 Chromosomes", description: "Chromosome number in body cells", timecode: "00:01:44–00:01:49" },
        { name: "23 Chromosome Pairs", description: "Homologous chromosomes", timecode: "00:02:04–00:02:09" },
        { name: "Diploid/Haploid", description: "Double vs. single chromosome set", timecode: "00:01:57–00:02:21" },
        { name: "Sex Chromosomes", description: "X and Y chromosome", timecode: "00:02:14–00:02:21" },
        { name: "23,000 Genes", description: "Number of human genes", timecode: "00:02:35–00:02:41" }
      ]
    },
    {
      id: 4,
      title: "Genome Research",
      description: "Scientific methods and discoveries in genome analysis",
      color: "#9f7aea",
      keywords: [
        { name: "Human Genome Project", description: "Decoding of the human genome", timecode: "00:02:46–00:02:51" },
        { name: "DNA Sequencing", description: "Method for genome decoding", timecode: "00:02:51–00:02:57" },
        { name: "Complete Base Sequence", description: "Complete DNA sequence since 2003", timecode: "00:02:57–00:03:02" },
        { name: "Genetic Diseases", description: "Diseases caused by DNA changes", timecode: "00:03:02–00:03:07" },
        { name: "Cancer", description: "Development through mutations", timecode: "00:03:07–00:03:14" }
      ]
    },
    {
      id: 5,
      title: "Genome Comparison",
      description: "Comparative analysis of genome sizes across different organisms",
      color: "#f56565",
      keywords: [
        { name: "Genome Size", description: "Total amount of DNA in a cell", timecode: "00:03:19–00:03:25" },
        { name: "Human: 3.3 Billion BP", description: "Size of the human genome", timecode: "00:03:36–00:03:41" },
        { name: "Fly vs. Cabbage", description: "Comparison of different organisms", timecode: "00:03:30–00:03:47" },
        { name: "Cabbage: 100,000 Genes", description: "More genes than humans", timecode: "00:03:47–00:03:53" },
        { name: "Complexity ≠ Genome Size", description: "No correlation between size and complexity", timecode: "00:03:53–00:04:01" }
      ]
    }
  ];

  const handleMouseEnter = (keyword, event) => {
    setHoveredKeyword(keyword);
    setTooltip({
      show: true,
      x: event.clientX + 10,
      y: event.clientY - 10,
      content: `${keyword.name}: ${keyword.description} (${keyword.timecode})`
    });
  };

  const handleMouseLeave = () => {
    setHoveredKeyword(null);
    setTooltip({ show: false, x: 0, y: 0, content: '' });
  };

  const handleKeywordClick = (keyword) => {
    setHighlightedKeyword(highlightedKeyword === keyword.name ? null : keyword.name);
  };

  const category = categories.find(cat => cat.id === activeCategory);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">
          Interactive Genome Visualization
        </h1>
        
        {/* Category Navigation */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id);
                setHighlightedKeyword(null);
              }}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                activeCategory === cat.id
                  ? 'text-white shadow-lg transform scale-105'
                  : 'bg-white text-gray-700 hover:bg-gray-100'
              }`}
              style={{
                backgroundColor: activeCategory === cat.id ? cat.color : undefined
              }}
            >
              {cat.title}
            </button>
          ))}
        </div>

        <div className="flex gap-8">
          {/* Keywords Panel */}
          <div className="w-1/2 p-4 bg-white rounded-lg shadow">
            <div className="text-xl font-bold mb-4" style={{ color: category.color }}>
              {category.title}
            </div>
            <p className="text-gray-600 mb-6">{category.description}</p>
            
            <div className="space-y-3">
              {category.keywords.map((keyword, index) => (
                <div
                  key={index}
                  onClick={() => handleKeywordClick(keyword)}
                  className={`p-3 rounded-lg cursor-pointer transition-all duration-200 border ${
                    highlightedKeyword === keyword.name
                      ? 'border-2 shadow-md transform scale-105'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  style={{
                    backgroundColor: highlightedKeyword === keyword.name ? `${category.color}20` : '#f8f9fa',
                    borderColor: highlightedKeyword === keyword.name ? category.color : undefined
                  }}
                >
                  <div className="font-semibold text-gray-800">{keyword.name}</div>
                  <div className="text-sm text-gray-600 mt-1">{keyword.description}</div>
                  <div className="text-xs text-gray-500 mt-2">{keyword.timecode}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Visualization Panel */}
          <div className="w-1/2 p-4 bg-white rounded-lg shadow overflow-y-auto">
            <div className="text-xl font-bold mb-4">Genome Structure & Chromosomes</div>
            <div className="flex justify-center">
              <svg width="450" height="500" viewBox="0 0 450 500">
                {/* Cell nucleus representing genome location */}
                <circle cx="225" cy="160" rx="160" ry="130" fill="#f7fafc" stroke="#2d3748" strokeWidth="2" />
                <text x="225" y="50" textAnchor="middle" dominantBaseline="middle" fontSize="14" fill="#2d3748">Cell Nucleus</text>
                
                {/* Central chromosome cluster */}
                <g transform="translate(225,160)">
                  {/* 23 chromosome pairs visualization */}
                  {Array.from({length: 23}, (_, i) => {
                    const angle = (i * 360 / 23) * Math.PI / 180;
                    const radius = 50;
                    const x = Math.cos(angle) * radius;
                    const y = Math.sin(angle) * radius;
                    
                    return (
                      <g key={i}>
                        {/* Chromosome pair */}
                        <rect 
                          x={x-4} 
                          y={y-15} 
                          width="8" 
                          height="30" 
                          rx="4" 
                          fill={activeCategory === 3 && (highlightedKeyword === "23 Chromosome Pairs" || hoveredKeyword?.name === "23 Chromosome Pairs" || highlightedKeyword === "46 Chromosomes" || hoveredKeyword?.name === "46 Chromosomes") ? "#ed8936" : "#e2e8f0"} 
                          stroke="#2d3748" 
                          strokeWidth="1"
                          onMouseEnter={(e) => {
                            if (activeCategory === 3) {
                              const keyword = category.keywords.find(k => k.name === "23 Chromosome Pairs" || k.name === "46 Chromosomes");
                              if (keyword) {
                                handleMouseEnter(keyword, e);
                              }
                            }
                          }}
                          onMouseLeave={handleMouseLeave}
                          style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
                        />
                        <rect 
                          x={x+4} 
                          y={y-15} 
                          width="8" 
                          height="30" 
                          rx="4" 
                          fill={activeCategory === 3 && (highlightedKeyword === "23 Chromosome Pairs" || hoveredKeyword?.name === "23 Chromosome Pairs" || highlightedKeyword === "46 Chromosomes" || hoveredKeyword?.name === "46 Chromosomes") ? "#ed8936" : "#e2e8f0"} 
                          stroke="#2d3748" 
                          strokeWidth="1"
                          onMouseEnter={(e) => {
                            if (activeCategory === 3) {
                              const keyword = category.keywords.find(k => k.name === "23 Chromosome Pairs" || k.name === "46 Chromosomes");
                              if (keyword) {
                                handleMouseEnter(keyword, e);
                              }
                            }
                          }}
                          onMouseLeave={handleMouseLeave}
                          style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
                        />
                        
                        {/* Special highlighting for sex chromosomes (X,Y) */}
                        {i === 22 && (
                          <>
                            <rect 
                              x={x-4} 
                              y={y-15} 
                              width="8" 
                              height="30" 
                              rx="4" 
                              fill={activeCategory === 3 && (highlightedKeyword === "Sex Chromosomes" || hoveredKeyword?.name === "Sex Chromosomes") ? "#f56565" : "#e2e8f0"} 
                              stroke="#2d3748" 
                              strokeWidth="2"
                              onMouseEnter={(e) => {
                                if (activeCategory === 3) {
                                  const keyword = category.keywords.find(k => k.name === "Sex Chromosomes");
                                  if (keyword) {
                                    handleMouseEnter(keyword, e);
                                  }
                                }
                              }}
                              onMouseLeave={handleMouseLeave}
                              style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
                            />
                            <rect 
                              x={x+4} 
                              y={y-15} 
                              width="8" 
                              height="22" 
                              rx="4" 
                              fill={activeCategory === 3 && (highlightedKeyword === "Sex Chromosomes" || hoveredKeyword?.name === "Sex Chromosomes") ? "#f56565" : "#e2e8f0"} 
                              stroke="#2d3748" 
                              strokeWidth="2"
                              onMouseEnter={(e) => {
                                if (activeCategory === 3) {
                                  const keyword = category.keywords.find(k => k.name === "Sex Chromosomes");
                                  if (keyword) {
                                    handleMouseEnter(keyword, e);
                                  }
                                }
                              }}
                              onMouseLeave={handleMouseLeave}
                              style={{ cursor: activeCategory === 3 ? 'pointer' : 'default' }}
                            />
                            <text x={x} y={y+25} textAnchor="middle" fontSize="10" fill="#f56565">XY</text>
                          </>
                        )}
                      </g>
                    );
                  })}
                </g>
                
                {/* DNA double helix representation - repositioned */}
                <g transform="translate(70,70)">
                  <path 
                    d="M0,0 Q12,-12 24,0 Q36,12 48,0 Q60,-12 72,0" 
                    fill="none" 
                    stroke={activeCategory === 1 && (highlightedKeyword === "DNA/RNA" || hoveredKeyword?.name === "DNA/RNA") ? "#4299e1" : "#718096"} 
                    strokeWidth={activeCategory === 1 && (highlightedKeyword === "DNA/RNA" || hoveredKeyword?.name === "DNA/RNA") ? 3 : 2}
                    onMouseEnter={(e) => {
                      if (activeCategory === 1) {
                        const keyword = category.keywords.find(k => k.name === "DNA/RNA");
                        if (keyword) {
                          handleMouseEnter(keyword, e);
                        }
                      }
                    }}
                    onMouseLeave={handleMouseLeave}
                    style={{ cursor: activeCategory === 1 ? 'pointer' : 'default' }}
                  />
                  <path 
                    d="M0,12 Q12,24 24,12 Q36,0 48,12 Q60,24 72,12" 
                    fill="none" 
                    stroke={activeCategory === 1 && (highlightedKeyword === "DNA/RNA" || hoveredKeyword?.name === "DNA/RNA") ? "#4299e1" : "#718096"} 
                    strokeWidth={activeCategory === 1 && (highlightedKeyword === "DNA/RNA" || hoveredKeyword?.name === "DNA/RNA") ? 3 : 2}
                    onMouseEnter={(e) => {
                      if (activeCategory === 1) {
                        const keyword = category.keywords.find(k => k.name === "DNA/RNA");
                        if (keyword) {
                          handleMouseEnter(keyword, e);
                        }
                      }
                    }}
                    onMouseLeave={handleMouseLeave}
                    style={{ cursor: activeCategory === 1 ? 'pointer' : 'default' }}
                  />
                  <text x="36" y="35" textAnchor="middle" fontSize="10">DNA Double Helix</text>
                </g>
                
                {/* Gene representation - repositioned */}
                <g transform="translate(300,70)">
                  <rect 
                    x="0" 
                    y="0" 
                    width="80" 
                    height="10" 
                    fill={activeCategory === 1 && (highlightedKeyword === "Genes" || hoveredKeyword?.name === "Genes") ? "#4299e1" : activeCategory === 2 && (highlightedKeyword === "Coding Regions" || hoveredKeyword?.name === "Coding Regions") ? "#48bb78" : "#cbd5e0"} 
                    stroke="#2d3748" 
                    strokeWidth="1"
                    onMouseEnter={(e) => {
                      if (activeCategory === 1) {
                        const keyword = category.keywords.find(k => k.name === "Genes");
                        if (keyword) {
                          handleMouseEnter(keyword, e);
                        }
                      } else if (activeCategory === 2) {
                        const keyword = category.keywords.find(k => k.name === "Coding Regions");
                        if (keyword) {
                          handleMouseEnter(keyword, e);
                        }
                      }
                    }}
                    onMouseLeave={handleMouseLeave}
                    style={{ cursor: (activeCategory === 1 || activeCategory === 2) ? 'pointer' : 'default' }}
                  />
                  <rect 
                    x="0" 
                    y="15" 
                    width="60" 
                    height="8" 
                    fill={activeCategory === 2 && (highlightedKeyword === "Non-coding Regions" || hoveredKeyword?.name === "Non-coding Regions") ? "#48bb78" : "#e2e8f0"} 
                    stroke="#2d3748" 
                    strokeWidth="1"
                    onMouseEnter={(e) => {
                      if (activeCategory === 2) {
                        const keyword = category.keywords.find(k => k.name === "Non-coding Regions");
                        if (keyword) {
                          handleMouseEnter(keyword, e);
                        }
                      }
                    }}
                    onMouseLeave={handleMouseLeave}
                    style={{ cursor: activeCategory === 2 ? 'pointer' : 'default' }}
                  />
                  <text x="40" y="40" textAnchor="middle" fontSize="10">Genes & Regions</text>
                </g>
                
                {/* Mutation indicator - repositioned */}
                {activeCategory === 2 && (highlightedKeyword === "Mutation" || hoveredKeyword?.name === "Mutation") && (
                  <g transform="translate(330,85)">
                    <circle cx="0" cy="0" r="6" fill="#f56565" opacity="0.7" />
                    <text x="0" y="20" textAnchor="middle" fontSize="10" fill="#f56565">Mutation</text>
                  </g>
                )}
                
                {/* Research visualization - repositioned */}
                {activeCategory === 4 && (
                  <g transform="translate(80,350)">
                    <rect 
                      x="0" 
                      y="0" 
                      width="280" 
                      height="40" 
                      fill={highlightedKeyword === "Human Genome Project" || hoveredKeyword?.name === "Human Genome Project" ? "#9f7aea" : "#edf2f7"} 
                      stroke="#2d3748" 
                      strokeWidth="2" 
                      rx="8"
                      onMouseEnter={(e) => {
                        const keyword = category.keywords.find(k => k.name === "Human Genome Project");
                        if (keyword) {
                          handleMouseEnter(keyword, e);
                        }
                      }}
                      onMouseLeave={handleMouseLeave}
                      style={{ cursor: 'pointer' }}
                    />
                    <text x="140" y="25" textAnchor="middle" fontSize="12" fill="#2d3748">Human Genome Project (2003)</text>
                    
                    <path 
                      d="M20,50 L20,65 L260,65 L260,50" 
                      stroke={highlightedKeyword === "DNA Sequencing" || hoveredKeyword?.name === "DNA Sequencing" ? "#9f7aea" : "#718096"} 
                      strokeWidth="3"
                      onMouseEnter={(e) => {
                        const keyword = category.keywords.find(k => k.name === "DNA Sequencing");
                        if (keyword) {
                          handleMouseEnter(keyword, e);
                        }
                      }}
                      onMouseLeave={handleMouseLeave}
                      style={{ cursor: 'pointer' }}
                    />
                    <text x="140" y="85" textAnchor="middle" fontSize="10">DNA Sequencing</text>
                  </g>
                )}
                
                {/* Genome size comparison - repositioned */}
                {activeCategory === 5 && (
                  <g transform="translate(60,350)">
                    <rect 
                      x="0" 
                      y="0" 
                      width="120" 
                      height="20" 
                      fill={highlightedKeyword === "Human: 3.3 Billion BP" || hoveredKeyword?.name === "Human: 3.3 Billion BP" ? "#f56565" : "#fed7d7"} 
                      stroke="#2d3748" 
                      strokeWidth="1"
                      onMouseEnter={(e) => {
                        const keyword = category.keywords.find(k => k.name === "Human: 3.3 Billion BP");
                        if (keyword) {
                          handleMouseEnter(keyword, e);
                        }
                      }}
                      onMouseLeave={handleMouseLeave}
                      style={{ cursor: 'pointer' }}
                    />
                    <text x="60" y="12" textAnchor="middle" fontSize="10">Human</text>
                    
                    <rect 
                      x="0" 
                      y="25" 
                      width="80" 
                      height="20" 
                      fill={highlightedKeyword === "Fly vs. Cabbage" || hoveredKeyword?.name === "Fly vs. Cabbage" ? "#f56565" : "#fed7d7"} 
                      stroke="#2d3748" 
                      strokeWidth="1"
                      onMouseEnter={(e) => {
                        const keyword = category.keywords.find(k => k.name === "Fly vs. Cabbage");
                        if (keyword) {
                          handleMouseEnter(keyword, e);
                        }
                      }}
                      onMouseLeave={handleMouseLeave}
                      style={{ cursor: 'pointer' }}
                    />
                    <text x="40" y="37" textAnchor="middle" fontSize="10">Fly</text>
                    
                    <rect 
                      x="140" 
                      y="0" 
                      width="160" 
                      height="20" 
                      fill={highlightedKeyword === "Cabbage: 100,000 Genes" || hoveredKeyword?.name === "Cabbage: 100,000 Genes" ? "#f56565" : "#fed7d7"} 
                      stroke="#2d3748" 
                      strokeWidth="1" 
                      onMouseEnter={(e) => {
                        const keyword = category.keywords.find(k => k.name === "Cabbage: 100,000 Genes");
                        if (keyword) {
                          handleMouseEnter(keyword, e);
                        }
                      }}
                      onMouseLeave={handleMouseLeave}
                      style={{ cursor: 'pointer' }}
                    />
                    <text x="220" y="12" textAnchor="middle" fontSize="10">Cabbage</text>
                    
                    <text x="150" y="75" textAnchor="middle" fontSize="12" fill="#2d3748">Genome Size Comparison</text>
                  </g>
                )}
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Tooltip */}
      {tooltip.show && (
        <div
          className="fixed bg-gray-800 text-white p-2 rounded shadow-lg text-sm max-w-xs z-50 pointer-events-none"
          style={{
            left: tooltip.x,
            top: tooltip.y,
            transform: 'translate(-50%, -100%)'
          }}
        >
          {tooltip.content}
        </div>
      )}
    </div>
  );
};

export default GenomeVisualization;