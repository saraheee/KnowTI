import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

const DNASequencingSimulator = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [speed, setSpeed] = useState(50);
  const [sequence, setSequence] = useState('');
  const [currentPosition, setCurrentPosition] = useState(0);
  const [stats, setStats] = useState({ A: 0, T: 0, G: 0, C: 0 });
  const intervalRef = useRef(null);
  
  // DNA template sequence (extended for demonstration)
  const templateDNA = 'ATGCGATCGATCGTAGCTAGCATGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGCTAGCTAGCATGCATGC';

  const nucleotideColors = {
    A: '#FF6B6B', // Red
    T: '#4ECDC4', // Turquoise
    G: '#45B7D1', // Blue
    C: '#96CEB4'  // Green
  };

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setCurrentPosition(prev => {
          if (prev >= templateDNA.length - 1) {
            setIsRunning(false);
            return prev;
          }
          
          const nextNucleotide = templateDNA[prev];
          setSequence(prevSeq => prevSeq + nextNucleotide);
          
          setStats(prevStats => ({
            ...prevStats,
            [nextNucleotide]: prevStats[nextNucleotide] + 1
          }));
          
          return prev + 1;
        });
      }, 101 - speed);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, speed]);

  const handleStart = () => {
    if (currentPosition >= templateDNA.length - 1) {
      handleReset();
    }
    setIsRunning(true);
  };

  const handlePause = () => setIsRunning(false);
  const handleStop = () => setIsRunning(false);
  const handleReset = () => {
    setIsRunning(false);
    setSequence('');
    setCurrentPosition(0);
    setStats({ A: 0, T: 0, G: 0, C: 0 });
  };

  const progress = (currentPosition / templateDNA.length) * 100;
  const totalBases = sequence.length;

  return (
    <div className="w-full h-full bg-white p-8 font-sans">
      <div className="max-w-6xl mx-auto h-full flex flex-col">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">DNA Sequencing Simulator</h1>
          <p className="text-gray-600">Human Genome Project: Decoding the base sequence</p>
        </div>

        {/* Sequencing Machine Visualization */}
        <div className="bg-gray-50 rounded-2xl p-6 mb-6 flex-1">
          <div className="relative h-40 mb-6">
            
            {/* DNA Strand Input */}
            <div className="absolute left-0 top-1/2 transform -translate-y-1/2">
              <div className="w-32 h-3 bg-gray-300 rounded-full relative overflow-hidden">
                <div 
                  className="h-full bg-blue-500 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <span className="text-xs text-gray-500 mt-1 block">DNA Template</span>
            </div>

            {/* Sequencing Machine */}
            <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="w-48 h-32 bg-gray-400 rounded-xl shadow-lg relative">
                <div className="absolute inset-4 bg-gray-300 rounded-lg">
                  <div className="w-full h-full bg-gray-600 rounded-lg flex items-center justify-center">
                    <div className="text-white text-sm font-bold">
                      {isRunning ? 'SEQUENCING...' : 'READY'}
                    </div>
                  </div>
                </div>
                <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-red-500 rounded-full animate-pulse" />
                <span className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs text-gray-600 whitespace-nowrap">Sequencer</span>
              </div>
            </div>

            {/* Output */}
            <div className="absolute right-0 top-1/2 transform -translate-y-1/2">
              <div className="w-32 h-8 bg-white border-2 border-gray-300 rounded-lg flex items-center justify-center">
                {sequence.slice(-4).split('').map((base, i) => (
                  <span 
                    key={i} 
                    className="font-bold text-lg mx-1"
                    style={{ color: nucleotideColors[base] }}
                  >
                    {base}
                  </span>
                ))}
              </div>
              <span className="text-xs text-gray-500 mt-1 block">Sequence Output</span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <button
              onClick={handleStart}
              disabled={isRunning}
              className="flex items-center gap-2 px-6 py-3 bg-green-500 hover:bg-green-600 disabled:bg-gray-400 text-white rounded-lg font-semibold transition-colors"
            >
              <Play size={20} />
              Start
            </button>
            
            <button
              onClick={handlePause}
              disabled={!isRunning}
              className="flex items-center gap-2 px-6 py-3 bg-yellow-500 hover:bg-yellow-600 disabled:bg-gray-400 text-white rounded-lg font-semibold transition-colors"
            >
              <Pause size={20} />
              Pause
            </button>
            
            <button
              onClick={handleReset}
              className="flex items-center gap-2 px-6 py-3 bg-gray-500 hover:bg-gray-600 text-white rounded-lg font-semibold transition-colors"
            >
              <RotateCcw size={20} />
              Reset
            </button>
          </div>

          {/* Speed Control */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <span className="text-gray-700 font-semibold">Speed:</span>
            <input
              type="range"
              min="10"
              max="90"
              value={speed}
              onChange={(e) => setSpeed(parseInt(e.target.value))}
              className="w-48 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-gray-600 min-w-0 text-sm">{speed}%</span>
          </div>

          {/* Progress Bar */}
          <div className="mb-4">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Progress</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-blue-500 h-3 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>

        {/* Results Section */}
        <div className="grid grid-cols-2 gap-6">
          
          {/* Live Sequence Output */}
          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Decoded Sequence</h3>
            <div className="bg-white rounded-lg p-4 h-32 overflow-y-auto border">
              <div className="font-mono text-sm leading-relaxed break-all">
                {sequence.split('').map((base, i) => (
                  <span 
                    key={i}
                    className="font-bold"
                    style={{ color: nucleotideColors[base] }}
                  >
                    {base}
                  </span>
                ))}
                {isRunning && <span className="animate-pulse text-gray-400">|</span>}
              </div>
            </div>
            <div className="text-sm text-gray-600 mt-2">
              Length: {totalBases.toLocaleString()} bases
            </div>
          </div>

          {/* Statistics */}
          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Base Composition</h3>
            <div className="space-y-3">
              {Object.entries(stats).map(([base, count]) => {
                const percentage = totalBases > 0 ? (count / totalBases * 100).toFixed(1) : 0;
                const name = base === 'A' ? 'denine' : base === 'T' ? 'hymine' : base === 'G' ? 'uanine' : 'ytosine';
                return (
                  <div key={base} className="flex items-center gap-3">
                    <div 
                      className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold"
                      style={{ backgroundColor: nucleotideColors[base] }}
                    >
                      {base}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="font-semibold">{base} ({name})</span>
                        <span>{count} ({percentage}%)</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="h-2 rounded-full transition-all duration-300"
                          style={{ 
                            backgroundColor: nucleotideColors[base],
                            width: `${percentage}%`
                          }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DNASequencingSimulator;
