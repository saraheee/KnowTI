import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Dna, Users, FileText } from 'lucide-react';

const DNAInheritanceDemo = () => {
  const [activeTab, setActiveTab] = useState('storage');
  const [isAnimating, setIsAnimating] = useState(false);
  const [generationStep, setGenerationStep] = useState(0);

  // DNA sequences for different traits
  const traits = {
    eyeColor: { sequence: 'ATCG-GCTA', color: '#3B82F6', name: 'Eye Color' },
    height: { sequence: 'CGAT-TACG', color: '#10B981', name: 'Height' },
    hair: { sequence: 'GCTA-ATCG', color: '#F59E0B', name: 'Hair Color' }
  };

  const codingRegions = [
    { start: 0, end: 4, name: 'Gene A', active: true },
    { start: 5, end: 9, name: 'Gene B', active: false },
    { start: 10, end: 14, name: 'Gene C', active: true }
  ];

  useEffect(() => {
    if (isAnimating && activeTab === 'inheritance') {
      const timer = setTimeout(() => {
        setGenerationStep((prev) => (prev + 1) % 4);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [isAnimating, generationStep, activeTab]);

  const DNAStrand = ({ sequence, highlighted = false, coding = [] }) => (
    <div className="flex items-center space-x-1">
      {sequence.split('').map((base, index) => {
        const isInCodingRegion = coding.some(region => 
          index >= region.start && index <= region.end && region.active
        );
        return (
          <div
            key={index}
            className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm transition-all duration-300 ${
              base === 'A' ? 'bg-red-500' :
              base === 'T' ? 'bg-blue-500' :
              base === 'C' ? 'bg-green-500' :
              base === 'G' ? 'bg-yellow-500' : 'bg-gray-300'
            } ${highlighted ? 'scale-110 shadow-lg' : ''} ${
              isInCodingRegion ? 'ring-2 ring-purple-400' : ''
            }`}
          >
            {base !== '-' ? base : ''}
          </div>
        );
      })}
    </div>
  );

  const StorageView = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h3 className="text-xl font-semibold mb-4">Genetic Information Storage</h3>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        {Object.entries(traits).map(([key, trait]) => (
          <div key={key} className="bg-gray-50 p-6 rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <span className="font-semibold" style={{ color: trait.color }}>
                {trait.name}
              </span>
              <div className="flex items-center space-x-2">
                <Dna className="w-5 h-5" style={{ color: trait.color }} />
              </div>
            </div>
            <DNAStrand sequence={trait.sequence} />
          </div>
        ))}
      </div>
      
      <div className="bg-blue-50 p-4 rounded-lg">
        <p className="text-sm text-center">
          Each trait is encoded by specific DNA sequences
        </p>
      </div>
    </div>
  );

  const InheritanceView = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-xl font-semibold mb-4">Passing Traits to Offspring</h3>
        <div className="flex justify-center space-x-4 mb-6">
          <button
            onClick={() => setIsAnimating(!isAnimating)}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
          >
            {isAnimating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isAnimating ? 'Pause' : 'Start'}</span>
          </button>
          <button
            onClick={() => { setGenerationStep(0); setIsAnimating(false); }}
            className="flex items-center space-x-2 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-8 items-center">
        {/* Parents */}
        <div className="space-y-4">
          <div className="text-center">
            <Users className="w-8 h-8 mx-auto mb-2 text-blue-600" />
            <h4 className="font-semibold">Parents</h4>
          </div>
          <div className="space-y-2">
            <div className={`transition-opacity duration-500 ${generationStep >= 0 ? 'opacity-100' : 'opacity-50'}`}>
              <DNAStrand sequence="ATCG-GCTA-CGAT" highlighted={generationStep === 1} />
            </div>
            <div className={`transition-opacity duration-500 ${generationStep >= 0 ? 'opacity-100' : 'opacity-50'}`}>
              <DNAStrand sequence="TACG-ATCG-GCTA" highlighted={generationStep === 1} />
            </div>
          </div>
        </div>

        {/* Arrow */}
        <div className="text-center">
          <div className={`text-4xl transition-all duration-500 ${isAnimating ? 'scale-110 text-green-500' : 'text-gray-400'}`}>
            →
          </div>
          <p className="text-sm mt-2">Inheritance</p>
        </div>

        {/* Offspring */}
        <div className="space-y-4">
          <div className="text-center">
            <Users className="w-8 h-8 mx-auto mb-2 text-green-600" />
            <h4 className="font-semibold">Offspring</h4>
          </div>
          <div className="space-y-2">
            <div className={`transition-all duration-500 ${generationStep >= 2 ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
              <DNAStrand sequence="ATCG-ATCG-CGAT" highlighted={generationStep === 3} />
            </div>
            <div className={`transition-all duration-500 ${generationStep >= 2 ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
              <DNAStrand sequence="TACG-GCTA-GCTA" highlighted={generationStep === 3} />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-green-50 p-4 rounded-lg">
        <p className="text-sm text-center">
          Genetic information is passed to the next generation through recombination
        </p>
      </div>
    </div>
  );

  const CodingView = () => {
    const [selectedRegion, setSelectedRegion] = useState(null);
    
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h3 className="text-xl font-semibold mb-4">Coding Regions</h3>
        </div>
        
        <div className="bg-gray-50 p-6 rounded-lg">
          <div className="mb-4">
            <h4 className="font-semibold mb-2">DNA Strand with Genes</h4>
            <DNAStrand 
              sequence="ATCG-TACG-GCTA-CG" 
              coding={codingRegions}
              highlighted={selectedRegion !== null}
            />
          </div>
          
          <div className="grid grid-cols-3 gap-4 mt-6">
            {codingRegions.map((region, index) => (
              <button
                key={index}
                onClick={() => setSelectedRegion(selectedRegion === index ? null : index)}
                className={`p-4 rounded-lg border-2 transition-all ${
                  region.active
                    ? selectedRegion === index
                      ? 'border-purple-500 bg-purple-100'
                      : 'border-purple-300 bg-purple-50 hover:bg-purple-100'
                    : 'border-gray-300 bg-gray-100 opacity-50'
                }`}
              >
                <FileText className={`w-6 h-6 mx-auto mb-2 ${region.active ? 'text-purple-600' : 'text-gray-400'}`} />
                <div className="text-sm font-semibold">{region.name}</div>
                <div className="text-xs">{region.active ? 'Active' : 'Inactive'}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div className="bg-purple-50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2 text-purple-800">Coding Regions</h4>
            <p className="text-sm">Contain information for proteins</p>
          </div>
          <div className="bg-gray-100 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Non-Coding Regions</h4>
            <p className="text-sm">Regulatory or structural functions</p>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full h-full bg-white p-8">
      <div className="max-w-5xl mx-auto h-full flex flex-col">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold mb-2">Genome Inheritance and Function</h1>
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => setActiveTab('storage')}
              className={`px-6 py-2 rounded-lg font-semibold ${
                activeTab === 'storage' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Storage
            </button>
            <button
              onClick={() => setActiveTab('inheritance')}
              className={`px-6 py-2 rounded-lg font-semibold ${
                activeTab === 'inheritance' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Inheritance
            </button>
            <button
              onClick={() => setActiveTab('coding')}
              className={`px-6 py-2 rounded-lg font-semibold ${
                activeTab === 'coding' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Coding
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-auto">
          {activeTab === 'storage' && <StorageView />}
          {activeTab === 'inheritance' && <InheritanceView />}
          {activeTab === 'coding' && <CodingView />}
        </div>
      </div>
    </div>
  );
};

export default DNAInheritanceDemo;
