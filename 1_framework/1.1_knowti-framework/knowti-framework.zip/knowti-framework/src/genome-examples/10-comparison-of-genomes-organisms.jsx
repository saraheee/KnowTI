import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer } from 'recharts';

const GenomeComparison = () => {
  const [selectedMetric, setSelectedMetric] = useState('basePairs');
  const [hoveredOrganism, setHoveredOrganism] = useState(null);

  const organisms = {
    human: {
      name: 'Human',
      basePairs: 3300,
      genes: 20000,
      complexity: 95,
      color: '#3B82F6',
      icon: '👤'
    },
    fly: {
      name: 'Fruit Fly',
      basePairs: 140,
      genes: 14000,
      complexity: 45,
      color: '#EF4444',
      icon: '🪰'
    },
    cabbage: {
      name: 'Cabbage',
      basePairs: 630,
      genes: 41000,
      complexity: 25,
      color: '#10B981',
      icon: '🥬'
    }
  };

  const getChartData = () => {
    return Object.values(organisms).map(org => ({
      name: org.name,
      value: org[selectedMetric],
      color: org.color,
      icon: org.icon
    }));
  };

  const formatValue = (value) => {
    if (selectedMetric === 'basePairs') {
      return value >= 1000 ? `${(value/1000).toFixed(1)}B` : `${value}M`;
    }
    if (selectedMetric === 'genes') {
      return `${(value/1000).toFixed(0)}k`;
    }
    return `${value}%`;
  };

  const getMetricLabel = () => {
    switch(selectedMetric) {
      case 'basePairs': return 'Genome Size (Base Pairs)';
      case 'genes': return 'Number of Genes';
      case 'complexity': return 'Biological Complexity';
      default: return '';
    }
  };

  const CustomBar = (props) => {
    const { payload, x, y, width, height } = props;
    return (
      <g>
        <rect
          x={x}
          y={y}
          width={width}
          height={height}
          fill={payload.color}
          rx={4}
          className="transition-all duration-300 hover:opacity-80"
          onMouseEnter={() => setHoveredOrganism(payload.name)}
          onMouseLeave={() => setHoveredOrganism(null)}
        />
        <text
          x={x + width/2}
          y={y - 10}
          textAnchor="middle"
          fontSize="24"
        >
          {payload.icon}
        </text>
        <text
          x={x + width/2}
          y={y + height + 35}
          textAnchor="middle"
          fontSize="14"
          fill="#374151"
          fontWeight="600"
        >
          {formatValue(payload.value)}
        </text>
      </g>
    );
  };

  return (
    <div className="w-full h-full bg-white p-8 font-sans">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 text-center mb-8">
          Genome Comparison: Size ≠ Complexity
        </h1>
        
        {/* Metric Selection */}
        <div className="flex justify-center mb-8">
          <div className="flex bg-gray-100 rounded-lg p-1">
            {[
              { key: 'basePairs', label: 'Genome Size' },
              { key: 'genes', label: 'Gene Count' },
              { key: 'complexity', label: 'Complexity' }
            ].map(metric => (
              <button
                key={metric.key}
                onClick={() => setSelectedMetric(metric.key)}
                className={`px-6 py-2 rounded-md font-medium transition-all ${
                  selectedMetric === metric.key
                    ? 'bg-blue-500 text-white shadow-md'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {metric.label}
              </button>
            ))}
          </div>
        </div>

        {/* Chart */}
        <div className="bg-gray-50 rounded-xl p-6 mb-8 relative">
          <h2 className="text-xl font-semibold text-center mb-6 text-gray-800">
            {getMetricLabel()}
          </h2>
          
          {/* Highlight for cabbage genes */}
          {selectedMetric === 'genes' && (
            <div className="absolute top-16 right-8 bg-green-500 text-white px-3 py-2 rounded-lg shadow-lg animate-pulse">
              <div className="text-sm font-bold">🥬 Surprise!</div>
              <div className="text-xs">Cabbage has the most genes</div>
            </div>
          )}
          
          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={getChartData()} margin={{ top: 40, right: 30, left: 20, bottom: 60 }}>
              <XAxis 
                dataKey="name" 
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 14, fill: '#374151', fontWeight: 500 }}
              />
              <YAxis hide />
              <Bar 
                dataKey="value" 
                shape={<CustomBar />}
                stroke="none"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Key Insights */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-blue-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-blue-900 mb-3">
              🧬 Surprising Facts
            </h3>
            <ul className="space-y-2 text-blue-800">
              <li>• <span className="font-bold text-green-600">Cabbage has 2x more genes than humans!</span></li>
              <li>• Fruit fly: 70% of human genes</li>
              <li>• Genome size varies by factor of 20+</li>
            </ul>
          </div>
          
          <div className="bg-green-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-green-900 mb-3">
              💡 Key Insight
            </h3>
            <p className="text-green-800">
              More genes or a larger genome does not automatically mean higher biological complexity. 
              Gene regulation and interaction are crucial.
            </p>
          </div>
        </div>

        {/* Hover Info */}
        {hoveredOrganism && (
          <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-4 py-2 rounded-lg shadow-lg">
            Click the buttons above for different comparisons
          </div>
        )}
      </div>
    </div>
  );
};

export default GenomeComparison;
