import React, { useState } from 'react';

const ChromatinStructure = () => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [activeLevel, setActiveLevel] = useState('dna');

  const levels = [
    { id: 'dna', name: 'DNA Strand', zoom: 1 },
    { id: 'nucleosome', name: 'Nucleosomes', zoom: 2 },
    { id: 'fiber', name: '30nm Fiber', zoom: 3 },
    { id: 'chromosome', name: 'Chromosome', zoom: 4 }
  ];

  // DNA Double Helix
  const DNAHelix = ({ scale = 1, x = 350, y = 250 }) => (
    <g transform={`translate(${x}, ${y}) scale(${scale})`}>
      <path
        d="M-100,0 Q-50,-20 0,0 T100,0"
        stroke="#4F46E5"
        strokeWidth="3"
        fill="none"
      />
      <path
        d="M-100,15 Q-50,-5 0,15 T100,15"
        stroke="#7C3AED"
        strokeWidth="3"
        fill="none"
      />
      {Array.from({ length: 8 }, (_, i) => (
        <line
          key={i}
          x1={-75 + i * 25}
          y1={-5 + Math.sin(i * 0.8) * 10}
          x2={-75 + i * 25}
          y2={20 + Math.sin(i * 0.8) * 10}
          stroke="#EF4444"
          strokeWidth="2"
        />
      ))}
    </g>
  );

  // Nucleosome (DNA wrapped around histones)
  const Nucleosome = ({ x, y, scale = 1 }) => (
    <g transform={`translate(${x}, ${y}) scale(${scale})`}>
      <circle r="25" fill="#64748B" opacity="0.9" />
      <circle r="20" fill="#94A3B8" opacity="0.7" />
      <text textAnchor="middle" y="4" fill="white" fontSize="10" fontWeight="bold">
        H2A H2B<tspan x="0" dy="8">H3 H4</tspan>
      </text>
      <path
        d="M-30,-15 Q-35,-25 -25,-30 Q0,-35 25,-30 Q35,-25 30,-15 Q25,0 30,15 Q35,25 25,30 Q0,35 -25,30 Q-35,25 -30,15 Q-25,0 -30,-15"
        stroke="#4F46E5"
        strokeWidth="3"
        fill="none"
        opacity="0.8"
      />
    </g>
  );

  // 30nm Chromatin Fiber
  const ChromatinFiber = ({ scale = 1 }) => (
    <g transform={`translate(350, 250) scale(${scale})`}>
      {Array.from({ length: 6 }, (_, i) => (
        <g key={i} transform={`translate(${(i - 2.5) * 40}, ${Math.sin(i * 0.5) * 20})`}>
          <Nucleosome x={0} y={0} scale={0.8} />
          {i < 5 && (
            <path
              d={`M30,0 Q35,${Math.sin((i + 1) * 0.5) * 20 - Math.sin(i * 0.5) * 20} 40,${Math.sin((i + 1) * 0.5) * 20}`}
              stroke="#4F46E5"
              strokeWidth="2"
              fill="none"
            />
          )}
        </g>
      ))}
    </g>
  );

  // Condensed Chromosome
  const Chromosome = ({ scale = 1 }) => (
    <g transform={`translate(350, 250) scale(${scale})`}>
      <ellipse rx="15" ry="80" fill="#1E293B" opacity="0.8" />
      <ellipse rx="12" ry="75" fill="#334155" opacity="0.6" />
      <ellipse rx="20" ry="8" fill="#EF4444" opacity="0.8" />
      {Array.from({ length: 12 }, (_, i) => (
        <rect
          key={i}
          x="-12"
          y={-70 + i * 12}
          width="24"
          height="4"
          fill={i % 3 === 0 ? "#64748B" : "transparent"}
          opacity="0.4"
        />
      ))}
    </g>
  );

  const renderCurrentLevel = () => {
    switch (activeLevel) {
      case 'dna':
        return <DNAHelix scale={1.5} />;
      case 'nucleosome':
        return (
          <g>
            {Array.from({ length: 4 }, (_, i) => (
              <Nucleosome key={i} x={200 + i * 100} y={250} scale={1.2} />
            ))}
            {Array.from({ length: 3 }, (_, i) => (
              <path
                key={i}
                d={`M${230 + i * 100},250 Q${250 + i * 100},240 ${270 + i * 100},250`}
                stroke="#4F46E5"
                strokeWidth="3"
                fill="none"
                opacity="0.7"
              />
            ))}
          </g>
        );
      case 'fiber':
        return <ChromatinFiber scale={1.2} />;
      case 'chromosome':
        return <Chromosome scale={2} />;
      default:
        return <DNAHelix />;
    }
  };

  const getLevelInfo = () => {
    switch (activeLevel) {
      case 'dna':
        return {
          title: 'DNA Double Helix',
          description: 'Basic structure of genetic information',
          details: 'Antiparallel strands with complementary base pairs'
        };
      case 'nucleosome':
        return {
          title: 'Nucleosomes',
          description: 'DNA wrapped around histones',
          details: 'First packaging level - "beads on a string"'
        };
      case 'fiber':
        return {
          title: '30nm Chromatin Fiber',
          description: 'Condensed nucleosomes',
          details: 'Further compaction for efficient storage'
        };
      case 'chromosome':
        return {
          title: 'Condensed Chromosome',
          description: 'Maximum compaction',
          details: 'Form during cell division'
        };
      default:
        return { title: '', description: '', details: '' };
    }
  };

  const info = getLevelInfo();

  return (
    <div className="w-full h-full bg-white flex flex-col items-center justify-center p-6">
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Chromatin Structure Levels</h2>
        <p className="text-gray-600">From DNA helix to compact chromosome</p>
      </div>

      {/* Level Controls */}
      <div className="flex gap-2 mb-6 bg-gray-100 p-2 rounded-lg">
        {levels.map((level) => (
          <button
            key={level.id}
            onClick={() => setActiveLevel(level.id)}
            className={`px-4 py-2 rounded-md font-medium transition-all duration-300 ${
              activeLevel === level.id
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-gray-700 hover:bg-gray-200'
            }`}
          >
            {level.name}
          </button>
        ))}
      </div>

      {/* Visualization Area */}
      <div className="relative bg-gray-50 rounded-lg border border-gray-200 mb-6">
        <svg width="700" height="400" viewBox="0 0 700 400">
          {renderCurrentLevel()}
        </svg>
      </div>

      {/* Information Panel */}
      <div className="bg-gray-100 p-6 rounded-lg max-w-2xl text-center">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">{info.title}</h3>
        <p className="text-gray-700 mb-2">{info.description}</p>
        <p className="text-gray-600 text-sm">{info.details}</p>
      </div>

      {/* Compaction Scale */}
      <div className="mt-6 bg-blue-50 p-4 rounded-lg w-full max-w-2xl">
        <h4 className="font-semibold text-gray-800 mb-3 text-center">Compaction Scale</h4>
        <div className="flex justify-between items-center">
          <div className="text-center">
            <div className="w-4 h-4 bg-blue-200 rounded mx-auto mb-1"></div>
            <span className="text-xs text-gray-600">DNA<br/>2nm</span>
          </div>
          <div className="text-center">
            <div className="w-6 h-6 bg-blue-400 rounded mx-auto mb-1"></div>
            <span className="text-xs text-gray-600">Nucleosomes<br/>11nm</span>
          </div>
          <div className="text-center">
            <div className="w-8 h-8 bg-blue-600 rounded mx-auto mb-1"></div>
            <span className="text-xs text-gray-600">30nm Fiber<br/>30nm</span>
          </div>
          <div className="text-center">
            <div className="w-10 h-10 bg-blue-800 rounded mx-auto mb-1"></div>
            <span className="text-xs text-gray-600">Chromosome<br/>700nm</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChromatinStructure;
