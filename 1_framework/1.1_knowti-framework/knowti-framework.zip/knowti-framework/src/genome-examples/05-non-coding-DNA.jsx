import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Zap } from 'lucide-react';

const DNASequenceScanner = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanPosition, setScanPosition] = useState(0);
  const [scanSpeed, setScanSpeed] = useState(50);
  const [scannedData, setScannedData] = useState([]);
  const [totalStats, setTotalStats] = useState({
    coding: 0,
    regulatory: 0,
    structural: 0,
    unknown: 0,
    total: 0
  });
  
  const intervalRef = useRef(null);
  const sequenceLength = 200;

  // Generate DNA sequence
  const generateSequence = () => {
    const sequence = [];
    for (let i = 0; i < sequenceLength; i++) {
      const random = Math.random();
      let type = 'unknown';
      let confidence = Math.random() * 100;
      
      if (random < 0.03) {
        type = 'coding';
        confidence = 85 + Math.random() * 15;
      } else if (random < 0.18) {
        type = 'regulatory';
        confidence = 70 + Math.random() * 25;
      } else if (random < 0.28) {
        type = 'structural';
        confidence = 65 + Math.random() * 30;
      } else {
        confidence = 30 + Math.random() * 40;
      }
      
      sequence.push({
        position: i,
        type,
        confidence: Math.round(confidence),
        nucleotide: ['A', 'T', 'G', 'C'][Math.floor(Math.random() * 4)]
      });
    }
    return sequence;
  };

  const [sequence] = useState(generateSequence());

  useEffect(() => {
    if (isScanning) {
      intervalRef.current = setInterval(() => {
        setScanPosition(prev => {
          if (prev >= sequenceLength - 1) {
            setIsScanning(false);
            return prev;
          }
          
          const nextPos = prev + 1;
          const currentElement = sequence[nextPos];
          
          setScannedData(prevData => [...prevData, currentElement]);
          
          // Update statistics
          setTotalStats(prevStats => ({
            ...prevStats,
            [currentElement.type]: prevStats[currentElement.type] + 1,
            total: prevStats.total + 1
          }));
          
          return nextPos;
        });
      }, 101 - scanSpeed);
    } else {
      clearInterval(intervalRef.current);
    }

    return () => clearInterval(intervalRef.current);
  }, [isScanning, scanSpeed, sequence, sequenceLength]);

  const handlePlay = () => setIsScanning(!isScanning);

  const handleReset = () => {
    setIsScanning(false);
    setScanPosition(0);
    setScannedData([]);
    setTotalStats({ coding: 0, regulatory: 0, structural: 0, unknown: 0, total: 0 });
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'coding': return '#3B82F6';
      case 'regulatory': return '#10B981';
      case 'structural': return '#F59E0B';
      case 'unknown': return '#E5E7EB';
      default: return '#E5E7EB';
    }
  };

  const getTypeLabel = (type) => {
    switch (type) {
      case 'coding': return 'Coding';
      case 'regulatory': return 'Regulatory';
      case 'structural': return 'Structural';
      case 'unknown': return 'Unknown';
      default: return 'Unknown';
    }
  };

  const getConfidenceColor = (confidence) => {
    if (confidence >= 80) return '#10B981';
    if (confidence >= 60) return '#F59E0B';
    return '#EF4444';
  };

  const calculatePercentage = (count, total) => (total > 0 ? ((count / total) * 100).toFixed(1) : '0.0');

  const nonCodingPercentage = calculatePercentage(
    totalStats.regulatory + totalStats.structural + totalStats.unknown,
    totalStats.total
  );

  return (
    <div className="w-full h-full bg-white p-6 font-sans">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">DNA Sequence Scanner</h1>
          <p className="text-gray-600">Simulation of a sequencing device with real-time analysis</p>
        </div>

        {/* Controls */}
        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <button
                onClick={handlePlay}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  isScanning 
                    ? 'bg-red-100 text-red-700 hover:bg-red-200' 
                    : 'bg-green-100 text-green-700 hover:bg-green-200'
                }`}
              >
                {isScanning ? <Pause size={18} /> : <Play size={18} />}
                {isScanning ? 'Pause' : 'Start Scan'}
              </button>
              
              <button
                onClick={handleReset}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <RotateCcw size={18} />
                Reset
              </button>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Zap size={16} className="text-gray-600" />
                <label className="text-sm text-gray-600">Speed:</label>
                <input
                  type="range"
                  min="10"
                  max="90"
                  value={scanSpeed}
                  onChange={(e) => setScanSpeed(parseInt(e.target.value))}
                  className="w-24"
                />
                <span className="text-sm text-gray-600 w-8">{scanSpeed}%</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end">
            <div className="text-sm text-gray-600">
              Position: {scanPosition + 1} / {sequenceLength}
            </div>
          </div>
        </div>

        {/* Scanner Display */}
        <div className="bg-gray-900 rounded-lg p-4 mb-6">
          <div className="mb-3">
            <div className="text-green-400 text-sm font-mono mb-2">SEQUENCER STATUS: {isScanning ? 'SCANNING...' : 'READY'}</div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-green-400 text-xs">DNA ANALYZER v2.1 ACTIVE</span>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
            <div 
              className="bg-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(scanPosition / sequenceLength) * 100}%` }}
            ></div>
          </div>

          {/* Sequence Display */}
          <div className="font-mono text-sm">
            <div className="text-gray-400 mb-2">NUCLEOTIDE SEQUENCE:</div>
            <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto">
              {sequence.map((base, index) => (
                <span
                  key={index}
                  className={`px-1 ${
                    index <= scanPosition 
                      ? 'text-white' 
                      : 'text-gray-600'
                  } ${
                    index === scanPosition ? 'bg-yellow-500 text-black' : ''
                  }`}
                  style={{
                    backgroundColor: index < scanPosition ? getTypeColor(base.type) : 'transparent'
                  }}
                >
                  {base.nucleotide}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Real-time Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* Coding Region */}
          <div className="bg-blue-50 rounded-lg p-6 text-center border-2 border-blue-200">
            <div className="text-3xl font-bold text-blue-700 mb-2">
              {calculatePercentage(totalStats.coding, totalStats.total)}%
            </div>
            <div className="text-lg font-semibold text-blue-600 mb-1">Coding</div>
            <div className="text-sm text-gray-600">{totalStats.coding} regions</div>
            <div className="text-xs text-blue-500 mt-2">Protein-coding sequences</div>
          </div>
          
          {/* Non-Coding Regions */}
          <div className="bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg p-6 text-center border-4 border-gray-400 shadow-lg transform hover:scale-105 transition-transform">
            <div className="text-4xl font-bold text-gray-700 mb-2">
              {nonCodingPercentage}%
            </div>
            <div className="text-xl font-bold text-gray-600 mb-2">Non-Coding</div>
            <div className="text-sm text-gray-700 font-medium">
              {totalStats.regulatory + totalStats.structural + totalStats.unknown} regions
            </div>
            <div className="mt-3 space-y-1">
              <div className="flex justify-between items-center text-xs">
                <span className="text-green-600">Regulatory:</span>
                <span className="font-semibold text-green-700">
                  {calculatePercentage(totalStats.regulatory, totalStats.total)}%
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-yellow-600">Structural:</span>
                <span className="font-semibold text-yellow-700">
                  {calculatePercentage(totalStats.structural, totalStats.total)}%
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-600">Unknown:</span>
                <span className="font-semibold text-gray-700">
                  {calculatePercentage(totalStats.unknown, totalStats.total)}%
                </span>
              </div>
            </div>
            <div className="mt-3 text-xs text-gray-600 italic">
              Regulatory, structural & unknown functions
            </div>
          </div>
        </div>

        {/* Recent Findings */}
        {scannedData.length > 0 && (
          <div className="bg-white border rounded-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-3">Recent Findings</h3>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {scannedData.slice(-10).reverse().map((item, index) => (
                <div key={`${item.position}-${index}`} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: getTypeColor(item.type) }}
                    ></div>
                    <span className="text-sm font-medium">{getTypeLabel(item.type)}</span>
                    <span className="text-xs text-gray-500">Position {item.position + 1}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span 
                      className="text-xs px-2 py-1 rounded text-white"
                      style={{ backgroundColor: getConfidenceColor(item.confidence) }}
                    >
                      {item.confidence}% Confidence
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DNASequenceScanner;
