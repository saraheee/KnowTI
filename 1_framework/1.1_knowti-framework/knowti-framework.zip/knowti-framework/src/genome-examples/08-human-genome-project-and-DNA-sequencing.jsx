import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw } from 'lucide-react';

const DNASequencingSimulator = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [revealedBases, setRevealedBases] = useState(0);
  const [selectedBase, setSelectedBase] = useState(null);
  
  // Sample DNA sequence
  const dnaSequence = 'ATCGATCGTAGCTACGATCGTAGCTACGATCGTAGCTACGATCG';
  const baseColors = {
    A: '#FF6B6B', // Red
    T: '#4ECDC4', // Teal
    G: '#45B7D1', // Blue
    C: '#FFA726'  // Orange
  };
  
  const basePairs = { A: 'T', T: 'A', G: 'C', C: 'G' };
  
  useEffect(() => {
    let interval;
    if (isRunning && progress < 100) {
      interval = setInterval(() => {
        setProgress(prev => {
          const newProgress = Math.min(prev + 2, 100);
          setRevealedBases(Math.floor((newProgress / 100) * dnaSequence.length));
          return newProgress;
        });
      }, 150);
    }
    return () => clearInterval(interval);
  }, [isRunning, progress, dnaSequence.length]);
  
  const handlePlayPause = () => setIsRunning(!isRunning);
  
  const handleReset = () => {
    setIsRunning(false);
    setProgress(0);
    setRevealedBases(0);
    setSelectedBase(null);
  };
  
  const handleBaseClick = (base, index) => {
    if (index < revealedBases) {
      setSelectedBase({ base, index });
    }
  };
  
  return (
    <div className="w-full h-full bg-white flex flex-col items-center justify-center p-8">
      {/* Title */}
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">DNA Sequencing</h1>
        <p className="text-gray-600">Human Genome Project Simulation</p>
      </div>
      
      {/* DNA Helix Container */}
      <div className="relative mb-8">
        <svg width="800" height="200" viewBox="0 0 800 200" className="overflow-visible">
          {/* Background helix structure */}
          <path
            d="M 50 100 Q 150 50 250 100 T 450 100 T 650 100 T 850 100"
            fill="none"
            stroke="#E0E0E0"
            strokeWidth="3"
            className="opacity-30"
          />
          <path
            d="M 50 100 Q 150 150 250 100 T 450 100 T 650 100 T 850 100"
            fill="none"
            stroke="#E0E0E0"
            strokeWidth="3"
            className="opacity-30"
          />
          
          {/* Animated helix strands */}
          <path
            d="M 50 100 Q 150 50 250 100 T 450 100 T 650 100"
            fill="none"
            stroke="#666"
            strokeWidth="2"
            style={{
              strokeDasharray: `${progress * 6} 600`,
              transition: 'stroke-dasharray 0.3s ease'
            }}
          />
          <path
            d="M 50 100 Q 150 150 250 100 T 450 100 T 650 100"
            fill="none"
            stroke="#666"
            strokeWidth="2"
            style={{
              strokeDasharray: `${progress * 6} 600`,
              transition: 'stroke-dasharray 0.3s ease'
            }}
          />
          
          {/* Base pairs */}
          {dnaSequence.split('').map((base, index) => {
            const x = 60 + index * 14;
            const y1 = 85 + Math.sin(index * 0.5) * 15;
            const y2 = 115 - Math.sin(index * 0.5) * 15;
            const isRevealed = index < revealedBases;
            const isSelected = selectedBase?.index === index;
            
            return (
              <g key={index}>
                {/* Connection line */}
                {isRevealed && (
                  <line
                    x1={x}
                    y1={y1}
                    x2={x}
                    y2={y2}
                    stroke="#CCC"
                    strokeWidth="1"
                  />
                )}
                
                {/* Top base */}
                <circle
                  cx={x}
                  cy={y1}
                  r="8"
                  fill={isRevealed ? baseColors[base] : '#F0F0F0'}
                  stroke={isSelected ? '#333' : 'white'}
                  strokeWidth={isSelected ? '3' : '2'}
                  className={isRevealed ? 'cursor-pointer hover:scale-110 transition-transform' : ''}
                  onClick={() => handleBaseClick(base, index)}
                />
                <text
                  x={x}
                  y={y1 + 4}
                  textAnchor="middle"
                  className="text-sm font-bold fill-white pointer-events-none"
                >
                  {isRevealed ? base : '?'}
                </text>
                
                {/* Bottom base */}
                <circle
                  cx={x}
                  cy={y2}
                  r="8"
                  fill={isRevealed ? baseColors[basePairs[base]] : '#F0F0F0'}
                  stroke={isSelected ? '#333' : 'white'}
                  strokeWidth="2"
                  className={isRevealed ? 'cursor-pointer hover:scale-110 transition-transform' : ''}
                />
                <text
                  x={x}
                  y={y2 + 4}
                  textAnchor="middle"
                  className="text-sm font-bold fill-white pointer-events-none"
                >
                  {isRevealed ? basePairs[base] : '?'}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
      
      {/* Progress Bar */}
      <div className="w-full max-w-2xl mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-gray-600">Decoding</span>
          <span className="text-sm font-semibold text-gray-800">{Math.round(progress)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-3">
          <div
            className="bg-gradient-to-r from-blue-500 to-purple-600 h-3 rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="mt-2 text-center text-sm text-gray-600">
          {revealedBases} / {dnaSequence.length} base pairs decoded
        </div>
      </div>
      
      {/* Controls */}
      <div className="flex items-center gap-4 mb-6">
        <button
          onClick={handlePlayPause}
          className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
        >
          {isRunning ? <Pause size={20} /> : <Play size={20} />}
          {isRunning ? 'Pause' : 'Start'}
        </button>
        
        <button
          onClick={handleReset}
          className="flex items-center gap-2 bg-gray-500 hover:bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
        >
          <RotateCcw size={20} />
          Reset
        </button>
      </div>
      
      {/* Base Legend */}
      <div className="flex gap-6 mb-4">
        {Object.entries(baseColors).map(([base, color]) => (
          <div key={base} className="flex items-center gap-2">
            <div
              className="w-4 h-4 rounded-full border-2 border-white"
              style={{ backgroundColor: color }}
            />
            <span className="text-sm font-medium text-gray-700">
              {base} - {base === 'A' ? 'Adenine' : base === 'T' ? 'Thymine' : base === 'G' ? 'Guanine' : 'Cytosine'}
            </span>
          </div>
        ))}
      </div>
      
      {/* Selected Base Info */}
      {selectedBase && (
        <div className="bg-gray-50 rounded-lg p-4 border-2 border-blue-200">
          <div className="text-center">
            <div className="text-lg font-bold text-gray-800 mb-1">
              Position {selectedBase.index + 1}
            </div>
            <div className="flex items-center justify-center gap-4">
              <div className="flex items-center gap-2">
                <div
                  className="w-6 h-6 rounded-full border-2 border-white"
                  style={{ backgroundColor: baseColors[selectedBase.base] }}
                />
                <span className="font-semibold">{selectedBase.base}</span>
              </div>
              <span className="text-gray-500">↔</span>
              <div className="flex items-center gap-2">
                <div
                  className="w-6 h-6 rounded-full border-2 border-white"
                  style={{ backgroundColor: baseColors[basePairs[selectedBase.base]] }}
                />
                <span className="font-semibold">{basePairs[selectedBase.base]}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DNASequencingSimulator;
