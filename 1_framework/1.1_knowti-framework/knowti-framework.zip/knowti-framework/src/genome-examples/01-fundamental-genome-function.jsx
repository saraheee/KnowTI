import React, { useState, useEffect } from 'react';
import { User, Leaf, Zap } from 'lucide-react';

const GenomeOrganismTransformation = () => {
  const [selectedOrganism, setSelectedOrganism] = useState('human');
  const [transformationPhase, setTransformationPhase] = useState(0);
  const [animationActive, setAnimationActive] = useState(false);

  const organisms = {
    human: {
      name: 'Human',
      icon: User,
      color: '#3b82f6',
      genomeSize: '3.2 Billion',
      characteristics: [
        { trait: 'Brain', position: { x: 50, y: 20 }, delay: 0 },
        { trait: 'Heart', position: { x: 45, y: 35 }, delay: 0.3 },
        { trait: 'Lungs', position: { x: 55, y: 35 }, delay: 0.6 },
        { trait: 'Kidneys', position: { x: 40, y: 50 }, delay: 0.9 },
        { trait: 'Muscles', position: { x: 60, y: 50 }, delay: 1.2 }
      ],
      genomeParts: [
        { section: 'Neuronal', color: '#8b5cf6', active: true },
        { section: 'Cardiovascular', color: '#ef4444', active: true },
        { section: 'Respiratory', color: '#06b6d4', active: true },
        { section: 'Muscular', color: '#10b981', active: true }
      ]
    },
    plant: {
      name: 'Plant',
      icon: Leaf,
      color: '#10b981',
      genomeSize: '157 Million',
      characteristics: [
        { trait: 'Leaves', position: { x: 45, y: 15 }, delay: 0 },
        { trait: 'Stem', position: { x: 50, y: 40 }, delay: 0.4 },
        { trait: 'Roots', position: { x: 50, y: 65 }, delay: 0.8 },
        { trait: 'Chloroplasts', position: { x: 35, y: 25 }, delay: 1.2 },
        { trait: 'Cell Wall', position: { x: 65, y: 30 }, delay: 1.6 }
      ],
      genomeParts: [
        { section: 'Photosynthesis', color: '#22c55e', active: true },
        { section: 'Structural', color: '#8b5cf6', active: true },
        { section: 'Metabolic', color: '#f59e0b', active: true },
        { section: 'Reproductive', color: '#ec4899', active: true }
      ]
    },
    bacteria: {
      name: 'Bacterium',
      icon: Zap,
      color: '#f59e0b',
      genomeSize: '4.6 Million',
      characteristics: [
        { trait: 'Cell Wall', position: { x: 50, y: 30 }, delay: 0 },
        { trait: 'Flagellum', position: { x: 35, y: 45 }, delay: 0.3 },
        { trait: 'Ribosomes', position: { x: 50, y: 50 }, delay: 0.6 },
        { trait: 'Plasmid', position: { x: 65, y: 40 }, delay: 0.9 }
      ],
      genomeParts: [
        { section: 'Metabolic', color: '#f59e0b', active: true },
        { section: 'Mobility', color: '#06b6d4', active: true },
        { section: 'Reproductive', color: '#ec4899', active: true },
        { section: 'Resistance', color: '#ef4444', active: true }
      ]
    }
  };

  useEffect(() => {
    if (animationActive) {
      const interval = setInterval(() => {
        setTransformationPhase(prev => {
          if (prev >= 4) {
            setAnimationActive(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1500);
      return () => clearInterval(interval);
    }
  }, [animationActive]);

  const handleOrganismChange = (organismKey) => {
    if (organismKey !== selectedOrganism) {
      setSelectedOrganism(organismKey);
      setAnimationActive(true);
      setTransformationPhase(0);
    }
  };

  const currentOrganism = organisms[selectedOrganism];
  const Icon = currentOrganism.icon;

  const GenomeCore = () => (
    <div className={`
      relative w-32 h-32 rounded-full transition-all duration-1000
      ${transformationPhase >= 1 ? 'scale-110' : 'scale-100'}
    `}>
      {/* Outer Ring */}
      <div className={`
        absolute inset-0 rounded-full border-4 transition-all duration-1500
        ${transformationPhase >= 1 ? 'border-blue-400 shadow-lg shadow-blue-200' : 'border-gray-300'}
      `} />
      
      {/* Genome Segments */}
      <div className="absolute inset-2 rounded-full overflow-hidden">
        {currentOrganism.genomeParts.map((part, index) => (
          <div
            key={part.section}
            className={`
              absolute inset-0 transition-all duration-1500
              ${transformationPhase >= 2 ? 'opacity-100' : 'opacity-30'}
            `}
            style={{
              background: `conic-gradient(from ${index * 90}deg, ${part.color} 0deg, ${part.color} 90deg, transparent 90deg)`,
              transform: `rotate(${transformationPhase * 5}deg)`
            }}
          />
        ))}
      </div>
      
      {/* Central Core */}
      <div className={`
        absolute inset-8 rounded-full bg-white border-2 flex items-center justify-center
        transition-all duration-1500
        ${transformationPhase >= 1 ? 'border-blue-400 shadow-md' : 'border-gray-300'}
      `}>
        <div className="text-xs font-bold text-gray-600">GENOME</div>
      </div>
      
      {/* Pulsing Effect */}
      {transformationPhase >= 1 && (
        <div className="absolute inset-0 rounded-full border-2 border-blue-300 animate-ping opacity-20" />
      )}
    </div>
  );

  const InformationFlow = () => (
    <div className="relative w-full h-8">
      {transformationPhase >= 2 && (
        <>
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className={`
                absolute w-2 h-2 rounded-full transition-all duration-800
                ${i % 2 === 0 ? 'bg-blue-400' : 'bg-purple-400'}
              `}
              style={{
                left: `${20 + i * 10}%`,
                top: '50%',
                transform: 'translateY(-50%)',
                animation: `flow 3s ease-in-out infinite`,
                animationDelay: `${i * 0.2}s`
              }}
            />
          ))}
          <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 text-xs text-gray-500">
            Information flow
          </div>
        </>
      )}
    </div>
  );

  const OrganismVisualization = () => (
    <div className="relative w-80 h-60">
      {/* Base Shape */}
      <div className={`
        absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2
        w-32 h-32 rounded-full border-4 transition-all duration-1500
        ${transformationPhase >= 3 ? 'border-gray-400 bg-gray-50' : 'border-gray-200 bg-white'}
      `}>
        <Icon className={`
          w-16 h-16 absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2
          transition-all duration-1500
          ${transformationPhase >= 3 ? currentOrganism.color : '#d1d5db'}
        `} style={{ color: transformationPhase >= 3 ? currentOrganism.color : '#d1d5db' }} />
      </div>

      {/* Characteristic Traits */}
      {transformationPhase >= 4 && currentOrganism.characteristics.map((char, index) => (
        <div
          key={char.trait}
          className={`
            absolute bg-white rounded-lg shadow-md border-2 px-3 py-1 text-sm font-medium
            transition-all duration-800 transform
            ${transformationPhase >= 4 ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}
          `}
          style={{
            left: `${char.position.x}%`,
            top: `${char.position.y}%`,
            transform: 'translate(-50%, -50%)',
            borderColor: currentOrganism.color,
            animationDelay: `${char.delay}s`
          }}
        >
          {char.trait}
        </div>
      ))}

      {/* Connecting Lines */}
      {transformationPhase >= 4 && (
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          {currentOrganism.characteristics.map((char, index) => (
            <line
              key={index}
              x1="50%"
              y1="50%"
              x2={`${char.position.x}%`}
              y2={`${char.position.y}%`}
              stroke={currentOrganism.color}
              strokeWidth="1"
              strokeDasharray="3,3"
              opacity="0.5"
              className="animate-pulse"
            />
          ))}
        </svg>
      )}
    </div>
  );

  return (
    <div className="w-full h-full bg-white p-8 relative overflow-hidden">
      {/* Title */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">From Genome to Organism</h1>
        <p className="text-gray-600">How genetic information shapes life</p>
      </div>

      {/* Organism Selection */}
      <div className="flex justify-center gap-4 mb-8">
        {Object.entries(organisms).map(([key, organism]) => {
          const OrgIcon = organism.icon;
          return (
            <button
              key={key}
              onClick={() => handleOrganismChange(key)}
              className={`
                flex items-center gap-2 px-4 py-2 rounded-xl border-2 transition-all duration-300
                ${selectedOrganism === key 
                  ? 'border-blue-400 bg-blue-50 shadow-md' 
                  : 'border-gray-200 bg-white hover:border-gray-300'
                }
              `}
            >
              <OrgIcon className="w-5 h-5" style={{ color: organism.color }} />
              <span className="font-medium text-gray-700">{organism.name}</span>
            </button>
          );
        })}
      </div>

      {/* Main Transformation */}
      <div className="relative w-full h-96 bg-gradient-to-r from-blue-50 via-purple-50 to-green-50 rounded-2xl border-2 border-gray-200 overflow-hidden">
        
        {/* Transformation Phases */}
        <div className="absolute inset-0 flex items-center justify-between px-12">
          
          {/* Phase 1: Genome */}
          <div className="flex flex-col items-center">
            <h3 className="text-lg font-semibold text-gray-700 mb-4">Genetic Information</h3>
            <GenomeCore />
            <div className="mt-4 text-center">
              <p className="text-sm text-gray-600">{currentOrganism.genomeSize} Base Pairs</p>
              <p className="text-xs text-gray-500 mt-1">Complete Blueprint</p>
            </div>
          </div>

          {/* Information Flow */}
          <div className="flex-1 mx-8">
            <InformationFlow />
          </div>

          {/* Phase 2: Organism */}
          <div className="flex flex-col items-center">
            <h3 className="text-lg font-semibold text-gray-700 mb-4">Living Organism</h3>
            <OrganismVisualization />
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
          <div className="flex items-center gap-2 bg-white/90 backdrop-blur-sm rounded-lg px-4 py-2 shadow-md">
            {[1, 2, 3, 4].map((phase) => (
              <div
                key={phase}
                className={`
                  w-3 h-3 rounded-full transition-all duration-300
                  ${transformationPhase >= phase ? currentOrganism.color : '#e5e7eb'}
                `}
                style={{
                  backgroundColor: transformationPhase >= phase ? currentOrganism.color : '#e5e7eb'
                }}
              />
            ))}
            <span className="ml-2 text-sm text-gray-600">
              {transformationPhase === 0 && 'Genome ready'}
              {transformationPhase === 1 && 'Activation'}
              {transformationPhase === 2 && 'Information flow'}
              {transformationPhase === 3 && 'Base form forming'}
              {transformationPhase >= 4 && 'Organism complete'}
            </span>
          </div>
        </div>

        {/* Background Animation */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className={`
                absolute w-1 h-1 rounded-full transition-all duration-1500
                ${transformationPhase >= 2 ? 'bg-blue-300 opacity-60' : 'bg-gray-300 opacity-30'}
              `}
              style={{
                left: `${10 + i * 7}%`,
                top: `${20 + (i % 4) * 20}%`,
                animation: transformationPhase >= 2 ? `float 3s ease-in-out infinite` : 'none',
                animationDelay: `${i * 0.2}s`
              }}
            />
          ))}
        </div>
      </div>

      {/* Info Panel */}
      <div className="mt-6 text-center max-w-2xl mx-auto">
        <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
          <p className="text-gray-700 leading-relaxed">
            The genome is the complete set of genetic instructions of an organism. 
            This information determines all characteristic traits and functions – 
            from basic structure to specialized abilities.
          </p>
        </div>
      </div>

      <style>{`
        @keyframes flow {
          0% { transform: translateY(-50%) translateX(-10px); opacity: 0; }
          50% { opacity: 1; }
          100% { transform: translateY(-50%) translateX(10px); opacity: 0; }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-8px); }
        }
      `}</style>
    </div>
  );
};

export default GenomeOrganismTransformation;