import React, { useState } from 'react';

const ChromosomeViewer = () => {
  const [selectedPair, setSelectedPair] = useState(null);
  const [showSexChromosomes, setShowSexChromosomes] = useState(true);

  // Chromosome data (relative sizes)
  const chromosomeData = [
    { pair: 1, size: 100, genes: 4300 },
    { pair: 2, size: 95, genes: 4100 },
    { pair: 3, size: 78, genes: 3200 },
    { pair: 4, size: 75, genes: 2800 },
    { pair: 5, size: 71, genes: 2600 },
    { pair: 6, size: 67, genes: 2400 },
    { pair: 7, size: 62, genes: 2200 },
    { pair: 8, size: 57, genes: 2000 },
    { pair: 9, size: 54, genes: 1800 },
    { pair: 10, size: 52, genes: 1700 },
    { pair: 11, size: 53, genes: 1900 },
    { pair: 12, size: 51, genes: 1600 },
    { pair: 13, size: 45, genes: 1200 },
    { pair: 14, size: 42, genes: 1100 },
    { pair: 15, size: 40, genes: 1000 },
    { pair: 16, size: 35, genes: 1200 },
    { pair: 17, size: 32, genes: 1500 },
    { pair: 18, size: 30, genes: 800 },
    { pair: 19, size: 23, genes: 1700 },
    { pair: 20, size: 25, genes: 900 },
    { pair: 21, size: 18, genes: 400 },
    { pair: 22, size: 20, genes: 700 }
  ];

  const Chromosome = ({ size, isSelected, onClick, label, isHomolog = false }) => (
    <div
      className={`relative cursor-pointer transition-all duration-300 ${
        isSelected ? 'scale-110 z-10' : 'hover:scale-105'
      }`}
      onClick={onClick}
      style={{ height: `${size * 1.2}px`, width: '12px' }}
    >
      <div
        className={`w-full h-full rounded-sm border-2 transition-colors duration-300 ${
          isSelected 
            ? 'bg-blue-500 border-blue-600' 
            : isHomolog 
              ? 'bg-purple-400 border-purple-500 hover:bg-purple-500' 
              : 'bg-gray-400 border-gray-500 hover:bg-gray-500'
        }`}
      >
        {/* Centromere */}
        <div 
          className="absolute w-full h-1 bg-red-500 rounded-full"
          style={{ top: `${size * 0.4}px` }}
        />
        {/* Band pattern */}
        {[...Array(3)].map((_, i) => (
          <div
            key={i}
            className="absolute w-full h-0.5 bg-black opacity-20"
            style={{ top: `${(i + 1) * (size * 0.2)}px` }}
          />
        ))}
      </div>
      <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs font-medium text-gray-700">
        {label}
      </div>
    </div>
  );

  const SexChromosome = ({ type, isSelected, onClick }) => (
    <div
      className={`relative cursor-pointer transition-all duration-300 ${
        isSelected ? 'scale-110 z-10' : 'hover:scale-105'
      }`}
      onClick={onClick}
      style={{ 
        height: type === 'X' ? '60px' : '30px', 
        width: '12px' 
      }}
    >
      <div
        className={`w-full h-full rounded-sm border-2 transition-colors duration-300 ${
          isSelected 
            ? 'bg-pink-500 border-pink-600' 
            : type === 'X' 
              ? 'bg-pink-400 border-pink-500 hover:bg-pink-500' 
              : 'bg-blue-400 border-blue-500 hover:bg-blue-500'
        }`}
      >
        <div 
          className="absolute w-full h-1 bg-red-500 rounded-full"
          style={{ top: type === 'X' ? '24px' : '12px' }}
        />
      </div>
      <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs font-bold text-gray-700">
        {type}
      </div>
    </div>
  );

  return (
    <div className="w-full h-full bg-white p-8 overflow-auto">
      {/* Header */}
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">
          Human Chromosomes 
        </h1>
        <div className="flex justify-center items-center gap-6 text-sm text-gray-600">
          <span className="bg-blue-100 px-3 py-1 rounded-full">
            46 chromosomes
          </span>
          <span className="bg-purple-100 px-3 py-1 rounded-full">
            23 pairs
          </span>
          <div className="flex gap-1">
            <button
              onClick={() => setShowSexChromosomes(true)}
              className={`px-3 py-1 rounded-full transition-colors ${
                showSexChromosomes 
                  ? 'bg-blue-500 text-white shadow-md' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              ♂ Male (XY)
            </button>
            <button
              onClick={() => setShowSexChromosomes(false)}
              className={`px-3 py-1 rounded-full transition-colors ${
                !showSexChromosomes 
                  ? 'bg-pink-500 text-white shadow-md' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              ♀ Female (XX)
            </button>
          </div>
        </div>
      </div>

      {/* Karyotype Grid */}
      <div className="grid grid-cols-6 gap-8 justify-center max-w-4xl mx-auto mb-8">
        {chromosomeData.map((chr) => (
          <div key={chr.pair} className="flex justify-center items-end gap-2">
            {/* Homologous pair */}
            <Chromosome
              size={chr.size}
              isSelected={selectedPair === chr.pair}
              onClick={() => setSelectedPair(selectedPair === chr.pair ? null : chr.pair)}
              label={chr.pair.toString()}
            />
            <Chromosome
              size={chr.size}
              isSelected={selectedPair === chr.pair}
              onClick={() => setSelectedPair(selectedPair === chr.pair ? null : chr.pair)}
              label=""
              isHomolog={true}
            />
          </div>
        ))}
        
        {/* Sex chromosomes */}
        <div className="flex justify-center items-end gap-2 relative">
          <SexChromosome
            type="X"
            isSelected={selectedPair === 'sex'}
            onClick={() => setSelectedPair(selectedPair === 'sex' ? null : 'sex')}
          />
          <SexChromosome
            type={showSexChromosomes ? 'Y' : 'X'}
            isSelected={selectedPair === 'sex'}
            onClick={() => setSelectedPair(selectedPair === 'sex' ? null : 'sex')}
          />
          <div className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 text-xs font-medium text-gray-700">
            23
          </div>
        </div>
      </div>

      {/* Info Panel */}
      {selectedPair && (
        <div className="bg-gray-50 rounded-lg p-6 max-w-2xl mx-auto">
          {selectedPair === 'sex' ? (
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-3">
                Sex Chromosomes
              </h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium text-pink-600">X chromosome:</span>
                  <p className="text-gray-700">Larger, ~1100 genes</p>
                </div>
                <div>
                  <span className="font-medium text-blue-600">Y chromosome:</span>
                  <p className="text-gray-700">Smaller, ~200 genes</p>
                </div>
              </div>
            </div>
          ) : (
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-3">
                Chromosome Pair {selectedPair}
              </h3>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="font-medium text-blue-600">Size:</span>
                  <p className="text-gray-700">Rank {selectedPair} of 23</p>
                </div>
                <div>
                  <span className="font-medium text-purple-600">Genes:</span>
                  <p className="text-gray-700">~{chromosomeData[selectedPair - 1]?.genes}</p>
                </div>
                <div>
                  <span className="font-medium text-gray-600">Homolog:</span>
                  <p className="text-gray-700">2 copies</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Legend */}
      <div className="mt-8 flex justify-center">
        <div className="bg-gray-50 rounded-lg p-4 flex gap-6 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-8 bg-gray-400 rounded-sm"></div>
            <span>Chromosome</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-8 bg-purple-400 rounded-sm"></div>
            <span>Homolog</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-1 bg-red-500 rounded-full"></div>
            <span>Centromere</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChromosomeViewer;
