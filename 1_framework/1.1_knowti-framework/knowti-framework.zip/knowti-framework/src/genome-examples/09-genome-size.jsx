import React, { useState, useEffect } from 'react';

const DNABasePairsVisual = () => {
  const [zoom, setZoom] = useState(1);
  const [selectedLevel, setSelectedLevel] = useState('individual');
  const [animating, setAnimating] = useState(false);

  const formatBasePairs = (bp) => {
    if (bp >= 1e9) return `${(bp / 1e9).toFixed(1)} Gbp`;
    if (bp >= 1e6) return `${(bp / 1e6).toFixed(1)} Mbp`;
    if (bp >= 1e3) return `${(bp / 1e3).toFixed(1)} kbp`;
    return `${bp} bp`;
  };

  const levels = {
    individual: { 
      scale: 1, 
      label: 'Individual Base Pairs', 
      count: 20,
      example: 'DNA Building Blocks',
      description: 'One base pair = 1 unit of information'
    },
    hundreds: { 
      scale: 100, 
      label: 'Hundreds of bp', 
      count: 1400,
      example: 'Insulin Gene (~1.4k bp)',
      description: 'Size of a single gene'
    },
    thousands: { 
      scale: 1000, 
      label: 'Thousands of bp', 
      count: 9000,
      example: 'HIV Virus (~9k bp)',
      description: 'Complete viral genome'
    },
    millions: { 
      scale: 1000000, 
      label: 'Millions of bp', 
      count: 4600000,
      example: 'E. coli Bacterium (~4.6M bp)',
      description: 'Complete bacterial genome'
    }
  };

  const bases = ['A', 'T', 'G', 'C'];
  const baseColors = {
    'A': '#FF6B6B', 'T': '#4ECDC4', 
    'G': '#45B7D1', 'C': '#96CEB4'
  };

  const generateBasePairs = (count) => {
    return Array.from({ length: count }, (_, i) => ({
      id: i,
      base1: bases[Math.floor(Math.random() * 4)],
      base2: bases[Math.floor(Math.random() * 4)]
    }));
  };

  const [basePairs, setBasePairs] = useState(generateBasePairs(levels.individual.count));

  useEffect(() => {
    setAnimating(true);
    setTimeout(() => {
      setBasePairs(generateBasePairs(levels[selectedLevel].count));
      setAnimating(false);
    }, 300);
  }, [selectedLevel]);

  const formatNumber = (num) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  return (
    <div className="w-full h-full bg-white p-8 font-sans overflow-hidden">
      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Genome Size</h1>
        <p className="text-gray-600">Number of base pairs in a cell</p>
        <p className="text-sm text-gray-500 mt-1">Genome size = total DNA content of an organism</p>
      </div>

      {/* Controls */}
      <div className="flex justify-center space-x-4 mb-6">
        {Object.entries(levels).map(([key, level]) => (
          <button
            key={key}
            onClick={() => setSelectedLevel(key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              selectedLevel === key
                ? 'bg-blue-500 text-white shadow-lg'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {level.label}
          </button>
        ))}
      </div>

      {/* DNA Visualization */}
      <div className="relative bg-gray-50 rounded-xl p-6 mb-6 h-80 overflow-hidden">
        <div className={`transition-opacity duration-300 ${animating ? 'opacity-0' : 'opacity-100'}`}>
          {selectedLevel === 'individual' && (
            <div className="flex flex-wrap gap-1 justify-center">
              {basePairs.slice(0, 20).map((pair) => (
                <div key={pair.id} className="relative group">
                  <div className="flex flex-col items-center">
                    <div 
                      className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
                      style={{ backgroundColor: baseColors[pair.base1] }}
                    >
                      {pair.base1}
                    </div>
                    <div className="w-0.5 h-4 bg-gray-400"></div>
                    <div 
                      className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
                      style={{ backgroundColor: baseColors[pair.base2] }}
                    >
                      {pair.base2}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {selectedLevel === 'hundreds' && (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                {/* Gene visualization */}
                <div className="flex items-center justify-center mb-4">
                  <div className="bg-green-500 h-8 w-32 rounded-lg flex items-center justify-center shadow-lg">
                    <span className="text-white text-sm font-bold">Insulin Gene</span>
                  </div>
                </div>
                <div className="text-lg font-semibold text-gray-700 mb-1">
                  ~1.4k base pairs
                </div>
                <p className="text-gray-600 text-sm max-w-xs mx-auto">
                  A single gene codes for a protein
                </p>
              </div>
            </div>
          )}

          {selectedLevel === 'thousands' && (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                {/* Virus visualization */}
                <div className="relative mb-4">
                  <div className="w-24 h-24 rounded-full bg-red-500 flex items-center justify-center shadow-lg mx-auto">
                    <div className="w-16 h-16 rounded-full border-2 border-white flex items-center justify-center">
                      <span className="text-white text-xs font-bold">HIV</span>
                    </div>
                  </div>
                  <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-red-100 rounded-full px-3 py-1">
                    <span className="text-red-700 text-xs font-medium">~9k bp</span>
                  </div>
                </div>
                <div className="text-lg font-semibold text-gray-700 mb-1">
                  Viral Genome
                </div>
                <p className="text-gray-600 text-sm max-w-xs mx-auto">
                  Complete hereditary information of a virus
                </p>
              </div>
            </div>
          )}

          {selectedLevel === 'millions' && (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                {/* Bacteria visualization */}
                <div className="relative mb-4">
                  <div className="w-32 h-20 bg-blue-500 rounded-full flex items-center justify-center shadow-lg mx-auto relative overflow-hidden">
                    <div className="absolute inset-2 border border-blue-200 rounded-full opacity-50"></div>
                    <div className="w-4 h-4 bg-blue-200 rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
                    <span className="text-white text-sm font-bold relative z-10">E. coli</span>
                  </div>
                  <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-blue-100 rounded-full px-3 py-1">
                    <span className="text-blue-700 text-xs font-medium">~4.6M bp</span>
                  </div>
                </div>
                <div className="text-lg font-semibold text-gray-700 mb-1">
                  Bacterial Genome
                </div>
                <p className="text-gray-600 text-sm max-w-xs mx-auto">
                  Complete DNA of a bacterium
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Info Panel */}
      <div className="bg-blue-50 rounded-xl p-6">
        <div className="text-center mb-4">
          <h3 className="text-lg font-semibold text-gray-800">
            {levels[selectedLevel].example}
          </h3>
          <p className="text-sm text-gray-600 mt-1">
            {levels[selectedLevel].description}
          </p>
        </div>
        
        <div className="grid grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-xl font-bold text-blue-600">
              {levels[selectedLevel].count.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Base Pairs</div>
          </div>
          <div>
            <div className="text-xl font-bold text-green-600">
              {(levels[selectedLevel].count * 2).toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Individual Bases</div>
          </div>
          <div>
            <div className="text-xl font-bold text-purple-600">
              1 Cell
            </div>
            <div className="text-sm text-gray-600">Contains this DNA</div>
          </div>
          <div>
            <div className="text-xl font-bold text-orange-600">
              {formatBasePairs(levels[selectedLevel].count)}
            </div>
            <div className="text-sm text-gray-600">Size Unit</div>
          </div>
        </div>
      </div>

      {/* Base Legend */}
      <div className="flex justify-center space-x-6 mt-4">
        {Object.entries(baseColors).map(([base, color]) => (
          <div key={base} className="flex items-center space-x-2">
            <div 
              className="w-4 h-4 rounded-full"
              style={{ backgroundColor: color }}
            ></div>
            <span className="text-sm text-gray-600">{base}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DNABasePairsVisual;
