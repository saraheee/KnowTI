Getting started:

------------------------------------------------
To run the framework:

1.) Install Node.js [version used: v22.15.1]
https://nodejs.org/en/download

2.) Place the videos in the `src` folder
We used the files `eukaryotes.mp4` and `genome.mp4` from `Studyflix.de` and provided two placeholder files there. Replace them with the actual videos.

3.) Install project dependencies with the following command:
npm install

4.) Run the application on the development server:
npm run dev


##########################################
To test different examples:

1.) Run the prompt files provided to generated the json file needed

2.) Place the json file in the `public` folder, the video file in the `src` folder, and the example components generated in an subfolder inside the `src` folder

3.) Update the file paths in `src/App.jsx` for the video file and json; and in `index.js` for the new folder with the example components

4.) install and tun the application as above with the following commands:
npm install
npm run dev